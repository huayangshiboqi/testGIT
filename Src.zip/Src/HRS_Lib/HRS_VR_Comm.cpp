

#include "NG.h"
#include "NG_SimpleTypes.h"
#include "MP_FindPackMgr.h"
#include "MP_Comm.h"

#include "HRS_VR_Pack.h"
#include "HRS_VR_Comm.h"

#define HRS_COMM_TOVR_RECV_BUF_LEN          4096


HRS_COMM_PACK_INFO *HRS_Comm_PackInfo_Create(void *pData, int nDataLen)
{
    char *pszData = NULL;

    if (NULL == pData || nDataLen <= 0)
    {
        return NULL;
    }

    int nLen = sizeof(HRS_COMM_PACK_INFO) + nDataLen + 16;

    HRS_COMM_PACK_INFO *pPackData = (HRS_COMM_PACK_INFO *)NG_malloc(nLen);
    if (NULL == pPackData)
    {
        return NULL;
    }

    pPackData->nTunnelNo = -1;
    pPackData->nPackLen      = nDataLen;
    pPackData->pPackData     = pPackData + sizeof(HRS_COMM_PACK_INFO);

    memcpy(pPackData->pPackData, pData, nDataLen);

    pszData = (char *)pPackData->pPackData;
    pszData[nDataLen] = '\0';

    return pPackData;
}


void HRS_Comm_PackInfo_Destory(HRS_COMM_PACK_INFO *pData)
{
    if (NULL == pData)
    {
        return;
    }

    NG_free(pData);

    return;
}

void HRS_Comm_Msg_Destory(void *pData)
{
    HRS_Comm_PackInfo_Destory((HRS_COMM_PACK_INFO *)pData);
}


/** Method:    HRS_Comm_VR_Recv_Thread_Func
    ��VR���������̺߳���

    @param: void * pData - ͨ�Ų���

    @return: void * - �̺߳�������ֵΪNULL
*/
void *HRS_Comm_VR_Recv_Thread_Func(void *pData)
{
    HRS_COMM_VR_INFO *pCommInfo = (HRS_COMM_VR_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    int             nRet        = 0;
    UINT            uExitFlag   = -1;
    char            szBuf[HRS_COMM_TOVR_RECV_BUF_LEN];

    int                 nTunnelNo      = HRS_ROLL_INFO_PACK;
    HRS_COMM_PACK_INFO  *pCommRecvPack = NULL;
    HRS_PACK_HEAD       *pVRHead       = NULL;

    MTask_EnterTask(pCommInfo->pMTask);
    for (;;)
    {
        uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
        if (MTASK_EXIT == uExitFlag)
        {
            break;
        }

        for ( nTunnelNo = HRS_ROLL_INFO_PACK; 
              nTunnelNo < HRS_VR_ACTION_PACK; 
              nTunnelNo++)
        {
            //��VR��������
            nRet = MP_Comm_RecvNoBlock(pCommInfo->hComm, 
                                       nTunnelNo, 
                                       szBuf, 
                                       HRS_COMM_TOVR_RECV_BUF_LEN-1);

            if ( nRet > 0 )
            {
                if (NULL == pCommRecvPack)
                {
                   pCommRecvPack = HRS_Comm_PackInfo_Create(szBuf, nRet);
                   if (NULL == pCommRecvPack)
                   {
                       printf("��������ģ�鴴��ʧ�ܣ�\n\n"); 
                       continue;
                   }
                }

                pCommRecvPack->nTunnelNo = nTunnelNo;

                MsgQueue_SendNoBlock(pCommInfo->pRecvMsgQue, pCommRecvPack);

                pCommRecvPack = NULL;

                printf("���ݽ��� �ɹ���\n\n\n");
            }
            else
            {
                printf("���ݽ��� ʧ�ܣ�nTunnelNo =  %d\n\n\n", nTunnelNo);
            }
        }
    }

    if (NULL != pCommRecvPack)
    {
        HRS_Comm_PackInfo_Destory(pCommRecvPack);
    }

    pCommRecvPack = NULL;

    MTask_LeaveTask(pCommInfo->pMTask);
    return NULL;
}


/** Method:    HRS_Comm_VR_Send_Thread_Func
    �����ݷ��͵�VR�̺߳���

    @param: void * pData - ͨ�Ų���

    @return: void * - �̺߳�������ֵΪNULL
*/
void *HRS_Comm_VR_Send_Thread_Func(void *pData)
{
    HRS_COMM_VR_INFO *pCommInfo = (HRS_COMM_VR_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    int             nRet = 0;
    UINT            uExitFlag = -1;

    HRS_COMM_PACK_INFO  *pCommSendPack = NULL;
    char                szBuf[HRS_COMM_TOVR_RECV_BUF_LEN];

    MTask_EnterTask(pCommInfo->pMTask);
    for (;;)
    {
        uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
        if (MTASK_EXIT == uExitFlag)
        {
            break;
        }

        //�ӷ�������������      
        pCommSendPack = 
        (HRS_COMM_PACK_INFO *)MsgQueue_TimeOut_Recv(pCommInfo->pSendMsgQue, 100); 

        //��������, ERR_SUCCESS��ʾ�ɹ���������ʾʧ��
        nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                                   pCommSendPack->nTunnelNo,
                                   pCommSendPack->pPackData, 
                                   pCommSendPack->nPackLen);

        if (ERR_SUCCESS == nRet)
        {
#if _DEBUG
            printf("���ݷ��͵�VR��\n\n\n");
#endif
        }

         HRS_Comm_PackInfo_Destory(pCommSendPack);
    }

    MTask_LeaveTask(pCommInfo->pMTask);
    return NULL;
}


/** Method:    HRS_Comm_VR_Thread
    ͨ���̣߳��շ�VR������

    @param: HRS_COMM_VR_INFO * pCommInfo - ͨ�Ų���

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_Comm_VR_Thread(HRS_COMM_VR_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ERR_FAILED;
    }

    // �����������ݴ����߳�
    pCommInfo->hRecvThread = NG_CreateThread(HRS_Comm_VR_Recv_Thread_Func, 
                                             pCommInfo, 
                                             NGTHREAD_RUNNING);

    pCommInfo->hSendThread = NULL;
    // �����������ݴ����߳�
    pCommInfo->hSendThread = NG_CreateThread(HRS_Comm_VR_Send_Thread_Func, 
                                             pCommInfo,
                                             NGTHREAD_RUNNING);

    if ((NULL == pCommInfo->hSendThread) ||
        (NULL == pCommInfo->hRecvThread))
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_Comm_VR_Create
    ��VRͨ���̵߳Ĵ��� 

    @param: char * pszTunnelCfg - ͨ�������ļ�

    @return: HRS_COMM_VR_INFO * - ͨ����Ϣ
*/
HRS_COMM_VR_INFO *HRS_Comm_VR_Create(char *pszTunnelCfg)
{
    int      i;
    STR2  HRS_FindPack_Funcs[] = {

        { "HRS_1", (char *)HRS_FindPack_Roll_Info },
        { "HRS_2", (char *)HRS_FindPack_VR_Operation },

        { NULL, NULL }
    };

    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_VR_INFO *pCommInfo = 
                       (HRS_COMM_VR_INFO *)NG_malloc(sizeof(HRS_COMM_VR_INFO));
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    i = 0;
    for ( ;; )
    {
        if (HRS_FindPack_Funcs[i].ppsz[0] == NULL)
        {
            break;
        }

        //
        // ע�����ص�����
        //
        MP_FindPackMgr_RegisterPackFunc(HRS_FindPack_Funcs[i].ppsz[0], 
                              (RW_FIND_PACK_FUNC)HRS_FindPack_Funcs[i].ppsz[1]);

        i += 1;
    }

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(100);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);

    // �������ݽ��ն���
    pCommInfo->pRecvMsgQue = MsgQueue_Create(nMsgBuffLen);


    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    HRS_Comm_VR_Thread(pCommInfo);

    return pCommInfo;
}


void HRS_Comm_VR_Destory(HRS_COMM_VR_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ;
    }

    // ���ٿͻ���ͨ�ž��
    if (NULL != pCommInfo->hComm)
    {
        NG_CloseHandle(pCommInfo->hComm);
    }

    // �������ݷ��Ͷ���
    if (NULL != pCommInfo->pSendMsgQue)
    {
        MsgQueue_Destroy(pCommInfo->pSendMsgQue, HRS_Comm_Msg_Destory);
    }

    // �������ݽ��ն���
    if (NULL != pCommInfo->pRecvMsgQue)
    {
        MsgQueue_Destroy(pCommInfo->pRecvMsgQue, HRS_Comm_Msg_Destory);
        pCommInfo->pRecvMsgQue = NULL;
    }    

    // ���ٶ�����ģ��
    if (NULL != pCommInfo->pMTask)
    {
        MTask_Destroy(pCommInfo->pMTask);
    }

    // �������ݷ��;��
    if (NULL != pCommInfo->hSendThread)
    {
        NG_CloseHandle(pCommInfo->hSendThread);
    }

    // �������ݽ��վ��
    if (NULL != pCommInfo->hRecvThread)
    {
        NG_CloseHandle(pCommInfo->hRecvThread);
    }

    NG_free(pCommInfo);
}
