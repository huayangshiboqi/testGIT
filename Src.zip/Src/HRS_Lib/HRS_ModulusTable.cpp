#include "NG.h"
#include "HRS_ModulusTable.h"

HRS_MODULUS_RATIO   g_aModulusRatio[] = {
    {HRS_STAND_NO_RM1, 0,             0,              696.5740234},
    {HRS_STAND_NO_RM2, 0.075248031,   0.081743482,    486.0746013},
    {HRS_STAND_NO_FM1, 0.012499571,   0.063482588,    594.6454781},
    {HRS_STAND_NO_FM2, 0.10519591,    0.055028105,    478.000196 },
    {HRS_STAND_NO_FM3, 0.012203414,   0.062242435,    540.0681699},
    {HRS_STAND_NO_FM4, 0.06897101,    0.061120112,    526.7469246},
    {HRS_STAND_NO_FM5, 0.158585939,   0.037875511,    350.3019622},
    {HRS_STAND_NO_FM6, 0.143372861,   0.043900437,    389.501418 },
    {HRS_STAND_NO_FM7, 0.177115342,   0.040281602,    339.8937158},

    {   -1, -1, -1, -1 }
};



/** Method:    HRS_GetModulusRatio
    ��ȡĳ�����ܵĸնȼ���ϵ�� 

    @param HRS_STAND_NO_EM nStandNo - ���ܺ�
    
    @return HRS_MODULUS_RATIO * - ʧ�ܷ���NULL, 
                                  �ɹ����ذ����նȼ���ϵ���Ľṹ��ָ��
*/
HRS_MODULUS_RATIO *HRS_GetModulusRatio(HRS_STAND_NO_EM  nStandNo)
{
    int i;

    HRS_MODULUS_RATIO  *pModulusRatio;

    i = 0;
    pModulusRatio = NULL;

    for (;;) 
    {
        if (g_aModulusRatio[i].nStandNo < 0)
        {
            break;
        }

        pModulusRatio = &(g_aModulusRatio[i]);

        if (pModulusRatio->nStandNo == nStandNo)
        {
            return pModulusRatio;
        }

        i += 1;
    }

    return pModulusRatio;
}



/** Method:    HRS_CalcModulus
    ������ܵĸն�ϵ�� 

    @param HRS_STAND_NO_EM nStandNo - ���ܺ�
    @param double dRollForce - ������
    @param double dWidth - ����
    @param double * pdModulus - [out] �ն�ϵ��
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_CalcModulus(HRS_STAND_NO_EM nStandNo, double dRollForce, 
                    double dWidth,
                    double *pdModulus)
{
    HRS_MODULUS_RATIO  *pRatio;
    double dModulus;

    pRatio = HRS_GetModulusRatio(nStandNo);

    if (pRatio == NULL)
    {
        return ERR_FAILED;
    }

    dModulus = pRatio->dRollForceRatio * dRollForce;
    dModulus += pRatio->dWidthRatio * dWidth;
    dModulus += pRatio->dConst;

    *pdModulus = dModulus;

    return ERR_SUCCESS;
}
