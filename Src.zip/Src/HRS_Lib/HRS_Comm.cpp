

#include "NG.h"
#include "NG_SimpleTypes.h"
#include "MP_FindPackMgr.h"
#include "MP_Comm.h"

#include "HRS_VR_Pack.h"
#include "HRS_Comm.h"
#include "NG_CheckSum.h"
#include "HRS_CalcData.h"

#define HRS_COMM_TOVR_RECV_BUF_LEN          4096 * 16
#define HRS_SERVER_IBA_COMM_CFG        "HRSServerIBAComm.cfg"


/** Method: HRS_Protocol_FindPack
    HRS��VR֮���ͨ��Э��Ĳ�����ұ��Ļص����������� RW_PACK_BUF_MGR �Ļص�����

    @param: void * pPackBufMgr - ���������������ָ��
    @param: int * pnPackLen - [out] ���ĳ��ȣ���������ͷ�����ݵ��ܳ���
    @param: int * pnRestLen - [out] �ӱ���ͷFlag��ʼ�������ݳ��ȣ�
                                    ����С��pnPackLen, ��Ϊ���Ŀ���δ��ȫ

    @return: int - ERR_FAILED,��ʾδ���ֱ��ı�־��
                   ��ʱpnPackLenΪ0, pnRestLenΪ-1
                   ERR_SUCCESS,��ʾ�����˱��ı�־��
                   ��ʱ�������п�����һ�����ĵ����ݣ�
                   Ҳ���ܲ���һ�����ĳ��ȵ����ݣ�Ҳ���ܳ���һ�����ĵ�����
*/
int HRS_Protocol_FindPack_Org(void *pPackBufMgr, int *pnPackLen, int *pnRestLen, 
                              uint16 usGramId, uint16 usLen)
{
    RW_PACK_BUF_MGR  *pMgr  = NULL;
    HRS_PACK_HEAD    *pHead = NULL;

    char    *psz        = NULL;
    int     nLen        = -1;
    int     nStartPos   = -1;
    DWORD   dwCheckSum  = -1;

    *pnPackLen = 0;

    if (NULL == pPackBufMgr)
    {
        *pnRestLen = -1;
        return ERR_FAILED;
    }

    pMgr = (RW_PACK_BUF_MGR *)pPackBufMgr;

    if ( pMgr->nDataLen < sizeof(HRS_PACK_HEAD) )
    {
        *pnRestLen = -1;
        return ERR_FAILED;
    }

    nLen = 0;
    nStartPos = -1;

    psz = ( char * )pMgr->pszBuf;

    while ( nLen <= (int)(pMgr->nDataLen - sizeof(HRS_PACK_HEAD)) )
    {
        pHead = (HRS_PACK_HEAD *)psz;

        if ( usGramId == pHead->sTelID 
            && usLen == pHead->sTelDataLength )
        {
            // �ҵ��˱��ı�־

            // ����У���
            dwCheckSum = GetByteCheckSum(psz, sizeof(HRS_PACK_HEAD) - sizeof(uint16));

            if ( pHead->sHeaderSun != (uint16)dwCheckSum )
            {
                printf("error! dwCheckSum!\n");
                // ���Ǳ��ģ���Ҫ���²���
                psz++;
                nLen += 1;

                continue;
            }
            else
            {
                // �Ǳ���ͷ
                nStartPos = nLen;
                *pnPackLen = pHead->sTelDataLength;
                break;
            }
        }
        else
        {
            // δ�ҵ���־������ѭ�����в���
            psz++;
            nLen += 1;
        }
    }

    *pnRestLen = pMgr->nDataLen - nLen;

    if ( nStartPos < 0 )
    {
        // δ�ҵ�����ͷ
        return ERR_FAILED;
    }
    else
    {
        return ERR_SUCCESS;
    }
}


/** Method:    HRS_FindPack_Roll_Info
    ����VR����ʵ���Ĳ������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��
    
    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_Roll_Info(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    return HRS_Protocol_FindPack_Org(pPackBufMgr,
                                     pnPackLen,
                                     pnRestLen, 
                                     HRS_ROLL_INFO_ID,
                                     HRS_ROLL_INFO_LEN);
}


/** Method:    HRS_FindPack_VR_Operation
    ����VR��������Ĳ������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��
    
    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_VR_Operation(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    return HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                     pnPackLen, 
                                     pnRestLen, 
                                     HRS_VR_OPERATION_ID,
                                     HRS_VR_OPERATION_LEN);
}


/** Method:    HRS_FindPack_RM_Star
    GUI����Server��RM��������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_RM_Star(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                 pnPackLen, 
                                                 pnRestLen, 
                                                 HRS_DATA_TYPE_ONLY_RM_PACK,
                                                 sizeof(HRS_RM_DATA_FROM_GUI)))
    {

        return ERR_SUCCESS;
    }
    else if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                      pnPackLen, 
                                                      pnRestLen, 
                                                      HRS_DATA_TYPE_RM_FM_PACK,
                                                      sizeof(HRS_RM_DATA_FROM_GUI)))
    {
        return ERR_SUCCESS;
    }
    else
    {
        return ERR_FAILED;
    }

}


/** Method:    HRS_FindPack_FM_Star
    GUI����Server��FM��������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_FM_Star(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                 pnPackLen, 
                                                 pnRestLen, 
                                                 HRS_DATA_TYPE_ONLY_FM_PACK,
                                                 sizeof(HRS_RM_DATA_FROM_GUI)))
    {

        return ERR_SUCCESS;
    }
    else if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                      pnPackLen, 
                                                      pnRestLen, 
                                                      HRS_DATA_TYPE_RM_FM_PACK,
                                                      sizeof(HRS_RM_DATA_FROM_GUI)))
    {
        return ERR_SUCCESS;
    }
    else
    {
        return ERR_FAILED;
    }

}


/** Method:    HRS_FindPack_FM_Sched
    GUI����Server��FM�������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_FM_Sched(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                pnPackLen, 
                                                pnRestLen, 
                                                HRS_DATA_TYPE_L1_SIMULATE,
                                                sizeof(HRS_L1_FM_SCHED)))
    {

        return ERR_SUCCESS;
    }
    else
    {
        return ERR_FAILED;
    }

}



/** Method:    HRS_FindPack_FM_Sched
    GUI����Server��RM�������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_RM_Sched(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    if (ERR_SUCCESS == HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                                pnPackLen, 
                                                pnRestLen, 
                                                HRS_DATA_TYPE_RM_SIMULATE,
                                                sizeof(HRS_L1_RM_SCHED)))
    {

        return ERR_SUCCESS;
    }
    else
    {
        return ERR_FAILED;
    }

}

/** Method:    HRS_FindPack_FM_Data
    L1���͵�Server������

    @param: void * pPackBufMgr - ������ָ��
    @param: int * pnPackLen - ���ݰ��ĳ���
    @param: int * pnRestLen - ���ݰ���ʣ�೤��

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_FindPack_FM_Data(void *pPackBufMgr, int *pnPackLen, int *pnRestLen)
{
    if (NULL == pPackBufMgr || NULL == pnPackLen || NULL == pnRestLen)
    {
        return ERR_FAILED;
    }

    return HRS_Protocol_FindPack_Org(pPackBufMgr, 
                                     pnPackLen, 
                                     pnRestLen, 
                                     HRS_FM_DATA_ID,
                                     HRS_FM_DATA_LEN);

}


int HRS_Comm_MsgQue_Empty(HRS_COMM_INFO *pCommInfo, int nTunnelNo, DESTROYFUNC DestroyFunc)
{
    if (NULL == pCommInfo || NULL == DestroyFunc || nTunnelNo < 0)
    {
        return ERR_FAILED;
    }

   MsgQueue_Empty(pCommInfo->pRecvMsgQue[nTunnelNo], DestroyFunc);

   return ERR_SUCCESS;
}


HRS_COMM_PACK_INFO *HRS_Comm_PackInfo_Create(void *pData, int nDataLen)
{
    char *pszData = NULL;

    if (NULL == pData || nDataLen <= 0)
    {
        return NULL;
    }

    int nLen = sizeof(HRS_COMM_PACK_INFO) + nDataLen + 64;

    HRS_COMM_PACK_INFO *pPackData = (HRS_COMM_PACK_INFO *)NG_malloc(nLen);
    if (NULL == pPackData)
    {
        return NULL;
    }

    pPackData->nTunnelNo = -1;
    pPackData->nPackLen      = nDataLen;
    pPackData->pPackData     = (char *)pPackData + sizeof(HRS_COMM_PACK_INFO);

    memcpy(pPackData->pPackData, pData, nDataLen);

    pszData = (char *)pPackData->pPackData;
    pszData[nDataLen] = '\0';

    return pPackData;
}


void HRS_Comm_PackInfo_Destory(void *pData)
{
    if (NULL == pData)
    {
        return;
    }

    NG_free(pData);

    return;
}


/** Method:    HRS_Comm_VR_Recv_Thread_Func
    ��VR���������̺߳���

    @param void * pData - ͨ�Ų���

    @return: void * - �̺߳�������ֵΪNULL
*/
void *HRS_Comm_Recv_Thread_Func(void *pData)
{
    HRS_COMM_INFO *pCommInfo = (HRS_COMM_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    error_log("HRSSendComm.log", "ͨ�Ž����̴߳�����\r\n");

    pCommInfo->nEndState = ERR_FAILED;
    pCommInfo->nPackNum  = 0;

    int             nRet        = 0;
    UINT            uExitFlag   = -1;
    char            szBuf[HRS_COMM_TOVR_RECV_BUF_LEN];

    int                 nTunnelNo      = 0;
    HRS_COMM_PACK_INFO  *pCommRecvPack = NULL;
    HRS_PACK_HEAD       *pVRHead       = NULL;

    int nPackNum = 0;

    MTask_EnterTask(pCommInfo->pMTask);

    if (HRS_VR_MODEL ==  pCommInfo->nCommModel)
    {
        for (;;)
        {
            uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
            if (MTASK_EXIT == uExitFlag)
            {
                error_log("HRSRecvComm.log", "VRͨ�Ž����߳��˳���\r\n");
                break;
            }

            for ( nTunnelNo = pCommInfo->nRecvThreadMin; 
                  nTunnelNo <= pCommInfo->nRecvThreadMax; 
                  nTunnelNo++)
            {
                //��VR��������
                nRet = MP_Comm_RecvNoBlock(pCommInfo->hComm, 
                                           nTunnelNo, 
                                           szBuf, 
                                           HRS_COMM_TOVR_RECV_BUF_LEN-1);

                if ( nRet > 0 )
                {
                    if (NULL == pCommRecvPack)
                    {
                        pCommRecvPack = HRS_Comm_PackInfo_Create(szBuf, nRet);
                        if (NULL == pCommRecvPack)
                        {
                            continue;
                        }
                    }

                    pCommRecvPack->nTunnelNo = nTunnelNo;

                    MsgQueue_SendNoBlock(pCommInfo->pRecvMsgQue[nTunnelNo],
                                         pCommRecvPack);

                    pCommRecvPack = NULL;

                    //printf("���ݽ��� �ɹ���\n\n\n");
                }
                else
                {
                    //Sleep(1);
                    //printf("���ݽ��� ʧ�ܣ�nTunnelNo =  %d\n\n\n", nTunnelNo);
                }
            }

            Sleep(10);
        }
    }
    else
    {
        for (;;)
        {
            uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
            if (MTASK_EXIT == uExitFlag)
            {
                error_log("HRSRecvComm.log", "ͨ�Ž����߳��˳���\r\n");

                break;
            }

            nTunnelNo = 0;
            nRet = MP_Comm_RecvNoBlock(pCommInfo->hComm, 
                                       nTunnelNo, 
                                       szBuf, 
                                       HRS_COMM_TOVR_RECV_BUF_LEN-1);

            if ( nRet > 0)
            {
                if (1 == nRet  && szBuf[0] == 'E')
                {
                    continue;
                }

                if (NULL == pCommRecvPack)
                {
                    if (HRS_SERVER_L1_COMM_NO == pCommInfo->nCommNo)
                    {
                        HRS_FM_DATA *pData = (HRS_FM_DATA *)szBuf;

                        nPackNum ++;

                        if (0 == pData->PackHead.sTelDataLength)
                        {
                            printf("����L1���ݽ�����%d \n\n\n\n",nPackNum); 

                            pCommInfo->nEndState = ERR_SUCCESS;

                            memcpy(&pCommInfo->FMData, szBuf, nRet);

                            pCommInfo->nPackNum = pData->nLoopTimes + 1;

                            nPackNum = 0;

                            error_log("HRSRecvComm.log", "����L1���ݽ�����");
                        }

                        pCommRecvPack = HRS_Comm_PackInfo_Create(szBuf, nRet);
                        if (NULL == pCommRecvPack)
                        {
                            printf("��������ģ�鴴��ʧ�ܣ�\n\n"); 
                            continue;
                        }

                        pCommRecvPack->nTunnelNo = nTunnelNo;
                    }
                    else
                    {
                        pCommRecvPack = HRS_Comm_PackInfo_Create(szBuf, nRet);
                        if (NULL == pCommRecvPack)
                        {
                            printf("��������ģ�鴴��ʧ�ܣ�\n\n"); 
                            continue;
                        }

                        HRS_DATA_HEAD *pPackHead = (HRS_DATA_HEAD *)szBuf;

                        pCommRecvPack->nTunnelNo = pPackHead->nTunnelNo;

                        nTunnelNo = pPackHead->nTunnelNo;
                    }

                }
                MsgQueue_SendNoBlock(pCommInfo->pRecvMsgQue[nTunnelNo], pCommRecvPack);

                pCommRecvPack = NULL;
            }
            else
            {
                Sleep(1);
            }
        }
    }

    if (NULL != pCommRecvPack)
    {
        HRS_Comm_PackInfo_Destory(pCommRecvPack);
    }

    pCommRecvPack = NULL;

    MTask_LeaveTask(pCommInfo->pMTask);
    return NULL;
}


/** Method:    HRS_Comm_VR_Send_Thread_Func
    �����ݷ��͵�VR�̺߳���

    @param void * pData - ͨ�Ų���

    @return: void * - �̺߳�������ֵΪNULL
*/
void *HRS_Comm_Send_Thread_Func(void *pData)
{
    HRS_COMM_INFO *pCommInfo = (HRS_COMM_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    error_log("HRSSendComm.log", "ͨ�ŷ����̴߳�����\r\n");

    int             nRet = 0;
    UINT            uExitFlag = -1;

    int nDataNum = 0;

    HRS_COMM_PACK_INFO  *pCommSendPack = NULL;

    MTask_EnterTask(pCommInfo->pMTask);

    if (HRS_VR_MODEL ==  pCommInfo->nCommModel)
    {
        for (;;)
        {
            uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
            if (MTASK_EXIT == uExitFlag)
            {
                break;
            }

            //�ӷ�������������      
            pCommSendPack = 
                (HRS_COMM_PACK_INFO *)MsgQueue_TimeOut_Recv(pCommInfo->pSendMsgQue, 100); 
            if (NULL == pCommSendPack)
            {
                Sleep(1);
                continue;
            }
            //��������, ERR_SUCCESS��ʾ�ɹ���������ʾʧ��
            nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                pCommSendPack->nTunnelNo,
                pCommSendPack->pPackData, 
                pCommSendPack->nPackLen);

            if (ERR_SUCCESS == nRet && pCommSendPack->nTunnelNo == HRS_GUI_L1_FM_SCHED)
            {
                HRS_RM_SCHED *pRMSched = (HRS_RM_SCHED *)pCommSendPack->pPackData;
                HRS_L1_FM_SCHED *pFMSched = (HRS_L1_FM_SCHED *)pCommSendPack->pPackData;
                pRMSched = (HRS_RM_SCHED *)pCommSendPack->pPackData;
            }

            if (ERR_FAILED == nRet)
            {
                Sleep(1000);
                nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                    pCommSendPack->nTunnelNo,
                    pCommSendPack->pPackData, 
                    pCommSendPack->nPackLen);

                if (ERR_FAILED == nRet)
                {
                    Sleep(1000);

                    nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                        pCommSendPack->nTunnelNo,
                        pCommSendPack->pPackData, 
                        pCommSendPack->nPackLen);

                    if (ERR_FAILED == nRet)
                    {
                        error_log("HRSSendComm.log", "���ݷ��͵�ʧ�ܣ�\r\n");
                    }
                }
            }

            HRS_Comm_PackInfo_Destory(pCommSendPack);
        }
    }
    else
    {
        for (;;)
        {
            uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
            if (MTASK_EXIT == uExitFlag)
            {
                error_log("HRSSendComm.log", "ͨ�ŷ����˳���\r\n");

                break;
            }

            //�ӷ�������������      
            pCommSendPack = 
                (HRS_COMM_PACK_INFO *)MsgQueue_TimeOut_Recv(pCommInfo->pSendMsgQue, 100); 
            if (NULL == pCommSendPack)
            {
                Sleep(1);

                nDataNum++;

                if (nDataNum > 50)
                {
                    nDataNum = 0;

                    nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                        0,
                        "E", 
                        1);
                    if (ERR_FAILED == nRet)
                    {
                        error_log("HRSSendComm.log", "��������ʧ�ܣ�\r\n");
                    }
                }
                continue;
            }
            //��������, ERR_SUCCESS��ʾ�ɹ���������ʾʧ��
            nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                0,//pCommSendPack->nTunnelNo,
                pCommSendPack->pPackData, 
                pCommSendPack->nPackLen);

            if (ERR_SUCCESS == nRet && pCommSendPack->nTunnelNo == HRS_GUI_L1_FM_SCHED)
            {
                HRS_RM_SCHED *pRMSched = (HRS_RM_SCHED *)pCommSendPack->pPackData;
                HRS_L1_FM_SCHED *pFMSched = (HRS_L1_FM_SCHED *)pCommSendPack->pPackData;
                pRMSched = (HRS_RM_SCHED *)pCommSendPack->pPackData;

#if _DEBUG
                //printf("���ݷ��͵��ɹ���\n\n\n");
#endif

            }

            if (ERR_FAILED == nRet)
            {
                Sleep(1000);
                nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                    0,//pCommSendPack->nTunnelNo,
                    pCommSendPack->pPackData, 
                    pCommSendPack->nPackLen);

                if (ERR_FAILED == nRet)
                {
                    Sleep(1000);

                    nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                        0,//pCommSendPack->nTunnelNo,
                        pCommSendPack->pPackData, 
                        pCommSendPack->nPackLen);
                    if (ERR_FAILED == nRet)
                    {
                        error_log("HRSSendComm.log", "���ݷ��͵�ʧ�ܣ�\r\n");
                    }
                }
            }

            HRS_Comm_PackInfo_Destory(pCommSendPack);
        }
    }

    MTask_LeaveTask(pCommInfo->pMTask);
    return NULL;
}


/** Method:    HRS_Comm_VR_Thread
    ͨ���̣߳��շ�VR������

    @param HRS_COMM_INFO * pCommInfo - ͨ�Ų���

    @return: int - ���ʧ�ܷ���ERR_FAILED������ɹ�����ERR_SUCCESS
*/
int HRS_Comm_Thread(HRS_COMM_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ERR_FAILED;
    }

    // �����������ݴ����߳�
    pCommInfo->hRecvThread = NG_CreateThread(HRS_Comm_Recv_Thread_Func, 
                                             pCommInfo, 
                                             NGTHREAD_RUNNING);


    pCommInfo->hSendThread = NULL;
    // �����������ݴ����߳�
    pCommInfo->hSendThread = NG_CreateThread(HRS_Comm_Send_Thread_Func, 
                                             pCommInfo,
                                             NGTHREAD_RUNNING);

    if ((NULL == pCommInfo->hSendThread) ||
        (NULL == pCommInfo->hRecvThread))
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}



HRS_COMM_INFO *HRS_Comm_Server_GUI_Create(char *pszTunnelCfg)
{
    int      i;
    STR2  HRS_FindPack_Funcs[] = {

        { HRS_GUI_RM_PACK, (char *)HRS_FindPack_RM_Star },
        { HRS_GUI_FM_PACK, (char *)HRS_FindPack_FM_Star },
        { HRS_GUI_RM_SCHED, (char *)HRS_FindPack_FM_Sched },
        { HRS_GUI_FM_SCHED, (char *)HRS_FindPack_RM_Sched },

        { NULL, NULL }
    };

    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_INFO *pCommInfo = 
        (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    i = 0;
    for ( ;; )
    {
        if (HRS_FindPack_Funcs[i].ppsz[0] == NULL)
        {
            break;
        }

        //
        // ע�����ص�����
        //
        MP_FindPackMgr_RegisterPackFunc(HRS_FindPack_Funcs[i].ppsz[0], 
            (RW_FIND_PACK_FUNC)HRS_FindPack_Funcs[i].ppsz[1]);

        i += 1;
    }

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(1000);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);

    // �������ݽ��ն���

    pCommInfo->nRecvThreadMin = HRS_GUI_RM_STRA_PACK;
    pCommInfo->nRecvThreadMax = HRS_GUI_L1_FM_SCHED;//HRS_SERVER_FM_PACK;

    for (i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        pCommInfo->pRecvMsgQue[i] = MsgQueue_Create(nMsgBuffLen);
    }

    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    pCommInfo->nCommModel = HRS_GUI_MODEL;

    HRS_Comm_Thread(pCommInfo);

    return pCommInfo;
}


HRS_COMM_INFO *HRS_Comm_Server_L1_Create(char *pszTunnelCfg)
{
    int      i;
    STR2  HRS_FindPack_Funcs[] = {

        { HRS_L1_FM_PACK, (char *)HRS_FindPack_FM_Data },

        { NULL, NULL }
    };

    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_INFO *pCommInfo = 
        (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    i = 0;
    for ( ;; )
    {
        if (HRS_FindPack_Funcs[i].ppsz[0] == NULL)
        {
            break;
        }

        //
        // ע�����ص�����
        //
        MP_FindPackMgr_RegisterPackFunc(HRS_FindPack_Funcs[i].ppsz[0], 
            (RW_FIND_PACK_FUNC)HRS_FindPack_Funcs[i].ppsz[1]);

        i += 1;
    }

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(1000);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);

    // �������ݽ��ն���

    pCommInfo->nRecvThreadMin = HRS_SERVER_FM_L1_PACK;
    pCommInfo->nRecvThreadMax = HRS_SERVER_FM_L1_PACK;//HRS_SERVER_FM_PACK;

    for (i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        pCommInfo->pRecvMsgQue[i] = MsgQueue_Create(nMsgBuffLen);
    }

    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    pCommInfo->nCommModel = HRS_L1_MODEL;

    HRS_Comm_Thread(pCommInfo);

    return pCommInfo;

}


void *HRS_Comm_Send_IBA_Thread_Func(void *pData)
{
    HRS_COMM_INFO *pCommInfo = (HRS_COMM_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    error_log("HRSSendComm.log", "ibaͨ�ŷ����̴߳�����\r\n");

    int             nRet = 0;
    UINT            uExitFlag = -1;

    int nDataNum = 0;

    HRS_COMM_PACK_INFO  *pCommSendPack = NULL;

    MTask_EnterTask(pCommInfo->pMTask);

    for (;;)
    {
        uExitFlag = MTask_GetExitFlag(pCommInfo->pMTask);
        if (MTASK_EXIT == uExitFlag)
        {
            break;
        }

        //�ӷ�������������      
        pCommSendPack = 
            (HRS_COMM_PACK_INFO *)MsgQueue_TimeOut_Recv(pCommInfo->pSendMsgQue, 100); 
        if (NULL == pCommSendPack)
        {
            Sleep(10);
            continue;
        }
        //��������, ERR_SUCCESS��ʾ�ɹ���������ʾʧ��
        nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
            pCommSendPack->nTunnelNo,
            pCommSendPack->pPackData, 
            pCommSendPack->nPackLen);

        if (ERR_FAILED == nRet)
        {
            Sleep(1000);
            nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                pCommSendPack->nTunnelNo,
                pCommSendPack->pPackData, 
                pCommSendPack->nPackLen);

            if (ERR_FAILED == nRet)
            {
                Sleep(1000);

                nRet = MP_Comm_SendNoBlock(pCommInfo->hComm, 
                    pCommSendPack->nTunnelNo,
                    pCommSendPack->pPackData, 
                    pCommSendPack->nPackLen);

                if (ERR_FAILED == nRet)
                {
                    error_log("HRSSendComm.log", " IBA���ݷ��͵�ʧ�ܣ�\r\n");
                }
            }
        }

        error_log("HRSServerComm.log", "server���;���VR��ػ������ݸ�IBA.\r\n");

        HRS_Comm_PackInfo_Destory(pCommSendPack);
    }

    MTask_LeaveTask(pCommInfo->pMTask);
    return NULL;
}


void *HRS_Comm_Server_IBA_Create(void *pData)
{
    HRS_COMM_INFO *pCommInfo = (HRS_COMM_INFO *)pData;
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    pCommInfo->hComm = MP_Comm_Create(HRS_SERVER_IBA_COMM_CFG);

    if (NULL == pCommInfo->hComm)
    {
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(1000);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);


    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    pCommInfo->nCommModel = HRS_VR_MODEL;

    pCommInfo->hSendThread = NULL;
    // �����������ݴ����߳�
    pCommInfo->hSendThread = NG_CreateThread(HRS_Comm_Send_IBA_Thread_Func, 
        pCommInfo,
        NGTHREAD_RUNNING);

    return pCommInfo;
}


HRS_COMM_INFO *HRS_Comm_Server_VR_Create(char *pszTunnelCfg)
{
    int      i;
    STR2  HRS_FindPack_Funcs[] = {

        { HRS_VR_ROLL_PACK, (char *)HRS_FindPack_Roll_Info },
        { HRS_VR_OPERATION_PACK, (char *)HRS_FindPack_VR_Operation },

        { NULL, NULL }
    };

    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_INFO *pCommInfo = 
        (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    i = 0;
    for ( ;; )
    {
        if (HRS_FindPack_Funcs[i].ppsz[0] == NULL)
        {
            break;
        }

        //
        // ע�����ص�����
        //
        MP_FindPackMgr_RegisterPackFunc(HRS_FindPack_Funcs[i].ppsz[0], 
            (RW_FIND_PACK_FUNC)HRS_FindPack_Funcs[i].ppsz[1]);

        i += 1;
    }

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(1000);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);

    // �������ݽ��ն���

    pCommInfo->nRecvThreadMin = HRS_SERVER_ROLL_INFO_PACK;
    pCommInfo->nRecvThreadMax = HRS_SERVER_VR_OPERATION_PACK;//HRS_SERVER_FM_PACK;

    for (i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        pCommInfo->pRecvMsgQue[i] = MsgQueue_Create(nMsgBuffLen);
    }

    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    pCommInfo->nCommModel = HRS_VR_MODEL;

    HRS_Comm_Thread(pCommInfo);

    return pCommInfo;
}


/** Method:    HRS_Comm_VR_Create
    ��VRͨ���̵߳Ĵ��� 

    @param char * pszTunnelCfg - ͨ�������ļ�

    @return: HRS_COMM_INFO * - ͨ����Ϣ
*/
HRS_COMM_INFO *HRS_Comm_Server_Create(char *pszTunnelCfg)
{
    int      i;
    STR2  HRS_FindPack_Funcs[] = {

        { "HRS_VR_Roll", (char *)HRS_FindPack_Roll_Info },
        { "HRS_VR_Operation", (char *)HRS_FindPack_VR_Operation },

        { NULL, NULL }
    };

    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_INFO *pCommInfo = 
                       (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    i = 0;
    for ( ;; )
    {
        if (HRS_FindPack_Funcs[i].ppsz[0] == NULL)
        {
            break;
        }

        //
        // ע�����ص�����
        //
        MP_FindPackMgr_RegisterPackFunc(HRS_FindPack_Funcs[i].ppsz[0], 
                              (RW_FIND_PACK_FUNC)HRS_FindPack_Funcs[i].ppsz[1]);

        i += 1;
    }

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    const int nMsgBuffLen(1000);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);

    // �������ݽ��ն���

    pCommInfo->nRecvThreadMin = HRS_SERVER_ROLL_INFO_PACK;
    pCommInfo->nRecvThreadMax = HRS_SERVER_FM_L1_PACK;//HRS_SERVER_FM_PACK;

    for (i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        pCommInfo->pRecvMsgQue[i] = MsgQueue_Create(nMsgBuffLen);
    }

    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    HRS_Comm_Thread(pCommInfo);

    return pCommInfo;
}


void HRS_Comm_Destory(HRS_COMM_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ;
    }

    // ���ٿͻ���ͨ�ž��
    if (NULL != pCommInfo->hComm)
    {
        NG_CloseHandle(pCommInfo->hComm);
    }

    // �������ݷ��Ͷ���
    if (NULL != pCommInfo->pSendMsgQue)
    {
        MsgQueue_Destroy(pCommInfo->pSendMsgQue, HRS_Comm_PackInfo_Destory);
    }

    // �������ݽ��ն���
    for (int i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        if (NULL != pCommInfo->pRecvMsgQue[i])
        {
            MsgQueue_Destroy(pCommInfo->pRecvMsgQue[i], HRS_Comm_PackInfo_Destory);
            pCommInfo->pRecvMsgQue[i] = NULL;
        }
    }
    

    // ���ٶ�����ģ��
    if (NULL != pCommInfo->pMTask)
    {
        MTask_Destroy(pCommInfo->pMTask);
    }

    // �������ݷ��;��
    if (NULL != pCommInfo->hSendThread)
    {
        NG_CloseHandle(pCommInfo->hSendThread);
    }

    // �������ݽ��վ��
    if (NULL != pCommInfo->hRecvThread)
    {
        NG_CloseHandle(pCommInfo->hRecvThread);
    }

    NG_free(pCommInfo);
}


void HRS_Comm_Server_Destory(HRS_COMM_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ;
    }

    HRS_Comm_Destory(pCommInfo);

    return;
}


HRS_COMM_INFO *HRS_Comm_Client_Create(char *pszTunnelCfg)
{
    if (NULL == pszTunnelCfg)
    {
        return NULL;
    }

    HRS_COMM_INFO *pCommInfo = 
                            (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 64);
    if (NULL == pCommInfo)
    {
        return NULL;
    }

    memset(pCommInfo , 0, sizeof(HRS_COMM_INFO));

    // ����ͨ������
    pCommInfo->hComm = MP_Comm_Create(pszTunnelCfg);
    if (NULL == pCommInfo->hComm)
    {
        NG_free(pCommInfo);
        return NULL;
    }

    // �������ݷ��Ͷ���
    int nMsgBuffLen(100);
    pCommInfo->pSendMsgQue = MsgQueue_Create(nMsgBuffLen);


    // �������ݽ��ն���
    pCommInfo->nRecvThreadMin = HRS_GUI_RM_ROLL_PACK;
    pCommInfo->nRecvThreadMax = HRS_GUI_COMM_INFO;

    for (int i = 0; i <= pCommInfo->nRecvThreadMax; i++)
    {
        pCommInfo->pRecvMsgQue[i] = MsgQueue_Create(nMsgBuffLen);

    }

    // ����������ģ��
    pCommInfo->pMTask = MTask_Create();

    pCommInfo->nCommModel = HRS_GUI_MODEL;

    HRS_Comm_Thread(pCommInfo);

    return pCommInfo;
}


//ClientGUIͨ�Ų���������
void HRS_Comm_Client_Destory(HRS_COMM_INFO *pCommInfo)
{
    if (NULL == pCommInfo)
    {
        return ;
    }

    HRS_Comm_Destory(pCommInfo);

    return;
}


