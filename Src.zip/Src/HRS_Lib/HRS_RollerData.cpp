#include "stdafx.h"
#include "NG.h"
#include "NG_SimpleTypes.h"
#include "DArray.h"
#include "RW_string.h"
#include "StrParse.h"

#include "HRS_CalcData.h"
#include "HRS_RollerData.h"


INT2_STR1   g_Int2Str1RollerDataNo[] = 
{
    {HRS_ROLLER_NO_E1WS,   HRS_ROLLER_GROUP_NO_E12,   HRS_ROLLER_E1WS_STR},
    {HRS_ROLLER_NO_E1OS,   HRS_ROLLER_GROUP_NO_E12,   HRS_ROLLER_E1OS_STR},
    {HRS_ROLLER_NO_R1T,    HRS_ROLLER_GROUP_NO_R1 ,   HRS_ROLLER_R1T_STR },
    {HRS_ROLLER_NO_R1B,    HRS_ROLLER_GROUP_NO_R1 ,   HRS_ROLLER_R1B_STR },
    {HRS_ROLLER_NO_E2WS,   HRS_ROLLER_GROUP_NO_E12,   HRS_ROLLER_E2WS_STR},
    {HRS_ROLLER_NO_E2OS,   HRS_ROLLER_GROUP_NO_E12,   HRS_ROLLER_E2OS_STR},
    {HRS_ROLLER_NO_R2BT,   HRS_ROLLER_GROUP_NO_R2B,   HRS_ROLLER_R2BT_STR},
    {HRS_ROLLER_NO_R2BB,   HRS_ROLLER_GROUP_NO_R2B,   HRS_ROLLER_R2BB_STR},
    {HRS_ROLLER_NO_R2WT,   HRS_ROLLER_GROUP_NO_R2W,   HRS_ROLLER_R2WT_STR},
    {HRS_ROLLER_NO_R2WB,   HRS_ROLLER_GROUP_NO_R2W,   HRS_ROLLER_R2WB_STR},
    {HRS_ROLLER_NO_E3WS,   HRS_ROLLER_GROUP_NO_E3 ,   HRS_ROLLER_E3WS_STR},
    {HRS_ROLLER_NO_E3OS,   HRS_ROLLER_GROUP_NO_E3 ,   HRS_ROLLER_E3OS_STR},
    {HRS_ROLLER_NO_F1BT,   HRS_ROLLER_GROUP_NO_FB ,   HRS_ROLLER_F1BT_STR},
    {HRS_ROLLER_NO_F1BB,   HRS_ROLLER_GROUP_NO_FB ,   HRS_ROLLER_F1BB_STR},
    {HRS_ROLLER_NO_F1WT,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F1WT_STR},
    {HRS_ROLLER_NO_F1WB,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F1WB_STR},
    {HRS_ROLLER_NO_F2BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F2BT_STR},
    {HRS_ROLLER_NO_F2BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F2BB_STR},
    {HRS_ROLLER_NO_F2WT,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F2WT_STR},
    {HRS_ROLLER_NO_F2WB,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F2WB_STR},
    {HRS_ROLLER_NO_F3BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F3BT_STR},
    {HRS_ROLLER_NO_F3BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F3BB_STR},
    {HRS_ROLLER_NO_F3WT,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F3WT_STR},
    {HRS_ROLLER_NO_F3WB,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F3WB_STR},
    {HRS_ROLLER_NO_F4BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F4BT_STR},
    {HRS_ROLLER_NO_F4BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F4BB_STR},
    {HRS_ROLLER_NO_F4WT,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F4WT_STR},
    {HRS_ROLLER_NO_F4WB,   HRS_ROLLER_GROUP_NO_FWL,   HRS_ROLLER_F4WB_STR},
    {HRS_ROLLER_NO_F5BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F5BT_STR},
    {HRS_ROLLER_NO_F5BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F5BB_STR},
    {HRS_ROLLER_NO_F5WT,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F5WT_STR},
    {HRS_ROLLER_NO_F5WB,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F5WB_STR},
    {HRS_ROLLER_NO_F6BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F6BT_STR},
    {HRS_ROLLER_NO_F6BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F6BB_STR},
    {HRS_ROLLER_NO_F6WT,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F6WT_STR},
    {HRS_ROLLER_NO_F6WB,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F6WB_STR},
    {HRS_ROLLER_NO_F7BT,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F7BT_STR},
    {HRS_ROLLER_NO_F7BB,   HRS_ROLLER_GROUP_NO_FB,    HRS_ROLLER_F7BB_STR},
    {HRS_ROLLER_NO_F7WT,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F7WT_STR},
    {HRS_ROLLER_NO_F7WB,   HRS_ROLLER_GROUP_NO_FWH,   HRS_ROLLER_F7WB_STR},

    {-1,  -1}
};



HRS_ROLLER_GROUP_NO_EM HRS_GetRollerDataOneNo(HRS_ROLLER_NO_EM emRollerNo)
{
    int i;
    INT2_STR1  *pInt2Str1;

    i = 0;
    for ( ;; )
    {
        pInt2Str1 = &(g_Int2Str1RollerDataNo[i]);
        if ( pInt2Str1->anValue[0] < 0 )
        {
            break;
        }

        if ( pInt2Str1->anValue[0] == emRollerNo )
        {
            return (HRS_ROLLER_GROUP_NO_EM)pInt2Str1->anValue[1];
        }

        i += 1;
    }

    return HRS_ROLLER_GROUP_NO_INVALID;
}


char *HRS_GetRollerType(HRS_ROLLER_NO_EM emRollerNo)
{
    int i;
    INT2_STR1  *pInt2Str1;

    i = 0;
    for ( ;; )
    {
        pInt2Str1 = &(g_Int2Str1RollerDataNo[i]);
        if ( pInt2Str1->anValue[0] < 0 )
        {
            break;
        }

        if ( pInt2Str1->anValue[0] == emRollerNo )
        {
            return pInt2Str1->ppsz[0];
        }

        i += 1;
    }

    return NULL;
}


int GetGroupNo(int nRollerNo)
{
    int nGroupNo = HRS_GetRollerDataOneNo((HRS_ROLLER_NO_EM)nRollerNo);

    return nGroupNo;
}

/** Method:    HRS_TotalRillerDataMgrCreate
    �����������ݴ洢�ռ䴴��

    
    @return ROLLER_TOTAL_DATA_MGR * - ���ش����õ�������Ϣ
*/
HRS_ROLLER_TOTAL_DATA_MGR *HRS_TotalRollerDataMgr_Create()
{
    HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr = 
      (HRS_ROLLER_TOTAL_DATA_MGR *)NG_malloc(sizeof(HRS_ROLLER_TOTAL_DATA_MGR));
    if (NULL != pTotalRollerMgr)
    {
        memset(pTotalRollerMgr, 0, sizeof(HRS_ROLLER_TOTAL_DATA_MGR));

        HRS_ROLLER_GROUP *pRollerData = (HRS_ROLLER_GROUP *)pTotalRollerMgr;
        for (int i= 0; i < HRS_ROLLER_GROUP_NO_MAX; i++)
        {
            pRollerData += 1;
            pRollerData->nRollerDataNum   = 0;
            for (int j = 0; j < HRS_ROLLLER_MAX; j++)
            {
                pRollerData->stRollerData[j].nRollerEmptyState = ERR_FAILED;
                pRollerData->stRollerData[j].nRollerUseState = ERR_FAILED;
            }
        }
    }

    return pTotalRollerMgr;
}


/** Method:    ShowRillerDataMgrCreate
    ������ʾ�����ݽṹ�Ĵ���

    @param ROLLER_TOTAL_DATA_MGR * pTotalRollerMgr - �Ѿ������õ��������ݵĽṹ��
    
    @return ROLLER_DATA_MGR * - �����Ľ�����ʾ�����ݽṹ��
*/
HRS_ROLLER_DATA_MGR *HRS_ShowRollerDataMgr_Create(HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pTotalRollerMgr)
    {
        return NULL;
    }

    HRS_ROLLER_DATA_MGR *pRollerMgr = NULL;

    pRollerMgr = (HRS_ROLLER_DATA_MGR *)NG_malloc(sizeof(HRS_ROLLER_DATA_MGR));
    if (NULL != pRollerMgr)
    {
        int i;
        HRS_ROLLER_GROUP_NO_EM   emRollerDataOneNo;
        HRS_ROLLER_GROUP  *pRollerDataOne;
        char             *pszRollerType;

        for ( i = 0; i < HRS_ROLLER_NO_MAX; i++ )
        {
            emRollerDataOneNo = HRS_GetRollerDataOneNo((HRS_ROLLER_NO_EM)i);
            pszRollerType     = HRS_GetRollerType((HRS_ROLLER_NO_EM)i);

            pRollerMgr->ppstData[i] = NULL;

            if ( emRollerDataOneNo != HRS_ROLLER_GROUP_NO_INVALID 
                && pszRollerType != NULL )
            {
                pRollerDataOne = &(pTotalRollerMgr->aRollerDataOne[emRollerDataOneNo]);

                int k;
                for ( k = 0; k < pRollerDataOne->nRollerDataNum; k++ )
                {
                    if ( stricmp(pRollerDataOne->stRollerData[k].szRollerType,
                        pszRollerType) == 0 )
                    {
                        pRollerMgr->ppstData[i] = &(pRollerDataOne->stRollerData[k]);
                        break;
                    }
                }

                if (pRollerMgr->ppstData[i] == NULL )
                {
                    int j = 0;
                    for (j = 0; j < pRollerDataOne->nRollerDataNum; j++)
                    {
                        if (stricmp(pRollerDataOne->stRollerData[j].szRollerType,
                            "NULL") == 0)
                        {
                            pRollerMgr->ppstData[i] = &pRollerDataOne->stRollerData[j];
                            strcpy(pRollerDataOne->stRollerData[j].szRollerType, 
                                   pszRollerType);

                            break;
                        }

                    }

                    if (j == pRollerDataOne->nRollerDataNum)
                    {
                        NG_free(pRollerMgr);

                        return NULL;
                    }
                }
            }

            
        } // for ( i = 0
    } 

    return pRollerMgr;
}


void HRS_TotalRollerDataMgr_Destory(HRS_ROLLER_TOTAL_DATA_MGR *pRollTotalData)
{
    if (NULL == pRollTotalData)
    {
        return;
    }

    NG_free(pRollTotalData);
    return;
}


void HRS_ShowRollerDataMgr_Destory(HRS_ROLLER_DATA_MGR *pRollData)
{
    if (NULL == pRollData)
    {
        return;
    }

    NG_free(pRollData);

    return;
}


int SearchRollerFromTotal(char *pszRollerName, HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pszRollerName || NULL == pTotalRollerMgr)
    {
        return ERR_FAILED;
    }

    HRS_ROLLER_GROUP *pRollerGroup;

    for (int i= 0; i < HRS_ROLLER_GROUP_NO_MAX; i++)
    {
        pRollerGroup= &(pTotalRollerMgr->aRollerDataOne[i]);
        for (int j = 0; j < pRollerGroup->nRollerDataNum; j++)
        {
            if (0 == StrCompare(pszRollerName, 
                pRollerGroup->stRollerData[j].szRollerNo))
            {

                return ERR_SUCCESS;
            }
        }
    }

    return ERR_FAILED;
}

/** Method:    SearchRolller
    ���������������в���ĳ��������Ϣ

    @param char * pszRollerName - �������
    @param ROLLER_TOTAL_DATA_MGR * pTotalRollerMgr - ���е�������Ϣ
    
    @return ROLLER_DATA* - �����ҵ���������Ϣ
*/
HRS_ROLLER_DATA*HRS_SearchRolller(char *pszRollerName, 
                                  HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pszRollerName || NULL == pTotalRollerMgr)
    {
        return NULL;
    }

    HRS_ROLLER_DATA  *pRollerData = NULL;

    HRS_ROLLER_GROUP *pRollerGroup;
    for (int i= 0; i < HRS_ROLLER_GROUP_NO_MAX; i++)
    {
        pRollerGroup= &(pTotalRollerMgr->aRollerDataOne[i]);
        for (int j = 0; j < pRollerGroup->nRollerDataNum; j++)
        {
            if (0 == StrCompare(pszRollerName, 
                pRollerGroup->stRollerData[j].szRollerNo))
            {
                if( 0 == StrCompare(pRollerGroup->stRollerData[j].szRollerType, "NULL"))
                {
                    pRollerData = &pRollerGroup->stRollerData[j];
                }
                else
                {
                    pRollerData = NULL;
                }

                break;
            }
        }
    }

    return pRollerData;
}


/** Method:    SearchRolller
    ���������������в���ĳ��������Ϣ

    @param ROLLER_TOTAL_DATA_MGR * pTotalRollerMgr - ���е�������Ϣ
    @param char * pszRollerType - ��������
    
    @return ROLLER_DATA* - �����ҵ���������Ϣ
*/
HRS_ROLLER_DATA*HRS_TotalRollerDataMgr_Find(
                                  HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                                  char *pszRollerType)
{
    if (NULL == pszRollerType
        || pszRollerType[0] == '\0'
        || NULL == pTotalRollerMgr)
    {
        return NULL;
    }

    HRS_ROLLER_DATA  *pRollerData = NULL;

    HRS_ROLLER_GROUP *pRollerGroup;
    for (int i= 0; i < HRS_ROLLER_GROUP_NO_MAX; i++)
    {
        pRollerGroup= &(pTotalRollerMgr->aRollerDataOne[i]);
        for (int j = 0; j < pRollerGroup->nRollerDataNum; j++)
        {
            if (0 == StrCompare(pszRollerType, 
                        pRollerGroup->stRollerData[j].szRollerType))
            {
                pRollerData = &(pRollerGroup->stRollerData[j]);
            }
        }
    }

    return pRollerData;
}



/** Method:    CheckRollerData
    ����ȡ�����������ݽ��з���洢

    @param ROLLER_DATA * pRollerData - ��ȡ����������
    @param ROLLER_TOTAL_DATA_MGR * pTotalRollerMgr - �ܵ��������ݽṹ��
    
    @return int - �ɹ�����ERR_SUCCESS��ʧ�ܷ���ERR_FAILED
*/
int HRS_CheckRollerData(HRS_ROLLER_DATA *pRollerData, 
                        HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pRollerData || NULL == pTotalRollerMgr)
    {
        return ERR_FAILED;
    }

    int nCurNo = 0;

    char *pszStandNo;

    int nRollerDataLen =  sizeof(HRS_ROLLER_DATA);

    pszStandNo = pRollerData->szStandNo;

    if (ERR_SUCCESS == SearchRollerFromTotal(pRollerData->szRollerNo, pTotalRollerMgr))
    {
        return ERR_FAILED;
    }

    if (0 == StrCompare(pszStandNo, "E12"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E12].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E12].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E12].nRollerDataNum++;
    }
    else if (0 == StrCompare(pszStandNo, "R1"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R1].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R1].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R1].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "R2B"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2B].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2B].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2B].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "R2W"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2W].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2W].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2W].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "E3"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E3].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E3].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E3].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "FB"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FB].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FB].stRollerData[nCurNo]),
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FB].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "F1234W"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWL].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWL].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWL].nRollerDataNum++;
    } 
    else if (0 == StrCompare(pszStandNo, "F567W"))
    {
        nCurNo = pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWH].nRollerDataNum;
        memcpy(&(pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWH].stRollerData[nCurNo]), 
            pRollerData, nRollerDataLen);
        pTotalRollerMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWH].nRollerDataNum++;
    }
    else
    {
        // ������
    }

    return ERR_SUCCESS;
}


int HRS_ParseRollerData(DARRAY *pArray, HRS_ROLLER_DATA *pRollerData, char *pszOutErr)
{
    //������
    int  i;
    char *pszData;
    int  nLen;

    pszOutErr[0] = '\0';

    for ( i = 0; i < pArray->nCurBound; i++ )
    {
        pszData = (char *)DArray_GetAt(pArray, i);

        StrTrimLeft(pszData);
        StrTrimRight(pszData);

        if ( pszData == NULL || pszData[0] == '\0' )
        {
            sprintf(pszOutErr, "Col: %d (start with 0) is Empty string", i);
            return ERR_FAILED;
        }

        nLen = (int)strlen(pszData);

        if ( nLen >= HRS_RILLER_INFO_LEN )
        {
            sprintf(pszOutErr, "Col: %d (start with 0)"
                               "Length is out of Range. ManLen = 11", i);
            return ERR_FAILED;
        }

        switch ( i )
        {
        case HRS_ROLLER_DATA_ROLLER_ID:
            strcpy(pRollerData->szRollerNo, pszData);
            break;
        case HRS_ROLLER_DATA_DIA:
            strcpy(pRollerData->szRollerDIA, pszData);
            break;
        case HRS_ROLLER_DATA_CROW:
            strcpy(pRollerData->szRollerCrow, pszData);
            break;
        case HRS_ROLLER_DATA_MATERIAL:
            strcpy(pRollerData->szRollerMaterial, pszData);
            break;
        case HRS_ROLLER_DATA_TONS:
            strcpy(pRollerData->szRollerTons, pszData);
            break;
        case HRS_ROLLER_DATA_TYPE:
            strcpy(pRollerData->szRollerType, pszData);
            break;
        case HRS_ROLLER_DATA_STAND_TYPE:
            strcpy(pRollerData->szStandNo, pszData);
            break;
        case HRS_ROLLER_DATA_POS:
            strcpy(pRollerData->szRollPos, pszData);
            break;
        case HRS_ROLLER_DATA_STATE:
            strcpy(pRollerData->szRollState, pszData);
            break;
        case HRS_ROLLER_DATA_USE_STATE:
            break;
        case HRS_ROLLER_DATA_EMPTY_STATE:
            break;
        case HRS_ROLLER_DATA_IS_SHOWED:
            break;
        default:
            break;
        }
    }

    //���ܻ���״̬
    pRollerData->nRollerUseState = ERR_FAILED;
    pRollerData->nRollerEmptyState = ERR_SUCCESS;

    pRollerData->nIsShowed = 0;

    return ERR_SUCCESS;
}


int HRS_TotalRollerMgr_Load(char *pszFileName, HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pszFileName || NULL == pTotalRollerMgr)
    {
        return ERR_FAILED;
    }

    char szOutErr[1024];

    char *pszTempFileData = NULL;
    char *pszTempTime     = NULL;
    char *pszData         = NULL;
    char *pszFileData     = NULL;
    char *pszRestLine     = NULL;

    char szLineData[256];
    char *pszLineData = (char *)&szLineData;

    INT_STR  IntStr;

    int      nTimeLen       = 0;
    int      nFileDataSize  = 0;

    int      nRet;

    //���ļ������ݶ�ȡ
    pszFileData = (char *)NG_ReadFileToMem((char *)pszFileName, &nFileDataSize);
    if (NULL == pszFileData)
    {
        return ERR_FAILED;
    }

    pszTempFileData = pszFileData;

    DARRAY *pArray;

    for (; ;)
    {
        //��ȡÿһ�е�����
        pszRestLine = StrGetLineOnce(pszTempFileData, pszLineData);
        if (NULL == pszRestLine)
        {
            break;
        }

        HRS_ROLLER_DATA RollerData;
        int nRollerDataLen =  sizeof(HRS_ROLLER_DATA);
        memset( &RollerData, 0, sizeof(HRS_ROLLER_DATA));

        IntStr.nValue = 0;
        IntStr.psz = pszLineData;

        pszTempFileData = pszRestLine;


        StrTrimLeft(pszLineData);
        StrTrimLeft(pszLineData);

        if ( pszLineData[0] == '#' 
            || pszLineData[0] == '\0' )
        {
            // ����ע���кͿ���
            continue;
        }

        pArray = ParseStrArray(pszLineData, " \t");

        if ( pArray->nDataCount != HRS_ROLLER_DATA_CFG_COL_NUM )
        {
            // ������ƥ�䣬���ø�ʽ����
            DArray_Destroy(pArray);

            continue;
        }

        nRet = HRS_ParseRollerData(pArray, &RollerData, szOutErr);

        if (nRet == ERR_FAILED )
        {
            DArray_Destroy(pArray);

            continue;
        }

        HRS_CheckRollerData(&RollerData, pTotalRollerMgr);

        DArray_Destroy(pArray);
    }

    NG_free(pszFileData);

    return ERR_SUCCESS;
}


int HRS_CreaterDataFile(FILE *fpFile)
{
    if (NULL == fpFile)
    {
        return ERR_FAILED;
    }
    //������ֵ�ļ�ͷ����Ϣ
    fputs("# ROLLER_NO", fpFile);
    fputs("\t", fpFile);

    fputs("ROLLER_DIA", fpFile);
    fputs("\t", fpFile);

    fputs("ROLLER_CROW", fpFile);
    fputs("\t", fpFile);

    fputs("ROLLER_MATERIAL", fpFile);
    fputs("\t", fpFile);

    fputs("ROLL_TONS", fpFile);
    fputs("\t", fpFile);

    fputs("RILL_TYPE", fpFile);
    fputs("\t", fpFile);

    fputs("STAND_NO", fpFile);
    fputs("\t", fpFile);

    fputs("ROLLER_POS", fpFile);
    fputs("\t", fpFile);

    fputs("ROLLER_STATE", fpFile);
    fputs("\n", fpFile);

    return ERR_SUCCESS;
}


/** Method:    SaveOneData
    �����ݴ洢���ļ��� 

    @param FILE * fpFile - �򿪵��ļ���
    @param ROLLER_DATA *pRollerData - ������Ϣ

    
    @return int - ����ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int HRS_SaveOneData(FILE *fpFile, HRS_ROLLER_DATA *pRollerData)
{
    if (NULL ==fpFile || NULL == pRollerData)
    {
        return ERR_FAILED;
    }

    char szData[64];
    memset(szData, 0, 64);

    fputs(pRollerData->szRollerNo, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollerDIA, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollerCrow, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollerMaterial, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollerTons, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollerType, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szStandNo, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollPos, fpFile);
    fputs("\t", fpFile);

    fputs(pRollerData->szRollState, fpFile);
    fputs("\n", fpFile);

    return ERR_SUCCESS;
}



/** Method:    HRS_TotalRollerDataMgr_Save
    ����������Ϣ�����������ļ� 

    @param char * pszRollerFile - ���������ļ�����
    @param ROLLER_TOTAL_DATA_MGR * pTotalRollerMgr - ���е�������Ϣ
    @param ROLLER_DATA_MGR * pShowRollerMgr - ��ǰ������ʾ��������Ϣ
    
    @return int - ����ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int HRS_TotalRollerDataMgr_Save(char *pszRollerFile,
                               HRS_ROLLER_DATA_MGR *pShowRollerMgr,
                               HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pszRollerFile || NULL == pShowRollerMgr || NULL == pTotalRollerMgr)
    {
        return ERR_FAILED;
    }

    //���ļ�
    FILE *fpFile = NULL;
    fopen_s(&fpFile, pszRollerFile, "w+");
    if (fpFile == NULL)
    {
        return ERR_FAILED;
    }

    //д��ͷ����Ϣ
    int nRet = HRS_CreaterDataFile(fpFile);
    if (ERR_FAILED == nRet)
    {
        return ERR_FAILED;
    }

    //�Ƚ����ݱ����ʶ��ʼ��
    HRS_ROLLER_GROUP *pRollerData = (HRS_ROLLER_GROUP *)pTotalRollerMgr;
    for (int i= 0; i < HRS_ROLLER_TYPE_NO; i++)
    {
        for (int j = 0; j < HRS_ROLLLER_MAX; j++)
        {
            pRollerData->stRollerData[j].nIsSaveState = ERR_FAILED;
        }

        pRollerData += 1;
    }

    //������ʹ�õ������������ȱ��浽�����ļ���
    HRS_ROLLER_DATA *pstRoller = NULL;

    for (int i = 0; i < HRS_ROLLER_GUI_TYPE_NO; i++)
    {
        pstRoller = pShowRollerMgr->ppstData[i];
       
        //��ȡRollerType
        char *pszRollerType = HRS_GetRollerType((HRS_ROLLER_NO_EM)i);
        strcpy(pstRoller->szRollerType, pszRollerType);

        nRet = HRS_SaveOneData(fpFile, pstRoller);
        if (ERR_SUCCESS == nRet)
        {
            pstRoller->nIsSaveState = ERR_SUCCESS;
        }
    }

    //����ȥ������ʾ�������������ݱ��浽�����ļ���
    pRollerData = (HRS_ROLLER_GROUP *)pTotalRollerMgr;

    for (int j = 0; j < HRS_ROLLER_TYPE_NO; j++)
    {
        if (NULL == pRollerData)
        {
            continue;;
        }

        for (int i = 0; i < pRollerData->nRollerDataNum; i++)
        {
            if (ERR_SUCCESS == pRollerData->stRollerData[i].nIsSaveState)
            {
                continue;
            }

            strcpy(pstRoller->szRollerType, "NULL");

            nRet = HRS_SaveOneData(fpFile, &pRollerData->stRollerData[i]);
            if (ERR_SUCCESS == nRet)
            {
                pRollerData->stRollerData[i].nRollerUseState = ERR_SUCCESS;
            }
        }

        pRollerData += 1;
    }

    fclose(fpFile);

    return ERR_SUCCESS;
}



HRS_ROLLER_GROUP *HRS_GetRollerDataOneByRow(
                                          HRS_ROLLER_TOTAL_DATA_MGR *pTotalMgr, 
                                          int nRow)
{
    HRS_ROLLER_GROUP *pRollerGroup;

    int row = nRow - 1;

    pRollerGroup = NULL;

    if (row == HRS_ROLLER_NO_E1WS
        || row == HRS_ROLLER_NO_E1OS
        || row == HRS_ROLLER_NO_E2WS 
        || row == HRS_ROLLER_NO_E2OS)//E1/E2
    {
        pRollerGroup =  &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E12];
    }
    else if (row == HRS_ROLLER_NO_R1T
            || row == HRS_ROLLER_NO_R1B)
    {
        pRollerGroup =  &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R1];
    }
    else if (row == HRS_ROLLER_NO_R2BT
             || row == HRS_ROLLER_NO_R2BB )
    {
            pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2B];
    }
    else if (row == HRS_ROLLER_NO_R2WT
             || row == HRS_ROLLER_NO_R2WB )
    {
        pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_R2W];
    }
    else if (row == HRS_ROLLER_NO_E3WS
            || row == HRS_ROLLER_NO_E3OS)
    {
        pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_E3];
    }
    else if (row == HRS_ROLLER_NO_F1BT
             || row == HRS_ROLLER_NO_F1BB
             || row == HRS_ROLLER_NO_F2BT
             || row == HRS_ROLLER_NO_F2BB
             || row == HRS_ROLLER_NO_F3BT
             || row == HRS_ROLLER_NO_F3BB
             || row == HRS_ROLLER_NO_F4BT
             || row == HRS_ROLLER_NO_F4BB
             || row == HRS_ROLLER_NO_F5BT
             || row == HRS_ROLLER_NO_F5BB
             || row == HRS_ROLLER_NO_F6BT
             || row == HRS_ROLLER_NO_F6BB
             || row == HRS_ROLLER_NO_F7BT
             || row == HRS_ROLLER_NO_F7BB)
    {
        pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FB];
    }
    else if (row == HRS_ROLLER_NO_F1WT 
             || row == HRS_ROLLER_NO_F1WB
             || row == HRS_ROLLER_NO_F2WT 
             || row == HRS_ROLLER_NO_F2WB
             || row == HRS_ROLLER_NO_F3WT 
             || row == HRS_ROLLER_NO_F3WB
             || row == HRS_ROLLER_NO_F4WT 
             || row == HRS_ROLLER_NO_F4WB)
    {
        pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWL];
    }
    else if (row == HRS_ROLLER_NO_F5WT 
            || row == HRS_ROLLER_NO_F5WB
            || row == HRS_ROLLER_NO_F6WT 
            || row == HRS_ROLLER_NO_F6WB
            || row == HRS_ROLLER_NO_F7WT 
            || row == HRS_ROLLER_NO_F7WB)
    {
        pRollerGroup = &pTotalMgr->aRollerDataOne[HRS_ROLLER_GROUP_NO_FWH];
    }
    else
    {
        pRollerGroup = NULL;
    }

    return pRollerGroup;
}


int HRS_TotalRollerDataMgr_Add(int nRow,
                               HRS_ROLLER_DATA_MGR *pRollerDataMgr,
                               HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pTotalRollerMgr || nRow <=0 || NULL == pRollerDataMgr)
    {
        return ERR_FAILED;
    }

    HRS_ROLLER_GROUP *pRollerGroup = NULL;

    pRollerGroup = HRS_GetRollerDataOneByRow(pTotalRollerMgr, nRow);
    if (NULL == pRollerGroup)
    {
        return ERR_FAILED;
    }

    int nRollerNo = pRollerGroup->nRollerDataNum;

    //for (int i = 0; i < nRollerNo; i++)
    //{
    //    if (0 == StrCompare(pRollerGroup->stRollerData[i].szRollerNo, ))
    //    {
    //        
    //    }
    //}

    memcpy(&pRollerGroup->stRollerData[nRollerNo],
           &pRollerDataMgr->ppstData[nRow - 1]->szRollerNo,
           sizeof(HRS_ROLLER_DATA));
    strcpy(pRollerGroup->stRollerData[nRollerNo].szRollerType, "NULL");

    //pRollerGroup->stRollerData[nRollerNo].nRollerEmptyState = ERR_SUCCESS;

    pRollerGroup->nRollerDataNum++;

    return ERR_SUCCESS;
}


int HRS_TotalRollerDataMgr_Delet(int nRow,
                                 HRS_ROLLER_DATA_MGR *pRollerDataMgr,
                                 HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    HRS_ROLLER_GROUP *pRollerGroup = NULL;
    pRollerGroup = HRS_GetRollerDataOneByRow(pTotalRollerMgr, nRow);
    if (NULL == pRollerGroup)
    {
        return ERR_FAILED;
    }

    //��ɾ����������Ϣ
    HRS_ROLLER_DATA *pOneRoller = pRollerDataMgr->ppstData[nRow-1];

    HRS_ROLLER_DATA *pTempRollerData = NULL;

    //������Ϣ���в�����û����ʹ�õ����������û��ֹͣɾ��
    int nRollerNo = pRollerGroup->nRollerDataNum;

    int nChangeN0 = -1;

    //CString StrItem;
    //CString StrRollerN0 = pOneRoller->szRollerNo;

    int j = 0;
    for (j = 0; j < HRS_ROLLLER_MAX; j++)
    {
        if(ERR_FAILED == pRollerGroup->stRollerData[j].nRollerEmptyState)
        {
            continue;
        }

        //StrItem = pRollerGroup->stRollerData[j].szRollerNo;
        if (0 == StrCompare(pOneRoller->szRollerNo, 
                            pRollerGroup->stRollerData[j].szRollerNo))
        {
            continue;
        }

        //����ɾ�����
        int i = 1;
        for (i = 1; i < HRS_ROLLER_GUI_TYPE_NO; i++)
        {
            int nIndex = (i - 1);

            pTempRollerData = pRollerDataMgr->ppstData[nIndex];
            if (NULL == pTempRollerData)
            {
                return ERR_FAILED ;
            }

            //CString StrTempItem = pTempRollerData->szRollerNo;
            if (0 == StrCompare(pTempRollerData->szRollerNo, 
                                pRollerGroup->stRollerData[j].szRollerNo))
            {
                break;
            }
        }

        if (i == HRS_ROLLER_GUI_TYPE_NO)
        {
            break;
        }
        else
        {
            continue;
        }
    }

    if (j == HRS_ROLLLER_MAX)
    {
        return ERROR_NG_DEL;
    }

    //���ҵ���Ҫɾ����������Ϣ
    int nN0 = 0;
    for (; nN0 < nRollerNo; nN0++)
    {
        if (0 == StrCompare(pOneRoller->szRollerNo, 
            pRollerGroup->stRollerData[nN0].szRollerNo))
        {
            break;
        }
    }

    memcpy(&pRollerGroup->stRollerData[nN0],
        &pRollerGroup->stRollerData[j],
        sizeof(HRS_ROLLER_DATA));

    for (int k = j; k < pRollerGroup->nRollerDataNum; k++)
    {
        memcpy(&pRollerGroup->stRollerData[k],
            &pRollerGroup->stRollerData[k + 1],
            sizeof(HRS_ROLLER_DATA));   
    }
    memset(&pRollerGroup->stRollerData[pRollerGroup->nRollerDataNum],
           0, 
           sizeof(HRS_ROLLER_DATA));

    pRollerGroup->stRollerData[pRollerGroup->nRollerDataNum].nRollerEmptyState = ERR_FAILED;

    pRollerGroup->nRollerDataNum -= 1;

    return ERR_SUCCESS;
}


int HRS_TotalRollerDataMgr_GetRMWorkingRadius(
                    HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                    double *padRadius, int nCount, char *pszOutErr)
{
    HRS_ROLLER_DATA  *pRollerData;
    double dR1T_WorkerRadius;
    double dR1B_WorkerRadius;
    double dR2WT_WorkerRadius;
    double dR2WB_WorkerRadius;

    strcpy(pszOutErr, "HRS_TotalRollerDataMgr_GetRMWorkingRadius() �����������");

    if (pTotalRollerMgr == NULL
        || padRadius == NULL 
        || nCount < 2 )
    {
        return ERR_FAILED;
    }

    padRadius[0] = 0.0;
    padRadius[1] = 0.0;

    pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
        HRS_ROLLER_R1T_STR);
    if ( pRollerData == NULL )
    {
        strcpy(pszOutErr, "R1 �Ϲ������뾶��ѯʧ��");

        return ERR_FAILED;
    }

    dR1T_WorkerRadius = atof(pRollerData->szRollerDIA) / 2.0;

    pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
        HRS_ROLLER_R1B_STR);
    if ( pRollerData == NULL )
    {
        strcpy(pszOutErr, "R1 �¹������뾶��ѯʧ��");

        return ERR_FAILED;
    }
    dR1B_WorkerRadius = atof(pRollerData->szRollerDIA) / 2.0;

    pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
        HRS_ROLLER_R2WT_STR);
    if ( pRollerData == NULL )
    {
        strcpy(pszOutErr, "R2 �Ϲ������뾶��ѯʧ��");

        return ERR_FAILED;
    }
    dR2WT_WorkerRadius = atof(pRollerData->szRollerDIA) / 2.0;


    pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
        HRS_ROLLER_R2WB_STR);
    if ( pRollerData == NULL )
    {
        strcpy(pszOutErr, "R2 �¹������뾶��ѯʧ��");

        return ERR_FAILED;
    }
    dR2WB_WorkerRadius = atof(pRollerData->szRollerDIA) / 2.0;

    padRadius[0] = (dR1T_WorkerRadius + dR1B_WorkerRadius) / 2.0;
    padRadius[1] = (dR2WT_WorkerRadius + dR2WB_WorkerRadius) / 2.0;

    padRadius[0] /= 1000.0;
    padRadius[1] /= 1000.0;

    return ERR_SUCCESS;
}


int HRS_TotalRollerDataMgr_GetFMWorkingRadius(
                        HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                        double *padRadius, int nCount, char *pszOutErr)
{
    HRS_ROLLER_DATA  *pRollerData;
    double dWorkerRadiusT;
    double dWorkerRadiusB;

    if (pTotalRollerMgr == NULL
        || padRadius == NULL 
        || nCount < HRS_FINISHMILL_NUM )
    {
        return ERR_FAILED;
    }

    int i;

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        padRadius[i] = 0.0;
    }


    char *s_ppszRollerType[] = {
            HRS_ROLLER_F1WT_STR,
            HRS_ROLLER_F1WB_STR,
            HRS_ROLLER_F2WT_STR,
            HRS_ROLLER_F2WB_STR,
            HRS_ROLLER_F3WT_STR,
            HRS_ROLLER_F3WB_STR,
            HRS_ROLLER_F4WT_STR,
            HRS_ROLLER_F4WB_STR,
            HRS_ROLLER_F5WT_STR,
            HRS_ROLLER_F5WB_STR,
            HRS_ROLLER_F6WT_STR,
            HRS_ROLLER_F6WB_STR,
            HRS_ROLLER_F7WT_STR,
            HRS_ROLLER_F7WB_STR,

            NULL
    };


    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
            s_ppszRollerType[2*i]);
        if ( pRollerData == NULL )
        {
            sprintf(pszOutErr, "��ѯ F%d �Ϲ������뾶ʧ��", i);

            return ERR_FAILED;
        }

        dWorkerRadiusT = atof(pRollerData->szRollerDIA) / 2.0;

        pRollerData = HRS_TotalRollerDataMgr_Find(pTotalRollerMgr, 
            s_ppszRollerType[2*i+1]);
        if ( pRollerData == NULL )
        {
            sprintf(pszOutErr, "��ѯ F%d �¹������뾶��ѯʧ��", i);

            return ERR_FAILED;
        }
        dWorkerRadiusB = atof(pRollerData->szRollerDIA) / 2.0;

        padRadius[i] = (dWorkerRadiusT + dWorkerRadiusB) / 2.0;
        padRadius[i] /= 1000.0;
    }

    return ERR_SUCCESS;
}
