#include "NG.h"

#include "HRS_CalcData.h"
#include "HRS_VR_Pack.h"

#include "HRS_Plate.h"



CHRS_Plate::CHRS_Plate()
{
    m_nPlateInitState = ERR_FAILED;

    memset(&m_SlabData, 0, sizeof(HRS_SLAB_DATA));

    m_fStripThickness = 0;
    m_fStripWidth     = 0;
    m_fStripLength    = 0;

    m_fStrip1HeadPosition = 0;
    m_fStrip1TailPosition = 0;
}


CHRS_Plate::~CHRS_Plate()
{

}

//�ְ���Ϣ��ʼ�������¸ְ�ʱ��ʼ��һ��
int CHRS_Plate::PlateLogIn(HRS_PLAN_DATA *pPlanData)
{
    if (NULL == pPlanData && ERR_SUCCESS == m_nPlateInitState)
    {
        return ERR_FAILED;
    }

    double dVomule;
    m_SlabData = pPlanData->SlabData;

    m_fStripThickness = pPlanData->dTargetGauge;
    m_fStripWidth     = pPlanData->dTargetWidth;

    if (m_fStripWidth > 0 && m_fStripThickness > 0)
    {
        dVomule = m_SlabData.dSlabGauge 
                  * m_SlabData.dSlabLen
                  * m_SlabData.dSlabWidth;

        m_fStripLength = dVomule / (m_fStripWidth * m_fStripThickness);
    }
    else
    {
        return ERR_FAILED;
    }

    m_nPlateInitState = ERR_SUCCESS;

    return ERR_SUCCESS;
}


//���øְ�ͷβλ����Ϣ
int CHRS_Plate::SetPlateInfo(float fHeadPos, float fTailPos)
{
    if (fHeadPos < 0 || fTailPos < 0)
    {
        return ERR_FAILED;
    }

    m_fStrip1HeadPosition = fHeadPos;
    m_fStrip1TailPosition = fTailPos;

    return ERR_SUCCESS;
}


//���÷��ͱ����еĸְ���Ϣ
int CHRS_Plate::GetRMData(HRS_RM_DATA &RMData)
{
    if (ERR_FAILED == m_nPlateInitState)
    {
        return ERR_FAILED;
    }

    StrSafeCopy(RMData.szPlateNo1, m_SlabData.szStripNo, HRS_VR_PLATE_NO);
    StrSafeCopy(RMData.szSteelGrade1, m_SlabData.szGrade, HRS_VR_PLATE_NO);

    RMData.fslabThickness1  = m_SlabData.dSlabGauge;
    RMData.fslabWidth1      = m_SlabData.dSlabWidth;
    RMData.fslabLength1     = m_SlabData.dSlabLen;

    RMData.fStripThickness1 = m_fStripThickness;
    RMData.fStripWidth1     = m_fStripWidth;
    RMData.fStripLength1    = m_fStripLength;

    RMData.fStrip1HeadPosition = m_fStrip1HeadPosition;
    RMData.fStrip1tailPosition = m_fStrip1TailPosition;

    return ERR_SUCCESS;
}


//�ְ�ע��
int CHRS_Plate::PlateLogOut()
{
    m_nPlateInitState = ERR_FAILED;

    memset(&m_SlabData, 0, sizeof(HRS_SLAB_DATA));

    m_fStripThickness = 0;
    m_fStripWidth     = 0;
    m_fStripLength    = 0;

    m_fStrip1HeadPosition = 0;
    m_fStrip1TailPosition = 0;

    return ERR_SUCCESS;
}


int CHRS_Plate::GetPlateLogInState()
{
    return m_nPlateInitState;
}
