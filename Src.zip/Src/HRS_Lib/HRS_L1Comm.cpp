#include "NG.h"
#include "MP_Comm.h"
#include "HRS_L1Comm.h"


HRS_L1COMM * HRS_L1Comm_Create(char *pszTunnelCfgFile)
{
    HRS_L1COMM *pComm;

    pComm = (HRS_L1COMM *)NG_malloc(sizeof(HRS_L1COMM));
    if (pComm == NULL)
    {
        return NULL;
    }

    pComm->hMPCom = MP_Comm_Create(pszTunnelCfgFile);
    if (pComm->hMPCom == NULL)
    {
        return NULL;
    }

    pComm->pszCfgfile = StrCopy(pszTunnelCfgFile);

    return pComm;
}


HRS_L1COMM *HRS_L1Comm_Open(char *pszTunnelCfgFile)
{
    HRS_L1COMM *pComm;

    pComm = (HRS_L1COMM *)NG_malloc(sizeof(HRS_L1COMM));
    if (pComm == NULL)
    {
        return NULL;
    }

    pComm->hMPCom = MP_Comm_Open(pszTunnelCfgFile);
    if (pComm->hMPCom == NULL)
    {
        return NULL;
    }

    pComm->pszCfgfile = StrCopy(pszTunnelCfgFile);

    return pComm;
}


void HRS_L1Comm_Destroy(HRS_L1COMM *pL1Comm)
{
    if (pL1Comm == NULL)
    {
        return;
    }

    NG_CloseHandle(pL1Comm->hMPCom);

    if (pL1Comm->pszCfgfile != NULL)
    {
        NG_free(pL1Comm->pszCfgfile);
    }

    NG_free(pL1Comm);

    return;
}


int HRS_L1Comm_SendData(HRS_L1COMM *pL1Comm, void *pData, int nDataLen)
{
    int nRet;

    if (pL1Comm == NULL)
    {
        return ERR_FAILED;
    }

    nRet = MP_Comm_SendNoBlock(pL1Comm->hMPCom, 0, pData, nDataLen);

    return nRet;
}


int HRS_L1Comm_RecvData(HRS_L1COMM *pL1Comm, void *pBuf, int nBufLen)
{
    int nRecvDataLen;

    if (pL1Comm == NULL)
    {
        return ERR_FAILED;
    }

    nRecvDataLen = MP_Comm_RecvNoBlock(pL1Comm->hMPCom, 0, pBuf, nBufLen);

    return nRecvDataLen;
}

