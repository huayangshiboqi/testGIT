#include "HRS_Descaler.h"


_ClassDescaler::_ClassDescaler(void)
 : m_bOpen(false)
 , m_fThick(0.f)
 , m_fWidth(0.f)
{
    return;
}


_ClassDescaler::~_ClassDescaler(void)
{
    return;
}


bool _ClassDescaler::SetOpen(const bool bOpen)
{
    /*
     * ���ó���ˮ����״̬
     */
    m_bOpen = bOpen;

    return true;
}


bool _ClassDescaler::GetOpen(void)
{
    return m_bOpen;
}


bool _ClassDescaler::SetThick(const bool bThick)
{
    /*
     * �����Ƿ�����
     */
    m_bThick = bThick;

    return true;
}


bool _ClassDescaler::IfThick(void)
{
    return m_bThick;
}


bool _ClassDescaler::SetData(const float fThick, const float fWidth)
{
    /*
     * ��ֵ���۰����ĺ�ȺͿ���
     */
    m_fThick = fThick;
    m_fWidth = fWidth;

    return true;
}

float _ClassDescaler::GetThick(void)
{
    return m_fThick;
}


float _ClassDescaler::GetWidth(void)
{
    return m_fWidth;
}
