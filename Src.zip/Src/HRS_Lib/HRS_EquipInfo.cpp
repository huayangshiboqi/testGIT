#include "HRS_EquipInfo.h"


//��������ĳ�ʼ��
HRS_EQUIP_INFO CHRS_EquipInfo::m_EquipInfo[EQ_MAX] ={
    {EQ_DESCALER,           (float)12.9, 20   },
    {EQ_E1_SG,              (float)32.9, 44   },
    {EQ_E1,                 45,   46   },
    {EQ_R1,                 47,   48   },
    {EQ_R1_SG,              50,   (float)58.8 },
    {EQ_E2_SG,              112,  124  },
    {EQ_E2,                 124,  126  },
    {EQ_R2,                 126,  128  },
    {EQ_R2_SG,              130,  (float)138.8},
    {EQ_CS_SG,              225,  230  },
    {EQ_CROPSHERA,          234,  236  },
    {EQ_FM_DESCALER,        238,  241  },
    {EQ_E3,                 242,  244  },
    {EQ_FM,                 244,  278  },
    {EQ_LCS,                290,  420  }};


CHRS_EquipInfo::CHRS_EquipInfo()
{

    m_nFMState = ERR_FAILED;
    memset(&m_RMSched, 0 , sizeof(m_RMSched));
}


CHRS_EquipInfo::~CHRS_EquipInfo()
{

}

int CHRS_EquipInfo::SetFullRM1EquipData(HRS_RM_DATA *pData)
{
    if (NULL == pData)
    {
        memset((void *)&m_RM1EquipData, 0 , sizeof(m_RM1EquipData));

        return ERR_FAILED;
    }

    m_RM1EquipData.fR1SpeedReference          = pData->RM1Data.fR1SpeedReference;
    m_RM1EquipData.fR1SpeedActualTopWorkRoll  = pData->RM1Data.fR1SpeedReference;
    m_RM1EquipData.fR1SpeedActualBotWorkRoll  = pData->RM1Data.fR1SpeedReference;
    m_RM1EquipData.fR1SpeedBal1               = 0;
    m_RM1EquipData.fR1SpeedBal2               = 0;
    m_RM1EquipData.fR1SGEntryWidthReference   = pData->RM1Data.fR1SGEntryWidthReference;
    m_RM1EquipData.fR1SGEntryWidthActual      = pData->RM1Data.fR1SGEntryWidthReference;
    m_RM1EquipData.fR1SGEntryForceReference   = 0;
    m_RM1EquipData.fR1SGEntryForceActual      = 0;
    m_RM1EquipData.fE1GapReference            = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fE1GapActual               = pData->RM1Data.fE1GapReference ;
    m_RM1EquipData.fE1ForceReference          = 0;
    m_RM1EquipData.fE1ForceActual             = 0;
    m_RM1EquipData.fR1GapAvgReference         = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapAvgActual            = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapWSReference          = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapWSActual             = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapDSReference          = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapDSActual             = pData->RM1Data.fE1GapReference;
    m_RM1EquipData.fR1GapTiltReference        = 0;
    m_RM1EquipData.fR1GapTiltActual           = 0;
    m_RM1EquipData.fR1ForceReference          = 0;
    m_RM1EquipData.fR1ForceActual             = 0;
    m_RM1EquipData.fR1SGExitWidthReference    = pData->RM1Data.fR1SGExitWidthReference;
    m_RM1EquipData.fR1SGExitWidthActual       = pData->RM1Data.fR1SGExitWidthReference;
    m_RM1EquipData.fR1SGExitForceReference    = 0;
    m_RM1EquipData.fR1SGExitForceActual       = 0;

    return ERR_SUCCESS;
}

int CHRS_EquipInfo::SetRM1EquipData(HRS_RM_SCHEDCALC_ONEPASS *pData)
{
    if (NULL == pData)
    {
        memset((void *)&m_RM1EquipData, 0 , sizeof(m_RM1EquipData));

        return ERR_FAILED;
    }

    m_RM1EquipData.fR1SpeedReference          = pData->fRollingSpeed;
    m_RM1EquipData.fR1SpeedActualTopWorkRoll  = pData->fRollingSpeed;
    m_RM1EquipData.fR1SpeedActualBotWorkRoll  = pData->fRollingSpeed;
    m_RM1EquipData.fR1SpeedBal1               = 0;
    m_RM1EquipData.fR1SpeedBal2               = 0;
    m_RM1EquipData.fR1SGEntryWidthReference   = pData->fDeliveryWidth;
    m_RM1EquipData.fR1SGEntryWidthActual      = pData->fDeliveryWidth;
    m_RM1EquipData.fR1SGEntryForceReference   = 0;
    m_RM1EquipData.fR1SGEntryForceActual      = 0;
    m_RM1EquipData.fE1GapReference            = pData->fDeliveryWidth;
    m_RM1EquipData.fE1GapActual               = pData->fDeliveryWidth;
    m_RM1EquipData.fE1ForceReference          = 0;
    m_RM1EquipData.fE1ForceActual             = 0;
    m_RM1EquipData.fR1GapAvgReference         = pData->fMillerGap;
    m_RM1EquipData.fR1GapAvgActual            = pData->fMillerGap;
    m_RM1EquipData.fR1GapWSReference          = pData->fMillerGap;
    m_RM1EquipData.fR1GapWSActual             = pData->fMillerGap;
    m_RM1EquipData.fR1GapDSReference          = pData->fMillerGap;
    m_RM1EquipData.fR1GapDSActual             = pData->fMillerGap;
    m_RM1EquipData.fR1GapTiltReference        = 0;
    m_RM1EquipData.fR1GapTiltActual           = 0;
    m_RM1EquipData.fR1ForceReference          = pData->fMillerForce;
    m_RM1EquipData.fR1ForceActual             = pData->fMillerForce;
    m_RM1EquipData.fR1SGExitWidthReference    = pData->fDeliveryWidth;
    m_RM1EquipData.fR1SGExitWidthActual       = pData->fDeliveryWidth;
    m_RM1EquipData.fR1SGExitForceReference    = 0;
    m_RM1EquipData.fR1SGExitForceActual       = 0;

    return ERR_SUCCESS;
}


int CHRS_EquipInfo::SetRM2EquipData(HRS_RM_SCHEDCALC_ONEPASS *pData)
{
    if (NULL == pData)
    {
        memset((void *)&m_RM2EquipData, 0 , sizeof(m_RM2EquipData));

        return ERR_FAILED;
    }

    m_RM2EquipData.fR2SpeedReference          = pData->fRollingSpeed;
    m_RM2EquipData.fR2SpeedActualTopWorkRoll  = pData->fRollingSpeed;
    m_RM2EquipData.fR2SpeedActualBotWorkRoll  = pData->fRollingSpeed;
    m_RM2EquipData.fR2SpeedBal1               = 0;
    m_RM2EquipData.fR2SpeedBal2               = 0;
    m_RM2EquipData.fR2SGEntryWidthReference   = pData->fDeliveryWidth;
    m_RM2EquipData.fR2SGEntryWidthActual      = pData->fDeliveryWidth;
    m_RM2EquipData.fR2SGEntryForceReference   = 0;
    m_RM2EquipData.fR2SGEntryForceActual      = 0;
    m_RM2EquipData.fE2GapReference            = pData->fDeliveryWidth;
    m_RM2EquipData.fE2GapActual               = pData->fDeliveryWidth;
    m_RM2EquipData.fE2ForceReference          = 0;
    m_RM2EquipData.fE2ForceActual             = 0;
    m_RM2EquipData.fR2GapAvgReference         = pData->fMillerGap;
    m_RM2EquipData.fR2GapAvgActual            = pData->fMillerGap;
    m_RM2EquipData.fR2GapWSReference          = pData->fMillerGap;
    m_RM2EquipData.fR2GapWSActual             = pData->fMillerGap;
    m_RM2EquipData.fR2GapDSReference          = pData->fMillerGap;
    m_RM2EquipData.fR2GapDSActual             = pData->fMillerGap;
    m_RM2EquipData.fR2GapTiltReference        = 0;
    m_RM2EquipData.fR2GapTiltActual           = 0;
    m_RM2EquipData.fR2ForceReference          = pData->fMillerForce;
    m_RM2EquipData.fR2ForceActual             = pData->fMillerForce;
    m_RM2EquipData.fR2SGExitWidthReference    = pData->fDeliveryWidth;
    m_RM2EquipData.fR2SGExitWidthActual       = pData->fDeliveryWidth;
    m_RM2EquipData.fR2SGExitForceReference    = 0;
    m_RM2EquipData.fR2SGExitForceActual       = 0;

    return ERR_SUCCESS;
}


int CHRS_EquipInfo::GetRMInfo(HRS_VR_ACTION &VRAction, HRS_RM_DATA &RMData)
{

    VRAction.fE1EntrySGWidth = RMData.RM1Data.fR1SGEntryWidthReference;//[mm]E1��ڲർ�忪�ڶ�
    VRAction.fE1Gap = RMData.RM1Data.fE1GapActual;                     //[mm]E1����
    VRAction.fR1Gap = RMData.RM1Data.fR1GapAvgActual;                  //[mm]R1����
    VRAction.fR1ExitSGWidth = RMData.RM1Data.fR1SGEntryWidthReference; //[mm]R1���ڲർ�忪�ڶ�

    VRAction.fE2EntrySGWidth = RMData.RM2Data.fR2SGEntryWidthReference; //[mm]E2��ڲർ�忪�ڶ�
    VRAction.fE2Gap = RMData.RM2Data.fE2GapActual; ;                    //[mm]E2����
    VRAction.fR2Gap = RMData.RM2Data.fR2GapAvgActual;                   //[mm]R2����
    VRAction.fR2ExitSGWidth = RMData.RM2Data.fR2SGEntryWidthReference;  //[mm]R2���ڲർ�忪�ڶ�


    return ERR_SUCCESS;
}


int CHRS_EquipInfo::GetEquipState(HRS_VR_ACTION &VRAction, HRS_RM_DATA &RMData)
{
    if (m_fSteelHeadPos <=0 || m_fSteelTailPos <= 0)
    {
        return ERR_FAILED;
    }

    //������λ��
    if (m_fSteelHeadPos >= m_EquipInfo[EQ_DESCALER].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_DESCALER].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x03;
    }

    //E1��ڲർ��
    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_E1_SG].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_E1_SG].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x0c;
    }*/

    //E1λ��
    if (RMData.sR1CurPassNum % 2 == 1||
        (0 == RMData.sR1CurPassNum &&  0 == RMData.sR1TotalPassNum ))
    {
        if (m_fSteelHeadPos >= m_EquipInfo[EQ_E1].fEquipHead
            && m_fSteelTailPos <= m_EquipInfo[EQ_E1].fEquipHead)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x04;
        }
        else if (m_fSteelTailPos > m_EquipInfo[EQ_E1].fEquipHead)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand & 0xFB;
        }
    }

    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_E1].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_E1].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x0c;
    }*/
    //R1λ��
    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_R1].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_R1].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x0c;
    }*/
    //R1���ڲർ��
   /* if (m_fSteelHeadPos >= m_EquipInfo[EQ_R1_SG].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_R1_SG].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x0c;
    }*/

    if (RMData.sR1CurPassNum % 2 == 1)
    {
        if (m_fSteelHeadPos >= m_EquipInfo[EQ_R1_SG].fEquipHead - 1
            && m_fSteelTailPos <= m_EquipInfo[EQ_R1_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x08;
        }
        else if (m_fSteelHeadPos < m_EquipInfo[EQ_R1_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand & 0xF7;
        }
    }

    //E2��ڲർ��
    if (m_fSteelHeadPos >= m_EquipInfo[EQ_E2_SG].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_E2_SG].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x30;
    }
    //E2λ��
    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_E2].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_E2].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x30;
    }*/

    if (RMData.sR2CurPassNum % 2 == 1)
    {
        if (m_fSteelHeadPos >= m_EquipInfo[EQ_R2_SG].fEquipHead - 1
            && m_fSteelTailPos <= m_EquipInfo[EQ_R2_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x10;
        }
        else if (m_fSteelHeadPos < m_EquipInfo[EQ_R2_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand & 0xEF;
        }
    }

    //R2λ��
    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_R2].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_R2].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x30;
    }*/
    //R2���ڲർ��
    if (RMData.sR2CurPassNum % 2 == 1)
    {
        if (m_fSteelHeadPos >= m_EquipInfo[EQ_R2_SG].fEquipHead - 1
            && m_fSteelTailPos <= m_EquipInfo[EQ_R2_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x20;
        }
        else if (m_fSteelHeadPos < m_EquipInfo[EQ_R2_SG].fEquipHead - 1)
        {
            VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand & 0xCF;
        }
    }

    /*if (m_fSteelHeadPos >= m_EquipInfo[EQ_R2_SG].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_R2_SG].fEquipEnd)
    {
        VRAction.sRMDeviceCommand = VRAction.sRMDeviceCommand | 0x30;
    }*/

    //CS��ڲർ��
    //�ɼ�λ��
    if (m_fSteelHeadPos >= m_EquipInfo[EQ_CROPSHERA].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_CROPSHERA].fEquipEnd)
    {
        //�ɼ�����ͷ��20-30���֣��ɼ�λ��m_EquipInfo[EQ_CROPSHERA].fEquipHead + 1
        if (m_fSteelHeadPos > m_EquipInfo[EQ_CROPSHERA].fEquipHead + 1.2 &&
            m_fSteelHeadPos < m_EquipInfo[EQ_CROPSHERA].fEquipHead + 2)
        {
            VRAction.sFMDeviceCommand = VRAction.sFMDeviceCommand | 0x1ff;
        }

        //�ɼ�����β��20-30���֣��ɼ�λ��m_EquipInfo[EQ_CROPSHERA].fEquipEnd - 1
        if (m_fSteelTailPos < m_EquipInfo[EQ_CROPSHERA].fEquipEnd - 1.2 &&
            m_fSteelTailPos > m_EquipInfo[EQ_CROPSHERA].fEquipEnd - 2)
        {
            VRAction.sFMDeviceCommand = VRAction.sFMDeviceCommand | 0x2ff;
        }
    }


    //FM������λ��
    //if (m_fSteelHeadPos >= m_EquipInfo[EQ_FM_DESCALER].fEquipHead
    //    && m_fSteelTailPos <= m_EquipInfo[EQ_FM_DESCALER].fEquipEnd)
    //{
    //    VRAction.sFMDeviceCommand = VRAction.sFMDeviceCommand | 0x1ff;
    //}
    ////E3λ��
    //if (m_fSteelHeadPos >= m_EquipInfo[EQ_E3].fEquipHead
    //    && m_fSteelTailPos <= m_EquipInfo[EQ_E3].fEquipEnd)
    //{
    //    VRAction.sFMDeviceCommand = VRAction.sFMDeviceCommand | 0x1ff;
    //}
    ////FMλ��
    if (m_fSteelHeadPos >= m_EquipInfo[EQ_FM].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_FM].fEquipEnd)
    {
        m_nFMState = ERR_SUCCESS;
        //VRAction.sFMDeviceCommand = VRAction.sFMDeviceCommand | 0x1ff;
    }
    printf("FMλ��= %f\n\n%f\n\n",m_fSteelHeadPos, m_fSteelTailPos);

    //��ȴˮ
    if (m_fSteelHeadPos >= m_EquipInfo[EQ_LCS].fEquipHead
        && m_fSteelTailPos <= m_EquipInfo[EQ_LCS].fEquipEnd)
    {
        VRAction.sPowerCooling1Top = VRAction.sPowerCooling1Top | 0x3fff;
        VRAction.sPowerCooling1Bottom = VRAction.sPowerCooling1Bottom | 0x7f;

        VRAction.sRegularCoolingTop = VRAction.sRegularCoolingTop | 0x3fff;
        VRAction.sRegularCoolingBottom = VRAction.sRegularCoolingBottom | 0xfff;

        VRAction.sPowerCooling2Top = VRAction.sPowerCooling2Top | 0x3fff;
        VRAction.sPowerCooling2Bottom = VRAction.sPowerCooling2Bottom | 0xfff;

        VRAction.sTrimmingCoolingTop = VRAction.sTrimmingCoolingTop | 0xff;
        VRAction.sTrimmingCoolingBottom = VRAction.sTrimmingCoolingBottom | 0xf;

        VRAction.sSideSprayInterzone = VRAction.sSideSprayInterzone | 0x7fff;
        VRAction.sSideSprayEntryExit = VRAction.sSideSprayEntryExit | 0x3;
    }

    return ERR_SUCCESS;
}


int CHRS_EquipInfo::GetRMEquipData(HRS_VR_ACTION &VRAction, HRS_RM_DATA &RMData)
{
    HRS_RM_SCHEDCALC_ONEPASS *pData = NULL;

    //[]R1��ǰ������
    m_nR1CurPassNo = RMData.sR1CurPassNum;

    //[]R2��ǰ������
    m_nR2CurPassNo = RMData.sR2CurPassNum;

    if (m_nR1CurPassNo >= 0 && m_nR1CurPassNo <= HRS_ROUGHROLL_R1_PASS_MAX)
    {
        if (m_nR1CurPassNo > 0)
        {
            pData = &m_RMSched.SchedCalcPassR1[m_nR1CurPassNo - 1];
            SetRM1EquipData(pData);
        }
        else 
        {
            SetFullRM1EquipData(&RMData);
        }

        RMData.RM1Data = m_RM1EquipData;
    }
    else if (m_nR2CurPassNo > 0 && m_nR2CurPassNo <= HRS_ROUGHROLL_R2_PASS_MAX)
    {
        pData = &m_RMSched.SchedCalcPassR2[m_nR2CurPassNo - 1];
        SetRM2EquipData(pData);
        RMData.RM2Data = m_RM2EquipData;
    }

    //[m]������һ��ͷ��λ��
    m_fSteelHeadPos = RMData.fStrip1HeadPosition / 1000;

    //[m]������һ��β��λ��
    m_fSteelTailPos = RMData.fStrip1tailPosition / 1000;

    if (m_fSteelHeadPos > 0 && m_fSteelTailPos > 0)
    {
        GetEquipState(VRAction, RMData);
    }

    GetRMInfo(VRAction, RMData);

    return ERR_FAILED;
}
