#include "NG.h"

#include "HRS_TempCalc.h"


double  g_HRS_TempCurveData[] = { 
    1039.896851, 1037.392822, 1033.069702, 1032.478394, 1031.898071, 
    1029.811646, 1026.479736, 1023.807129, 1021.774353, 1019.109375,
    1016.194153, 1013.770081, 1011.195313, 1015.860291, 1015.903503,
    1012.510986, 1011.288086, 1012.501221, 1016.221191, 1014.058289,
    1010.769897, 1010.515808, 1009.876587, 1008.607788, 1006.055542,
    1003.446411, 1000.991638, 1000.849182, 1002.679688, 1003.81897,
    1004.719299, 1005.644104, 1005.72052,  1005.901489, 1006.575134,
    1006.556152, 1005.634827, 1001.626465, 997.2492065, 996.149231,
    999.0391846, 1003.283813, 1007.080139, 1007.69342,  1008.902893,
    1009.670349, 1009.533691, 1007.671326, 1005.891357, 1004.358643,
    1005.023376, 1006.742554, 1008.058777, 1008.132568, 1008.889648,
    1009.423889, 1008.500916, 1007.696533, 1007.853821, 1006.371704,
    1004.559021, 1002.795166, 1001.515625, 1002.715454, 1004.193298,
    1003.85437,  1003.273926, 1003.238098, 1001.979431, 999.640625,
    997.4593506, 995.6917725, 993.1442871, 991.786377,  991.1590576,
    990.2181396, 989.4573975, 988.1243896, 987.1213379, 987.1831665,
    987.3022461, 987.1113281, 986.5930786, 985.3952637, 982.4547729,
    980.7523804, 980.1021729, 980.3413086, 982.1057129, 985.9291382,
    990.2785645, 992.3252563, 989.3751221, 963.3903198
};


HRS_TEMP_CALC  *g_pHRSTempCalc = NULL;


/** Method:    HRS_TempCalc_SysInit
    ΪHRS_TempCalc_Query()����׼����ʼ������ 

    
    @return void - ��
*/
void HRS_TempCalc_SysInit()
{
    int nDataCount = NG_ARRAY_SIZE(g_HRS_TempCurveData);

    g_pHRSTempCalc = HRS_TempCalc_Create(g_HRS_TempCurveData, 
                                         nDataCount, 
                                         nDataCount + 128);

    return;
}


void HRS_TempCalc_SysClose()
{
    if (g_pHRSTempCalc == NULL)
    {
        return;
    }

    HRS_TempCalc_Destroy(g_pHRSTempCalc);

    g_pHRSTempCalc = NULL;

    return;
}


int HRS_TempCalc_QueryOrgTemp(double dIndex, double *pdTempOut)
{
    int    nRet;
    double dTemp;

    if (g_pHRSTempCalc == NULL)
    {
        return ERR_FAILED;
    }

    dTemp = 0.0;

    nRet = HRS_TempCalc_GetTemp(g_pHRSTempCalc, dIndex, &dTemp);
    if (nRet == ERR_FAILED)
    {
        *pdTempOut = 0.0;
        return ERR_FAILED;
    }

    *pdTempOut = dTemp;

    return ERR_SUCCESS;
}

/** Method:    HRS_TempCalc_Query
    ��ѯ�¶� 

    @param double dEntryTemp - ����¶�
    @param double dIndex - ����
    @param double * pdTempOut - [out]����¶�
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_TempCalc_Query(double dEntryTemp, double dIndex, double *pdTempOut)
{
    int    nRet;
    double dTemp;
    double dFirstTemp;

    if (g_pHRSTempCalc == NULL)
    {
        return ERR_FAILED;
    }

    dFirstTemp = g_pHRSTempCalc->padTempCurveData[0];

    dTemp = 0.0;

    nRet = HRS_TempCalc_GetTemp(g_pHRSTempCalc, dIndex, &dTemp);
    if (nRet == ERR_FAILED)
    {
        *pdTempOut = 0.0;
        return ERR_FAILED;
    }

    dTemp *= (dEntryTemp / dFirstTemp); 

    *pdTempOut = dTemp;

    return ERR_SUCCESS;
}


int HRS_TempCalc_GetTempSectionCount()
{
    return NG_ARRAY_SIZE(g_HRS_TempCurveData);
}


// ��ȡ��С�¶�
void HRS_TempCalc_GetMinTemp(double *pdMinTemp)
{
    int nIndex;

    nIndex = NG_ARRAY_SIZE(g_HRS_TempCurveData);

    *pdMinTemp = g_HRS_TempCurveData[nIndex-1];

    return;
}


/** Method:    HRS_TempCalc_Create
    ���� 

    @param double * padTempCurveData - �¶��½�������������
    @param int nCurveDataCount - �����������ݸ���
    @param int nMaxCurveDataCount - ����������ݸ���,�����nCurveDataCount��
    
    @return HRS_TEMP_CALC * - ����HRS_TEMP_CALCָ�룬ʧ��NULL
*/
HRS_TEMP_CALC *HRS_TempCalc_Create(double *padTempCurveData, 
                                   int nCurveDataCount, 
                                   int nMaxCurveDataCount)
{
    int             i;
    int             nDataSize;
    HRS_TEMP_CALC  *pTempCalc;

    if (padTempCurveData == NULL)
    {
        return NULL;
    }

    if (nCurveDataCount >= nMaxCurveDataCount)
    {
        return NULL;
    }

    nDataSize = sizeof(double) * (nMaxCurveDataCount + 2);

    pTempCalc = (HRS_TEMP_CALC *)NG_malloc(sizeof(HRS_TEMP_CALC) + nDataSize);
    if (pTempCalc == NULL)
    {
        return NULL;
    }

    pTempCalc->padTempCurveData 
        = (double *)((char *)pTempCalc + sizeof(HRS_TEMP_CALC));

    pTempCalc->nCurveDataCount    = nCurveDataCount;
    pTempCalc->nMaxCurveDataCount = nMaxCurveDataCount;

    for (i = 0; i < nCurveDataCount; i++)
    {
        pTempCalc->padTempCurveData[i] = padTempCurveData[i];
    }

    return pTempCalc;
}


void HRS_TempCalc_Destroy(HRS_TEMP_CALC *pTempCalc)
{
    if (pTempCalc == NULL)
    {
        return;
    }

    NG_free(pTempCalc);

    return;
}


/** Method:    HRS_TempCalc_GetTemp
    ͨ����ֵ������dIndex�����¶� 

    @param HRS_TEMP_CALC * pTempCalc - �¶����ݽṹ��ָ��
    @param double dIndex - ����ֵ
    @param double * pdTemp - [out]�¶�
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_TempCalc_GetTemp(HRS_TEMP_CALC *pTempCalc, 
                         double dIndex, 
                         double *pdTemp)
{
    int nIndex;
    double dTemp1;      // �½��¶�
    double dTemp2;      // �Ͻ��¶�
    double dTempValue;  // ��ֵ����¶�ֵ������dTemp1��dTemp2�Ĳ�ֵ���

    if (pTempCalc == NULL || pdTemp == NULL)
    {
        return ERR_FAILED;
    }

    nIndex = (int)dIndex;

    if (nIndex < 0 || nIndex >= (pTempCalc->nCurveDataCount-1))
    {
        return ERR_FAILED;
    }


    dTemp1 = pTempCalc->padTempCurveData[nIndex];
    dTemp2 = pTempCalc->padTempCurveData[nIndex+1];

    dTempValue  = (1.0 + nIndex - dIndex) * dTemp1;
    dTempValue += (dIndex - nIndex) * dTemp2;

    *pdTemp     = dTempValue;

    return ERR_SUCCESS;
}

