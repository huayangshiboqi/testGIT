#include "HRS_Track.h"

#include "HRS_RMCalc.h"
#include "HRS_FMCalc.h"


CHRS_Track::CHRS_Track()
{

    m_pPlanData = NULL;
    m_pModule   = NULL;

    m_nTotalPackNum = 0;
    m_nFMCurPackNo  = 0;

    const int nMsgBuffLen(1000);

    m_L1FMMsgQue = MsgQueue_Create(nMsgBuffLen);

}


CHRS_Track::~CHRS_Track()
{
    if (NULL != m_pRunTable)
    {
        delete m_pRunTable;
    }

    if (NULL != m_pOnLinePlate)
    {
        delete m_pOnLinePlate;
    }

   /* if (NULL != m_pAllOutData)
    {
        NG_free(m_pAllOutData);
    }*/

    if (NULL != m_pRMSched)
    {
        NG_free(m_pRMSched);
    }

    if (NULL != m_pModule)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);
    }

    if (NULL != m_L1FMMsgQue)
    {
        MsgQueue_Destroy(m_L1FMMsgQue, NG_free);
    }
}


int CHRS_Track::TrackDataInit()
{

    memset(m_pPlanData, 0, sizeof(HRS_PLAN_DATA));
    memset(&m_RMAllOutData, 0 , sizeof(HRS_RM_ALL_OUT_DATA));

    memset(&m_RMGUIData, 0 , sizeof(HRS_RM_DATA_FROM_GUI));

    m_nGetRMDataState = ERR_FAILED;
    m_nClacRMState    = ERR_FAILED;

    m_nSetSteelInfo  = ERR_SUCCESS;
    m_nSetGUIRMState = ERR_SUCCESS;
    m_nGetGUIRMState = ERR_FAILED;

    memset(&m_FMAllOutData, 0 , sizeof(HRS_FM_ALL_OUT_DATA));
    memset(&m_FMSched, 0 , sizeof(HRS_FM_SCHED));

    memset(&m_FMStrData, 0 , sizeof(HRS_FM_STRATEGY_DATA));

    m_nGetFMDataState = ERR_FAILED;
    m_nClacFMState    = ERR_FAILED;

    m_nSetFMDataState   = ERR_FAILED;
    m_nSetGUIFMState    = ERR_SUCCESS;
    m_nGetGUIFMState    = ERR_FAILED;

    m_nSetL1FMState = ERR_FAILED;
    m_nGetL1FMState = ERR_FAILED;

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));
    memset(&m_FMData, 0 , sizeof(HRS_FM_DATA));

    memset(&m_RollInfo, 0 , sizeof(HRS_ROLL_INFO));
    memset(&m_VROperation, 0 , sizeof(HRS_VR_OPERATION));

    m_nGetVRRollInfoState = ERR_FAILED;
    m_nGetVROperState     = ERR_FAILED;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;
    m_nSetVRFMState  = ERR_FAILED;

    m_nGetVRActState = ERR_FAILED;
    m_nGetVRRMState  = ERR_FAILED;
    m_nGetVRFMState  = ERR_FAILED;

    m_nPlateOnLineState = ERR_FAILED;
    m_nLogoutState      = ERR_SUCCESS;

    m_nTrackStart = ERR_FAILED;
    m_nCalcL1Ave  = ERR_FAILED;
    m_nSetGUIL1Ave = ERR_SUCCESS;

    m_nGetRMSchedState = ERR_FAILED;
    m_nGetFMSchedState = ERR_FAILED;

    return ERR_SUCCESS;
}


// ��ʼ��  
int CHRS_Track::Initial()
{
    int nRet = -1;

    m_pModule = (CHRSEquipParaMgr *)CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, m_pModule);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    m_pRunTable  = new CRMRunTable;
    if (NULL == m_pRunTable)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        return ERR_FAILED;
    }

    m_pOnLinePlate = new CHRS_Plate;
    if (NULL == m_pOnLinePlate)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        return ERR_FAILED;
    }

    //����ͨ��ʵ��(gui)
    m_pCServerGUIComm = new CHRSServerComm;
    if (NULL == m_pCServerGUIComm)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        return ERR_FAILED;
    }

    nRet = m_pCServerGUIComm->ServerCommCreate(HRS_SERVER_GUI_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
               HRS_SERVER_GUI_COMM_CFG);
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerGUIComm;

        return ERR_FAILED;
    }

    //����ͨ��ʵ��(L1)
    m_pCServerL1Comm = new CHRSServerComm;
    if (NULL == m_pCServerL1Comm)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;

        return ERR_FAILED;
    }

    nRet = m_pCServerL1Comm->ServerCommCreate(HRS_SERVER_L1_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
            HRS_SERVER_L1_COMM_CFG);

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;

        return ERR_FAILED;
    }

    //����ͨ��ʵ��(VR)
    m_pCServerVRComm = new CHRSServerComm;
    if (NULL == m_pCServerVRComm)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pRunTable;
        delete m_pOnLinePlate;
        return ERR_FAILED;
    }

    nRet = m_pCServerVRComm->ServerCommCreate(HRS_SERVER_VR_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
            HRS_SERVER_L1_COMM_CFG);

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    memset(&m_FMAllData, 0 , sizeof(HRS_FM_ALL_DATA));
    memset(&m_RMAllData, 0 , sizeof(HRS_RM_ALL_DATA));


    // ��ȡ������
    nRet = m_pModule->GetAllStandPara(&m_FMAllData.AllStandPara);
    if (nRet == ERR_FAILED)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    nRet = m_pModule->GetAllStandPara(&m_RMAllData.AllStandPara);
    if (nRet == ERR_FAILED)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    m_pEquipInfo = new CHRS_EquipInfo;
    if (NULL == m_pEquipInfo)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    m_pPlanData   = (HRS_PLAN_DATA *)NG_malloc(sizeof(HRS_PLAN_DATA));
    memset(m_pPlanData, 0, sizeof(HRS_PLAN_DATA));

    m_pRMSched    = (HRS_RM_SCHED *)NG_malloc(sizeof(HRS_RM_SCHED));

    memset(&m_RMAllOutData, 0 , sizeof(HRS_RM_ALL_OUT_DATA));

    memset(&m_RMGUIData, 0 , sizeof(HRS_RM_DATA_FROM_GUI));

    m_nGetRMDataState = ERR_FAILED;
    m_nClacRMState    = ERR_FAILED;

    m_nSetSteelInfo  = ERR_SUCCESS;

    m_nSetGUIRMState = ERR_SUCCESS;
    m_nGetGUIRMState = ERR_FAILED;

    memset(&m_FMAllOutData, 0 , sizeof(HRS_FM_ALL_OUT_DATA));
    memset(&m_FMSched, 0 , sizeof(HRS_FM_SCHED));

    memset(&m_FMStrData, 0 , sizeof(HRS_FM_STRATEGY_DATA));

    m_nGetFMDataState = ERR_FAILED;
    m_nClacFMState    = ERR_FAILED;

    m_nSetFMDataState   = ERR_FAILED;
    m_nSetGUIFMState    = ERR_SUCCESS;
    m_nGetGUIFMState    = ERR_FAILED;

    m_nSetL1FMState = ERR_FAILED;
    m_nGetL1FMState = ERR_FAILED;

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));
    memset(&m_FMData, 0 , sizeof(HRS_FM_DATA));

    memset(&m_RollInfo, 0 , sizeof(HRS_ROLL_INFO));
    memset(&m_VROperation, 0 , sizeof(HRS_VR_OPERATION));

    m_nGetVRRollInfoState = ERR_FAILED;
    m_nGetVROperState     = ERR_FAILED;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;
    m_nSetVRFMState  = ERR_FAILED;

    m_nGetVRActState = ERR_FAILED;
    m_nGetVRRMState  = ERR_FAILED;
    m_nGetVRFMState  = ERR_FAILED;

    m_nPlateOnLineState = ERR_FAILED;
    m_nLogoutState      = ERR_SUCCESS;

    printf("CHRS_Track::Initial() Successful.\r\n");

    m_nTrackStart = ERR_FAILED;
    m_nCalcL1Ave  = ERR_FAILED;
    m_nSetGUIL1Ave = ERR_SUCCESS;

    m_nGetRMSchedState = ERR_FAILED;
    m_nGetFMSchedState = ERR_FAILED;

    return ERR_SUCCESS;
}


// ������¼
int CHRS_Track::Login()
{
    if (NULL == m_pPlanData || NULL == m_pOnLinePlate 
        || HRS_DATA_TYPE_L1_SIMULATE == m_FMGUIData.DataHead.nDataType)
    {
        return ERR_FAILED;
    }

    int nRet = -1;
    //����û�иְ壬�ְ��¼
    if (ERR_FAILED == m_pRunTable->GetTableState()
        && ERR_FAILED == m_nPlateOnLineState)
    {
        //�ְ����ݳ�ʼ��
        /*if (ERR_SUCCESS == m_nClacRMState 
            && ERR_SUCCESS == m_nClacFMState 
            && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())*/
        if (ERR_SUCCESS == m_nGetRMSchedState
            && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())
        {
            m_pPlanData->SlabData     = m_L1RMSched.SlabData;
            m_pPlanData->dTargetGauge = m_L1RMSched.dTargetGauge;
            m_pPlanData->dTargetWidth = m_L1RMSched.dTargetGauge;

            nRet = m_pOnLinePlate->PlateLogIn(m_pPlanData);
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            //�������ݳ�ʼ��
            nRet = m_pRunTable->RunTableInit();
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            int nPackNum = m_pCServerL1Comm->GetL1FMNum();

            m_pEquipInfo->SetRMSched(&m_L1RMSched.stRoughRollSched);
            m_pEquipInfo->SetEquipFM(m_pCServerL1Comm->GetL1FMSteelTail());

            m_pRunTable->SetEquipF7Speed(m_pCServerL1Comm->GetF7Speed());
            m_pRunTable->SetEquipF7TableEnd(m_pCServerL1Comm->GetL1FMSteelTail());

            nRet = m_pRunTable->SetTableInfo(&m_L1RMSched, 
                                      nPackNum, 
                                      m_pCServerL1Comm->GetF7SteelLen());
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            m_nTotalPackNum = nPackNum;

            m_nPlateOnLineState = ERR_SUCCESS;

            printf("�ְ��¼�ɹ���\n");

            return ERR_SUCCESS;
        }
    }

    return ERR_FAILED;
}


// ����ע��
int CHRS_Track::Logout(void)
{
    if (ERR_SUCCESS == m_pRunTable->GetTableState())
    {
        m_nTrackStart = ERR_SUCCESS;
        return ERR_FAILED;
    }
    else if (ERR_SUCCESS == m_nGetRMSchedState 
             && ERR_SUCCESS == m_nTrackStart)
    {
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n\n\n\n");

        m_pCServerL1Comm->SetL1FMState();

        TrackDataInit();

        m_nFMCurPackNo = 0;
    }


    //if (ERR_SUCCESS == m_nPlateOnLineState && ERR_SUCCESS == m_nLogoutState)
    //{
    //    return ERR_SUCCESS;
    //}

    ////�ְ���Ϣ��ʼ��
    //int nRet = m_pOnLinePlate->PlateLogOut();

    ////������Ϣ��ʼ��
    //m_pRunTable->RunTableInit();

    ////����������ݳ�ʼ��
    ////m_pRMSched = NULL;

    //m_nPlateOnLineState = ERR_FAILED;

    return ERR_SUCCESS;
}


// �趨����
int CHRS_Track::SetEquipState()
{
    //�ְ��¼״̬
    if (ERR_FAILED == m_nPlateOnLineState)
    {
        return ERR_FAILED;
    }

    //��ȡ������Ϣ
    if (NULL == m_pRunTable)
    {
        return ERR_FAILED;
    }

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));

    m_RMData.fslabThickness1 = m_RMGUIData.PlanData.SlabData.dSlabGauge;
    m_RMData.fslabWidth1 = m_RMGUIData.PlanData.SlabData.dSlabWidth;
    m_RMData.fslabLength1 = m_RMGUIData.PlanData.SlabData.dSlabLen;

    m_RMData.fStripThickness1 = m_RMGUIData.PlanData.dTargetGauge;
    m_RMData.fStripWidth1 = m_RMGUIData.PlanData.dTargetWidth;
    if (ERR_SUCCESS == m_pEquipInfo->GetFMState())
    {
        m_RMData.fStrip1HeadPosition =
                                   m_FMData.OnePlateData[0].fStripHeadPosition;
        m_RMData.fStrip1tailPosition = 
                                   m_FMData.OnePlateData[0].fStriptailPosition;

        m_RMData.fStripLength1 = m_FMData.OnePlateData[0].fStripLength;
    }
    else
    {
        m_RMData.fStripLength1 = 
                   m_RMData.fStrip1HeadPosition - m_RMData.fStrip1tailPosition;
    }

    m_RMData.RM1Data.fR1SGEntryWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM1Data.fR1SGEntryWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;

    m_RMData.RM2Data.fR2SGEntryWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM2Data.fR2SGEntryWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;


    m_RMData.RM1Data.fR1SGExitWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM1Data.fR1SGExitWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;

    m_RMData.RM2Data.fR2SGExitWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM2Data.fR2SGExitWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;


    m_pRunTable->GetTableInfo(m_VRAactionData, m_RMData);
    if (ERR_FAILED == m_pRunTable->GetTableState())
    {
        return ERR_FAILED;
    }

    //�����豸״̬
    if (NULL == m_pEquipInfo)
    {
        return ERR_FAILED;
    }

    m_pEquipInfo->GetRMEquipData(m_VRAactionData, m_RMData);

    if(m_RMData.sR1CurPassNum > 0)
    {
        printf("sR1CurPassNum");
    }

    if(m_RMData.sR2CurPassNum > 0)
    {
        printf("sR2CurPassNum");
    }

    m_nGetVRActState = ERR_SUCCESS;
    m_nGetVRRMState  = ERR_SUCCESS;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;

    return ERR_SUCCESS;
}


int CHRS_Track::SendOnLineData()
{
    int nRet = -1;

    if (NULL == m_pCServerGUIComm
        && NULL == m_pCServerL1Comm 
        && NULL == m_pCServerVRComm)
    {
        return ERR_FAILED;
    }

    //���͵�GUI
    if (ERR_FAILED == m_nSetGUIRMState && ERR_SUCCESS == m_nClacRMState)
    {
        nRet = m_pCServerGUIComm->SetRMSched(m_pRMSched);
        m_nSetGUIRMState = nRet;

#if 0
        if (HRS_DATA_TYPE_ONLY_RM_PACK == m_RMGUIData.DataHead.nDataType
            && ERR_SUCCESS == m_nSetGUIRMState)
        {
            m_nClacRMState   = ERR_FAILED;

        }
#else
    m_nClacRMState   = ERR_FAILED;
#endif
    }

    if (ERR_FAILED == m_nSetGUIFMState && ERR_SUCCESS == m_nClacFMState)
    {
        nRet = m_pCServerGUIComm->SetFMSched(&m_FMSched);
        m_nSetGUIFMState = nRet;

#if 0
        if (HRS_DATA_TYPE_ONLY_FM_PACK == m_FMGUIData.DataHead.nDataType
            && ERR_SUCCESS == m_nSetGUIFMState)
        {
            m_nClacFMState   = ERR_FAILED;
        }
#else
    m_nClacFMState   = ERR_FAILED;
#endif
    }

    //���͵���ֵ��GUI
    if (ERR_FAILED == m_nSetGUIL1Ave 
        && ERR_FAILED == m_nCalcL1Ave
        && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())
    {
        HRS_FM_DATA *pFMData = m_pCServerL1Comm->GetL1AveData();

        if (ERR_SUCCESS == GetL1Ave(pFMData))
        {
            nRet = m_pCServerGUIComm->SetL1AveData(&m_stSunL1Ave);

            m_nSetGUIL1Ave = nRet;

            m_nCalcL1Ave = ERR_SUCCESS;
        }
        else
        {
            //�ݲ�����
        }
    }

    //���͵��ְ�λ�õ�GUI
    if (ERR_FAILED == m_nSetSteelInfo)
    {
        nRet = m_pCServerGUIComm->SetSteelInfo(&m_SteelInfo);
        m_nSetSteelInfo = nRet;

        if (0 == m_SteelInfo.fStrip1HeadPosition)
        {
            printf("���͸ְ�λ�õ�GUI�ɹ���%f, %f\n\n\n\n\n", 
                   m_SteelInfo.fStrip1HeadPosition, 
                   m_SteelInfo.fStrip1tailPosition);
        }

    }

    //���͵�L1
#if 0
    if (ERR_FAILED == m_nSetL1FMState && ERR_SUCCESS == m_nGetL1FMState)
    {
        if (HRS_DATA_TYPE_L1_FM_PACK == m_FMGUIData.DataHead.nDataType
            || HRS_DATA_TYPE_L1_SIMULATE == m_FMGUIData.DataHead.nDataType)
        {
            nRet = HRS_FML2Calc_BuildSched(&m_FMAllData, 
                &m_FMAllOutData, 
                &m_FMSched);
            if (ERR_SUCCESS == nRet)
            {
                nRet = m_pCServerL1Comm->SetL1FMClac(&m_FMSched);

                m_nSetL1FMState  = nRet;
                m_nGetL1FMState = ERR_FAILED;

                printf("����FM��L1�ɹ���");
                LogPrint("TRACKL1Comm.log", "Send Data.  To L1 LoopTimes\r\n");
            }
        }
    }

#else

    if (ERR_FAILED == m_nSetL1FMState && ERR_SUCCESS == m_nGetFMSchedState)
    {
        nRet = m_pCServerL1Comm->SetL1FMClac(&m_L1FMSched.stFinishRollSched);
        m_nSetL1FMState  = nRet;
        m_nGetL1FMState = ERR_FAILED;
        m_nGetFMSchedState = ERR_FAILED;

        printf("����FM��L1�ɹ���");
        LogPrint("TRACKL1Comm.log", "Send Data.  To L1 LoopTimes\r\n");

        /*nRet = HRS_FML2Calc_BuildSched(&m_FMAllData, 
                                       &m_FMAllOutData, 
                                       &m_FMSched);
        if (ERR_SUCCESS == nRet)
        {
            nRet = m_pCServerL1Comm->SetL1FMClac(&m_FMSched);

            m_nSetL1FMState  = nRet;
            m_nGetL1FMState = ERR_FAILED;
            m_nGetFMSchedState = ERR_SUCCESS;

            printf("����FM��L1�ɹ���");
            LogPrint("TRACKL1Comm.log", "Send Data.  To L1 LoopTimes\r\n");
        }*/
    }
#endif


    //���͵�VR
    if (ERR_SUCCESS == m_nGetVRActState && ERR_FAILED == m_nSetVRActState)
    {
        nRet = m_pCServerVRComm->SetVRAactionData(&m_VRAactionData);

        if (ERR_SUCCESS == nRet)
        {
            printf("����VR�ɹ���\n");

            m_nSetVRActState = nRet;
            m_nGetVRActState = ERR_FAILED;
        }
    }

    if (ERR_SUCCESS == m_nGetVRRMState && ERR_FAILED == m_nSetVRRMState)
    {
        nRet = m_pCServerVRComm->SetRMData(&m_RMData);

        if (ERR_SUCCESS == nRet)
        {
            printf("����RM�ɹ���\n");

            m_nSetVRRMState = nRet;
            m_nGetVRRMState = ERR_FAILED;

            m_nSetSteelInfo = ERR_FAILED;
            m_SteelInfo.fStrip1HeadPosition = m_RMData.fStrip1HeadPosition;
            m_SteelInfo.fStrip1tailPosition = m_RMData.fStrip1tailPosition;

        }                                               
    }

    if (ERR_SUCCESS == m_nGetVRFMState && ERR_FAILED == m_nSetVRFMState)
    {
        nRet = m_pCServerVRComm->SetFMData(&m_FMData);
        if (ERR_SUCCESS == nRet)
        {
            m_nFMCurPackNo++;
            printf("����FM�ɹ���\n");
            printf("FMCurPackNo = %d��\n",m_nFMCurPackNo);

            if (m_nTotalPackNum == m_nFMCurPackNo)
            {
                printf("����FM������m_nTotalPackNum = %d\n\n\n\n", m_nTotalPackNum);

                m_pEquipInfo->SetFMState(ERR_FAILED);
                m_pRunTable->SetTableState(ERR_FAILED);
            }

            m_nGetL1FMState = ERR_FAILED;
            m_nSetVRFMState = nRet;
        }
    }

    return ERR_SUCCESS;
}


int CHRS_Track::RecvGUIOnLineData()
{
    int nRet = -1;

    //ͨ�Ż�ȡ����(����GUI)
    if (ERR_FAILED == m_nGetRMDataState && ERR_SUCCESS == m_nSetGUIRMState)
    {
        nRet = m_pCServerGUIComm->GetRMData(m_RMGUIData);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetRMDataState = ERR_SUCCESS;
            m_nSetGUIRMState  = ERR_FAILED;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //��������GUI
    if (ERR_FAILED == m_nGetFMDataState && ERR_SUCCESS == m_nSetGUIFMState)
    {
        nRet = m_pCServerGUIComm->GetFMData(m_FMGUIData);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetFMDataState = ERR_SUCCESS;
            m_nSetGUIFMState  = ERR_FAILED;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //�����������
    if (ERR_FAILED == m_nGetRMSchedState)
    {
        nRet = m_pCServerGUIComm->GetRMSched(m_L1RMSched);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetRMSchedState = ERR_SUCCESS;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //�����������
    if (ERR_FAILED == m_nGetFMSchedState)
    {
        nRet = m_pCServerGUIComm->GetFMSched(m_L1FMSched);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetFMSchedState = ERR_SUCCESS;
            m_nSetL1FMState     = ERR_FAILED;

            m_nCalcL1Ave  = ERR_FAILED;

            m_nSetGUIL1Ave = ERR_FAILED;
            //�ӽ������FM��̣��·���L1SIMULATOR,L1���Ϸ������������
            //��˶����в��������ݱ�����ն�������
            m_pCServerL1Comm->ServerCommMsgQueEmpty(HRS_SERVER_FM_L1_PACK,
                                                    HRS_Comm_PackInfo_Destory);

            m_pCServerL1Comm->SetL1FMState();
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    return ERR_SUCCESS;
}

#if 1


int CHRS_Track::GetL1Ave(void *pData)
{
    if (NULL == pData)
    {
        return ERR_FAILED;
    }

    HRS_FM_DATA *pFMData = (HRS_FM_DATA *)pData;

    memset(&m_stSunL1Ave, 0, sizeof(m_stSunL1Ave));

    //������ֵ��
    HRS_ONE_FM_DATA  *pOneFMData;
    HRS_ONE_FX_DATA  *pOneFXData;

    float  *pfDeliveryGauge = &pFMData->OnePlateData[1].fBarThickness;
    float  *pfDrafRatio = &pFMData->OnePlateData[1].fStriptailPosition;

    for (int i = 0; i < 6; i++)
    {
        pOneFMData = &(pFMData->OneEquitData[i].OneFMData);
        pOneFXData = &(pFMData->OneEquitData[i].OneFXData);

        m_stSunL1Ave.FMActualData[i].dAveDeliveryGauge = *pfDeliveryGauge;
        m_stSunL1Ave.FMActualData[i].dAveDraftRatio = *pfDrafRatio;    
        m_stSunL1Ave.FMActualData[i].dAveRollingForce = pOneFMData->fSumForceActual;
        m_stSunL1Ave.FMActualData[i].dAveTension = pOneFXData->fVRTensionActual;
        m_stSunL1Ave.FMActualData[i].dAveGap = pOneFMData->fGapAvgActual;

        pfDeliveryGauge++;
        pfDrafRatio++;
    }

    m_stSunL1Ave.FMActualData[6].dAveDeliveryGauge = *pfDeliveryGauge;
    m_stSunL1Ave.FMActualData[6].dAveDraftRatio = *pfDrafRatio;
    m_stSunL1Ave.FMActualData[6].dAveRollingForce = pFMData->stFM7Data.fSumForceActual;
    m_stSunL1Ave.FMActualData[6].dAveGap = pFMData->stFM7Data.fGapAvgActual;

    m_stSunL1Ave.FMActualData[6].dAveTension = 0.0;

    return ERR_SUCCESS;
}
#endif


int CHRS_Track::RecvOnLineData()
{
    int nRet = -1;

    //����GUI����
    if (NULL == m_pCServerGUIComm
         && NULL == m_pCServerL1Comm 
         && NULL == m_pCServerVRComm) 
    {
        return ERR_FAILED;
    }

    //����û�иְ�ʱ�������淢�͵�����
    if (ERR_FAILED == m_pRunTable->GetTableState())
    {
        RecvGUIOnLineData();
    }
    else
    {
        //������
    }

#if 1

    //�ְ����е�FM����ʱ����L1�������ݶ����н���FM��������
    if (ERR_FAILED == m_nGetL1FMState 
        && ERR_SUCCESS == m_pEquipInfo->GetFMState())
    {
        nRet = m_pCServerL1Comm->GetL1Data(m_FMData);
        if (ERR_SUCCESS == nRet)
        {
            if (0 == m_FMData.PackHead.sTelDataLength)
            {
                m_nSetSteelInfo = ERR_FAILED;
                m_SteelInfo.fStrip1HeadPosition = 0;
                m_SteelInfo.fStrip1tailPosition = 0;
            }

            m_pRunTable->SetFMData(m_FMData);
            m_nGetL1FMState  = nRet;
            m_nGetVRFMState  = nRet;
            m_nSetVRFMState  = ERR_FAILED;
        }
    }
#endif

    //����VR
    if (ERR_FAILED == m_nGetVRRollInfoState)
    {
        nRet = m_pCServerVRComm->GetRollInfo(m_RollInfo);

        m_nGetVRRollInfoState = nRet;
    }

    if (ERR_FAILED == m_nGetVROperState)
    {
        nRet = m_pCServerVRComm->GetVROperation(m_VROperation);

        m_nGetVROperState = nRet;
    }

    return ERR_SUCCESS;
}


int CHRS_Track::RMSchedClac()
{
    int nRet = -1;
    HRS_STAND_PARA  *pStandPara;

    // ��ȡ������
    m_RMAllData.PlanData     = m_RMGUIData.PlanData;
    m_RMAllData.StrategyData = m_RMGUIData.StrategyData;

    memcpy(&m_RMAllData.PlateData.SlabeData, 
        &m_RMAllData.PlanData.SlabData, 
        sizeof(HRS_SLAB_DATA));

    m_RMAllData.PlateData.dSlabeEntryTemp =
        m_RMGUIData.PlanData.dDischargeTemp;

    //���ο�������
    m_RMAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;        // ��������
    m_RMAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
    m_RMAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
    m_RMAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
    m_RMAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
    m_RMAllData.DeformFactor.dReserve1 = 1;
    m_RMAllData.DeformFactor.dReserve2 = 1;

    if (NULL == m_pRMSched)
    {
        m_pRMSched = (HRS_RM_SCHED *)NG_malloc(sizeof(HRS_RM_SCHED));
    }

    pStandPara = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_RM1]);
    pStandPara->dMaxWorkingRollerRadius 
        = m_RMGUIData.adWorkingRollerRadius[0];

    pStandPara = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_RM2]);
    pStandPara->dMaxWorkingRollerRadius 
        = m_RMGUIData.adWorkingRollerRadius[1];

    memset(m_pRMSched, 0 , sizeof(HRS_RM_SCHED));
    nRet = HRS_RML2Calc_CalcAllData(&m_RMAllData, &m_RMAllOutData);
    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        //return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_BuildSched(&m_RMAllData, &m_RMAllOutData, m_pRMSched);
    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        m_nGetRMDataState = ERR_FAILED;

        //return ERR_FAILED;
    }
    else
    {
        printf("��������ɹ���\n");
    }

    return nRet;
}


int CHRS_Track::FMSchedClac()
{
    int nRet = -1;
    HRS_STAND_PARA  *pStandPara;


    m_FMAllData.PlanData       = m_FMGUIData.PlanData;
    m_FMAllData.FMStrategyData = m_FMGUIData.StrategyData;

    //���ο�������
    memcpy(m_FMAllData.DeformFactor.szSteelGrade, 
        m_FMAllData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);

    m_FMAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;    // ��������
    m_FMAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
    m_FMAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
    m_FMAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
    m_FMAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;

    m_FMAllData.DeformFactor.dReserve1 = 1;
    m_FMAllData.DeformFactor.dReserve2 = 1;

    for ( int i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        pStandPara 
            = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i]);

        pStandPara->dMaxWorkingRollerRadius 
            = m_FMGUIData.adWorkingRollerRadius[i];
    }

    //��������
    nRet = HRS_FML2Calc_CalcAllData(&m_FMAllData, &m_FMAllOutData);
    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        m_nGetFMDataState = ERR_FAILED;
        //return ERR_FAILED;
    }

    nRet = HRS_FML2Calc_BuildSched(&m_FMAllData, &m_FMAllOutData, &m_FMSched);
    if (nRet == ERR_FAILED)
    {
        m_nGetFMDataState = ERR_FAILED;

        printf("��������ʧ�ܣ�\n");

        //return ERR_FAILED;
    }
    else
    {
        printf("��������ɹ���\n");
    }

    return nRet;
}



int CHRS_Track::CalcData()
{
    int nRet = -1;

    //��������
    if (ERR_SUCCESS == m_nGetRMDataState && ERR_FAILED == m_nClacRMState)
    {
        int nRet = RMSchedClac();

        m_nClacRMState = nRet;

#if 0
        if (HRS_DATA_TYPE_ONLY_RM_PACK == m_RMGUIData.DataHead.nDataType)
        {
            m_nGetRMDataState = ERR_FAILED;
        }
#else
        m_nGetRMDataState = ERR_FAILED;
#endif

        //m_pPlanData = &m_RMGUIData.PlanData;
    }

    //��������
    if (ERR_SUCCESS == m_nGetFMDataState 
        && ERR_FAILED == m_nClacFMState)
    {
        int nRet = FMSchedClac();

        m_nClacFMState = nRet;
        m_nSetL1FMState = ERR_FAILED;

        //m_pPlanData = &m_RMGUIData.PlanData;

#if 0
        if (HRS_DATA_TYPE_ONLY_FM_PACK == m_FMGUIData.DataHead.nDataType)
        {
            m_nGetFMDataState = ERR_FAILED;
        }
#else
        m_nGetFMDataState = ERR_FAILED;
#endif
    }

    return ERR_SUCCESS;
}

