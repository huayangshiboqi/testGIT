#include "NG.h"
#include "HRS_MTR.h"



CHRSMtr::CHRSMtr()
{

}


CHRSMtr::~CHRSMtr()
{

}


int CHRSMtr::Init()
{
    return ERR_SUCCESS;
}


int CHRSMtr::Close()
{
    return ERR_SUCCESS;
}


int CHRSMtr::Run(UINT uDeltaTime)
{
    return ERR_SUCCESS;
}


void *CHRSMtr_Create(CGlobalInstance *pInstance,
                            void *pArg1,
                            void *pArg2,
                            int nArg)
{
    CHRSMtr  *pMgr;

    pMgr = new CHRSMtr;

    printf("CHRSMtr Module created.\n");

    return pMgr;
}


int CHRSMtr_Init(CGlobalInstance *pInstance, void *pModule)
{
    CHRSMtr  *pMgr;
    int nRet;

    pMgr = (CHRSMtr *)pModule;

    nRet = pMgr->Init();

    printf("CHRSMtr Module Init.\n");

    return nRet;
}


int CHRSMtr_Run(CGlobalInstance *pInstance,
                       void *pModule,
                       UINT uDeltaTime)
{
    CHRSMtr  *pMgr;
    int nRet;

    pMgr = (CHRSMtr *)pModule;

    nRet = pMgr->Run(uDeltaTime);

    printf("CHRSMtr Module Run.\n");

    return nRet;
}


void CHRSMtr_Destroy(void *pModule)
{
    CHRSMtr  *pMgr;

    pMgr = (CHRSMtr *)pModule;

    if (pMgr != NULL)
    {
        printf("CHRSMtr Module Destroy.\n");

        delete pMgr;
    }

    return;
}
