#include "NG.h"
#include "CfgAPI.h"
#include "HRS_EquipParaMgr.h"
#include "NG_Path.h"


int ParseOneMillParaFromSection(APPCONF *pAppConf, 
                                HRS_ALL_STAND_PARA * pAllMillPara, 
                                char *pszSectionName)
{
    APPSECTION     * pSection;
    APPKEY         * pAppKey;
    HRS_STAND_PARA * pMillPara;

    pSection = AppConf_FindSection(pAppConf, pszSectionName);
    if (pSection == NULL)
    {
        return ERR_FAILED;
    }

    pAppKey = AppSection_FindKey(pSection, "MillNo");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    int nMillNo = atoi(pAppKey->key_value);

    pMillPara = &(pAllMillPara->aEquipPara[nMillNo]);

    if (pMillPara->emStandNo != 0)
    {
        return ERR_FAILED; //�ظ�
    }
    pMillPara->emStandNo =  (HRS_STAND_NO_EM)nMillNo;

    pAppKey = AppSection_FindKey(pSection, "MillType");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->nMillType = atoi(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "RollerMaterial");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->nRollerMaterial = atoi(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxRollingForce");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxRollingForce = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxRollingTorque");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxRollingTorque = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxDraft");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxDraft = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxCurrent");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxCurrent = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxPower");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxPower = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxWorkingRollerRadius");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxWorkingRollerRadius = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "BackupRollerDiameter");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dBackupRollerDiameter = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MainDriverAcceleration");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMainDriverAcceleration = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxEntryGauge");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxEntryGauge = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MinDeliveryGauge");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMinDeliveryGauge = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxEntryTemperature");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxEntryTemperature = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MinEntryTemperature");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMinEntryTemperature = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MaxWidth");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxWidth = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "MinWidth");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMinWidth = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "EnvironmentTemperature");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dEnvironmentTemperature = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "CalcAdjust");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dCalcAdjust = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "AGCFactor");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dAGCFactor = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "AGCResponseTimeMs");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dAGCResponseTimeMs = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "PlasticFactor");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dPlasticFactor = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "SpeedRatio");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dSpeedRatio = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "TimeForSpeed");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dTimeForSpeed = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "TimeForLooper");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dTimeForLooper = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "Position");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dPosition = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "LooperAngleRatio");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dLooperAngleRatio = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "LooperAdjustRatio");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dLooperAdjustRatio = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "TensionServoRatio");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dTensionServoRatio = atof(pAppKey->key_value);

    // �����趨ֵ
    pAppKey = AppSection_FindKey(pSection, "LooperWaitAngle");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dLooperWaitAngle = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "LooperTargetAngle");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dLooperTargetAngle = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "SetupLooperLen");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dSetupLooperLen = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "LowerLooperRestLen");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dLowerLooperRestLen = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, "GaugeForceFactor");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dGaugeForceFactor = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "TempForceFactor");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dTempForceFactor = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "Modulus");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dModulus = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, "MaxAGCAdjust");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dMaxAGCAdjust = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "ZeroForce");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dZeroForce = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, "Reserve1");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dReserve1 = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "Reserve2");
    if (pAppKey == NULL)
    {
        return ERR_FAILED;
    }
    pMillPara->dReserve2 = atof(pAppKey->key_value);

    // 
    
    return ERR_SUCCESS;
}


HRS_ALL_STAND_PARA *AllStandPara_LoadFromFile(char *pszCfgFile)
{
    HRS_ALL_STAND_PARA * pAllMillPara;
    APPCONF        *pAppConf;
    APPSECTION     *pSection;
    APPKEY         *pAppKey;
    int            nRet;

#ifdef _DEBUG
    char szPath[260];
    memset(szPath, 0, sizeof(szPath));
    NG_Path_GetCurPath(szPath, sizeof(szPath));
    printf("Current Path = %s\n", szPath);
#endif

    pAppConf = AppConf_LoadFromFile(pszCfgFile);        //"MillPara.cfg"
    if (pAppConf == NULL)
    {
        return NULL;
    }

    pAllMillPara = (HRS_ALL_STAND_PARA *) NG_malloc(sizeof(HRS_ALL_STAND_PARA));
    if (pAllMillPara == NULL)
    {
        return NULL;
    }
    memset(pAllMillPara, 0, sizeof(HRS_ALL_STAND_PARA));

    pSection = AppConf_FindSection( pAppConf, "Global");
    if (pSection == NULL)
    {
        goto Label_HRS_EquipParaCfg_LoadFromFile;
    }


    AppSection_SearchStart(pSection);

    for (;;)
    {
        pAppKey = AppSection_SearchNext(pSection);
        if (pAppKey == NULL)
        {
            break;
        }

        if (stricmp(pAppKey->key_name, "Mill") == 0 )
        {
            nRet = ParseOneMillParaFromSection( pAppConf, 
                                                pAllMillPara, 
                                                pAppKey->key_value);
            if (nRet == ERR_FAILED)
            {
                goto Label_HRS_EquipParaCfg_LoadFromFile;
            }
        }
    }


    AppConf_Destroy(pAppConf);

    return pAllMillPara;

Label_HRS_EquipParaCfg_LoadFromFile:
    AppConf_Destroy(pAppConf);
    if (pAllMillPara != NULL)
    {
        NG_free(pAllMillPara);
    }

    return NULL;

}


CHRSEquipParaMgr::CHRSEquipParaMgr()
{
    m_pAllMillPara = NULL;
    m_pszCfgFile = NULL;
}


CHRSEquipParaMgr::~CHRSEquipParaMgr()
{
    if (m_pAllMillPara != NULL)
    {
        NG_free(m_pAllMillPara);
    }

    if (m_pszCfgFile != NULL)
    {
        NG_free(m_pszCfgFile);
    }
}


int CHRSEquipParaMgr::Init()
{

    int nRet;

    if (m_pszCfgFile == NULL
        || m_pszCfgFile[0] == '\0')
    {
        return ERR_FAILED;
    }

    nRet = LoadFromFile(m_pszCfgFile);

    if (nRet != ERR_SUCCESS)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CHRSEquipParaMgr::Close()
{
    return ERR_SUCCESS;
}


int CHRSEquipParaMgr::Run(UINT uDeltaTime)
{
    return ERR_SUCCESS;
}

void CHRSEquipParaMgr::SetCfgFile(char *pszCfgFile)
{
    if (m_pszCfgFile != NULL)
    {
        NG_free(m_pszCfgFile);
    }

    m_pszCfgFile = StrCopy(pszCfgFile);

    return;
}

int CHRSEquipParaMgr::LoadFromFile(char *pszCfgFile) // ��������װ�ر��ο�����������
{
    m_pAllMillPara = AllStandPara_LoadFromFile(m_pszCfgFile);
    if (m_pAllMillPara == NULL)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


HRS_STAND_PARA * CHRSEquipParaMgr::GetStandPara(int nStandNo) // ���һ��ܲ���
{
    if (nStandNo < 0 || nStandNo >= HRS_MAX_STAND_NUM)
    {
        return NULL;
    }

    return &(m_pAllMillPara->aEquipPara[nStandNo]);
}

int CHRSEquipParaMgr::GetAllStandPara(HRS_ALL_STAND_PARA *pAllStandPara)
{
    if (pAllStandPara == NULL || m_pAllMillPara == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(pAllStandPara, m_pAllMillPara, sizeof(HRS_ALL_STAND_PARA));

    return ERR_SUCCESS;
}

void *CHRSEquipParaMgr_Create(CGlobalInstance *pInstance,
                            void *pArg1,
                            void *pArg2,
                            int nArg)
{
    CHRSEquipParaMgr  *pMgr;

    pMgr = new CHRSEquipParaMgr;

    char *pszCfgFile = (char *)pArg1;

    pMgr->SetCfgFile(pszCfgFile);

    printf("CHRSEquipParaMgr Module created.\n");

    return pMgr;
}


int CHRSEquipParaMgr_Init(CGlobalInstance *pInstance, void *pModule)
{
    CHRSEquipParaMgr  *pMgr;
    int nRet;

    pMgr = (CHRSEquipParaMgr *)pModule;

    nRet = pMgr->Init();

    printf("CHRSEquipParaMgr Module Init.\n");

    return nRet;
}


int CHRSEquipParaMgr_Run(CGlobalInstance *pInstance,
                       void *pModule,
                       UINT uDeltaTime)
{
    CHRSEquipParaMgr  *pMgr;
    int nRet;

    pMgr = (CHRSEquipParaMgr *)pModule;

    nRet = pMgr->Run(uDeltaTime);

    printf("CHRSEquipParaMgr Module Run.\n");

    return nRet;
}


void CHRSEquipParaMgr_Destroy(void *pModule)
{
    CHRSEquipParaMgr  *pMgr;

    pMgr = (CHRSEquipParaMgr *)pModule;

    if (pMgr != NULL)
    {
        printf("CHRSEquipParaMgr Module Destroy.\n");

        delete pMgr;
    }

    return;
}
