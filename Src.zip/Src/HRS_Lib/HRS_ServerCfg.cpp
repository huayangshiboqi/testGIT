#include "NG.h"
#include "CfgAPI.h"
#include "HRS_ServerCfg.h"


#define HRS_KEY_FINISH_POS         "FinishPos"

#define HRS_KEY_THROW_STEEL_POS    "ThrowSteelPos"
#define HRS_KEY_THROW_ACCER        "ThrowAccer"

#define HRS_KEY_POWER_ACCER_POS    "PowerAccerPos"
#define HRS_KEY_POWER_ACCER        "PowerAccer"

#define HRS_KEY_TEMP_ACCER_POS     "TempAccerPos"
#define HRS_KEY_TEMP_ACCER         "TempAccer"

#define HRS_KEY_MAX_F7_SPEED       "MaxF7Speed"
#define HRS_KEY_MIN_F7_SPEED       "MinF7Speed"
#define HRS_KEY_MAX_LOOPER_ANGLE   "MaxLooperAngle"
#define HRS_KEY_MIN_LOOPER_ANGLE   "MinLooperAngle"
#define HRS_KEY_MAX_TENSION        "MaxTension"
#define HRS_KEY_MIN_TENSION        "MinTension"

#define HRS_KEY_GAUGE_RANGE_RATIO  "GaugeRangeRatio"

#define HRS_KEY_GAUGE_VALUE        "GaugeValue"


#define HRS_KEY_AGC_MODEL_INDEX    "AGCModelIndex"

#define HRS_KEY_GAUGE_SWITCH       "GaugeSwitch"
#define HRS_KEY_TEMP_SWITCH        "TempSwitch"
#define HRS_KEY_AGC_SWITCH         "AGCSwitch"
#define HRS_KEY_IS_WIRTE_LOG       "IsWriteLog"

#define HRS_KEY_ENTRY_TEMP_POS     "EntryTempPos"
#define HRS_KEY_WATER_TEMP         "WaterTemp"
#define HRS_KEY_K_TEMP_RATIO       "KTempRatio"



UINT HRS_DeformResistFactor_Hash(void *p, UINT uBucketCount)
{
    HRS_DEFORM_RESIST_FACTOR *pFactor;

    pFactor = (HRS_DEFORM_RESIST_FACTOR *)p;

    return HashString(pFactor->szSteelGrade, uBucketCount);
}


int HRS_DeformResistFactor_CompareName(void *p1, void *p2)
{
    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    char                      *pszSteelGradeName;

    pFactor = (HRS_DEFORM_RESIST_FACTOR *)p1;
    pszSteelGradeName = (char *)p2;

    return StrCompareNoCase(pFactor->szSteelGrade, pszSteelGradeName);
}


HRS_CALC_CFG *HRS_CalcCfg_Create()
{
    HRS_CALC_CFG *pCfg;

    pCfg = (HRS_CALC_CFG *)NG_malloc(sizeof(HRS_CALC_CFG));
    if (pCfg == NULL)
    {
        return NULL;
    }

    memset(pCfg, 0, sizeof(HRS_CALC_CFG));

    pCfg->CalcPara.nIsWriteLog = 1;

    pCfg->pDeformTable = HashTable_Create(16);

    return pCfg;
}


void HRS_CalcCfg_Destroy(void *pCalcCfg)
{
    HRS_CALC_CFG *pCfg;

    pCfg = (HRS_CALC_CFG *)pCalcCfg;

    if (pCfg != NULL)
    {
        HashTable_Destroy(pCfg->pDeformTable, NG_free);

        NG_free(pCfg);
    }

    return;
}


#if 0
# ���ø�ʽ

[CalcPara]
ThrowSteelPos = 220
ThrowAccer    = 1.0

PowerAccerPos = 180
PowerAccer    = 1.0

TempAccerPos  = 160
TempAccer     = 1.0



[Global]
# ������ = SectionName
Q235B  = Q235B_Section
Q345B  = Q345B_Section

[Q235B_Section]
dFactorA = 3.652089;         # ���ο����ع����a        
dFactorB = -1.665050;        # ���ο����ع����b        
dFactorC = 1.161469;         # ���ο����ع����c        
dFactorD = -0.587948;        # ���ο����ع����d        
dFactorN = -0.072103;        # ���ο����ع����n        

[Q345B_Section]
dFactorA = 3.711204;         # ���ο����ع����a        
dFactorB = -1.032179;        # ���ο����ع����b        
dFactorC = 1.085765;         # ���ο����ع����c        
dFactorD = -0.744100;        # ���ο����ع����d        
dFactorN = 0.030179;         # ���ο����ع����n        

#endif

HRS_DEFORM_RESIST_FACTOR  *HRS_CalcCfg_ReadSection(APPCONF *pAppConf,
                                                   char *pszSectionName,
                                                   char *pszSteelGradeName)
{
    APPSECTION  *pSection;
    APPKEY      *pAppKey;
    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    double dA;
    double dB;
    double dC;
    double dD;
    double dN;

    int nLen = (int)strlen(pszSteelGradeName);
    if (nLen >= HRS_MAX_GRADE_LEN)
    {
        return NULL;
    }


    pSection = AppConf_FindSection(pAppConf, pszSectionName);
    if (pSection == NULL)
    {
        return NULL;
    }

    pAppKey = AppSection_FindKey(pSection, "dFactorA");
    if (pAppKey == NULL)
    {
        return NULL;
    }
    dA = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "dFactorB");
    if (pAppKey == NULL)
    {
        return NULL;
    }
    dB = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "dFactorC");
    if (pAppKey == NULL)
    {
        return NULL;
    }
    dC = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, "dFactorD");
    if (pAppKey == NULL)
    {
        return NULL;
    }
    dD = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, "dFactorN");
    if (pAppKey == NULL)
    {
        return NULL;
    }
    dN = atof(pAppKey->key_value);

    pFactor = (HRS_DEFORM_RESIST_FACTOR *)NG_malloc(
        sizeof(HRS_DEFORM_RESIST_FACTOR));
    if (pFactor == NULL)
    {
        return NULL;
    }

    strcpy(pFactor->szSteelGrade, pszSteelGradeName);
    pFactor->dFactorA = dA;
    pFactor->dFactorB = dB;
    pFactor->dFactorC = dC;
    pFactor->dFactorD = dD;
    pFactor->dFactorN = dN;

    return pFactor;
}



int HRS_CalcCfg_ReadCalcPara(APPCONF *pAppConf, 
                             APPSECTION *pSection,
                             HRS_CALC_CFG *pCalcCfg)
{
    APPKEY *pAppKey;

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_FINISH_POS);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
                HRS_KEY_FINISH_POS,
                pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dFinishPos = atof(pAppKey->key_value);

    // 
    // �׸�λ�ú��׸ּ��ٶ�
    //

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_THROW_STEEL_POS);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_THROW_STEEL_POS,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dThrowSteelPos = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_THROW_ACCER);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_THROW_ACCER,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dThrowAccer = atof(pAppKey->key_value);

    // 
    // ���ʼ��ٶ�λ�ú͹��ʼ��ٶ�
    //
    pAppKey = AppSection_FindKey(pSection, HRS_KEY_POWER_ACCER_POS);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_POWER_ACCER_POS,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dPowerAccerPos = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_POWER_ACCER);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_POWER_ACCER,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }

    pCalcCfg->CalcPara.dPowerAccer = atof(pAppKey->key_value);

    // 
    // �¶ȼ��ٶ�λ�ú��¶ȼ��ٶ�
    //
    pAppKey = AppSection_FindKey(pSection, HRS_KEY_TEMP_ACCER_POS);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_TEMP_ACCER_POS,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dTempAccerPos = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_TEMP_ACCER);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_TEMP_ACCER,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dTempAccer = atof(pAppKey->key_value);


    // ��ȡ�����Сֵ
    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MAX_F7_SPEED);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MAX_F7_SPEED,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMaxF7Speed = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MIN_F7_SPEED);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MIN_F7_SPEED,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMinF7Speed = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MAX_LOOPER_ANGLE);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MAX_LOOPER_ANGLE,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMaxLooperAngle = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MIN_LOOPER_ANGLE);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MIN_LOOPER_ANGLE,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMinLooperAngle = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MAX_TENSION);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MAX_TENSION,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMaxTension = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_MIN_TENSION);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_MIN_TENSION,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dMinTension = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, HRS_KEY_GAUGE_RANGE_RATIO);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_GAUGE_RANGE_RATIO,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dGaugeRangeRatio = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_GAUGE_VALUE);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_GAUGE_VALUE,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dGaugeValue = atof(pAppKey->key_value);



    pAppKey = AppSection_FindKey(pSection, HRS_KEY_ENTRY_TEMP_POS);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_ENTRY_TEMP_POS,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dEntryTempPos = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_WATER_TEMP);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_WATER_TEMP,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dWaterTemp = atof(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_K_TEMP_RATIO);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_K_TEMP_RATIO,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.dKaTemp = atof(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, HRS_KEY_AGC_MODEL_INDEX);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_AGC_MODEL_INDEX,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.nAGCModelIndex = atoi(pAppKey->key_value);

    if ( pCalcCfg->CalcPara.nAGCModelIndex <= HRS_AGC_MODEL_INVALID 
        || pCalcCfg->CalcPara.nAGCModelIndex >= HRS_AGC_MODEL_MAX )
    {
        printf("AGCModelIndex is out of Range, Valid Value is Less than %d. CfgFile = %s\n", 
            HRS_AGC_MODEL_MAX,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }

    // ����Ŷ����غ��¶��Ŷ�����
    pAppKey = AppSection_FindKey(pSection, HRS_KEY_GAUGE_SWITCH);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_GAUGE_SWITCH,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.nGaugeSwitch = atoi(pAppKey->key_value);

  
    pAppKey = AppSection_FindKey(pSection, HRS_KEY_TEMP_SWITCH);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_TEMP_SWITCH,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.nTempSwitch = atoi(pAppKey->key_value);


    pAppKey = AppSection_FindKey(pSection, HRS_KEY_AGC_SWITCH);
    if (pAppKey == NULL)
    {
        printf("Read Key %s From CfgFile %s Failed.\n", 
            HRS_KEY_AGC_SWITCH,
            pAppConf->pszCfgFileName);

        return ERR_FAILED;
    }
    pCalcCfg->CalcPara.nAGCSwitch = atoi(pAppKey->key_value);

    pAppKey = AppSection_FindKey(pSection, HRS_KEY_IS_WIRTE_LOG);
    if (pAppKey == NULL)
    {
        pCalcCfg->CalcPara.nIsWriteLog = 1;
    }
    else
    {
        pCalcCfg->CalcPara.nIsWriteLog = atoi(pAppKey->key_value);
    }

    return ERR_SUCCESS;
}


HRS_CALC_CFG * HRS_CalcCfg_LoadFromFile(char *pszCfgFile)
{
    int             nRet;
    HRS_CALC_CFG   *pCalcCfg;
    APPCONF        *pAppConf;
    APPSECTION     *pSection;
    APPKEY         *pAppKey;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;


    pCalcCfg = NULL;

    pAppConf = AppConf_LoadFromFile(pszCfgFile);
    if (pAppConf == NULL)
    {
        return NULL;
    }

    pSection = AppConf_FindSection( pAppConf, "CalcPara");
    if (pSection == NULL)
    {
        goto Label_HRS_CalcCfg_LoadFromFile;
    }

    pCalcCfg = HRS_CalcCfg_Create();

    nRet = HRS_CalcCfg_ReadCalcPara(pAppConf, pSection, pCalcCfg);
    if (nRet == ERR_FAILED)
    {
        goto Label_HRS_CalcCfg_LoadFromFile;
    }

    pSection = AppConf_FindSection( pAppConf, "Global");
    if (pSection == NULL)
    {
        goto Label_HRS_CalcCfg_LoadFromFile;
    }



    AppSection_SearchStart(pSection);

    for (;;)
    {
        pAppKey = AppSection_SearchNext(pSection);
        if (pAppKey == NULL)
        {
            break;
        }

        pFactor = (HRS_DEFORM_RESIST_FACTOR *)HashTable_Find(
                                 pCalcCfg->pDeformTable, 
                                 pAppKey->key_name,
                                 HashString, 
                                 HRS_DeformResistFactor_CompareName);
        if (pFactor != NULL)
        {
            printf("Find dumplicate SteelGradeName: %s\n", pAppKey->key_name);
            goto Label_HRS_CalcCfg_LoadFromFile;
        }


        pFactor = (HRS_DEFORM_RESIST_FACTOR *)HRS_CalcCfg_ReadSection(
                                pAppConf, 
                                pAppKey->key_value,  // Section Name
                                pAppKey->key_name);  // szSteelGradeName
        if (pFactor == NULL)
        {
            goto Label_HRS_CalcCfg_LoadFromFile;
        }


        HashTable_Insert(pCalcCfg->pDeformTable, 
                         pFactor, 
                         HRS_DeformResistFactor_Hash);
    }

    AppConf_Destroy(pAppConf);

    return pCalcCfg;

Label_HRS_CalcCfg_LoadFromFile:
    AppConf_Destroy(pAppConf);
    if (pCalcCfg != NULL)
    {
        HRS_CalcCfg_Destroy(pCalcCfg);
    }

    return NULL;
}


//
// 
//
//

CHRSServerCfg::CHRSServerCfg()
{
    m_pCalcCfg   = NULL; 

    m_pszCfgFile = NULL;
}


CHRSServerCfg::~CHRSServerCfg()
{
    if (m_pCalcCfg != NULL)
    {
        HRS_CalcCfg_Destroy(m_pCalcCfg);
        m_pCalcCfg = NULL;
    }

    if (m_pszCfgFile != NULL)
    {
        NG_free(m_pszCfgFile);
        m_pszCfgFile = NULL;
    }
}


void CHRSServerCfg::SetCfgFile(char *pszCfgFile)
{
    if (m_pszCfgFile != NULL)
    {
        NG_free(m_pszCfgFile);
    }

    m_pszCfgFile = StrCopy(pszCfgFile);

    return;
}


int CHRSServerCfg::Init()
{
    int nRet;

    if (m_pszCfgFile == NULL
        || m_pszCfgFile[0] == '\0')
    {
        return ERR_FAILED;
    }

    nRet = LoadFromFile(m_pszCfgFile);

    if (nRet != ERR_SUCCESS)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CHRSServerCfg::Close()
{
    return ERR_SUCCESS;
}


int CHRSServerCfg::Run(UINT uDeltaTime)
{
    return ERR_SUCCESS;
}


int CHRSServerCfg::LoadFromFile(char *pszCfgFile) // ��������װ�ر��ο�����������
{
    m_pCalcCfg = HRS_CalcCfg_LoadFromFile(pszCfgFile);

    if (m_pCalcCfg == NULL)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


// ���ұ��ο�������
HRS_DEFORM_RESIST_FACTOR *CHRSServerCfg::FindDeformFactor(
                                             char *pszSteelGradeName)
{
    HRS_DEFORM_RESIST_FACTOR  *pFactor;

    if (m_pCalcCfg == NULL)
    {
        return NULL;
    }

    pFactor = (HRS_DEFORM_RESIST_FACTOR *)HashTable_Find(
                            m_pCalcCfg->pDeformTable, 
                            pszSteelGradeName, 
                            HashString, 
                            HRS_DeformResistFactor_CompareName);
    if (pFactor == NULL)
    {
        return NULL;
    }

    return pFactor;
}


////////////////////////////////////////////////////////////////////////////////
////
///
void *CHRSServerCfg_Create(CGlobalInstance *pInstance,
                            void *pArg1,
                            void *pArg2,
                            int nArg)
{
    CHRSServerCfg  *pMgr;

    pMgr = new CHRSServerCfg;

    char *pszCfgFile = (char *)pArg1;

    pMgr->SetCfgFile(pszCfgFile);

    printf("CHRSServerCfg Module created.\n");

    return pMgr;
}


int CHRSServerCfg_Init(CGlobalInstance *pInstance, void *pModule)
{
    CHRSServerCfg  *pMgr;
    int nRet;

    pMgr = (CHRSServerCfg *)pModule;

    nRet = pMgr->Init();

    printf("CHRSServerCfg Module Init.\n");

    return nRet;
}


int CHRSServerCfg_Run(CGlobalInstance *pInstance,
                       void *pModule,
                       UINT uDeltaTime)
{
    CHRSServerCfg  *pMgr;
    int nRet;

    pMgr = (CHRSServerCfg *)pModule;

    nRet = pMgr->Run(uDeltaTime);

    printf("CHRSServerCfg Module Run.\n");

    return nRet;
}


void CHRSServerCfg_Destroy(void *pModule)
{
    CHRSServerCfg  *pMgr;

    pMgr = (CHRSServerCfg *)pModule;

    if (pMgr != NULL)
    {
        printf("CHRSServerCfg Module Destroy.\n");

        delete pMgr;
    }

    return;
}
