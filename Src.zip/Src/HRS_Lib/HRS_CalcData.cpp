#include "NG_CheckSum.h"
#include "HRS_CalcData.h"


void HRS_HeaderSun(HRS_DATA_HEAD *pCommPackHead)
{
    if (NULL == pCommPackHead)
    {
        return;
    }
    char *pszSun  = NULL;

    int nSunPos = sizeof(HRS_DATA_HEAD) -2;

    pszSun = (char *)pCommPackHead;

    pCommPackHead->usCheckSum = GetByteCheckSum(pszSun, nSunPos);

    return;
}