#include "NG.h"
#include "HRS_LCO.h"
