
#include "NG.h"
#include "NG_CheckSum.h"
#include "MP.h"
#include "MP_Comm.h"
#include "HRS_Server_Comm.h"



#define HRS_VR_ACTION_CFG_FILE  "HRS_VRAction.cfg"
#define HRS_VR_RM_DATA_FILE     "HRS_VRRMData.cfg"
#define HRS_VR_FM_DATA_FILE     "HRS_VRFMData.cfg"




CHRSServerComm::CHRSServerComm()
{
    m_pCommInfo = NULL;

    m_pPrintfMsg = NULL;

    m_nFMDataNum = 0;
    m_nRMDataNum = 0;
    m_nVRDataNum = 0;

    m_nVRDataState = ERR_FAILED;

    memset(m_szPlateNoLog, 0,HRS_VR_PLATE_NO + 1);

}


CHRSServerComm::~CHRSServerComm()
{

    if (NULL != m_pPrintfMsg)
    {
        delete m_pPrintfMsg;
    }
}


int CHRSServerComm::SetVRAactionData(HRS_VR_ACTION *pVRAactionData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pVRAactionData )
    {
        return ERR_FAILED;
    }

    char *pszData = (char *)pVRAactionData;

    pVRAactionData->sTelID          = HRS_VR_ACTION_ID;
    pVRAactionData->sTel_DataLength = HRS_VR_ACTION_LEN;
    pVRAactionData->sHeaderSun      = 
               GetByteCheckSum(pszData, sizeof(HRS_PACK_HEAD) - sizeof(uint16));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pVRAactionData, sizeof(HRS_VR_ACTION));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_SERVER_VR_ACTION_PACK;

    m_nVRDataNum++;
    if (m_nVRDataNum %20 == 0)
    {
        m_pPrintfMsg->Printf_Message(HRS_VR_ACTION_CFG_FILE,
            sizeof(HRS_VR_ACTION), 
            (char *)pCommPack->pPackData);
        if (m_nVRDataNum > 1000)
        {
            m_nVRDataNum = 0;
        }
    }
    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSServerComm.log", "Server����������ʵ�������ĸ�VR.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetRMData(HRS_RM_DATA *pRMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pRMData)
    {
        return ERR_FAILED;
    }

    char *pszData = (char *)pRMData;

    pRMData->sTelID          = HRS_RM_DATA_ID;
    pRMData->sTel_DataLength = HRS_RM_DATA_LEN;
    pRMData->sHeaderSun      = 
               GetByteCheckSum(pszData, sizeof(HRS_PACK_HEAD) - sizeof(uint16));

    HRS_COMM_PACK_INFO *pCommPack = 
                HRS_Comm_PackInfo_Create(pRMData, sizeof(HRS_RM_DATA));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_SERVER_RM_DATA_PACK;

    m_nRMDataNum++;
    if (m_nRMDataNum %20 == 0)
    {
        printf("%s \n\n\n\n\n\n\n\n\n\n",pRMData->szPlateNo1);
        memcpy(m_szPlateNoLog, pRMData->szPlateNo1, HRS_VR_PLATE_NO);

        m_pPrintfMsg->SetLogName(m_szPlateNoLog);

        m_pPrintfMsg->Printf_Message(HRS_VR_RM_DATA_FILE,
            sizeof(HRS_RM_DATA), 
            (char *)pCommPack->pPackData);
        if (m_nRMDataNum > 1000)
        {
            m_nRMDataNum = 0;
        }
    }

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSServerComm.log", "Server���ʹ���VR��ػ������ݸ�VR.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetFMData(HRS_FM_DATA *pFMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pFMData)
    {
        return ERR_FAILED;
    }

    char *pszData = (char *)pFMData;

    pFMData->PackHead.sTelID          = HRS_FM_DATA_ID;
    pFMData->PackHead.sTelDataLength  = HRS_FM_DATA_LEN;
    pFMData->PackHead.sHeaderSun      = 
             GetByteCheckSum(pszData, sizeof(HRS_PACK_HEAD) - sizeof(uint16));

    HRS_COMM_PACK_INFO *pCommPack = 
                        HRS_Comm_PackInfo_Create(pFMData, sizeof(HRS_FM_DATA));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_SERVER_FM_DATA_PACK;

    m_nFMDataNum++;
    if (m_nFMDataNum %20 == 0)
    {
        m_pPrintfMsg->SetFileName(m_szPlateNoLog);

        m_pPrintfMsg->Printf_Message(HRS_VR_FM_DATA_FILE,
                                    sizeof(HRS_FM_DATA), 
                                    (char *)pCommPack->pPackData);
        if (m_nFMDataNum > 1000)
        {
            m_nFMDataNum = 0;
        }
    }

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSServerComm.log", "server���;���VR��ػ������ݸ�VR.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetIbaData(HRS_FM_DATA *pFMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_SUCCESS;
    }

    if (NULL == m_pCommInfo->hComm || NULL == pFMData)
    {
        return ERR_SUCCESS;
    }

    char *pszData = (char *)pFMData;

    pFMData->PackHead.sTelID          = HRS_FM_DATA_ID;
    pFMData->PackHead.sTelDataLength  = HRS_FM_DATA_LEN;
    pFMData->PackHead.sHeaderSun      = 
        GetByteCheckSum(pszData, sizeof(HRS_PACK_HEAD) - sizeof(uint16));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pFMData, sizeof(HRS_FM_DATA));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = 0;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    return ERR_SUCCESS;
}



int CHRSServerComm::GetRollInfo(HRS_ROLL_INFO &RollInfo)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    HRS_ROLL_INFO *pRollInfo = &RollInfo;
    MSGQUEUE *pRecvMsgQue;
    HRS_COMM_PACK_INFO *pCommPack;

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_SERVER_ROLL_INFO_PACK];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(pRollInfo, 0, sizeof(HRS_ROLL_INFO));

    if (pCommPack->nPackLen > sizeof(HRS_ROLL_INFO))
    {
        memcpy(pRollInfo, pCommPack->pPackData, sizeof(HRS_ROLL_INFO));
    }
    else
    {
        memcpy(pRollInfo, pCommPack->pPackData, pCommPack->nPackLen);
    }

    m_pPrintfMsg->Printf_Message(HRS_SERVER_ROLLER_COMM_CFG,
                                 sizeof(HRS_ROLL_INFO), 
                                 (char *)pCommPack->pPackData);

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "��ȡ����VR����ʵ������.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::GetVROperation(HRS_VR_OPERATION &VROperation)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    HRS_VR_OPERATION *pVROperation = &VROperation;
    MSGQUEUE *pRecvMsgQue;
    HRS_COMM_PACK_INFO *pCommPack;

    //printf("Start Get HRS_SERVER_VROPER_COMM_CFG\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_SERVER_VR_OPERATION_PACK];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(pVROperation, 0, sizeof(HRS_VR_OPERATION));

    if (pCommPack->nPackLen > sizeof(HRS_VR_OPERATION))
    {
        memcpy(pVROperation, pCommPack->pPackData, sizeof(HRS_VR_OPERATION));
    }
    else
    {
        memcpy(pVROperation, pCommPack->pPackData, pCommPack->nPackLen);
    }

    /*m_pPrintfMsg->Printf_Message(HRS_SERVER_VROPER_COMM_CFG,
                                 sizeof(HRS_VR_OPERATION), 
                                 (char *)pCommPack->pPackData);

    printf("Get HRS_SERVER_VROPER_COMM_CFG\n\n\n\n\n\n\n\n\n\n\n\n\n\n");*/

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "����VR��������.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetRMSched(HRS_RM_SCHED *pRMSched)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pRMSched)
    {
        return ERR_FAILED;
    }

    pRMSched->DataHead.nDataType  = HRS_GUI_RM_ROLL_PACK;
    pRMSched->DataHead.nPackLen   = sizeof(HRS_RM_SCHED);
    pRMSched->DataHead.nTunnelNo  = HRS_GUI_RM_ROLL_PACK;
    pRMSched->DataHead.usHeadBeat = HRS_GUI_RM_ROLL_PACK;
    pRMSched->DataHead.usCheckSum = 
                             GetByteCheckSum((const char *)&pRMSched->DataHead, 
                             (sizeof(HRS_DATA_HEAD) - sizeof(int)));

    HRS_COMM_PACK_INFO *pCommPack = 
                    HRS_Comm_PackInfo_Create(pRMSched, sizeof(HRS_RM_SCHED));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_RM_ROLL_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    printf("RM���������ݷ��ͣ�\n");

    error_log("HRSServerComm.log", "SetRMSched ������̼��������ݷ��͸�GUI.\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetFMSched(HRS_FM_SCHED *pFMSched)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pFMSched)
    {
        return ERR_FAILED;
    }

    pFMSched->DataHead.nDataType  = HRS_GUI_FM_ROLL_PACK;
    pFMSched->DataHead.nPackLen   = sizeof(HRS_RM_SCHED);
    pFMSched->DataHead.nTunnelNo  = HRS_GUI_FM_ROLL_PACK;
    pFMSched->DataHead.usHeadBeat = HRS_GUI_FM_ROLL_PACK;
    pFMSched->DataHead.usCheckSum = 
                            GetByteCheckSum((const char *)&pFMSched->DataHead, 
                            (sizeof(HRS_DATA_HEAD) - sizeof(int)));

    HRS_COMM_PACK_INFO *pCommPack = 
                    HRS_Comm_PackInfo_Create(pFMSched, sizeof(HRS_FM_SCHED));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_FM_ROLL_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    printf("FM���������ݷ��ͣ�\n");

    error_log("HRSServerComm.log", "SetFMSched ������̼��������ݷ��͸�GUI.\r\n");

    return ERR_SUCCESS;
}



int CHRSServerComm::SetSteelInfo(HRS_STEEL_INFO *pSteelInfo)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pSteelInfo)
    {
        return ERR_FAILED;
    }

    pSteelInfo->stDataHead.nDataType  = HRS_GUI_STEEL_INFO_PACK;
    pSteelInfo->stDataHead.nPackLen   = sizeof(HRS_STEEL_INFO);
    pSteelInfo->stDataHead.nTunnelNo  = HRS_GUI_STEEL_INFO_PACK;
    pSteelInfo->stDataHead.usHeadBeat = HRS_GUI_STEEL_INFO_PACK;
    pSteelInfo->stDataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pSteelInfo->stDataHead, 
        (sizeof(HRS_DATA_HEAD) - sizeof(int)));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pSteelInfo, sizeof(HRS_STEEL_INFO));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_STEEL_INFO_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    printf("SteelInfo���ݷ��ͣ�\n");

    //error_log("HRSServerComm.log", "SteelInfo���ݷ���.\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetServiceCommState(HRS_Service_CommError *pServiceCommState)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pServiceCommState)
    {
        return ERR_FAILED;
    }

    pServiceCommState->stDataHead.nDataType  = HRS_GUI_COMM_INFO;
    pServiceCommState->stDataHead.nPackLen   = sizeof(HRS_STEEL_INFO);
    pServiceCommState->stDataHead.nTunnelNo  = HRS_GUI_COMM_INFO;
    pServiceCommState->stDataHead.usHeadBeat = HRS_GUI_COMM_INFO;
    pServiceCommState->stDataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pServiceCommState->stDataHead, 
        (sizeof(HRS_DATA_HEAD) - sizeof(int)));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pServiceCommState, sizeof(HRS_STEEL_INFO));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_COMM_INFO;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    printf("CommInfo���ݷ��ͣ�\n");

    //error_log("HRSServerComm.log", "CommInfo���ݷ��ͣ�.\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetL1AveData(HRS_L1_SIMULATE_ALL_AVEDATA *pAveData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pAveData)
    {
        return ERR_FAILED;
    }

    pAveData->DataHead.nDataType  = HRS_GUI_L1_AVE_PACK;
    pAveData->DataHead.nPackLen   = sizeof(HRS_L1_SIMULATE_ALL_AVEDATA);
    pAveData->DataHead.nTunnelNo  = HRS_GUI_L1_AVE_PACK;
    pAveData->DataHead.usHeadBeat = HRS_GUI_L1_AVE_PACK;
    pAveData->DataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pAveData->DataHead, 
        (sizeof(HRS_DATA_HEAD) - sizeof(int)));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pAveData, sizeof(HRS_L1_SIMULATE_ALL_AVEDATA));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_L1_AVE_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    printf("L1Ave���ݷ��ͣ�\n");

    error_log("HRSServerComm.log", "L1��������ֵL1Ave���ݷ��͸�GUI��\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::GetRMData(HRS_RM_DATA_FROM_GUI &RMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    HRS_RM_DATA_FROM_GUI *pRMData = &RMData;
    MSGQUEUE *pRecvMsgQue;
    HRS_COMM_PACK_INFO *pCommPack;

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_GUI_RM_STRA_PACK];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(pRMData, 0, sizeof(HRS_RM_DATA_FROM_GUI));

    if (pCommPack->nPackLen > sizeof(HRS_RM_DATA_FROM_GUI))
    {
        memcpy(pRMData, pCommPack->pPackData, sizeof(HRS_RM_DATA_FROM_GUI));
    }
    else
    {
        memcpy(pRMData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "��ȡGUI������̼��������\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::GetFMData(HRS_FM_DATA_FROM_GUI &FMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    MSGQUEUE             *pRecvMsgQue;
    HRS_COMM_PACK_INFO   *pCommPack;

    HRS_FM_DATA_FROM_GUI *pFMData = &FMData;

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_GUI_FM_STRA_PACK];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(pFMData, 0, sizeof(HRS_FM_DATA_FROM_GUI));

    if (pCommPack->nPackLen > sizeof(HRS_FM_DATA_FROM_GUI))
    {
        memcpy(pFMData, pCommPack->pPackData, sizeof(HRS_FM_DATA_FROM_GUI));
    }
    else
    {
        memcpy(pFMData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "��ȡGUI������̼��������\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::GetRMSched(HRS_L1_RM_SCHED &RMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    MSGQUEUE             *pRecvMsgQue;
    HRS_COMM_PACK_INFO   *pCommPack;

    HRS_L1_RM_SCHED *pRMData = &RMData;

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_GUI_L1_RM_SCHED];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(&RMData, 0, sizeof(HRS_L1_RM_SCHED));

    if (pCommPack->nPackLen > sizeof(HRS_L1_RM_SCHED))
    {
        memcpy(&RMData, pCommPack->pPackData, sizeof(HRS_L1_RM_SCHED));
    }
    else
    {
        memcpy(&RMData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "��ȡ�������Ʋ�����\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::GetFMSched(HRS_L1_FM_SCHED &FMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    MSGQUEUE             *pRecvMsgQue;
    HRS_COMM_PACK_INFO   *pCommPack;

    HRS_L1_FM_SCHED *pFMData = &FMData;

    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_GUI_L1_FM_SCHED];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    memset(&FMData, 0, sizeof(HRS_L1_FM_SCHED));

    if (pCommPack->nPackLen > sizeof(HRS_L1_FM_SCHED))
    {
        memcpy(&FMData, pCommPack->pPackData, sizeof(HRS_L1_FM_SCHED));
    }
    else
    {
        memcpy(&FMData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSServerComm.log", "��ȡGUI����������������\r\n\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::CHRSServerCommInit()
{

    return ERR_SUCCESS;
}


void *HRS_Comm_Server_IBA_ThreadCreate(void *pData)
{
    HRS_COMM_INFO *pCommInfo = NULL;
    pCommInfo = (HRS_COMM_INFO *)pData;

    for (;;)
    {
        HRS_Comm_Server_IBA_Create(pCommInfo);
        if (NULL != pCommInfo->hComm)
        {
            pCommInfo->nCommNo = 8;

            break;
        }

        Sleep(60000);

        continue;
    }

    return NULL;
}


int CHRSServerComm::ServerCommCreate(char *pszCfgName)
{
    //����ͨ�Ž���
    if (NULL == pszCfgName)
    {
        return ERR_FAILED;
    }

    m_pPrintfMsg = new _CPrintfMessage;

    if (0 == StrCompare(pszCfgName, HRS_SERVER_GUI_COMM_CFG))
    {
        m_pCommInfo = HRS_Comm_Server_GUI_Create(pszCfgName);
        if (NULL != m_pCommInfo)
        {
            m_pCommInfo->nCommNo = HRS_SERVER_GUI_COMM_NO;
        }
    }
    else if (0 == StrCompare(pszCfgName, HRS_SERVER_L1_COMM_CFG))
    {
        m_pCommInfo = HRS_Comm_Server_L1_Create(pszCfgName);
        if (NULL != m_pCommInfo)
        {
            m_pCommInfo->nCommNo = HRS_SERVER_L1_COMM_NO;
        }
    }
    else if (0 == StrCompare(pszCfgName, HRS_SERVER_VR_COMM_CFG))
    {
        m_pCommInfo = HRS_Comm_Server_VR_Create(pszCfgName);
        if (NULL != m_pCommInfo)
        {
            m_pCommInfo->nCommNo = HRS_SERVER_VR_COMM_NO;
        }
        m_nVRDataState = ERR_SUCCESS;
    }

    /*if (0 == StrCompare(pszCfgName, HRS_SERVER_IBA_COMM_CFG))
    {
        HANDLE Hdata = 
            NG_CreateThread(HRS_Comm_Server_IBA_ThreadCreate, 
            m_pCommInfo, 
            NGTHREAD_RUNNING);
    }*/

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CHRSServerComm::ServerIBACommCreate()
{
    m_pCommInfo = 
        (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == m_pCommInfo)
    {
        return NULL;
    }

    m_pCommInfo->hComm = NULL;
    m_pCommInfo->hSendThread = NULL;

    HANDLE Hdata = 
        NG_CreateThread(HRS_Comm_Server_IBA_ThreadCreate, 
        m_pCommInfo, 
        NGTHREAD_RUNNING);

    NG_CloseHandle(Hdata);

    /*m_pCommInfo = 
        (HRS_COMM_INFO *)NG_malloc(sizeof(HRS_COMM_INFO) + 10);
    if (NULL == m_pCommInfo)
    {
        return NULL;
    }

    HRS_Comm_Server_IBA_Create(m_pCommInfo);
    if (NULL != m_pCommInfo->hComm)
    {
        m_pCommInfo->nCommNo = 8;
    }*/

    return ERR_SUCCESS;
}

int CHRSServerComm::SetL1FMClac(HRS_FM_SCHED *pFMSched)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (NULL == pFMSched)
    {
        return ERR_FAILED;
    }

    HRS_COMM_PACK_INFO *pCommPack = 
                      HRS_Comm_PackInfo_Create(pFMSched, sizeof(HRS_FM_SCHED));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_SERVER_FM_L1_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSServerComm.log", "Server���;�����̸�L1��\r\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::SetL1FMState()
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    m_pCommInfo->nEndState = ERR_FAILED;
    m_pCommInfo->nPackNum  = 0;

    return ERR_SUCCESS;
}


int CHRSServerComm::GetL1FMState()
{
    if (NULL == m_pCommInfo)
    {
        return -1;
    }

    return m_pCommInfo->nEndState;
}


int CHRSServerComm::GetL1FMNum()
{
    if (NULL == m_pCommInfo)
    {
        return -1;
    }

    return m_pCommInfo->nPackNum;
}

float CHRSServerComm::GetL1FMSteelTail()
{
    if (NULL == m_pCommInfo)
    {
        return -1;
    }

    return m_pCommInfo->FMData.OnePlateData[0].fStriptailPosition;
}


float CHRSServerComm::GetF7Speed()
{
    if (NULL == m_pCommInfo)
    {
        return -1;
    }

    return m_pCommInfo->FMData.stFM7Data.fSpeedReference;
}

float CHRSServerComm::GetF7SteelLen()
{
    if (NULL == m_pCommInfo)
    {
        return -1;
    }

    return m_pCommInfo->FMData.OnePlateData[0].fStripLength;
}

HRS_FM_DATA *CHRSServerComm::GetL1AveData()
{
    if (NULL == m_pCommInfo)
    {
        return NULL;
    }

    return &m_pCommInfo->FMData;
}


int CHRSServerComm::GetL1Data(HRS_FM_DATA &FMData)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    MSGQUEUE *pRecvMsgQue;
    HRS_COMM_PACK_INFO *pCommPack;
    HRS_FM_DATA *pFMData = &FMData;

    pFMData     = (HRS_FM_DATA *)NG_malloc(sizeof(HRS_FM_DATA));
    pRecvMsgQue = m_pCommInfo->pRecvMsgQue[HRS_SERVER_FM_L1_PACK];

    pCommPack = (HRS_COMM_PACK_INFO *)MsgQueue_RecvNoBlock(pRecvMsgQue);
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_FM_DATA))
    {
        memcpy(&FMData, pCommPack->pPackData, sizeof(HRS_FM_DATA));
    }
    else
    {
        memcpy(&FMData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    //error_log("HRSServerComm.log", "GetL1Data��\n");

    return ERR_SUCCESS;
}


int CHRSServerComm::ServerCommMsgQueEmpty(int nTunnelNo, DESTROYFUNC DestroyFunc)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    if (nTunnelNo < 0 || NULL == DestroyFunc)
    {
        return ERR_FAILED;
    }

    int nRet = HRS_Comm_MsgQue_Empty(m_pCommInfo, nTunnelNo, DestroyFunc);

    return nRet;
}



int CHRSServerComm::GetCommState(int nTunnelMin, int nTunnelMax, int nCommType)
{
    if (nTunnelMax <= 0 || nTunnelMax > 64
        || nTunnelMin < 0 || nTunnelMin> 64
        || nTunnelMax <= nTunnelMin)
    {
        return ERR_FAILED;
    }

    int anState[64] = {0};
    int i;

    m_nCommState = ERR_SUCCESS;

    if ( m_pCommInfo != NULL && m_pCommInfo->hComm != NULL )
    {
        for ( i = nTunnelMin; i < nTunnelMax; i++ )
        {
            if (HRS_KEEP_COMM_TYPE == nCommType)
            {
                anState[i] = MP_Comm_GetStatus(m_pCommInfo->hComm, i);
            }
            else if (HRS_SINGLE_RECV_COMM_TYPE == nCommType)
            {
                int nState = MP_Comm_GetStatus(m_pCommInfo->hComm, i);

                anState[i] = MP_Comm_GetRecvStatus(nState);
            }
            else if (HRS_SINGLE_SEND_COMM_TYPE == nCommType)
            {
                int nState = MP_Comm_GetStatus(m_pCommInfo->hComm, i);

                anState[i] = MP_Comm_GetSendStatus(nState);
            }
        }
    }
    else
    {
        for ( i = nTunnelMin; i < nTunnelMax; i++ )
        {
            anState[i] = RW_TCP_KEEP_STATUS_DOUBLE_INIT;
        }
    }

    for ( i = nTunnelMin; i < nTunnelMax; i++ )
    {
        if (0 != anState[i])
        {
            m_nCommState = ERR_FAILED;
            break;
        }
    }

    return m_nCommState;
}


int CHRSServerComm::SetVRDataState(int nVRDataState)
{
    m_nVRDataState = ERR_SUCCESS;;

    return ERR_SUCCESS;
}

