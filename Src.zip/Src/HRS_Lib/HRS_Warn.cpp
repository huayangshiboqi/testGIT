
#include "NG.h"
#include "RWWarn.h"
#include "HRS_Warn.h"



/** Method:    HRS_Warn_Init
    �澯ģ���ʼ�� 

    
    @return: int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_Warn_Init()
{
    int nRet;

    nRet = RWWarn_Init(HRS_WARN_CFG_FILE);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_Warn_Close
    �رո澯ģ�� 

    
    @return: void - ��
*/
void HRS_Warn_Close()
{
    RWWarn_Close(); 
}



/** Method:    HRS_Warn
    ���ݸ澯IDд�澯��Ϣ����Ӧ�ĵط�

    @param char * pszFile - �ļ���
    @param int nWarnId - �澯ID
    
    @return: int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_Warn(char *pszFile, int nWarnId)
{
    RW_WARN_NODE *pNode;
    int nDBLevel, nGuiLevel;

    pNode = RWWarn_GetNode(nWarnId);
    if ( pNode == NULL )
    {
        return ERR_FAILED;
    }

    nDBLevel = RWWarn_GetDBLevel();
    nGuiLevel = RWWarn_GetGuiLevel();

    if (pNode->nWarnLevel >= nDBLevel)
    {
        // д���ݡ�����
        return ERR_SUCCESS;
    }

    if (pNode->nWarnLevel >= nGuiLevel)
    {
        // дͼ�ν��档����
        return ERR_SUCCESS;
    }

    // д�ļ�
    RWWarn_Send(pszFile, nWarnId);   

    return ERR_SUCCESS;
}


int HRS_WarnMsg(char *pszFile, int nWarnId, char *pszMsg)
{
    RW_WARN_NODE *pNode;
    int nDBLevel, nGuiLevel;

    pNode = RWWarn_GetNode(nWarnId);
    if ( pNode == NULL )
    {
        return ERR_FAILED;
    }

    nDBLevel = RWWarn_GetDBLevel();
    nGuiLevel = RWWarn_GetGuiLevel();

    if (pNode->nWarnLevel >= nDBLevel)
    {
        // д���ݡ�����
        return ERR_SUCCESS;
    }

    if (pNode->nWarnLevel >= nGuiLevel)
    {
        // дͼ�ν��档����
        return ERR_SUCCESS;
    }

    // д�ļ�
//    RWWarn_SendMsg(pszFile, nWarnId, pszMsg);   

    return ERR_SUCCESS;
}

