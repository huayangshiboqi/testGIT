
#ifndef __HRS_ServerCOMM_H__
#define __HRS_ServerCOMM_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "HRS_CalcData.h"
#include "HRS_Comm.h"
#include "HRS_VR_Pack.h"

#include "Printf_Message.h"
#include "HRS_Service_CommError.h"

#define HRS_SERVER_COMM_CFG             "HRSServerComm.cfg"

#define HRS_SERVER_GUI_COMM_CFG        "HRSServerGUIComm.cfg"
#define HRS_SERVER_L1_COMM_CFG         "HRSServerL1Comm.cfg"
#define HRS_SERVER_VR_COMM_CFG         "HRSServerVRComm.cfg"

    //��VR����
#define HRS_SERVER_ROLLER_COMM_CFG         "HRSServerRollerComm.cfg"
#define HRS_SERVER_VROPER_COMM_CFG         "HRSServerVROperComm.cfg"


#define HRS_L1_TUNNEL_MAX           1
#define HRS_VR_RECVTUNNEL_MAX       2
#define HRS_VR_SENDTUNNEL_MAX       5


#define HRS_KEEP_COMM_TYPE           1
#define HRS_SINGLE_RECV_COMM_TYPE    2
#define HRS_SINGLE_SEND_COMM_TYPE    3

class CHRSServerComm
{
public:
    CHRSServerComm();
    ~CHRSServerComm();

    int CHRSServerCommInit();

    int ServerCommCreate(char *pszCfgName);
    int ServerIBACommCreate();

    //��IBAͨ��
    int SetIbaData(HRS_FM_DATA *pFMData);

    //���������ͨ�Ŵ���
    int SetVRAactionData(HRS_VR_ACTION *pVRAactionData);
    int SetRMData(HRS_RM_DATA *pFMData);
    int SetFMData(HRS_FM_DATA *pFMData);

    int GetRollInfo(HRS_ROLL_INFO &RollInfo);
    int GetVROperation(HRS_VR_OPERATION &VROperation);

    //��GUI��ͨ��
    int SetRMSched(HRS_RM_SCHED *pRMSched);
    int SetFMSched(HRS_FM_SCHED *pFMSched);

    int SetL1AveData(HRS_L1_SIMULATE_ALL_AVEDATA *pAveData);
    int SetSteelInfo(HRS_STEEL_INFO *pSteelInfo);
    int SetServiceCommState(HRS_Service_CommError *pServiceCommState);

    int GetRMData(HRS_RM_DATA_FROM_GUI &RMData);
    int GetFMData(HRS_FM_DATA_FROM_GUI &FMData);

    int GetRMSched(HRS_L1_RM_SCHED &RMData);
    int GetFMSched(HRS_L1_FM_SCHED &FMData);


    //��L1��ͨ��
    int SetL1FMClac(HRS_FM_SCHED *pFMSched);

    int GetL1Data(HRS_FM_DATA &FMData);
    HRS_FM_DATA *GetL1AveData();

    int SetL1FMState();
    int GetL1FMState();

    int GetL1FMNum();

    float GetL1FMSteelTail();
    float GetF7Speed();

    float GetF7SteelLen();

    int ServerCommMsgQueEmpty(int nTunnelNo, DESTROYFUNC DestroyFunc);

    //��ȡͨ��״̬
    int GetCommState(int nTunnelMin, int nTunnelMax, int nCommType);

    int SetVRDataState(int nVRDataState);

    //��Զ�̼����ͨ��
private:
    int m_nFMDataNum;
    int m_nRMDataNum;
    int m_nVRDataNum;

    int m_nVRDataState;

    char  m_szPlateNoLog[HRS_VR_PLATE_NO + 1];

    //ͨ��״̬
    int m_nCommState;

    _CPrintfMessage *m_pPrintfMsg;

    HRS_COMM_INFO *m_pCommInfo;                   //ͨ����Ϣ
};



#ifdef __cplusplus
}
#endif



#endif // __HRS_ServerCOMM_H__
