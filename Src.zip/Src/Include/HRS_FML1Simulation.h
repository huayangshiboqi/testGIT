
/* 
 *    FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      �����дģ������XXXXXX        
 *
 *    HISTORY
 *        2016-10-4 8:49 create by zhouweiming.
 *
 */
#ifndef __HRS_FML1Simulation_H__
#define __HRS_FML1Simulation_H__


#ifdef __cplusplus
extern "C" {
#endif

typedef struct HRS_TENSION_DATA_st {

} HRS_TENSION_DATA;




#ifdef __cplusplus
}
#endif



#endif // __HRS_FML1Simulation_H__
