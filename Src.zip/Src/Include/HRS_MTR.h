
/* 
 *    FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      ����ģ��        
 *
 *    HISTORY
 *        2016-10-4 8:50 create by zhouweiming.
 *
 */
#ifndef __HRS_MTR_H__
#define __HRS_MTR_H__

#include "CGameObj.h"
#include "CGlobalInstance.h"

class CHRSMtr :public CGameObj {
private:

public:
    CHRSMtr();
    virtual ~CHRSMtr();
public:
    virtual int Init();

    virtual int Close();

    virtual int Run(UINT uDeltaTime);  

};


#ifdef __cplusplus
extern "C" {
#endif



void * CHRSMtr_Create(CGlobalInstance *pInstance,
                        void *pArg1,
                        void *pArg2,
                        int nArg);
int CHRSMtr_Init(CGlobalInstance *pInstance, void *pModule);

int CHRSMtr_Run(CGlobalInstance *pInstance,
                    void *pModule,
                    UINT uDeltaTime);

void CHRSMtr_Destroy(void *pModule);


#ifdef __cplusplus
}
#endif



#endif // __HRS_MTR_H__
