
/* 
 *    FILE
 *      C:\svn_Company\AnyangSteckleMill\Src\Include
 *
 *    DESCRIPTION
 *      �澯ģ��        
 *
 *    HISTORY
 *        2016-7-21 13:26 create by zhouweiming.
 *
 */
#ifndef __HRS_Warn_H__
#define __HRS_Warn_H__


#ifdef __cplusplus
extern "C" {
#endif

#define HRS_WARN_CFG_FILE     "HRS_Warn.cfg"

/** Method:    HRS_Warn_Init
    �澯ģ���ʼ�� 

    
    @return: int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_Warn_Init();


/** Method:    HRS_Warn_Close
    �رո澯ģ�� 

    
    @return: void - ��
*/
void HRS_Warn_Close();


/** Method:    HRS_Warn
    ���ݸ澯IDд�澯��Ϣ����Ӧ�ĵط�

    @param char * pszFile - �ļ���
    @param int nWarnId - �澯ID
    
    @return: int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_Warn(char *pszFile, int nWarnId);

int HRS_WarnMsg(char *pszFile, int nWarnId, char *pszMsg);

#ifdef __cplusplus
}
#endif



#endif // __HRS_Warn_H__
