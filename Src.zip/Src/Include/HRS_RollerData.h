#ifndef __HRS_ROLLERDATA_H__
#define __HRS_ROLLERDATA_H__

#define   HRS_ROLLER_ITEM_NUM           7

#define     HRS_ROLLER_DATA_LIST      \
                     M_T(STAND_NO),    M_T(ROLLER_NO),       M_T(ROLLER_DIA), \
                     M_T(ROLLER_CROW), M_T(ROLLER_MATERIAL), M_T(ROLLER_TONS),\
                     M_T(ROLLER_STATE),M_T(ROLLER_TYPE), M_T(ROLLER_POS)

#define     HRS_ROLLER_DATA_UNIT_LIST   \
                            M_T(\0),      M_T((mm)),    M_T((t)), \
                            M_T(\0),      M_T(\0),      M_T(\0), \
                            M_T(\0),      M_T(\0),      M_T(\0)

/* 
 * ������Ϣ
 */
#define M_T(x) HRS_ROLLER_DATA_##x
    enum HRSRollerDataEnum   { HRS_ROLLER_DATA_LIST };  
#undef  M_T

#define  HRS_RILLER_INFO_LEN                12
#define  HRS_ROLLER_TYPE_NO                 8
#define  HRS_ROLLER_GUI_TYPE_NO             40

#define  HRS_ROLLLER_MAX                    64

#define HRS_ROLLER_E12                      1
#define HRS_ROLLER_R1                       3
#define HRS_ROLLER_R2B                      5
#define HRS_ROLLER_R2W                      7
#define HRS_ROLLER_E3                       9
#define HRS_ROLLER_FB                       13
#define HRS_ROLLER_FWL                      15
#define HRS_ROLLER_FWH                      27


#define HRS_ROLLER_E1WS_STR                 "E1WS"
#define HRS_ROLLER_E1OS_STR                 "E1OS"
#define HRS_ROLLER_R1T_STR                  "R1T"
#define HRS_ROLLER_R1B_STR                  "R1B"
#define HRS_ROLLER_E2WS_STR                 "E2WS"
#define HRS_ROLLER_E2OS_STR                 "E2OS"
#define HRS_ROLLER_R2BT_STR                 "R2BT"
#define HRS_ROLLER_R2BB_STR                 "R2BB"
#define HRS_ROLLER_R2WT_STR                 "R2WT"
#define HRS_ROLLER_R2WB_STR                 "R2WB"
#define HRS_ROLLER_E3WS_STR                 "E3WS"
#define HRS_ROLLER_E3OS_STR                 "E3OS"
#define HRS_ROLLER_F1BT_STR                 "F1BT"
#define HRS_ROLLER_F1BB_STR                 "F1BB"
#define HRS_ROLLER_F1WT_STR                 "F1WT"
#define HRS_ROLLER_F1WB_STR                 "F1WB"
#define HRS_ROLLER_F2BT_STR                 "F2BT"
#define HRS_ROLLER_F2BB_STR                 "F2BB"
#define HRS_ROLLER_F2WT_STR                 "F2WT"
#define HRS_ROLLER_F2WB_STR                 "F2WB"
#define HRS_ROLLER_F3BT_STR                 "F3BT"
#define HRS_ROLLER_F3BB_STR                 "F3BB"
#define HRS_ROLLER_F3WT_STR                 "F3WT"
#define HRS_ROLLER_F3WB_STR                 "F3WB"
#define HRS_ROLLER_F4BT_STR                 "F4BT"
#define HRS_ROLLER_F4BB_STR                 "F4BB"
#define HRS_ROLLER_F4WT_STR                 "F4WT"
#define HRS_ROLLER_F4WB_STR                 "F4WB"
#define HRS_ROLLER_F5BT_STR                 "F5BT"
#define HRS_ROLLER_F5BB_STR                 "F5BB"
#define HRS_ROLLER_F5WT_STR                 "F5WT"
#define HRS_ROLLER_F5WB_STR                 "F5WB"
#define HRS_ROLLER_F6BT_STR                 "F6BT"
#define HRS_ROLLER_F6BB_STR                 "F6BB"
#define HRS_ROLLER_F6WT_STR                 "F6WT"
#define HRS_ROLLER_F6WB_STR                 "F6WB"
#define HRS_ROLLER_F7BT_STR                 "F7BT"
#define HRS_ROLLER_F7BB_STR                 "F7BB"
#define HRS_ROLLER_F7WT_STR                 "F7WT"
#define HRS_ROLLER_F7WB_STR                 "F7WB"


//����ֱ��
//E1	R1	E2	R2	E3	F1	F2	F3	F4	F5	F6	F7
//1.2	1.35	1.2	1.25	0.64	0.83	0.83	0.83	0.83	0.72	0.72	0.72
//1.1	1.2	    1.1	1.1	    0.56	0.73	0.73	0.73	0.73	0.63	0.63	0.63
//
#define HRS_ROLLER_NO_E12_MAX                1.2
#define HRS_ROLLER_NO_R1_MAX                 1.35
#define HRS_ROLLER_NO_R2B_MAX                1.55
#define HRS_ROLLER_NO_R2W_MAX                1.25
#define HRS_ROLLER_NO_E3_MAX                 0.64
#define HRS_ROLLER_NO_FB_MAX                 1.55
#define HRS_ROLLER_NO_FWL_MAX                0.83
#define HRS_ROLLER_NO_FWH_MAX                0.72

#define HRS_ROLLER_NO_E12_MIN                1.1
#define HRS_ROLLER_NO_R1_MIN                 1.2
#define HRS_ROLLER_NO_R2B_MIN                1.4
#define HRS_ROLLER_NO_R2W_MIN                1.1
#define HRS_ROLLER_NO_E3_MIN                 0.56
#define HRS_ROLLER_NO_FB_MIN                 1.4
#define HRS_ROLLER_NO_FWL_MIN                0.73
#define HRS_ROLLER_NO_FWH_MIN                0.63


typedef enum HRS_ROLLER_NO_em {
    HRS_ROLLER_NO_INVALID = -1,

    HRS_ROLLER_NO_E1WS,
    HRS_ROLLER_NO_E1OS,
    HRS_ROLLER_NO_R1T,
    HRS_ROLLER_NO_R1B,
    HRS_ROLLER_NO_E2WS,
    HRS_ROLLER_NO_E2OS,
    HRS_ROLLER_NO_R2BT,
    HRS_ROLLER_NO_R2BB,
    HRS_ROLLER_NO_R2WT,
    HRS_ROLLER_NO_R2WB,
    HRS_ROLLER_NO_E3WS,
    HRS_ROLLER_NO_E3OS,
    HRS_ROLLER_NO_F1BT,
    HRS_ROLLER_NO_F1BB,
    HRS_ROLLER_NO_F1WT,
    HRS_ROLLER_NO_F1WB,
    HRS_ROLLER_NO_F2BT,
    HRS_ROLLER_NO_F2BB,
    HRS_ROLLER_NO_F2WT,
    HRS_ROLLER_NO_F2WB,
    HRS_ROLLER_NO_F3BT,
    HRS_ROLLER_NO_F3BB,
    HRS_ROLLER_NO_F3WT,
    HRS_ROLLER_NO_F3WB,
    HRS_ROLLER_NO_F4BT,
    HRS_ROLLER_NO_F4BB,
    HRS_ROLLER_NO_F4WT,
    HRS_ROLLER_NO_F4WB,
    HRS_ROLLER_NO_F5BT,
    HRS_ROLLER_NO_F5BB,
    HRS_ROLLER_NO_F5WT,
    HRS_ROLLER_NO_F5WB,
    HRS_ROLLER_NO_F6BT,
    HRS_ROLLER_NO_F6BB,
    HRS_ROLLER_NO_F6WT,
    HRS_ROLLER_NO_F6WB,
    HRS_ROLLER_NO_F7BT,
    HRS_ROLLER_NO_F7BB,
    HRS_ROLLER_NO_F7WT,
    HRS_ROLLER_NO_F7WB,

    HRS_ROLLER_NO_MAX
} HRS_ROLLER_NO_EM;


#define HRS_ROLLER_DATA_CFG_COL_NUM    9

typedef struct HRS_ROLLER_DATA_st
{
    char szRollerNo[HRS_RILLER_INFO_LEN];
    char szRollerDIA[HRS_RILLER_INFO_LEN];
    char szRollerCrow[HRS_RILLER_INFO_LEN];
    char szRollerMaterial[HRS_RILLER_INFO_LEN];
    char szRollerTons[HRS_RILLER_INFO_LEN];
    char szRollerType[HRS_RILLER_INFO_LEN];
    char szStandNo[HRS_RILLER_INFO_LEN];
    char szRollPos[HRS_RILLER_INFO_LEN];
    char szRollState[HRS_RILLER_INFO_LEN];

    int    nRollerUseState;
    int    nRollerEmptyState;
    int    nIsShowed;
    int    nIsSaveState;

} HRS_ROLLER_DATA;



typedef enum HRS_ROLLER_DATA_INDEX_em {
    HRS_ROLLER_DATA_INVALID = -1,

    HRS_ROLLER_DATA_ROLLER_ID = 0,
    HRS_ROLLER_DATA_DIA,
    HRS_ROLLER_DATA_CROW,
    HRS_ROLLER_DATA_MATERIAL,
    HRS_ROLLER_DATA_TONS,
    HRS_ROLLER_DATA_TYPE,
    HRS_ROLLER_DATA_STAND_TYPE,
    HRS_ROLLER_DATA_POS,
    HRS_ROLLER_DATA_STATE,
    HRS_ROLLER_DATA_USE_STATE,
    HRS_ROLLER_DATA_EMPTY_STATE,
    HRS_ROLLER_DATA_IS_SHOWED,

    HRS_ROLLER_DATA_MAX
};


typedef struct HRS_ROLLER_GROUP_st
{
    HRS_ROLLER_DATA     stRollerData[HRS_ROLLLER_MAX];
    int                 nRollerDataNum;
}HRS_ROLLER_GROUP;


typedef struct HRS_ROLLER_DATA_MGR_st
{
    HRS_ROLLER_DATA     *ppstData[HRS_ROLLER_NO_MAX];
} HRS_ROLLER_DATA_MGR;


typedef enum HRS_ROLLER_GROUP_NO_em {
    HRS_ROLLER_GROUP_NO_INVALID = -1,

    HRS_ROLLER_GROUP_NO_E12 = 0,
    HRS_ROLLER_GROUP_NO_R1, 
    HRS_ROLLER_GROUP_NO_R2B,
    HRS_ROLLER_GROUP_NO_R2W,
    HRS_ROLLER_GROUP_NO_E3, 
    HRS_ROLLER_GROUP_NO_FB, 
    HRS_ROLLER_GROUP_NO_FWL,
    HRS_ROLLER_GROUP_NO_FWH,

    HRS_ROLLER_GROUP_NO_MAX
} HRS_ROLLER_GROUP_NO_EM;

typedef struct HRS_ROLLER_TOTAL_DATA_MGR_st
{
    HRS_ROLLER_GROUP     aRollerDataOne[HRS_ROLLER_GROUP_NO_MAX];

} HRS_ROLLER_TOTAL_DATA_MGR;


static double g_RollerDiaMax[HRS_ROLLER_GROUP_NO_MAX] = {HRS_ROLLER_NO_E12_MAX ,
                                                  HRS_ROLLER_NO_R1_MAX ,
                                                  HRS_ROLLER_NO_R2B_MAX ,
                                                  HRS_ROLLER_NO_R2W_MAX ,
                                                  HRS_ROLLER_NO_E3_MAX , 
                                                  HRS_ROLLER_NO_FB_MAX  ,
                                                  HRS_ROLLER_NO_FWL_MAX ,
                                                  HRS_ROLLER_NO_FWH_MAX };

static double g_RollerDiaMin[HRS_ROLLER_GROUP_NO_MAX] = {HRS_ROLLER_NO_E12_MIN,
                                                  HRS_ROLLER_NO_R1_MIN ,
                                                  HRS_ROLLER_NO_R2B_MIN ,
                                                  HRS_ROLLER_NO_R2W_MIN ,
                                                  HRS_ROLLER_NO_E3_MIN , 
                                                  HRS_ROLLER_NO_FB_MIN ,
                                                  HRS_ROLLER_NO_FWL_MIN ,
                                                  HRS_ROLLER_NO_FWH_MIN };




HRS_ROLLER_TOTAL_DATA_MGR *HRS_TotalRollerDataMgr_Create();
HRS_ROLLER_DATA_MGR *HRS_ShowRollerDataMgr_Create(HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);

void HRS_TotalRollerDataMgr_Destory(HRS_ROLLER_TOTAL_DATA_MGR *pRollTotalData);
void HRS_ShowRollerDataMgr_Destory(HRS_ROLLER_DATA_MGR *pRollData);

int SearchRollerFromGroup(char *pszRollerName, HRS_ROLLER_GROUP *pRollerData);

int SearchRollerFromTotal(char *pszRollerName, HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);

HRS_ROLLER_DATA*HRS_SearchRolller(char *pszRollerName, 
                                  HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);
HRS_ROLLER_DATA *HRS_TotalRollerDataMgr_Find(
                                  HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                                  char *pszRollerType);

int GetGroupNo(int nRollerNo);

int HRS_TotalRollerDataMgr_Save(char *pszRollerName,
                                HRS_ROLLER_DATA_MGR *pRollerData,
                                HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);

int HRS_TotalRollerMgr_Load(char *pszFileName, HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);


HRS_ROLLER_GROUP *HRS_GetRollerDataOneByRow(
                                        HRS_ROLLER_TOTAL_DATA_MGR *pTotalMgr, 
                                        int nRow);

int HRS_TotalRollerDataMgr_Add(int nRow,
                               HRS_ROLLER_DATA_MGR *pRollerDataMgr,
                               HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);

int HRS_TotalRollerDataMgr_Delet(int nRow,
                                 HRS_ROLLER_DATA_MGR *pRollerDataMgr,
                                 HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr);

// ��ѯ�������Ĺ������뾶 
int HRS_TotalRollerDataMgr_GetRMWorkingRadius(
                            HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                            double *padRadius, int nCount, char *pszOutErr);

// ��ѯ�������Ĺ������뾶
int HRS_TotalRollerDataMgr_GetFMWorkingRadius(
                            HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr,
                            double *padRadius, int nCount, char *pszOutErr);

#endif // __HRS_ROLLERDATA_H__
