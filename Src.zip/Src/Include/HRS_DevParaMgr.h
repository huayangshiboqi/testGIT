
/* 
 *	FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *	DESCRIPTION
 *      �����дģ������XXXXXX		
 *
 *	HISTORY
 *		2016-10-4 8:49 create by zhouweiming.
 *
 */
#ifndef __HRS_DevParaMgr_H__
#define __HRS_DevParaMgr_H__

#include "CGameObj.h"
#include "CGlobalInstance.h"

class CHRSDevParaMgr :public CGameObj {
private:

public:
    CHRSDevParaMgr();
    virtual ~CHRSDevParaMgr();
public:
    virtual int Init();

    virtual int Close();

    virtual int Run(UINT uDeltaTime);  

};


#ifdef __cplusplus
extern "C" {
#endif



void * CHRSDevParaMgr_Create(CGlobalInstance *pInstance,
                        void *pArg1,
                        void *pArg2,
                        int nArg);
int CHRSDevParaMgr_Init(CGlobalInstance *pInstance, void *pModule);

int CHRSDevParaMgr_Run(CGlobalInstance *pInstance,
                    void *pModule,
                    UINT uDeltaTime);

void CHRSDevParaMgr_Destroy(void *pModule);


#ifdef __cplusplus
}
#endif



#endif // __HRS_DevParaMgr_H__