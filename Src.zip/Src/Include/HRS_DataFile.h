
/* 
 *    FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      �����дģ������XXXXXX        
 *
 *    HISTORY
 *        2016-10-4 8:49 create by zhouweiming.
 *
 */
#ifndef __HRS_DataFile_H__
#define __HRS_DataFile_H__


#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif



#endif // __HRS_DataFile_H__