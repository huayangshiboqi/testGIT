
/* 
 *    FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      �豸�������ù���       
 *
 *    HISTORY
 *        2016-10-4 8:49 create by zhouweiming.
 *
 */
#ifndef __HRS_EquipParaMgr_H__
#define __HRS_EquipParaMgr_H__

#include "CGameObj.h"
#include "CGlobalInstance.h"

#include "HRS_CalcData.h"




#if 0

[Global]
Mill =  RM1_Section
Mill =  RM2_Section


[RM1_Section]
MillNo = 1
RollerMaterial = 233;

[RM2_Section]
MillNo = 2
RollerMaterial = 233;


#endif


HRS_ALL_STAND_PARA *AllStandPara_LoadFromFile(char *pszCfgFile);



class CHRSEquipParaMgr :public CGameObj {
private:
    HRS_ALL_STAND_PARA   *m_pAllMillPara;
    char                 *m_pszCfgFile;  // �����ļ���

public:
    CHRSEquipParaMgr();
    virtual ~CHRSEquipParaMgr();

    void SetCfgFile(char *pszCfgFile);
public:
    virtual int Init();

    virtual int Close();

    virtual int Run(UINT uDeltaTime);  

public:
    int LoadFromFile(char *pszCfgFile);

    HRS_STAND_PARA *GetStandPara(int nStandNo);

    int GetAllStandPara(HRS_ALL_STAND_PARA *pAllStandPara);
};


#ifdef __cplusplus
extern "C" {
#endif



void * CHRSEquipParaMgr_Create(CGlobalInstance *pInstance,
                        void *pArg1,
                        void *pArg2,
                        int nArg);
int CHRSEquipParaMgr_Init(CGlobalInstance *pInstance, void *pModule);

int CHRSEquipParaMgr_Run(CGlobalInstance *pInstance,
                    void *pModule,
                    UINT uDeltaTime);

void CHRSEquipParaMgr_Destroy(void *pModule);


#ifdef __cplusplus
}
#endif



#endif // __HRS_EquipParaMgr_H__
