
/* 
 *    FILE
 *      C:\svn_Company\HotContinuousRoll\Src\HRS_Lib
 *
 *    DESCRIPTION
 *      ģ��������        
 *
 *    HISTORY
 *        2016-10-10 9:48 create by zhouweiming.
 *
 */
#ifndef __HRS_ModuleName_H__
#define __HRS_ModuleName_H__


#ifdef __cplusplus
extern "C" {
#endif

#define  HRS_MOD_NAME_HRS_SchedulePlan     "CHRSSchedulePlan"
#define  HRS_MOD_NAME_HRS_MTR              "CHRSMtr"
#define  HRS_MOD_NAME_HRS_EquipParaMgr     "CHRSEquipParaMgr"
#define  HRS_MOD_NAME_HRS_ServerCfg        "CHRSServerCfg"


#ifdef __cplusplus
}
#endif



#endif // __HRS_ModuleName_H__