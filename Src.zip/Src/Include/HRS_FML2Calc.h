
/* 
 *    FILE
 *      c:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      �����дģ������XXXXXX        
 *
 *    HISTORY
 *        2016-10-4 8:50 create by zhouweiming.
 *
 */
#ifndef __HRS_FML2Calc_H__
#define __HRS_FML2Calc_H__


#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif



#endif // __HRS_FML2Calc_H__