
/** 
 *    FILE
 *      C:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      ��̨�����L1���������ͨ��        
 *
 *    HISTORY
 *        2016-10-28 17:44 create by zhouweiming.
 *
 */
#ifndef __HRS_L1Comm_H__
#define __HRS_L1Comm_H__


#ifdef __cplusplus
extern "C" {
#endif

typedef struct HRS_L1COMM_st {
    HANDLE hMPCom;       // ͨ�ž��
    char   *pszCfgfile;  // ͨ�������ļ���
} HRS_L1COMM;

HRS_L1COMM *HRS_L1Comm_Create(char *pszTunnelCfgFile);
HRS_L1COMM *HRS_L1Comm_Open(char *pszTunnelCfgFile);
void HRS_L1Comm_Destroy(HRS_L1COMM *pL1Comm);

int HRS_L1Comm_SendData(HRS_L1COMM *pL1Comm, void *pData, int nDataLen);
int HRS_L1Comm_RecvData(HRS_L1COMM *pL1Comm, void *pBuf, int nBufLen);


#ifdef __cplusplus
}
#endif



#endif // __HRS_L1Comm_H__