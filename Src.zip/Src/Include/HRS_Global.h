
/* 
 *    FILE
 *      C:\svn_Company\HotContinuousRoll\Src\Include
 *
 *    DESCRIPTION
 *      ȫ���õ��ĺ���������        
 *
 *    HISTORY
 *        2016-10-11 15:08 create by zhouweiming.
 *
 */
#ifndef __HRS_Global_H__
#define __HRS_Global_H__


#ifdef __cplusplus
extern "C" {
#endif

#define  HRS_SUCCESS_STR    "#!Success\r\n"

CGlobalInstance *HRS_GetGlobalInstance();



#ifdef __cplusplus
}
#endif



#endif // __HRS_Global_H__
