
#ifndef __HRS_Service_CommError_H__
#define __HRS_Service_CommError_H__


#ifdef __cplusplus
extern "C" {
#endif
#include "HRS_CalcData.h"


typedef struct HRS_Service_CommError_st
{
    HRS_DATA_HEAD stDataHead;

    int nServiceL1State;
    int nServiceVRState;

}HRS_Service_CommError;


#ifdef __cplusplus
}
#endif



#endif // __HRS_Service_CommError_H__