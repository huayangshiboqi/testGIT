
/* 
 *	FILE
 *      C:\svn_Company\HotContinuousRoll\Src\Include
 *
 *	DESCRIPTION
 *      ����ģ��		
 *
 *	HISTORY
 *		2016-10-25 15:01 create by zhouweiming.
 *
 */
#ifndef __HRS_Calc_H__
#define __HRS_Calc_H__

#include "HRS_CalcData.h"

#ifdef __cplusplus
extern "C" {
#endif



HANDLE HRS_Calc_RM_Create(HRS_PLAN_DATA *pPlanData,
                          HRS_RM_STRATEGY_DATA *pStrategyData,
                          HRS_PLATE_DATA    *pPlateData,
                          HRS_ALL_STAND_PARA *pAllStandPara,
                          HRS_DEFORM_RESIST_FACTOR *pDeformFactor
                          );

int HRS_Calc_RM_Gauge(HANDLE hCalcData, 
                      HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge);

int HRS_Calc_RM_Speed(HANDLE hCalcData, HRS_RM_ALL_SPEED *pAllSpeed);
int HRS_Calc_RM_Temp(HANDLE hCalcData, HRS_RM_ALL_TEMP *pAllTemp);

int HRS_Calc_RM_RollingForce(HANDLE hCalcData, 
                             HRS_RM_ALL_ROLL_FORCE *pAllRollForce);
int HRS_Calc_RM_Gap(HANDLE hCalcData, HRS_RM_ALL_GAP *pAllGap);

int HRS_Calc_RM_AllData(HANDLE hCalcData, HRS_RM_ALL_OUT_DATA *pAllOutData);

#ifdef __cplusplus
}
#endif



#endif // __HRS_Calc_H__