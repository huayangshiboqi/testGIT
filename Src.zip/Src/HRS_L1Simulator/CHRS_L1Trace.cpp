#include <assert.h>
#include <math.h>
#include <direct.h>
#include "NG.h"
#include "NG_Clock.h"
#include "NG_CheckSum.h"
#include "NG_Path.h"
#include "NG_FastRandom.h"
#include "HRS_GaugeSimulator.h"
#include "CHRS_L1Trace.h"
#include "HRS_TempCalc.h"
#include "HRS_CalcSpeed.h"



void HRS_Position_Destroy(HRS_POSITION *pPosition)
{
    int i;

    if (pPosition != NULL)
    {
        for (i = 0; i < HRS_FINISHMILL_NUM+1; i++)
        {
            if (pPosition->m_ppSteelSection[i] != NULL)
            {
                delete pPosition->m_ppSteelSection[i];
            }
        }

        NG_free(pPosition);
    }

    return;
}



CHRS_L1Trace::CHRS_L1Trace()
{
    m_bHaveSteel = false;
    m_bFinish    = false;

    m_pFastRandom = FastRandom_Init(NGClock_GetTicks());
    
    m_pAllStandPara = NULL;
    m_pCalcCfg      = NULL;

    m_pPositionArray  = DArray_Create(1024, (DESTROYFUNC)HRS_Position_Destroy, NULL, NULL);
    m_pSimulatorArray = DArray_Create(1024, NG_free, NULL, NULL);

    m_pszMsgBuf = NULL;
    m_nMsgBufLen = 64 * 1024 * 1024;

    m_nUpdateTimes = 0;

    m_dPaoGangPos = -1.0;
}


CHRS_L1Trace::~CHRS_L1Trace()
{
    if (m_pCalcCfg != NULL)
    {
        HRS_CalcCfg_Destroy(m_pCalcCfg);
        m_pCalcCfg = NULL;
    }

    if (m_pAllStandPara != NULL)
    {
        NG_free(m_pAllStandPara);
        m_pAllStandPara = NULL;
    }

    if (m_pPositionArray != NULL)
    {
        DArray_Destroy(m_pPositionArray); 
        m_pPositionArray = NULL;
    }

    if (m_pSimulatorArray != NULL)
    {
        DArray_Destroy(m_pSimulatorArray);
        m_pSimulatorArray = NULL;
    }

    if (m_pszMsgBuf != NULL)
    {
        free(m_pszMsgBuf);
        m_pszMsgBuf = NULL;
    }

    FastRandom_Close(m_pFastRandom);
}


HRS_POSITION *CHRS_L1Trace::CopyPosition()
{
    HRS_POSITION  *pPosition;
    int           i;

    pPosition = (HRS_POSITION *)NG_malloc(sizeof(HRS_POSITION));
    if (pPosition == NULL)
    {
        return NULL;
    }

    for ( i = 0; i < HRS_FINISHMILL_NUM +1; i++ )
    {
        pPosition->m_ppSteelSection[i] = m_aSteelSection[i].Copy();
    }

    return pPosition;
}


HRS_L1_SIMULATOR *CHRS_L1Trace::CopySimulator()
{
    HRS_L1_SIMULATOR  *pSimulator;

    pSimulator = (HRS_L1_SIMULATOR *)NG_malloc(sizeof(HRS_L1_SIMULATOR));
    if (pSimulator == NULL)
    {
        return NULL;
    }

    memcpy(pSimulator, &m_Simulator, sizeof(HRS_L1_SIMULATOR));


    // �޸����ݣ�δ����ʱ��ʵ������������ں�Ⱥͳ��ں�Ⱦ�Ϊ0
    // ����δ����ʱ�����������ؾ�Ϊ0
    int i;

    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        if ( pSimulator->anIsLoad[i] != HRS_MILL_IS_LOADED )
        {
            pSimulator->adEntryGauge[i]    = 0.0;
            pSimulator->adDeliveryGauge[i] = 0.0;
            pSimulator->adActRollForce[i]  = 0.0;
        }
    }

    for ( i = 0; i < HRS_FINISHMILL_NUM-1; i++ )
    {
        if ( pSimulator->anLooperState[i] == HRS_LOOPER_STATE_INIT
             || pSimulator->anLooperState[i] == HRS_LOOPER_STATE_DOWNED )
        {
            pSimulator->adActTensionTorque[i] = 0.0;
            pSimulator->adTension[i]          = 0.0;
        }
    }

    return pSimulator;
}


// ����������׵�����ʣ�೤��
void CHRS_L1Trace::CalcLooperDownRestLen(int nStandIndex)
{
    double dRestLen;
    double dSpeed;
    double dStandDis;
    int    i;

    double dTotalTime;
    double dTime;

    dTotalTime = 5.0;   // 5��

    if ( m_Simulator.adEntrySpeed[0] < NG_POSITIVE_ZERO )
    {
        return;
    }

    if ( nStandIndex == 0 )
    {
        dSpeed = m_Simulator.adEntrySpeed[0];

        dRestLen = dSpeed * dTotalTime;
        
        m_adLooperDownRestLen[nStandIndex] = dRestLen;

        m_Simulator.adLowerLooperRestLen[nStandIndex] = dRestLen;

        return;
    }

    dRestLen = 0.0;
    for (i = nStandIndex; i > 0; i-- )
    {
        dStandDis = m_AllStand.aAllStand[i].dPosition 
                    - m_AllStand.aAllStand[i-1].dPosition;
        dSpeed = m_Simulator.adEntrySpeed[i];

        dTime = dStandDis / dSpeed;

        if ( dTime > dTotalTime )
        {
            dRestLen += dTotalTime * dSpeed;

            dTotalTime = 0.0;

            break;
        }
        else
        {
            dRestLen += dSpeed * dTime;

            dTotalTime -= dTime;

            if ( dTotalTime < NG_POSITIVE_ZERO )
            {
                break;
            }
        }
    }

    m_adLooperDownRestLen[nStandIndex] = dRestLen;

    m_Simulator.adLowerLooperRestLen[nStandIndex] = dRestLen;

    return;
}


// �����׸�λ��
void CHRS_L1Trace::CalcPaoGangPos()
{
    double dActSpeed1;
    double dEntrySpeed1;
    double dPaoGangSpeed;
    double dAccer1;
    double dRatio;
    double dTime;
    double dRestLen;

    //
    // ׼������
    //
    dRatio  = m_pFMSched->PreCalcDataF[HRS_FINISHMILL_NUM-1].fEntryGauge;
    dRatio /= m_pFMSched->PreCalcDataF[0].fEntryGauge;

    dActSpeed1     = m_Simulator.adActSpeed[0];
    dPaoGangSpeed  = m_AllStand.CalcPara.dMinF7Speed;

    dPaoGangSpeed *= dRatio;

    dEntrySpeed1  = m_Simulator.adEntrySpeed[0];

    dAccer1       = m_AllStand.CalcPara.dThrowAccer;

    dAccer1       *= dRatio;  

    if ( dAccer1 < 0.0 )
    {
        dAccer1 = 0.0 - dAccer1;
    }

    if ( dAccer1 < NG_POSITIVE_ZERO 
       && dAccer1 > NG_NEGATIVE_ZERO )
    {
        return;
    }

    // ������ٵ��׸��ٶ����õ���ʱ��
    dTime = (dActSpeed1 - dPaoGangSpeed) / dAccer1;

    if ( dTime < 0.0 )
    {
        dTime = 0.0 - dTime;
    }

    // ���㳤��
    dRestLen = dEntrySpeed1 * dTime;
    dRestLen -= 0.5 * dAccer1 * dTime * dTime;
    dRestLen += 2.0;
    
    m_dPaoGangPos = m_AllStand.aAllStand[0].dPosition - dRestLen;

    m_Simulator.dPaoGangPos = m_dPaoGangPos;

    return;
}


// ����������ֵ�İٷֱ�ֵ������С��0%����һ�������ٷֱ�ֵ֮��
double CHRS_L1Trace::GetDeltaGaugeRatio()
{
    int nValue;

    double  dRatio;

    nValue = FastRandom_Get(m_pFastRandom);

    nValue = nValue % 200;

    nValue -= 100;

    dRatio = (double)nValue / 100.0;

    dRatio *= m_AllStand.CalcPara.dGaugeRangeRatio;   // ���ȷ�Χ

    // ��ʱ��һ���̶�ֵ ...
#if 0
    dRatio = 0.00;
#endif

    return dRatio;
}



int CHRS_L1Trace::Init()
{  
    m_pCalcCfg = HRS_CalcCfg_LoadFromFile(HRS_CALC_CFG_FILE);
    if (m_pCalcCfg == NULL)
    {
        return ERR_FAILED;
    }

    m_pAllStandPara = AllStandPara_LoadFromFile("MillPara.cfg");
    if (m_pAllStandPara == NULL)
    {
        return ERR_FAILED;
    }

    m_bFinish    = false;
    m_bHaveSteel = false;
 
    m_nProcessState = HRS_PROCESS_STATE_INIT;

    // ����16���ڴ���Ϊд�ļ�����Ϣ������
    m_nMsgBufLen = 1024 * 1024 * 100;
    m_pszMsgBuf = (char *)malloc(m_nMsgBufLen + 10);
    if (m_pszMsgBuf == NULL)
    {
        return ERR_FAILED;
    }

    m_AllStand.CalcPara = m_pCalcCfg->CalcPara;

    m_nUpdateTimes = 0;

    DArray_Empty(m_pPositionArray);
    DArray_Empty(m_pSimulatorArray);

    memset(&m_stSunL1Ave, 0, sizeof(m_stSunL1Ave));
    return ERR_SUCCESS;
}


int CHRS_L1Trace::ReInit()
{
    m_bHaveSteel = false;
    m_bFinish    = false;

    m_nUpdateTimes = 0;

    return ERR_SUCCESS;
}


bool CHRS_L1Trace::IsHaveSteel()      // �Ƿ��и�
{
    return m_bHaveSteel;
}


bool CHRS_L1Trace::IsFinish()      // �Ƿ����һ���
{
    return m_bFinish;
}


// ��ȡ�ְ�ͷ��λ��
// ����С��0 ��ʾδ��ȡ��ͷ��λ�ã������иְ���Ѿ��׸���
double CHRS_L1Trace::GetHeadPos()     
{
    int i;
    double dHeadPos;
    int    nRet;

    dHeadPos = -1.0;

    for (i = HRS_FINISHMILL_NUM; i >= 0; i--)
    {
        nRet = m_aSteelSection[i].GetHeadPos(&dHeadPos);
        if (nRet == ERR_FAILED)
        {
            continue;
        }
        else
        {
            break;
        }
    }

    return dHeadPos;
}


double CHRS_L1Trace::GetTailPos()     // ��ȡ�ְ�β��λ��
{
    int i;
    double dTailPos;
    int    nRet;

    dTailPos = -1.0;

    for (i = 0; i <= HRS_FINISHMILL_NUM; i++)
    {
        nRet = m_aSteelSection[i].GetTailPos(&dTailPos);
        if (nRet == ERR_FAILED)
        {
            continue;
        }
        else
        {
            break;
        }
    }

    return dTailPos;
}


// ׼���������Ҫ�õ�����
void CHRS_L1Trace::PrepareData(HRS_FM_SCHED *pSchedData, 
                               double        dHeadPosition,
                               double        dTailPosition,
                               double        dFMEntryRollTableSpeed,
                               double        dDeltaTimeMs)
{
    HRS_L1Simulator_PrepareData(pSchedData, 
                                m_pAllStandPara,
                                dHeadPosition, 
                                dTailPosition,
                                dFMEntryRollTableSpeed, 
                                dDeltaTimeMs, 
                                &m_AllStand);

    m_Simulator.adEntryGauge[0]    = pSchedData->PreCalcDataF[0].fEntryGauge;
    m_Simulator.adDeliveryGauge[0] = pSchedData->PreCalcDataF[0].fDeliveryGauge;

    m_Simulator.adEntrySpeed[0] = dFMEntryRollTableSpeed;

    m_pFMSched = pSchedData;

    return;
}


// ��¼�¸ְ�
int CHRS_L1Trace::Login(double dHeadPos, 
                        double dTailPos, 
                        double dGauge, 
                        double dWidth)                        
{
    int i;

    m_bHaveSteel    = true;
    m_bFinish       = false;
    m_nProcessState = HRS_PROCESS_STATE_INIT;

    m_nUpdateTimes  = 0;

    m_dHeadPos = dHeadPos;
    m_dTailPos = dTailPos;

    // ���ó�ʼ�˵Ķ�
    HRS_L1Simulator_Init(&m_Simulator);

    // �����еĶ�ȫ�����³�ʼ��
    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        m_aSteelSection[i].ReInit();
        m_adDeltaGauge[i] = 0.0;      // ��������ں���Ŷ�ֵ
        m_adDeltaTemp[i]  = 0.0;      // ����������¶��Ŷ�ֵ
//        m_Simulator.adEntryGauge[i]    = m_pFMSched->PreCalcDataF[i].fEntryGauge;
//        m_Simulator.adDeliveryGauge[i] = m_pFMSched->PreCalcDataF[i].fDeliveryGauge;
        m_Simulator.adActSpeed[i]      = m_pFMSched->PreCalcDataF[i].fSpeed;
        m_Simulator.adEntrySpeed[i]    = m_pFMSched->PreCalcDataF[i].fSpeed;
        m_Simulator.adSetupSpeed[i]    = m_pFMSched->PreCalcDataF[i].fSpeed;

        m_Simulator.anLooperState[i]   = HRS_LOOPER_STATE_INIT;

        m_Simulator.adRollForce[i] = m_pFMSched->PreCalcDataF[i].fRollingForce;
        //  ��ʼ����������
        m_Simulator.adGap[i]       = m_pFMSched->PreCalcDataF[i].fGap;
        m_Simulator.adActGap[i]    = m_Simulator.adGap[i];

        m_Simulator.adActRollForce[i] = m_Simulator.adRollForce[i];

        m_Simulator.adActLooperAngle[i]
                        = m_AllStand.aAllStand[i].dLooperWaitAngle; // ���׽Ƕ�
        m_Simulator.adLooperTargetAngle[i] = m_Simulator.adActLooperAngle[i];

        m_Simulator.adTension[i] = m_pFMSched->PreCalcDataF[i].fTension;

        m_Simulator.adForwardSlip[i] = m_AllStand.aAllStand[i].dForwardSlip;

    }

    // ��ʼ�����һ��Section
    m_aSteelSection[HRS_FINISHMILL_NUM].ReInit();


    m_Simulator.adEntryGauge[0] = m_pFMSched->PreCalcDataF[0].fEntryGauge;

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        double dEntryGauge;
        double dDeliveryGauge;
        HRS_FM_PRECALC_DATA *pCalcData;

        pCalcData      = &(m_pFMSched->PreCalcDataF[i]);

        // ������ں��
        m_Simulator.adEntryGauge[i] = pCalcData->fEntryGauge;
        m_Simulator.adDeliveryGauge[i] = pCalcData->fDeliveryGauge;

        dEntryGauge    = m_Simulator.adEntryGauge[i];
        dDeliveryGauge = m_Simulator.adDeliveryGauge[i];

        // ����ѹ����
        m_Simulator.adDraft[i] = dEntryGauge - dDeliveryGauge;

        // �����ٶ�
        m_Simulator.adDeliverySpeed[i] = m_Simulator.adActSpeed[i];
        m_Simulator.adDeliverySpeed[i] *= (1.0 + m_Simulator.adForwardSlip[i]);

        m_Simulator.adEntrySpeed[i] = m_Simulator.adDeliverySpeed[i];
        m_Simulator.adEntrySpeed[i] *= dDeliveryGauge / dEntryGauge;

    }

    //m_Simulator.adEntrySpeed[0] = m_AllStand.dFMEntryRollTableSpeed;  // ����ٶȵ��ڳ�ʼ�����ٶ�

    m_aSteelSection[0].AddSection(dHeadPos, dTailPos, dGauge, dWidth, 0.0);

    //
    // ���û���λ��
    //
    m_aSteelSection[0].SetOrgPos(0.0, m_AllStand.aAllStand[0].dPosition);

    for ( i = 1; i < HRS_FINISHMILL_NUM; i++)
    {
        m_aSteelSection[i].SetOrgPos(m_AllStand.aAllStand[i-1].dPosition,
                                     m_AllStand.aAllStand[i].dPosition);
    }

    m_aSteelSection[HRS_FINISHMILL_NUM].SetOrgPos(
                              m_AllStand.aAllStand[HRS_FINISHMILL_NUM-1].dPosition,
                              0.0);

    // ���Ҫд���ļ��е���Ϣ
    DArray_Empty(m_pPositionArray);
    DArray_Empty(m_pSimulatorArray);

    m_dPaoGangPos = m_AllStand.CalcPara.dThrowSteelPos;

    m_AllStand.dAccerPos = m_AllStand.CalcPara.dTempAccerPos;
    m_AllStand.dTempAccer = m_AllStand.CalcPara.dTempAccer;
    m_AllStand.dPowerAccer = m_AllStand.CalcPara.dPowerAccer;
    m_AllStand.dPaoGangPos = m_AllStand.CalcPara.dFinishPos;

    return ERR_SUCCESS;
}


//
// ע���ְ�
//
int CHRS_L1Trace::LogOut()                         
{
    m_bHaveSteel = false;
    m_bFinish    = true;

 //   DumpAllSimulatorData();
 //   DumpPosition();

    m_nUpdateTimes = 0;

    return ERR_SUCCESS;
}


int CHRS_L1Trace::CalcPos(double dDeltaTimeMs)
{
    int i;
    int    nRet;
    double dMovDis;
    double dDeliveryLen;
    double dHeadPos;
    double dTailPos;
    double dWidth;
    double dGauge;
    double adMovDis[HRS_FINISHMILL_NUM+1];
    double adDeliveryLen[HRS_FINISHMILL_NUM+1];
    
    dDeliveryLen = 0.0;

    for ( i = 0; i < HRS_FINISHMILL_NUM+1; i++ )
    {
        adMovDis[i] = 0.0;
        adDeliveryLen[i] = 0.0;
    }

    // �����һ�����ܿ�ʼ����
    for (i = HRS_FINISHMILL_NUM-1; i > 0; i--)
    {
        // ��ȡ����ͷ��λ�ã����ͷ��λ��С��0��ʾ���λ�û������
        nRet = m_aSteelSection[i].GetHeadPos(&dHeadPos);
        if (nRet != ERR_SUCCESS)
        {
            // ��ҪUpdate��һ�ε�Pos��������һ��λ���޷�����
            dDeliveryLen = m_Simulator.adDeliverySpeed[i];
            dDeliveryLen *= dDeltaTimeMs / 1000.0;

            m_aSteelSection[i+1].UpdatePos(dDeliveryLen);
        }
        else
        {
            double dLooperLen;
            if (i == 0)
            {
                dLooperLen = 0.0;
            }
            else
            {
                dLooperLen = m_Simulator.adActLooperLen[i-1];
            }

            double dTemp;

            m_aSteelSection[i].GetHeadTemp(&dTemp);

            // ��������
            m_aSteelSection[i].SetLooperDis(dLooperLen);

            // ɾ�����ƹ��Ķ�
            m_aSteelSection[i].Remove(m_Simulator.adEntrySpeed[i],
                dDeltaTimeMs, 
                m_Simulator.adDeliveryGauge[i], // ���ں��...
                &dDeliveryLen);

            if (dDeliveryLen > NG_POSITIVE_ZERO)
            {
                dTailPos = m_AllStand.aAllStand[i].dPosition;
                dHeadPos = dTailPos + dDeliveryLen;
                dGauge   = m_Simulator.adDeliveryGauge[i];
                dWidth   = m_AllStand.aAllStand[i].dDeliveryWidth;

#ifdef _DEBUG
                dMovDis = m_Simulator.adDeliverySpeed[i] * dDeltaTimeMs / 1000.0;

                if ((dMovDis - dDeliveryLen) > NG_POSITIVE_ZERO 
                    || (dMovDis - dDeliveryLen) < NG_NEGATIVE_ZERO )
                {
                    printf("i = %d, dMovDis = %f, dDeliveryLen = %f\r\n",
                           i, dMovDis, dDeliveryLen);
                }
#if 0
                assert((dMovDis - dDeliveryLen) < NG_POSITIVE_ZERO 
                    && (dMovDis - dDeliveryLen) > NG_NEGATIVE_ZERO );
#endif
#endif


                m_aSteelSection[i+1].UpdatePos(dDeliveryLen);

                m_aSteelSection[i+1].AddSection(dHeadPos, dTailPos, 
                                                dGauge, dWidth, dTemp);
            }
        }
    }


    nRet = m_aSteelSection[0].GetHeadPos(&dHeadPos);
    if (nRet == ERR_SUCCESS)
    {
        double dDeltaGauge;
        double dRatio;

        dDeltaGauge = 0.0;
        if ( m_AllStand.CalcPara.nGaugeSwitch == 0 )
        {
            dRatio = 0.0;
            dDeltaGauge = 0.0;
        }
        else if (m_AllStand.CalcPara.nGaugeSwitch == 1 )
        {
            if ( m_Simulator.nLoopTimes >= 60 )
            {
                dDeltaGauge = m_AllStand.CalcPara.dGaugeValue;  
            }
            else
            {
                dDeltaGauge = 0.0;
            }
        }
        else if ( m_AllStand.CalcPara.nGaugeSwitch == 2 )
        {
            if ( m_Simulator.nLoopTimes >= 60 )
            {
                dDeltaGauge = 0.0 - m_AllStand.CalcPara.dGaugeValue;  
            }
            else
            {
                dDeltaGauge = 0.0;
            }
        }
        else
        {
            dRatio = GetDeltaGaugeRatio();
            dDeltaGauge = dRatio * m_Simulator.adEntryGauge[0];
        }


        m_aSteelSection[0].FirstStandRemove(m_Simulator.adEntrySpeed[0],
                                            dDeltaTimeMs, 
                                            m_Simulator.adDeliveryGauge[0], 
                                            dDeltaGauge,
                                            &dDeliveryLen);

        if (dDeliveryLen > NG_POSITIVE_ZERO)
        {
            dTailPos = m_AllStand.aAllStand[0].dPosition;
            dHeadPos = dTailPos + dDeliveryLen;
            dGauge   = m_Simulator.adDeliveryGauge[0];
            dWidth   = m_AllStand.aAllStand[0].dDeliveryWidth;

            double dEntryTemp;

            dEntryTemp = m_AllStand.aAllStand[0].dEntryTemp;
            dEntryTemp += m_adDeltaTemp[0];

            m_aSteelSection[1].UpdatePos(dDeliveryLen);

            m_aSteelSection[1].AddSection(dHeadPos, dTailPos, 
                                          dGauge, dWidth, dEntryTemp);
        }
    }
    else
    {
        dDeliveryLen = m_Simulator.adEntrySpeed[1];
        dDeliveryLen *= dDeltaTimeMs / 1000.0;
        m_aSteelSection[1].UpdatePos(dDeliveryLen);
    }


    dMovDis = m_Simulator.adEntrySpeed[0] * dDeltaTimeMs / 1000.0;

    m_aSteelSection[0].UpdatePos(dMovDis);

    return ERR_SUCCESS;
}


//
// �������״̬
//
int CHRS_L1Trace::CalcLooperState()  
{
    int i;
    int nLooperState;
    HRS_L1_STAND *pStand;

    double dAngleRatio;    // �Ƕȵ���ϵ�������ݲ�ͬ�Ļ���״̬�б仯

    // ����������׵�״̬
    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        nLooperState = m_Simulator.anLooperState[i];

        pStand = &(m_AllStand.aAllStand[i]);

        dAngleRatio = 1.0;

        if (nLooperState == HRS_LOOPER_STATE_INIT)
        {
            // ����Ƿ���Ҫ���ף����ǰ���������ܶ����صĻ�����ô��Ϊ����״̬
            if (m_Simulator.anIsLoad[i] == HRS_MILL_IS_LOADED
                && m_Simulator.anIsLoad[i+1] == HRS_MILL_IS_LOADED)
            {
                // ǰ���������ܶ��Ѿ����أ��л�������״̬
                m_Simulator.anLooperState[i] = HRS_LOOPER_STATE_UPPING;
            }
        }
        else if (nLooperState == HRS_LOOPER_STATE_UPPING)
        {
            // �ж������Ƿ񵽴������趨ֵ
            double dActLooperLen = m_Simulator.adActLooperLen[i];

            if (dActLooperLen > (pStand->dSetupLooperLen * 0.99))
            {
                // ���׵������趨��������������ɣ��л����������̬
                m_Simulator.anLooperState[i] = HRS_LOOPER_STATE_FINISH;
            }

            double dDeltaLen = dActLooperLen - pStand->dSetupLooperLen;
            dDeltaLen = fabs(dDeltaLen);

            dDeltaLen = dDeltaLen / pStand->dSetupLooperLen;

            if ( dDeltaLen < 0.02 )
            {
                dAngleRatio = 0.05;
            }
            else if ( dDeltaLen < 0.05 )
            {
                dAngleRatio = 0.08;
            }
            else if ( dDeltaLen < 0.1 )
            {
                dAngleRatio = 0.15;
            }
            else if ( dDeltaLen < 0.3 )
            {
                dAngleRatio = 0.2;
            }
            else if ( dDeltaLen < 0.4 )
            {
                dAngleRatio = 0.3;
            }
            else if ( dDeltaLen < 0.5 )
            {
                dAngleRatio = 0.4;
            }
            else if ( dDeltaLen < 0.6 )
            {
                dAngleRatio = 0.45;
            }
            else if ( dDeltaLen < 0.8 )
            {
                dAngleRatio = 0.5;
            }
            else if ( dDeltaLen < 1.0)
            {
                dAngleRatio = 0.55;
            }
            else
            {
                dAngleRatio = 0.6;
            }
        }
        else if (nLooperState == HRS_LOOPER_STATE_FINISH)
        {
            double dLowerLooperRestLen;

            dLowerLooperRestLen = m_adLooperDownRestLen[i];
            // �ж��Ƿ�ﵽ��������������ʣ�೤��С��ĳ������
            if (m_Simulator.adTotalRestLen[i] < dLowerLooperRestLen)
            {
                // �����������������л�������״̬
                m_Simulator.anLooperState[i] = HRS_LOOPER_STATE_DOWNING;
            }

            dAngleRatio = 0.3;

            double dActLooperLen = m_Simulator.adActLooperLen[i];

            double dDeltaLen = dActLooperLen - pStand->dSetupLooperLen;
            dDeltaLen = fabs(dDeltaLen);

            dDeltaLen = dDeltaLen / pStand->dSetupLooperLen;

            if ( dDeltaLen < 0.01 )
            {
                dAngleRatio = 0.3;
            }
            else if ( dDeltaLen < 0.05 )
            {
                dAngleRatio = 0.35;
            }
            else if ( dDeltaLen < 0.1 )
            {
                dAngleRatio = 0.4;
            }
            else if ( dDeltaLen < 0.2 )
            {
                dAngleRatio = 0.45;
            }
            else if ( dDeltaLen < 0.3)
            {
                dAngleRatio = 0.6;
            }

        }
        else if (nLooperState == HRS_LOOPER_STATE_DOWNING)
        {
            // ���׽Ƕ�С�ڵ���ԭʼλ�õĽǶ�
            if (m_Simulator.adActLooperAngle[i] < (pStand->dLooperWaitAngle + 0.01))
            {
                // ������ɣ�������״̬�л�Ϊ��ʼ̬
                m_Simulator.anLooperState[i] = HRS_LOOPER_STATE_DOWNED;
            }
            dAngleRatio = 1.0;
        }
        else
        {
            // DOWNED״̬������Ҫ����
        }

        m_Simulator.adAngleRatio[i] = dAngleRatio;
    }

    return ERR_SUCCESS;
}


// ������������������
int CHRS_L1Trace::CalcStandLoaded()
{
    int    i;
    int    nRet;
    double dHeadPos;
    int    nTailIndex;
    int    nHeadIndex;

    // ���ݸְ�λ����Ϣ������������ܵ��������
    // �����������βλ���ϵ�������м�������������ص�
    
    // �ȼ���β��λ���ϵ��������
    nTailIndex = -1;
    for ( i = 0; i < HRS_FINISHMILL_NUM+1; i++ )
    {
        nRet = m_aSteelSection[i].GetHeadPos(&dHeadPos);
        if (nRet != ERR_FAILED)
        {
            nTailIndex = i;
            break;
        }
    }

    if (nTailIndex < 0)
    {
        // ���жζ�û����Ϣ
        return ERR_FAILED;
    }

    nHeadIndex = -1;
    for ( i = nTailIndex; i <= HRS_FINISHMILL_NUM; i++ )
    {
        nRet = m_aSteelSection[i].GetHeadPos(&dHeadPos);
        if (nRet == ERR_FAILED)
        {
            nHeadIndex = i;
            break;
        }
    }

    if (nHeadIndex < 0)
    {
        // ���жζ�û����Ϣ
        nHeadIndex = HRS_FINISHMILL_NUM + 1;
    }

    for (i = 0; i < nTailIndex; i++)
    {
        if (m_Simulator.anIsLoad[i] == HRS_MILL_IS_LOADED)
        {
            m_Simulator.anIsLoad[i] = HRS_MILL_UNLOADED;
        }
    }

    for ( i = nTailIndex; i < nHeadIndex-1; i++)
    {
        if ( m_Simulator.anIsLoad[i] != HRS_MILL_IS_LOADED )
        {
            m_Simulator.anIsLoad[i] = HRS_MILL_IS_LOADED;
        }
    }

    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        if ( m_Simulator.anIsLoad[i] == HRS_MILL_IS_LOADED )
        {
            m_Simulator.anLoadedLoopTimes[i] += 1;
        }
    }
 
    return ERR_SUCCESS;
}


int CHRS_L1Trace::CalcGaugeAndLen()
{
    double dEntryGauge;
    double dDeliveryGauge;
    double dRestLen;
    double dTotalLen;
    int    nRet;
    int i;

    dRestLen  = 0.0;
    dTotalLen = 0.0;

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        nRet = m_aSteelSection[i].GetDeliveryGauge(&dEntryGauge);   // ���γ��ڼ�Ϊ��i�����������
        if (nRet == ERR_FAILED)
        {
            //            m_Simulator.adEntryGauge[i]    = m_pFMSched->PreCalcDataF[i].fEntryGauge;
        }
        else
        {
            m_Simulator.adEntryGauge[i]    = dEntryGauge;
        }
        nRet = m_aSteelSection[i+1].GetEntryGauge(&dDeliveryGauge); // ��i+1�ε���ڼ�Ϊ��i�������ĳ���
        if (nRet == ERR_FAILED)
        {
            //            m_Simulator.adDeliveryGauge[i]    = m_pFMSched->PreCalcDataF[i].fDeliveryGauge;
        }
        else
        {
            m_Simulator.adDeliveryGauge[i]    = dDeliveryGauge;
        }
        
        m_aSteelSection[i].GetTotalLength(&dTotalLen);
        m_Simulator.adEntryLen[i] = dTotalLen;

        dRestLen += dTotalLen;

        m_Simulator.adTotalRestLen[i]  = dRestLen;

        m_aSteelSection[i+1].GetTotalLength(&dTotalLen);
        m_Simulator.adDeliveryLen[i] = dTotalLen;
    }

    return ERR_SUCCESS;
}


// ������ٶ�
int CHRS_L1Trace::CalcAccer()
{
    int    i;                 // ѭ����������
    double dHeadPos;          // �ְ�ͷ��λ��
    double dTailPos;          // �ְ�β��λ��
    double dThrowSteelPos;    // �׸�λ�õ�
    double dPowerAccerPos;    // ���ʼ��ٶ�λ��
    double dTempAccerPos;     // �¶ȼ��ٶ�λ��

    double dCurAccer;         // FM7�ļ��ٶ�
    double dAccer;            // ��ʱʹ�õı���
    double dFinalGauge;       // ������7�ĳ��ں��
    double dGauge;            // ��ʱ����

    dHeadPos = GetHeadPos();  //ȡ�øְ�ͷ��λ��
    if (dHeadPos < 0.0)
    {
        for (i = 0; i < HRS_FINISHMILL_NUM; i++)
        {
            m_Simulator.adAccer[i] = 0.0;
        }
    }

    dTailPos = GetTailPos();

    dCurAccer = 0.0;

    dThrowSteelPos = m_dPaoGangPos;
    dPowerAccerPos = m_pCalcCfg->CalcPara.dPowerAccerPos;
    dTempAccerPos  = m_pCalcCfg->CalcPara.dTempAccerPos;

    m_nProcessState = m_Simulator.nProcessState;

    // �ж��׸�λ���øְ�β��λ��
    if (dTailPos > dThrowSteelPos)
    {
        dCurAccer = m_pCalcCfg->CalcPara.dThrowAccer;

        if ( m_nProcessState == HRS_PROCESS_STATE_TEMP 
            || m_nProcessState == HRS_PROCESS_STATE_POWER 
            || m_nProcessState == HRS_PROCESS_STATE_MAX_SPEED )
        {
            m_nProcessState = HRS_PROCESS_STATE_DECSPEED;    // �����׸ּ���״̬
        }
    }
    else
    {
        // ���ж��Ƿ����л��׶����������̬��ֻ��ȫ�������������̬�ſ��Լ���
        if (m_Simulator.anLooperState[0] == HRS_LOOPER_STATE_FINISH
           && m_Simulator.anLooperState[5] == HRS_LOOPER_STATE_FINISH)
        {
            if (dHeadPos > dPowerAccerPos)
            {
                dCurAccer = m_pCalcCfg->CalcPara.dPowerAccer;
                m_nProcessState = HRS_PROCESS_STATE_POWER;   // ���빦�ʼ���״̬
            }
            else
            {
                if (dHeadPos > dTempAccerPos)
                {
                    dCurAccer = m_pCalcCfg->CalcPara.dTempAccer;
                    if ( m_nProcessState == HRS_PROCESS_STATE_INIT )
                    {
                        m_nProcessState = HRS_PROCESS_STATE_TEMP; // �����¶ȼ���״̬
                    }
                }
            }
        }
    }

    double dSetupSpeed = m_Simulator.adSetupSpeed[HRS_FINISHMILL_NUM-1];

    if ( m_nProcessState == HRS_PROCESS_STATE_TEMP 
        || m_nProcessState == HRS_PROCESS_STATE_POWER )
    {
        // ���F7�ٶȴ����ٶ����ޣ����������ٶ�״̬
        double dMaxSpeed = m_AllStand.CalcPara.dMaxF7Speed;
        double dAddSpeed = dCurAccer * m_AllStand.dDeltaTimeMs / 1000.0;

        if ( dSetupSpeed + dAddSpeed > dMaxSpeed )
        {
            m_nProcessState = HRS_PROCESS_STATE_MAX_SPEED;  
        }
    }

    if ( m_nProcessState == HRS_PROCESS_STATE_DECSPEED )
    {
        // �ж�F7�Ƿ�����ٶ����ޣ��׸��ٶȣ�������ﵽ���Ϊ�׸�״̬
        double dMinSpeed = m_AllStand.CalcPara.dMinF7Speed;
        double dDecSpeed = dCurAccer * m_AllStand.dDeltaTimeMs / 1000.0;
        
        // ����¸����ڵ�F7�趨�ٶ�С����С�ٶȽ����׸�״̬
        if ( (dSetupSpeed + dDecSpeed ) < dMinSpeed )
        {
            m_nProcessState = HRS_PROCESS_STATE_PAOGANG;
        }
    }

    m_Simulator.nProcessState = m_nProcessState;

    switch (m_nProcessState)
    {
    case HRS_PROCESS_STATE_INIT:
        dCurAccer = 0.0;
        break;
    case HRS_PROCESS_STATE_TEMP:
        dCurAccer = m_pCalcCfg->CalcPara.dTempAccer;
        break;
    case HRS_PROCESS_STATE_POWER:
        dCurAccer = m_pCalcCfg->CalcPara.dPowerAccer;
        break;
    case HRS_PROCESS_STATE_MAX_SPEED:
        dCurAccer = 0.0;
        break;
    case HRS_PROCESS_STATE_DECSPEED:
        dCurAccer = m_pCalcCfg->CalcPara.dThrowAccer;
        break;
    case HRS_PROCESS_STATE_PAOGANG:
        dCurAccer = 0.0;
        break;
    default:
        dCurAccer = 0.0;
        break;
    }

    m_Simulator.adAccer[HRS_FINISHMILL_NUM-1] = dCurAccer;
    dFinalGauge = m_Simulator.adDeliveryGauge[HRS_FINISHMILL_NUM-1];

    // ����������ܵļ��ٶ�
    for (i = HRS_FINISHMILL_NUM-2; i >= 0; i--)
    {
        // 
        if (m_Simulator.anIsLoad[i] == HRS_MILL_IS_LOADED)
        {
            // ֻ�м����˵������ż�����ٶ�
            dAccer = dCurAccer;
            dAccer *= dFinalGauge;

            dGauge = m_Simulator.adDeliveryGauge[i];

            if (dGauge < NG_POSITIVE_ZERO)
            {
                printf("������ٶ��õĳ��ں��ֵС�ڵ���0.0\n");
                return ERR_FAILED;
            }

            dAccer /= dGauge;

            m_Simulator.adAccer[i] = dAccer;
        }
        else
        {
            // δ���ص����������ٶȼ���Ϊ0.0
            dAccer = 0.0;
            m_Simulator.adAccer[i] = dAccer;
        }
    }

    return ERR_SUCCESS;
}


// 
// �������Ŷ�ֵ
//
int CHRS_L1Trace::CalcDeltaGauge()
{
    int    i;
    int    nRet;
    double dDeltaGauge;

    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        //
        // ������ܵ���ں���Ŷ�ֵdDeltaGauge
        //
        if (i == 0)
        {
            // ��1��������ڣ�ֱ��ʹ����ڸֶεĵ�ǰ�Ŷ�ֵ
            dDeltaGauge = m_aSteelSection[0].GetCurDeltaGauge();
        }
        else
        {
            // ��1��֮��Ļ��ܣ���ʵ����ں��ֵ��ȥ�������е���ں��ֵ
            double dEntryGauge;

            nRet = m_aSteelSection[i].GetEntryGauge(&dEntryGauge);
            if (nRet == ERR_SUCCESS)
            {
                dDeltaGauge = dEntryGauge;
                dDeltaGauge -= m_AllStand.aAllStand[i].dEntryGauge;
            }
            else
            {
                dDeltaGauge = 0.0;
            }
        }

        m_adDeltaGauge[i] = dDeltaGauge;
    }

    return ERR_SUCCESS;
}


// �����¶��Ŷ�ֵ
int CHRS_L1Trace::CalcDeltaTemp()
{
    double dSetupTemp;     // ��1�����ܵ��趨�¶�
    double dEntryTemp;     // ��1�����ܵĵ�ǰ����¶�
    double dMinTemp;       // �¶ȱ��в������С�¶�
    double dCurPos;        // �ְ嵱ǰλ��
    double dTailPos;       // �ְ�β��λ��
    int    nTempCount;     // �¶ȶ�����
    int    nRet;

    dSetupTemp = m_AllStand.aAllStand[0].dEntryTemp;

    if (dSetupTemp < NG_POSITIVE_ZERO)
    {
        return ERR_FAILED;
    }

    //
    // ���ݵ�ǰ�ְ�λ����Ϣ�����1�����ܵ�����¶�
    //
    nTempCount = HRS_TempCalc_GetTempSectionCount();
    HRS_TempCalc_GetMinTemp(&dMinTemp);

    nRet = m_aSteelSection[0].GetHeadPos(&dCurPos);

    if (nRet == ERR_FAILED)
    {
        dEntryTemp = dMinTemp;
    }
    else
    {
        m_aSteelSection[0].GetTailPos(&dTailPos);

        double dOrgLen  = m_dHeadPos - m_dTailPos;   // ԭʼ�ְ峤��
        double dRestLen = dCurPos - dTailPos;       // ��ǰ�ְ�ʣ�೤��
        double dIndex = (double)nTempCount;
        
        dIndex *= (dRestLen / dOrgLen); 
        dIndex = 94 - dIndex;

        // ���¶ȱ��в�ѯ����¶�
        nRet = HRS_TempCalc_QueryOrgTemp(dIndex, &dEntryTemp);
        if (nRet == ERR_FAILED)
        {
            dEntryTemp = dMinTemp;
        }
    }

    m_adDeltaTemp[0]              = dEntryTemp - dSetupTemp;
    m_Simulator.adDeliveryTemp[0] = dEntryTemp;
    m_Simulator.adEntryTemp[0]    = dEntryTemp;

    int    i;
    int nTempSwitch = m_AllStand.CalcPara.nTempSwitch;

    if ( nTempSwitch == 0 )
    {
        for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
        {
            m_adDeltaTemp[i] = 0.0;
            m_Simulator.adDeliveryTemp[i] = m_AllStand.aAllStand[i].dEntryTemp;
            m_Simulator.adEntryTemp[i]    = m_AllStand.aAllStand[i].dEntryTemp;

        }
    }
#if 0
    else if ( m_AllStand.CalcPara.nTempSwitch == 2 )
    {
        for ( i = 1; i < HRS_FINISHMILL_NUM; i++ )
        {
            m_adDeltaTemp[i] = 0.0;
            m_Simulator.adDeliveryTemp[i] = m_AllStand.aAllStand[i].dEntryTemp;
            m_Simulator.adEntryTemp[i]    = m_AllStand.aAllStand[i].dEntryTemp;

        }
    }
#endif
    else
    {
        //
        // ����������ܵ�����¶��Ŷ�ֵ
        //
        double dCurSetupTemp;  // ��ǰ���ܵ��趨�¶�
        double dCurEntryTemp;  // ��ǰ���ܵ�����¶�
        double dCurHeadTemp;

        for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
        {
            m_aSteelSection[i].GetHeadTemp(&dCurHeadTemp);

            if ( dCurHeadTemp < NG_POSITIVE_ZERO )
            {
                continue;
            }
            dCurSetupTemp = m_AllStand.aAllStand[i].dEntryTemp;
#if 1
            nRet = CalcCurTemp(dCurHeadTemp, i, &dCurEntryTemp);
            if ( nRet == ERR_FAILED )
            {
                m_adDeltaTemp[i] = 0.0;

                m_Simulator.adDeliveryTemp[i] = m_AllStand.aAllStand[i].dEntryTemp;
                m_Simulator.adEntryTemp[i]    = m_AllStand.aAllStand[i].dEntryTemp;

                continue;
            }
#else
            if ( dCurHeadTemp < NG_POSITIVE_ZERO )
            {
                m_adDeltaTemp[i] = 0.0;

                m_Simulator.adDeliveryTemp[i] = m_AllStand.aAllStand[i].dEntryTemp;
                m_Simulator.adEntryTemp[i]    = m_AllStand.aAllStand[i].dEntryTemp;
                
                continue;
            }
            dCurEntryTemp = dCurHeadTemp * dCurSetupTemp / dSetupTemp;
#endif

            m_adDeltaTemp[i]              = dCurEntryTemp - dCurSetupTemp;
            m_Simulator.adDeliveryTemp[i] = dCurEntryTemp;
            m_Simulator.adEntryTemp[i]    = dCurEntryTemp;
        }
    }

    for ( i = 1; i < HRS_FINISHMILL_NUM; i++ )
    {
        if ( NG_GetBitValue(nTempSwitch, i) == 0 )
        {
            m_adDeltaTemp[i] = 0.0;
            m_Simulator.adDeliveryTemp[i] = m_AllStand.aAllStand[i].dEntryTemp;
            m_Simulator.adEntryTemp[i]    = m_AllStand.aAllStand[i].dEntryTemp;
        }
    }

    return ERR_SUCCESS;  
}


// ���ݸ��¼ƴ����¶������㵱ǰ���ܵĳ����¶�
int CHRS_L1Trace::CalcCurTemp(double dEntryTemp, int nStandIndex, 
                              double *pdCurTemp)
{
    HRS_L1_STAND  *pStand;

    double dWaterTemp;     // ˮ�£���������ȡ��
    double dKaTempRatio;   // �¶�ϵ������������ȡ��

    double dLen;           // ��1�����¼Ƶ���ǰ���ܵľ���
    double dSpeed;         // ���һ�����ܵĳ����ٶ�
    double dDeliveryGauge; // ���һ�����ܵĳ��ں��
    double dCurTemp;       // ��ǰ�¶ȣ�������
    double dValue;         // �м����

    // ȡ�����ò���
    pStand = &(m_AllStand.aAllStand[nStandIndex]);
    dLen         = pStand->dPosition - m_AllStand.CalcPara.dEntryTempPos;
    dWaterTemp   = m_AllStand.CalcPara.dWaterTemp;
    dKaTempRatio = m_AllStand.CalcPara.dKaTemp;

    // �������һ�����ܵĳ����ٶ�
    dSpeed = m_AllStand.aAllStand[HRS_FINISHMILL_NUM-1].dSetupSpeed;
    dSpeed *= (m_pFMSched->PreCalcDataF[HRS_FINISHMILL_NUM-1].fForwardSlip + 1.0);

    // �������һ�����ܵĳ����¶�
    dDeliveryGauge = m_AllStand.aAllStand[HRS_FINISHMILL_NUM-1].dDeliveryGauge;

    // ���ٶȺ��¶ȵĳ˻�
    dValue = dSpeed * dDeliveryGauge / 1000.0;  // ��ȵ�λ�ɺ���ת������

    if ( dValue < NG_POSITIVE_ZERO )
    {
        dprintf("Failed. dSpeed * dDeliveryGauge < 0 \r\n");
        return ERR_FAILED;
    }

    // ���㵱ǰ�¶�ֵ

    dValue = exp(0.0 - dKaTempRatio * dLen / dValue);

#if 1
    dCurTemp = dEntryTemp - dWaterTemp;

    dCurTemp *= dValue;

    dCurTemp += dWaterTemp;
#else

    dCurTemp = dEntryTemp - m_AllStand.aAllStand[0].dEntryTemp;
    dCurTemp *= 0.8;
    dCurTemp += pStand->dEntryTemp;
#endif

    *pdCurTemp = dCurTemp;

    return ERR_SUCCESS;
}


//
// ��ʱ���еĺ���
//
int CHRS_L1Trace::Update(double dDeltaTimeMs)
{
    int    i;                   // ѭ������i
    double dDeltaTemp;          // �¶��Ŷ�ֵ

    double dDeltaGauge = 0.0;   // ��������ں���Ŷ�ֵ

    dDeltaTemp = 0.0;

    if (!m_bHaveSteel)
    {
        return ERR_FAILED;
    }
#if 1
    if (m_Simulator.nLoopTimes == 436)
    {
        printf("Debug Break. 689\n");
    }
#endif
    // �ж�β��λ���Ƿ񵽴��׸�λ��
    double dTailPos = GetTailPos();
    if (dTailPos > m_pCalcCfg->CalcPara.dFinishPos)
    {
        // ע��
        LogOut();
        m_bHaveSteel = false;
        m_bFinish    = true;
        return ERR_FAILED;
    }

    // �����¶��Ŷ�ֵ
    CalcDeltaTemp();

    // ����ְ�λ����Ϣ
    CalcPos(dDeltaTimeMs);

    m_Simulator.dCurHeadPos = GetHeadPos();
    m_Simulator.dCurTailPos = GetTailPos();

    // ������������������
    CalcStandLoaded();

    // �������ں�Ⱥ�ʣ�೤�ȵ���Ϣ
    CalcGaugeAndLen();

#if 1
    // ������ٶ�
    CalcAccer();  

    // �������Ŷ�ֵ
    CalcDeltaGauge();


    // ���μ���������ܵ������������졢��ڡ����ں�ȵ�����
    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        HRS_L1Simulator_CalcOneStand(&m_AllStand, 
                                     &m_Simulator,
                                     m_adDeltaGauge[i],
                                     m_adDeltaTemp[i],
                                     i);
    }

    // �������״̬
    CalcLooperState();

    // ���������仯�����ŷ���������
    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        HRS_L1Simulator_CalcTension(&m_AllStand, &m_Simulator, i);      
    }

    // ���������������仯��
    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        HRS_L1Simulator_CalcLooperAngle(&m_AllStand, &m_Simulator, i);     
    }

    //
    // ������׶��ٶȵĵ�����, �������
    // ע�����һ������û�л��ף���˴�HRS_FINISHMILL_NUM-2��ʼ����
    //

    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        m_Simulator.adLooperSpeedAdjust[i] = 0.0;
    }

    if ( m_nProcessState == HRS_PROCESS_STATE_INVALID ) // �ݲ����㴩��
    {
        // ���������У����ô����ļ����ٶȺ���������
        HRS_CalcCDSpeed(&m_AllStand, &m_Simulator);
    }
    else
    {
        // �����ٶȵ���
        for ( i = HRS_FINISHMILL_NUM-2; i >= 0; i-- )
        {
            HRS_L1Simulator_CalcSpeedAdjust(&m_AllStand, &m_Simulator, i);
        }
        // �����ٶ�
        for (i = 0; i < HRS_FINISHMILL_NUM; i++)
        {
            HRS_L1Simulator_CalcSpeed(&m_AllStand, &m_Simulator, i);      
        }

    }

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        CalcLooperDownRestLen(i);
    }

    CalcPaoGangPos();

    //
    // �������ְ����������ֵ
    //
    for ( i = 1; i < HRS_FINISHMILL_NUM; i++ )
    {
        m_aSteelSection[i].SetLooperDis(m_Simulator.adActLooperLen[i-1]);
    }
#endif
    m_Simulator.nLoopTimes += 1;

#if 0
    if (m_Simulator.nLoopTimes == 29)
    {
        printf("nLoopTimes = 29\r\n");
    }
#endif
//    DumpSteelSection();
//    DumpSimulatorData();

    HRS_POSITION *pPosition = CopyPosition();

    DArray_Add(m_pPositionArray, pPosition);

    HRS_L1_SIMULATOR *pSimulator = CopySimulator();

    DArray_Add(m_pSimulatorArray, pSimulator);

    m_nUpdateTimes += 1;

    if (m_nUpdateTimes > 1000)
    {
        m_bFinish = true;
    }

    return ERR_SUCCESS;
}


int CHRS_L1Trace::ClacFMActualAve(HRS_FM_DATA *pFMData)
{
    if (NULL == m_pSimulatorArray)
    {
        return ERR_FAILED;
    }

    memset(&m_stSunL1Ave, 0, sizeof(m_stSunL1Ave));
    HRS_L1_SIMULATOR *pSimulator = NULL;

    int nDataCount = 0;

    nDataCount = m_pSimulatorArray->nDataCount;
    if (0 >= nDataCount)
    {
        return ERR_FAILED;
    }

    int nDataNum[5][7] = {0};

    DArray_EnumBegin(m_pSimulatorArray);

    //������ֵ��
    int k = 0;
    for (;;k++)
    {
        pSimulator = (HRS_L1_SIMULATOR *)DArray_EnumNext(m_pSimulatorArray);
        if (NULL == pSimulator)
        {
            break;
        }

        for (int i = 0; i < 7; i++)
        {
            if (pSimulator->adDeliveryGauge[i] > 0)
            {
                nDataNum[0][i] += 1 ;
                m_stSunL1Ave.FMActualData[i].dAveDeliveryGauge += pSimulator->adDeliveryGauge[i];

            }
            if (m_Simulator.adActRollForce[i] > 0)
            {
                nDataNum[1][i] += 1 ;
                m_stSunL1Ave.FMActualData[i].dAveDraftRatio += pSimulator->adActRollForce[i];
            }
            if (pSimulator->adActRollForce[i] > 100)
            {  
                nDataNum[2][i] += 1 ;
                m_stSunL1Ave.FMActualData[i].dAveRollingForce += pSimulator->adActRollForce[i];  

                if (i == 0)
                {
                    printf("pSimulator->dAveRollingForce[i] = %f \
                           nDataNum = %d\
                           \n"
                           , pSimulator->adActRollForce[i]
                    ,nDataNum[2][i]);
                }
                
            }

            if (pSimulator->adTension[i] > 0)
            {
                nDataNum[3][i] += 1 ;
                m_stSunL1Ave.FMActualData[i].dAveTension += pSimulator->adTension[i];

            }

            if (pSimulator->adActGap[i] > 0)
            {
                nDataNum[4][i] += 1 ;

                m_stSunL1Ave.FMActualData[i].dAveGap += pSimulator->adActGap[i];
            }

           /* printf("pSimulator->adDeliveryGauge[i] = %f \n \
                 pSimulator->adDraft[i]/m_Simulator.adDeliveryGauge[i] = %f\n \
                 pSimulator->adActRollForce[i] = %f \n \
                 pSimulator->adTension[i] = %f \n \
                 pSimulator->adActGap[i] = %f \n \n\n\n\n"
                 , pSimulator->adDeliveryGauge[i]
                 , pSimulator->adDraft[i]
                 , pSimulator->adActRollForce[i]
                 , pSimulator->adTension[i]
                 ,pSimulator->adActGap[i]);*/
        }

    }
    //printf("pSimulator->dAveRollingForce[0] = %f \n \n \n\n\n\n" ,m_stSunL1Ave.FMActualData[0].dAveRollingForce);
    //printf("K = %d, nDataCount = %d\n\n\n\n\n\n\n\n\n\n\n\n", k,nDataCount);


    //�����ֵ
    HRS_ONE_FM_DATA  *pOneFMData;
    HRS_ONE_FX_DATA  *pOneFXData;

    HRS_L1_SIMULATE_ALL_AVEDATA stSunL1Ave;//GUI�����ֵ

    float  *pfDeliveryGauge = &pFMData->OnePlateData[1].fBarThickness;
    float  *pfDrafRatio = &pFMData->OnePlateData[1].fStriptailPosition;

    int i = 0;
    for (i = 0; i < 6;i++)
    {
        pOneFMData = &(pFMData->OneEquitData[i].OneFMData);
        pOneFXData = &(pFMData->OneEquitData[i].OneFXData);

        *pfDeliveryGauge
            = m_stSunL1Ave.FMActualData[i].dAveDeliveryGauge
            / nDataNum[0][i];
        stSunL1Ave.FMActualData[i].dAveDeliveryGauge =  *pfDeliveryGauge;

        *pfDrafRatio
            = m_stSunL1Ave.FMActualData[i].dAveDraftRatio 
            / nDataNum[1][i];
        stSunL1Ave.FMActualData[i].dAveDraftRatio = *pfDrafRatio;

        pOneFMData->fSumForceActual
            = m_stSunL1Ave.FMActualData[i].dAveRollingForce
            / nDataNum[2][i];
        stSunL1Ave.FMActualData[i].dAveRollingForce = pOneFMData->fSumForceActual;

        pOneFXData->fVRTensionActual
            = m_stSunL1Ave.FMActualData[i].dAveTension 
            / nDataNum[3][i];
        stSunL1Ave.FMActualData[i].dAveTension = pOneFXData->fVRTensionActual;

        pOneFMData->fGapAvgActual
            = m_stSunL1Ave.FMActualData[i].dAveGap
            / nDataNum[4][i];
        stSunL1Ave.FMActualData[i].dAveGap = pOneFMData->fGapAvgActual;

        pfDeliveryGauge++;
        pfDrafRatio++;
    }

    *pfDeliveryGauge 
            = m_stSunL1Ave.FMActualData[i].dAveDeliveryGauge / nDataNum[0][i];
    *pfDrafRatio = m_stSunL1Ave.FMActualData[i].dAveDraftRatio / nDataNum[1][i];
    pFMData->stFM7Data.fSumForceActual
            = m_stSunL1Ave.FMActualData[i].dAveRollingForce / nDataNum[2][i];
    pFMData->stFM7Data.fGapAvgActual
            = m_stSunL1Ave.FMActualData[i].dAveGap / nDataNum[4][i];

    return ERR_SUCCESS;
}


static int g_nFMTelCounter = 0;


int CHRS_L1Trace::BuildSched(HRS_FM_DATA *pFMData)
{
    if (NULL == pFMData)
    {
        return ERR_FAILED;
    }

    pFMData->nLoopTimes   = m_Simulator.nLoopTimes;
    pFMData->fDeltaTimeMs = m_AllStand.dDeltaTimeMs;

    pFMData->PackHead.sTelID           = HRS_FM_DATA_ID;      //����ʶ���(2113)
    pFMData->PackHead.sTelHeaderLength = sizeof(HRS_FM_DATA); //[-]����ͷ�������ֽ���
    pFMData->PackHead.sTelDataLength   = HRS_FM_DATA_LEN;     //[-]�������ݳ����ֽ���
    pFMData->PackHead.sCounter         = g_nFMTelCounter;     //counter (1~32767)

    if ( g_nFMTelCounter >= 32767 )
    {
        g_nFMTelCounter = 0;
    }
    else
    {
        g_nFMTelCounter += 1;
    }

    memset(pFMData->PackHead.szSpace1, 0, HRS_CHAR_SPACE);       //����


    uint32 uCheckSum = GetByteCheckSum((char *)&(pFMData->PackHead), 
        sizeof(HRS_PACK_HEAD) - sizeof(short));

    pFMData->PackHead.sHeaderSun = (short)uCheckSum;    //[-]����ͷ���ֽ�У���



    pFMData->sPlateBasicID1 = 0;                 //[-]�����ְ��1��6���ڲ�ID��
    pFMData->sFurnaceID1    = 0;                    //[-]����¯�ţ���ǰ��
    pFMData->sPlateBasicID2 = 0;                 //[-]�����ְ��1��6���ڲ�ID������һ�飩
    pFMData->sFurnaceID2    = 0;                    //[-]����¯�ţ���һ�飩
    
    strcpy(pFMData->szPlateNo1, m_pFMSched->szPlateNo);    //[-]�������ֺţ���ǰ��
    strcpy(pFMData->szSteelGrade1, m_pFMSched->szSteelGrade);              //[-]�������֣���ǰ��
    
    strcpy(pFMData->szPlateNo2, pFMData->szPlateNo1);    //[-]�������ֺţ���һ�飩
    strcpy(pFMData->szSteelGrade2, pFMData->szSteelGrade1);              //[-]�������֣���һ�飩


    HRS_L1_STAND  *pStand0 = &(m_AllStand.aAllStand[0]);
    HRS_L1_STAND  *pStand6 = &(m_AllStand.aAllStand[HRS_FINISHMILL_NUM-1]);


    double dHeadPos = GetHeadPos();
    double dTailPos = GetTailPos();

    double dHeadPos0 = 0.0;
    double dTailPos0 = 0.0;
    m_aSteelSection[0].GetHeadPos(&dHeadPos0);
    m_aSteelSection[0].GetTailPos(&dTailPos0);

    double dEntryGauge0    = 0.0;
    double dDeliveryGauge0 = 0.0;
    m_aSteelSection[0].GetEntryGauge(&dEntryGauge0);
    m_aSteelSection[0].GetEntryGauge(&dDeliveryGauge0);

    HRS_ONE_PLATE_DATA  *pPlateData0;

    pPlateData0 = &(pFMData->OnePlateData[0]);


    pPlateData0->fBarThickness       = dEntryGauge0;            //[m]������ڰ�����ȣ���ǰ��
    pPlateData0->fBarWidth           = pStand0->dEntryWidth;    //[m]������ڰ������ȣ���ǰ��
    pPlateData0->fBarLength          = dHeadPos0 - dTailPos0;   //[m]������ڰ������ȣ���ǰ��
    pPlateData0->fStripThickness     = pStand6->dDeliveryGauge; //[m]������Ʒ��ȣ���ǰ��
    pPlateData0->fStripWidth         = pStand6->dDeliveryWidth; //[m]������Ʒ���ȣ���ǰ��
    pPlateData0->fStripLength        = dHeadPos - dTailPos;     //[m]������Ʒ���ȣ���ǰ��
    pPlateData0->fStripHeadPosition  = dHeadPos;                   //[m]��������ͷ��λ�ã���ǰ��
    pPlateData0->fStriptailPosition  = dTailPos;                   //[m]��������β��λ�ã���ǰ��
    pPlateData0->sBarRMTemperature   = pStand0->dEntryTemp;        //[��]���������¶ȣ���ǰ��
    pPlateData0->sBarCSTemperature   = m_Simulator.adEntryTemp[0]; //[��]��������¶ȣ���ǰ��
    pPlateData0->sStripFMTemperature = m_Simulator.adDeliveryTemp[HRS_FINISHMILL_NUM-1]; //[��]���������¶ȣ���ǰ��
    pPlateData0->sStripCoilerTemperature = 0.0; //[��]��ȡ�¶ȣ���ǰ��
    pPlateData0->fStripTempSpeedup       = m_AllStand.CalcPara.dTempAccer;       //[m/s^2]�����¶ȼ��ٶȣ���ǰ��
    pPlateData0->fStripPowerSpeedup      = m_AllStand.CalcPara.dPowerAccer;      //[m/s^2]�������ʼ��ٶȣ���ǰ��
    pPlateData0->fStripCutHead           = 0.0;           //[mm]������ͷ���ȣ���ǰ��
    pPlateData0->fStripCutTail           = 0.0;           //[mm]������β���ȣ���ǰ��

    pFMData->fCSSGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]�ɼ���ڲർ�忪�ڶ��趨ֵ
    pFMData->fCSSGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]�ɼ���ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF2SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F2��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF2SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F2��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF3SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F3��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF3SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F3��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF4SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F4��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF4SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F4��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF5SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F5��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF5SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F5��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF6SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F6��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF6SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F6��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fF7SGEntryWidthReference  = pStand0->dEntryWidth;   // [mm]F7��ڲർ�忪�ڶ��趨ֵ
    pFMData->fF7SGEntryWidthActual     = pStand0->dEntryWidth;   // [mm]F7��ڲർ�忪�ڶ�ʵ��ֵ
    pFMData->fE3GapReference           = pStand0->dEntryWidth;   // [mm]E3���������趨ֵ
    pFMData->fE3GapActual              = pStand0->dEntryWidth;   // [mm]E3��������ʵ��ֵ

    pFMData->fE3ForceReference         = 0.0;   // [kN]E3����ѹ���趨ֵ
    pFMData->fE3ForceActual            = 0.0;   // [kN]E3����ѹ��ʵ��ֵ


    HRS_ONE_FM_DATA  *pOneFMData;
    HRS_ONE_FX_DATA  *pOneFXData;
    HRS_L1_STAND     *pStand;
    float  *pfDeliveryGauge = &pFMData->OnePlateData[1].fBarThickness;
    float  *pfDrafRatio = &pFMData->OnePlateData[1].fStriptailPosition;

    for (int i = 0; i < 6; i++)
    {
        *pfDeliveryGauge = m_Simulator.adDeliveryGauge[i];
        *pfDrafRatio = m_Simulator.adDraft[i]/m_Simulator.adDeliveryGauge[i];
        pfDeliveryGauge++;
        pfDrafRatio++;

        pOneFMData = &(pFMData->OneEquitData[i].OneFMData);

        pOneFMData->fGapAvgReference = m_Simulator.adGap[i];             //[mm]FXƽ�������趨ֵ
        pOneFMData->fGapAvgActual    = m_Simulator.adActGap[i];                //[mm]FXƽ������ʵ��ֵ
        pOneFMData->fGapWSReference  = m_Simulator.adGap[i];              //[mm]FX����������趨ֵ
        pOneFMData->fGapWSActual     = m_Simulator.adActGap[i];                 //[mm]FX���������ʵ��ֵ
        pOneFMData->fGapDSReference  = m_Simulator.adGap[i];              //[mm]FX����������趨ֵ
        pOneFMData->fGapDSActual     = m_Simulator.adActGap[i];                 //[mm]FX���������ʵ��ֵ
        pOneFMData->fGapTiltReference = 0.0;            //[mm]FX��б�����趨ֵ��WS��DS��
        pOneFMData->fGapTiltActual    = 0.0;               //[mm]FX��б����ʵ��ֵ��WS��DS��
        pOneFMData->fHGCWSReference   = 0.0;              //[mm]FX�����������趨ֵ
        pOneFMData->fHGCWSActual      = 0.0;                 //[mm]FX����������ʵ��ֵ
        pOneFMData->fHGCDSReference   = 0.0;              //[mm]FX�����������趨ֵ
        pOneFMData->fHGCDSActual      = 0.0;                 //[mm]FX����������ʵ��ֵ
        pOneFMData->fSumForceReference = m_Simulator.adRollForce[i];           //[MN]FX���������趨ֵ
        pOneFMData->fSumForceActual    = m_Simulator.adActRollForce[i];              //[MN]FX��������ʵ��ֵ
        pOneFMData->fWSForceActual     =  m_Simulator.adActRollForce[i] / 2.0;               //[MN]FX������������ʵ��ֵ
        pOneFMData->fDSForceActual     =  m_Simulator.adActRollForce[i] / 2.0;               //[MN]FX������������ʵ��ֵ
        pOneFMData->fBendingForceReference  = 0.0;       //[MN]FX������趨ֵ
        pOneFMData->fBendingForceActual     = 0.0;          //[MN]FX�����ʵ��ֵ
        pOneFMData->fSpeedReference         = m_Simulator.adSetupSpeed[i];              //[m/s]FX�趨�ٶ�
        pOneFMData->fSpeedActualTopWorkRoll = m_Simulator.adActSpeed[i];      //[m/s]FX�Ϲ�����ʵ���ٶ�
        pOneFMData->fSpeedActualBotWorkRoll = m_Simulator.adActSpeed[i];      //[m/s]FX������ʵ���ٶ�
        pOneFMData->fCVCReference           = 0.0;                //[mm]FX�ܹ��趨λ��
        pOneFMData->fCVCActual              = 0.0;                   //[mm]FX�ܹ�ʵ��λ��
        pOneFMData->fWCLReference           = 0.0;                //[%]FX��������ȴˮ���趨ֵ
        pOneFMData->fWCLActual              = 0.0;                   //[%]FX��������ȴˮ��ʵ��ֵ
        pOneFMData->fCurrentActual          = 0.0;               //[%]FX���������ʵ��ֵ

        pOneFXData = &(pFMData->OneEquitData[i].OneFXData);
        pStand = &(m_AllStand.aAllStand[i]);

        pOneFXData->fVRTensionReference = pStand->dTension;       // [N/mm^2]VR�����趨ֵ
        pOneFXData->fVRTensionActual    = m_Simulator.adTension[i];       // [N/mm^2]VR����ʵ��ֵ
        pOneFXData->fVRAngleReference   = m_Simulator.adLooperTargetAngle[i];       // [��]VR���׽Ƕ��趨ֵ
        pOneFXData->fVRAngleActual      = m_Simulator.adActLooperAngle[i];       // [��]VR���׽Ƕ�ʵ��ֵ
    }

    pFMData->stFM7Data.fGapAvgReference        = m_Simulator.adGap[6];             //[mm]FXƽ�������趨ֵ
    pFMData->stFM7Data.fGapAvgActual           = m_Simulator.adActGap[6];                //[mm]FXƽ������ʵ��ֵ
    pFMData->stFM7Data.fGapWSReference         = m_Simulator.adGap[6];              //[mm]FX����������趨ֵ
    pFMData->stFM7Data.fGapWSActual            = m_Simulator.adActGap[6];                 //[mm]FX���������ʵ��ֵ
    pFMData->stFM7Data.fGapDSReference         = m_Simulator.adGap[6];              //[mm]FX����������趨ֵ
    pFMData->stFM7Data.fGapDSActual            = m_Simulator.adActGap[6];                 //[mm]FX���������ʵ��ֵ
    pFMData->stFM7Data.fGapTiltReference       = 0.0;            //[mm]FX��б�����趨ֵ��WS��DS��
    pFMData->stFM7Data.fGapTiltActual          = 0.0;               //[mm]FX��б����ʵ��ֵ��WS��DS��
    pFMData->stFM7Data.fHGCWSReference         = 0.0;              //[mm]FX�����������趨ֵ
    pFMData->stFM7Data.fHGCWSActual            = 0.0;                 //[mm]FX����������ʵ��ֵ
    pFMData->stFM7Data.fHGCDSReference         = 0.0;              //[mm]FX�����������趨ֵ
    pFMData->stFM7Data.fHGCDSActual            = 0.0;                 //[mm]FX����������ʵ��ֵ
    pFMData->stFM7Data.fSumForceReference      = m_Simulator.adRollForce[6];           //[MN]FX���������趨ֵ
    pFMData->stFM7Data.fSumForceActual         = m_Simulator.adActRollForce[6];              //[MN]FX��������ʵ��ֵ
    pFMData->stFM7Data.fWSForceActual          = m_Simulator.adActRollForce[6] / 2.0;               //[MN]FX������������ʵ��ֵ
    pFMData->stFM7Data.fDSForceActual          = m_Simulator.adActRollForce[6] / 2.0;               //[MN]FX������������ʵ��ֵ
    pFMData->stFM7Data.fBendingForceReference  = 0.0;       //[MN]FX������趨ֵ
    pFMData->stFM7Data.fBendingForceActual     = 0.0;          //[MN]FX�����ʵ��ֵ
    pFMData->stFM7Data.fSpeedReference         = m_Simulator.adSetupSpeed[6];              //[m/s]FX�趨�ٶ�
    pFMData->stFM7Data.fSpeedActualTopWorkRoll = m_Simulator.adActSpeed[6];      //[m/s]FX�Ϲ�����ʵ���ٶ�
    pFMData->stFM7Data.fSpeedActualBotWorkRoll = m_Simulator.adActSpeed[6];      //[m/s]FX������ʵ���ٶ�
    pFMData->stFM7Data.fCVCReference           = 0.0;                //[mm]FX�ܹ��趨λ��
    pFMData->stFM7Data.fCVCActual              = 0.0;                   //[mm]FX�ܹ�ʵ��λ��
    pFMData->stFM7Data.fWCLReference           = 0.0;                //[%]FX��������ȴˮ���趨ֵ
    pFMData->stFM7Data.fWCLActual              = 0.0;                   //[%]FX��������ȴˮ��ʵ��ֵ
    pFMData->stFM7Data.fCurrentActual          = 0.0;               //[%]FX���������ʵ��ֵ

    pFMData->fGMThickness                      = m_Simulator.adDeliveryGauge[6];                           //[mm]����ʵ�ʳ��ں��
    pFMData->fGMTemp                           = m_Simulator.adDeliveryTemp[6];                                //[��]���������¶�ʵ��ֵ

    *pfDeliveryGauge = m_Simulator.adDeliveryGauge[7];
    *pfDrafRatio = m_Simulator.adDraft[7]/m_Simulator.adDeliveryGauge[7];
    return ERR_SUCCESS;
}


void CHRS_L1Trace::DumpSteelSection()
{
    int   i;
    int   nSize;
    char *pszMsg;
    char *apszSectionMsg[HRS_FINISHMILL_NUM + 1];

    nSize = 0;
    for (i = 0; i < HRS_FINISHMILL_NUM + 1; i++)
    {
        apszSectionMsg[i] = m_aSteelSection[i].DumpStr();
        nSize += (int)strlen(apszSectionMsg[i]);
    }

    nSize += 1024;

    pszMsg = (char *)NG_malloc(nSize);
    if (pszMsg == NULL)
    {
        return;
    }

    pszMsg[0] = '\0';
    char szTemp[128];

    sprintf(szTemp, "\r\n\r\n########################LoopTimes: %d ###########################\r\n", m_Simulator.nLoopTimes);
    strcat(pszMsg, szTemp);

    for (i = 0; i < HRS_FINISHMILL_NUM + 1; i++)
    {
        sprintf(szTemp, 
                "!!!--------------- Section: %d -----------------------\r\n", 
                i);
        strcat(pszMsg, szTemp);

        strcat(pszMsg, apszSectionMsg[i]);

        NG_free(apszSectionMsg[i]);
    }

    strcat(pszMsg, "\r\n\r\n");

    error_log("HRS_SteelSection.log", pszMsg);

    NG_free(pszMsg);

    return;
}


void CHRS_L1Trace::DumpSimulatorData()
{
    char *pszMsg;

    pszMsg = HRS_L1Simulator_DumpStr(&m_Simulator);
    if (pszMsg == NULL)
    {
        return;
    }

    error_log("HRS_L1Simulator.log", pszMsg);

    NG_free(pszMsg);

    return;
}


void CHRS_L1Trace::DumpAllStand()
{
    char *pszMsg;

    pszMsg = HRS_L1AllStand_DumpAllStand(&m_AllStand);

    if (pszMsg == NULL)
    {
        return;
    }

    error_log("HRS_AllStand.log", pszMsg);

    NG_free(pszMsg);

    return;
}


void HRS_BuildLine_Double(double *pdData,
                          int nDataCount,
                          char *pszPrefix,
                          char *pszBuf)
{
    int  i;
    char szItem[256];

    pszBuf[0] = '\0';
    strcat(pszBuf, pszPrefix);
    for ( i = 0; i < nDataCount; i++ )
    {
        sprintf(szItem, "%f ", pdData[i]);

        strcat(pszBuf, szItem);
    }
    strcat(pszBuf, "\r\n");

    return;
}


void CHRS_L1Trace::DumpSched()
{
    int i;
    char szBuf[2048];
    char szMsg[16384];

    HRS_FM_PRECALC_DATA  *pCalcData;

    double adEntryGauge[HRS_FINISHMILL_NUM];
    double adDeliveryGauge[HRS_FINISHMILL_NUM];
    double adEntrySpeed[HRS_FINISHMILL_NUM];
    double adGap[HRS_FINISHMILL_NUM];
    double adDraftRatio[HRS_FINISHMILL_NUM];
    double adFlatRadius[HRS_FINISHMILL_NUM];
    double adForwardSlip[HRS_FINISHMILL_NUM];
    double adRollForce[HRS_FINISHMILL_NUM];
    double adTension[HRS_FINISHMILL_NUM];
    double adEntryTemp[HRS_FINISHMILL_NUM];
    double adGaugeRollForceFactor[HRS_FINISHMILL_NUM];
    double adTempForceFactor[HRS_FINISHMILL_NUM];
    double adZeroForce[HRS_FINISHMILL_NUM];
    double adWorkingRollerRadius[HRS_FINISHMILL_NUM];
    double adModulus[HRS_FINISHMILL_NUM];
    double adDeformResist[HRS_FINISHMILL_NUM];
    double adQp[HRS_FINISHMILL_NUM];

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        pCalcData = &(m_pFMSched->PreCalcDataF[i]);
        adEntryGauge[i]    = pCalcData->fEntryGauge;
        adDeliveryGauge[i] = pCalcData->fDeliveryGauge;
        adEntrySpeed[i]    = pCalcData->fSpeed;
        adGap[i]           = pCalcData->fGap;
        adDraftRatio[i]    = pCalcData->fDraftRatio;

        adFlatRadius[i]    = pCalcData->fFlatRadius;
        adForwardSlip[i]   = pCalcData->fForwardSlip;
        adRollForce[i]     = pCalcData->fRollingForce;
        adDeformResist[i]  = pCalcData->fDeformResist;
        adQp[i]            = pCalcData->fQp;
        adTension[i]       = pCalcData->fTension;

        adEntryTemp[i]     = pCalcData->fEnterTemp;
        adGaugeRollForceFactor[i] = pCalcData->fGaugeRollForceFactor;
        adTempForceFactor[i]      = pCalcData->fTempRollForceFactor;

        adZeroForce[i]           = pCalcData->fZeroForce;
        adWorkingRollerRadius[i] = pCalcData->fWorkingRollerRadius;

        adModulus[i]             = pCalcData->fModulus;
    }

    szMsg[0] = '\0';

    strcat(szMsg, "---------------------FMSched Data ----------------------\r\n");

    HRS_BuildLine_Double(adEntryGauge, HRS_FINISHMILL_NUM,
                        "adEntryGauge   : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adDeliveryGauge, HRS_FINISHMILL_NUM,
                        "adDeliveryGauge: ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adEntrySpeed, HRS_FINISHMILL_NUM,
                        "adEntrySpeed   : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adForwardSlip, HRS_FINISHMILL_NUM,
        "adForwardSlip  : ", szBuf);
    strcat(szMsg, szBuf);


    HRS_BuildLine_Double(adGap, HRS_FINISHMILL_NUM,
                        "adGap          : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adDraftRatio, HRS_FINISHMILL_NUM,
                        "adDraftRatio   : ", szBuf);
    strcat(szMsg, szBuf);

    strcat(szMsg, "\r\n");


    HRS_BuildLine_Double(adFlatRadius, HRS_FINISHMILL_NUM,
                        "adFlatRadius         : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adWorkingRollerRadius, HRS_FINISHMILL_NUM,
                        "adWorkingRollerRadius: ", szBuf);
    strcat(szMsg, szBuf);




    strcat(szMsg, "\r\n");


    HRS_BuildLine_Double(adTension, HRS_FINISHMILL_NUM,
                        "adTension      : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adEntryTemp, HRS_FINISHMILL_NUM,
                        "adEntryTemp    : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adRollForce, HRS_FINISHMILL_NUM,
                        "adRollForce    : ", szBuf);
    strcat(szMsg, szBuf);
    HRS_BuildLine_Double(adZeroForce, HRS_FINISHMILL_NUM,
                        "adZeroForce    : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adDeformResist, HRS_FINISHMILL_NUM,
                        "adDeformResist : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adQp, HRS_FINISHMILL_NUM,
                        "adQp           : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adGaugeRollForceFactor, HRS_FINISHMILL_NUM,
                        "adGaugeRollForceFactor: ", szBuf);
    strcat(szMsg, szBuf);
    HRS_BuildLine_Double(adTempForceFactor, HRS_FINISHMILL_NUM,
                        "adTempForceFactor     : ", szBuf);
    strcat(szMsg, szBuf);

    HRS_BuildLine_Double(adModulus, HRS_FINISHMILL_NUM,
                        "adModulus             : ", szBuf);
    strcat(szMsg, szBuf);

    error_log("HRS_Sched.log", szMsg);

    return;
}

//
// �����е�λ����Ϣдһ����д���ļ���
//
void CHRS_L1Trace::DumpPosition()
{
    int            i;
    int            nIndex;
    HRS_POSITION  *pPosition;

    char szTemp[128];
    char *pszMsg;

    char *pszData;


    int   nLen;
    int   nTotalLen;

    if ( m_pCalcCfg == NULL )
    {
        return;
    }

    if (m_pCalcCfg->CalcPara.nIsWriteLog == 0)
    {
        return;
    }

    pszMsg = m_pszMsgBuf;


    pszMsg[0] = '\0';
    nTotalLen = 0;

    strcat(pszMsg, "Begin to Dump Steel Section Message.\r\n");

    nTotalLen = (int)strlen(pszMsg);

    DArray_EnumBegin(m_pPositionArray);

    nIndex = 1;
    for (;;)
    {
        pPosition = (HRS_POSITION *)DArray_EnumNext(m_pPositionArray);
        if (pPosition == NULL)
        {
            break;
        }

        if (nTotalLen > m_nMsgBufLen - 65536 )
        {
            printf("Buf Size not enough, CurIndex = %d, Total Count = %d\r\n", 
                nIndex, 
                m_pPositionArray->nDataCount);

            // ���������Ȳ��㣬ֱ���жϣ��ض�
            break;
        }


        sprintf(szTemp, "\r\n\r\n######################### LoopTimes: %d #############################\r\n", nIndex);

        nLen = (int)strlen(szTemp);
        memcpy(pszMsg + nTotalLen, szTemp, nLen);
        nTotalLen += nLen;

        nIndex += 1;

        for (i = 0; i < HRS_FINISHMILL_NUM + 1; i++)
        {
            sprintf(szTemp, 
                "!!!--------------- Section: %d -----------------------\r\n", 
                i);
            nLen = (int)strlen(szTemp);
            memcpy(pszMsg + nTotalLen, szTemp, nLen);
            nTotalLen += nLen;

            pszData = pPosition->m_ppSteelSection[i]->DumpStr();

            nLen = (int)strlen(pszData);

            memcpy(pszMsg + nTotalLen, pszData, nLen);

            nTotalLen += nLen;

            NG_free(pszData);
        }
    }

    pszMsg[nTotalLen] = '\0';


    char szPath[512];
    NG_Path_GetRunPath(szPath, sizeof(szPath));

    strcat(szPath, "\\FMSimuLog\\");

    _mkdir(szPath);

    NG_TIME  ng_time;
    char szTime[128];

    NGTime_GetLocalTimeMs(&ng_time);

    sprintf(szTime, "%04d%02d%02d%02d%02d%02d", 
        ng_time.nYear, ng_time.nMonth, ng_time.nDate, 
        ng_time.nHour, ng_time.nMinute, ng_time.nSecond);

    strcat(szPath, szTime);
    strcat(szPath, "_");

    strcat(szPath, m_pFMSched->szPlateNo);

    strcat(szPath, "_HRS_SteelSection.log");

    error_log(szPath, pszMsg);

    return;
}


//
// �����е�ģ�������������Ϣһ����д�뵽�ļ���
//
void CHRS_L1Trace::DumpAllSimulatorData()
{
    HRS_L1_SIMULATOR *pSimulator;
    
    char *pszMsg;
    char *pszData;

    int  nTotalLen;
    int  nLen;

    if ( m_pCalcCfg == NULL )
    {
        return;
    }

    if (m_pCalcCfg->CalcPara.nIsWriteLog == 0)
    {
        return;
    }

    pszMsg = (char *)m_pszMsgBuf;
    if (pszMsg == NULL)
    {
        return;
    }

    pszMsg[0] = '\0';

    strcat(pszMsg, "Begin to dump Simulator message.\r\n");

    nTotalLen = (int)strlen(pszMsg);

    DArray_EnumBegin(m_pSimulatorArray);

    for (;;)
    {
        pSimulator = (HRS_L1_SIMULATOR *)DArray_EnumNext(m_pSimulatorArray);
        if (pSimulator == NULL)
        {
            break;
        }

        if (nTotalLen > m_nMsgBufLen - 16384 )
        {
            printf("Buf Size not enough, CurIndex = %d, Total Count = %d\r\n", 
                m_pSimulatorArray->nCurData, 
                m_pSimulatorArray->nDataCount);

            // ���������Ȳ��㣬ֱ���жϣ��ض�
            break;
        }
        pszData = HRS_L1Simulator_DumpStr(pSimulator);

        nLen = (int)strlen(pszData);

        memcpy(pszMsg + nTotalLen, pszData, nLen);

        nTotalLen += nLen;

        NG_free(pszData);
    }

    pszMsg[nTotalLen] = '\0';

    char szPath[512];
    NG_Path_GetRunPath(szPath, sizeof(szPath));

    strcat(szPath, "\\FMSimuLog\\");

    _mkdir(szPath);

    NG_TIME  ng_time;
    char szTime[128];

    NGTime_GetLocalTimeMs(&ng_time);

    sprintf(szTime, "%04d%02d%02d%02d%02d%02d", 
        ng_time.nYear, ng_time.nMonth, ng_time.nDate, 
        ng_time.nHour, ng_time.nMinute, ng_time.nSecond);


    strcat(szPath, szTime);
    strcat(szPath, "_");
    strcat(szPath, m_pFMSched->szPlateNo);

    strcat(szPath, "_HRS_L1Simulator.log");

    error_log(szPath, pszMsg);

    return;
}

