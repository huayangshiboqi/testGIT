#include "NG.h"
#include "NG_sock.h"
#include "HRS_L1Comm.h"
#include "HRS_CalcData.h"

extern int HRS_L1Simulator_Entry();

int main(int argc, char *argv[])
{
    NG_malloc_init();
    {
        NGSock_SysInit();

        printf("HRS L1 Simulator running.\n");

        HRS_L1Simulator_Entry();

        NGSock_SysClose();
    }
    NG_malloc_close();

    return 0;
}

