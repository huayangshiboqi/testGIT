#include <math.h>
#include <stdlib.h>
#include "NG.h"
#include "HRS_CommonCalc.h"
#include "HRS_GaugeSimulator.h"
#include "HRS_LooperTable.h"


void HRS_L1Simulator_FixSched(HRS_FM_SCHED *pSchedData, 
                              HRS_ALL_STAND_PARA *pAllStand)
{
    int i;
    HRS_FM_PRECALC_DATA *pPreCalcData;
    HRS_FM_PRECALC_DATA *pCalcData;
    HRS_STAND_PARA      *pEquipPara;


    //
    // �����������Ϣ
    //
    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        pPreCalcData = &(pSchedData->PreCalcDataF[i]);
        double dDeliveryGauge = pPreCalcData->fGap;
        double dRollingForce  = pPreCalcData->fRollingForce;

        pEquipPara = &(pAllStand->aEquipPara[HRS_STAND_NO_FM1 + i]);

        dDeliveryGauge += (dRollingForce - pPreCalcData->fZeroForce) / pSchedData->PreCalcDataF[i].fModulus;
        //dDeliveryGauge += (dRollingForce / pEquipPara->dModulus);

        pPreCalcData->fDeliveryGauge = dDeliveryGauge;
    }

    for ( i = 1; i < HRS_FINISHMILL_NUM; i++)
    {
        pPreCalcData = &(pSchedData->PreCalcDataF[i]);
        pCalcData = &(pSchedData->PreCalcDataF[i-1]);

        // �����ܵ���ں�ȵ�����һ�����ܵĳ��ں��
        pPreCalcData->fEntryGauge = pCalcData->fDeliveryGauge;
    }

    // ����F7��ǰ��ϵ�������������������ǰ��ϵ��
    double dForwardSlip;
    pPreCalcData = &(pSchedData->PreCalcDataF[HRS_FINISHMILL_NUM-1]);

    double dForwardSlip7 = pPreCalcData->fForwardSlip;

    double dValue = pPreCalcData->fDeliveryGauge;
    dValue *= pPreCalcData->fSpeed;
    dValue *= (1.0 + dForwardSlip7);

    for ( i = HRS_FINISHMILL_NUM-2; i >= 0; i-- )
    {
        pPreCalcData = &(pSchedData->PreCalcDataF[i]);

        dForwardSlip = dValue / pPreCalcData->fSpeed;
        dForwardSlip /= pPreCalcData->fDeliveryGauge;

        dForwardSlip -= 1.0;

        pPreCalcData->fForwardSlip = dForwardSlip;
    }
}


/** Method:    HRS_L1Simulator_PrepareData
    ׼��L1��������õĳ�ʼ����

    @param HRS_FM_SCHED * pSchedData - �����������ָ��
    @param HRS_ALL_STAND_PARA * pAllStandPara - ���ܲ���ָ��
    @param double dHeadPosition - �ְ�ͷ��λ��
    @param double dTailPosition - �ְ�β��λ��
    @param double dFMEntryRollTableSpeed - ��ڹ����ٶ�
    @param double dDeltaTimeMs - �����������
    @param HRS_L1_ALL_STAND * pL1AllStand - [out]��������õĳ�ʼ����
    
    @return void - ��
*/
void HRS_L1Simulator_PrepareData(HRS_FM_SCHED *pSchedData,
                                 HRS_ALL_STAND_PARA *pAllStandPara,
                                 double        dHeadPosition,
                                 double        dTailPosition,
                                 double        dFMEntryRollTableSpeed,
                                 double        dDeltaTimeMs,      
                                 HRS_L1_ALL_STAND *pL1AllStand)
{
    int                  i;
    HRS_L1_STAND        *pStand;
    HRS_STAND_PARA      *pPara;
    HRS_FM_PRECALC_DATA *pPreCalcData;

    //HRS_L1Simulator_FixSched(pSchedData, pAllStandPara);

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        pStand = &(pL1AllStand->aAllStand[i]);
        pPreCalcData = &(pSchedData->PreCalcDataF[i]);
        pPara = &(pAllStandPara->aEquipPara[HRS_STAND_NO_FM1 + i]);

        pStand->dEntryGauge        = pPreCalcData->fEntryGauge;
        pStand->dDeliveryGauge     = pPreCalcData->fDeliveryGauge;
        pStand->dFlatRadius        = pPreCalcData->fFlatRadius;
        pStand->dGap               = pPreCalcData->fGap;
        pStand->dRollForce         = pPreCalcData->fRollingForce;
                                  
        pStand->dEntryTemp         = pPreCalcData->fEnterTemp;
        pStand->dDeliveryTemp      = pPreCalcData->fDeliveryTemp;

        pStand->dEntryWidth        = pPreCalcData->fEntryWidth;
        pStand->dDeliveryWidth     = pPreCalcData->fDeliveryWidth;
                                  
       pStand->dGaugeForceFactor  = pPara->dGaugeForceFactor;  // ���������ϵ��
       pStand->dGaugeForceFactor  = pPreCalcData->fGaugeRollForceFactor 
                                      * HRS_GAUGE_FORCE_FACTOR;  // ���������ϵ��, ��ʱ����0.25��������
//        pStand->dTempForceFactor   = pPara->dTempForceFactor;   // �¶�������ϵ��
        pStand->dTempForceFactor   = pPreCalcData->fTempRollForceFactor;  // �¶�������ϵ��
                                  
//        pStand->dModulus           = pPara->dModulus;   // �ն�ϵ��
        pStand->dModulus           = pPreCalcData->fModulus;
        pStand->dPosition          = pPara->dPosition;  // ����λ�ã���Գ�¯��

        pStand->dSetupSpeed        = pPreCalcData->fSpeed;     // �趨���ٶ�
        pStand->dAGCFactor         = pPara->dAGCFactor;        // AGCϵ����ȱʡ0.5
        pStand->dAGCResponseTimeMs = pPara->dAGCResponseTimeMs;// AGC��Ӧʱ��
        pStand->dMaxAGCAdjust      = pPara->dMaxAGCAdjust;     // ���AGC����ʱ��
        pStand->dPlasticFactor     = pPara->dPlasticFactor;    // ����ϵ��

        pStand->dPlasticFactor     = pPreCalcData->fRollingForce;
        pStand->dPlasticFactor    /= (pPreCalcData->fEntryGauge - pPreCalcData->fDeliveryGauge);
        pStand->dPlasticFactor    *= 1.0;          // ��λ�ɶ�ת��Ϊǧţ
        
        pStand->dSpeedRatio        = pPara->dSpeedRatio;    // �ٶȿ��Ʊ���ϵ��
        pStand->dTimeForSpeed      = pPara->dTimeForSpeed;  // ����ʱ�����
        pStand->dTimeForLooper     = pPara->dTimeForLooper; // ���׵Ļ���ʱ�����
        pStand->dLooperAngleRatio  = pPara->dLooperAngleRatio; // ���׽Ƕ�ϵ�� 

        pStand->dLooperAdjustRatio = pPara->dLooperAdjustRatio; // �ٶȶ�����
                                                                // �ĵ��ڱ���
        pStand->dTension           = pPreCalcData->fTension;    // �趨����
 
        pStand->dZeroForce         = pPreCalcData->fZeroForce;  // ���������

//        pStand->dTempForceFactor   = pPara->dTempForceFactor;

        if  (pPreCalcData->fLooperWaitAngle > 0)
        {
            pStand->dLooperWaitAngle     = pPreCalcData->fLooperWaitAngle;   
        }
        else
        {
            pStand->dLooperWaitAngle     = pPara->dLooperWaitAngle;
        }

        if (pPreCalcData->fLooperTargetAngle > 0)
        {
            pStand->dLooperTargetAngle   = pPreCalcData->fLooperTargetAngle; 
        }
        else
        {
            pStand->dLooperTargetAngle   = pPara->dLooperTargetAngle;
        }

        if (pPreCalcData->fSetupLooperLen > 0)
        {
            pStand->dSetupLooperLen      = pPreCalcData->fSetupLooperLen;
        }
        else
        {
            pStand->dSetupLooperLen      = pPara->dSetupLooperLen;
        }

        if (pPreCalcData->fLowerLooperRestLen > 0)
        {
            pStand->dLowerLooperRestLen  = pPreCalcData->fLowerLooperRestLen;
        }
        else
        {
            pStand->dLowerLooperRestLen  = pPara->dLowerLooperRestLen;
        }

       // pStand->dWorkingRollerRadius = pPara->dMaxWorkingRollerRadius;
        pStand->dWorkingRollerRadius = pPreCalcData->fWorkingRollerRadius;

        pStand->dTensionServoRatio   = pPara->dTensionServoRatio;
        pStand->dForwardSlip         = pPreCalcData->fForwardSlip;

        // ������������������趨�Ƕ�
        double dLooperAngle;
        double dArm;
        HRS_LooperTable_FindAngle(i, pStand->dSetupLooperLen, &dLooperAngle);

        pStand->dSetupLooperAngle = dLooperAngle;

        HRS_LooperTable_FindArmByAngle(dLooperAngle, &dArm);

        pStand->dSetupArm  = dArm;

    }

    pL1AllStand->dOrgHeadPosition    = dHeadPosition;     // ��ʼ�ְ�ͷ��λ��
    pL1AllStand->dOrgTailPosition    = dTailPosition;     // ��ʼ�ְ�β��λ��

    NG_NetTime_GetLocalTimeMs(&(pL1AllStand->StartTime));

    pL1AllStand->dFMEntryRollTableSpeed = dFMEntryRollTableSpeed;   // ����ٶ�
    pL1AllStand->dDeltaTimeMs           = dDeltaTimeMs;             // ʱ������

    return;
}


/** Method:    HRS_L1Simulator_Init
    ��ʼ��L1�������� 

    @param HRS_L1_SIMULATOR * pSimulator - L1����������ṹ��ָ��
    
    @return void - ��
*/
void HRS_L1Simulator_Init(HRS_L1_SIMULATOR *pSimulator)
{
    int i;

    if (pSimulator == NULL)
    {
        return;
    }

    pSimulator->dCurAccer    = 0.0;     // ��ǰ���ٶ�Ϊ0.0

    pSimulator->nProcessState = HRS_PROCESS_STATE_INIT;
    pSimulator->nLoopTimes    = 0;       // ѭ������
    pSimulator->dTotalTimeMs  = 0.0;     // ѭ��һ�ε�ʱ��(ms)

    pSimulator->dCurHeadPos   = 0.0;     // ��ǰ�ְ�ͷ��λ��
    pSimulator->dCurTailPos   = 0.0;     // ��ǰ�ְ�β��λ��
    pSimulator->dPaoGangPos   = 0.0;     // �׸�λ��

    pSimulator->nFirstLoadNo  = -1;      // ��ʼС��0��ʾû�����ص�����
    pSimulator->nLastLoadNo   = -1;      // ��ʼС��0��ʾû�����ص�����

    for (i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        pSimulator->adLowerLooperRestLen[i] = 0.0;
        pSimulator->anLoadedLoopTimes[i]   = 0;    // ���غ����������������
        pSimulator->anIsLoad[i]            = HRS_MILL_NOT_LOADED;  // ��ʼδ����
        pSimulator->adEntryLen[i]          = -1.0; // ��ΪС��0�����ݣ���ʾ��û������
        pSimulator->adDeliveryLen[i]       = 0.0;
        pSimulator->adTotalRestLen[i]      = 0.0;  // ��ʣ�೤��
        pSimulator->adSetupSpeed[i]        = 0.0;

        pSimulator->adLooperSpeedAdjust[i] = 0.0; // ���׿����ٶȵ�����
        pSimulator->adManualSpeedAdjust[i] = 0.0; // �ֶ��ٶȵ�����

        pSimulator->adLooperAngleAdjust[i] = 0.0; // ���׽Ƕȵ���
        pSimulator->adActLooperAngle[i]    = 0.0; // ���׽Ƕ�
        pSimulator->adActLooperLen[i]      = 0.0;

        pSimulator->adActArm[i]            = 0.0; // ��ǰʵ������
        pSimulator->adDeltaArm[i]          = 0.0; // ���۱仯ֵ

        pSimulator->adDeliverySpeed[i]     = 0.0; // �����ٶ�
        pSimulator->adActSpeed[i]          = 0.0; // �ٶ�ʵ��ֵ
        pSimulator->adActSpeedAdjust[i]    = 0.0; // ʵ���ٶȵĵ�����
        pSimulator->adEntrySpeed[i]        = 0.0; 
        pSimulator->adForwardSlip[i]       = 0.0; 

        pSimulator->adSteelSpeed[i]        = 0.0;
        pSimulator->adRollForce[i]         = 0.0;
        pSimulator->adGap[i]               = 0.0;
        pSimulator->adTension[i]           = 0.0;
        pSimulator->adActTensionTorque[i]  = 0.0;
        pSimulator->adSetupTensionTorque[i] = 0.0;
                                          
        pSimulator->adAccer[i]             = 0.0; // ���ٶ�
        pSimulator->adDeltaGauge[i]        = 0.0; // ��������ں���Ŷ�
        pSimulator->adGaugeRollForce[i]    = 0.0; // �����ܺ���Ŷ�������������仯ֵ
        pSimulator->adAGCAdjust[i]         = 0.0; // ������AGC������
        pSimulator->adActAGCAdjust[i]      = 0.0; // ������ʵ��AGC������

        pSimulator->adDeltaGaugeRollForce[i] = 0.0;
        pSimulator->adDeltaTempRollForce[i]  = 0.0;

        pSimulator->adDeltaGap[i]          = 0.0; // �����ܹ��������
        pSimulator->adAGCTargetAdjust[i]   = 0.0; // ������AGCĿ�������(��Ծ)
        pSimulator->adActGap[i]            = 0.0; // ������ʵ�ʹ���

        pSimulator->adDeltaGapRollForce[i] = 0.0; // ����������������仯ֵ
        pSimulator->adActRollForce[i]      = 0.0; // ������ʵ��������

        pSimulator->adDeliveryGauge[i]     = 0.0; // �����ܳ��ں��
        pSimulator->adDraft[i]             = 0.0; // ѹ����

        pSimulator->adDeltaTension[i]      = 0.0;
        pSimulator->adLooperDeltaTension[i] = 0.0;
        pSimulator->adServoAdjust[i]       = 0.0;
        pSimulator->adDeltaLooperLen[i]    = 0.0;

        pSimulator->adEntryTemp[i]         = 0.0;
        pSimulator->adDeliveryTemp[i]      = 0.0;
        pSimulator->adDeltaTemp[i]         = 0.0;

        pSimulator->adForwardSlip[i]       = 0.0;

        pSimulator->adAngleRatio[i]        = 1.0;

        pSimulator->anLooperState[i] = HRS_LOOPER_STATE_INIT;


    }

    pSimulator->adSteelSpeed[HRS_FINISHMILL_NUM] = 0.0;

    return;
}


void HRS_L1Simulator_CalcFirstLoaded(
                            HRS_L1_SIMULATOR *pSimulator, // ģ����ָ��
                            HRS_L1_STAND     *pStand,     // ��1����������ָ��
                            double           dSpeed,      // ������ڹ����ٶ�
                            double dOrgHeadPosition,      // �ְ�ͷ��λ��
                            double dOrgTailPosition,      // �ְ�β��λ��
                            double dDeltaTimeMs           // ʱ��
                            )
{
    // ����1����
    pSimulator->anIsLoad[0] = HRS_MILL_IS_LOADED;

    //
    // ���ݹ����ٶȼ������ٶ����¼���headλ�ú�tailλ��
    //

    // ����ҧ��ʱ��
    double dTime;
    double dRestTime;
    double dEntrySpeed;
    double dDeliverySpeed;

    dTime = pStand->dPosition - dOrgHeadPosition;
    dTime = dTime / dSpeed;   // ��������ٶȵ���ʱ��

    dTime = dTime * 1000.0;                // ת��Ϊ����
    dRestTime = dDeltaTimeMs - dTime;

    // �����ٶ�
    dEntrySpeed = pStand->dSetupSpeed;  

    dDeliverySpeed = dEntrySpeed;
    dDeliverySpeed *= (pStand->dEntryGauge / pStand->dDeliveryGauge);

 //   pSimulator->adPrevSteelSpeed[0] = dEntrySpeed;
 //   pSimulator->adPrevSteelSpeed[1] = dDeliverySpeed;
    pSimulator->adSteelSpeed[0]     = dEntrySpeed;
    pSimulator->adSteelSpeed[1]     = dDeliverySpeed;

    // ���¸ְ�λ��
    double dDis = (dDeliverySpeed * dRestTime) / 1000.0;
    pSimulator->dCurHeadPos = pStand->dPosition + dDis;

    dDis = (dEntrySpeed * dRestTime) / 1000.0;
    pSimulator->dCurTailPos = pStand->dPosition;
    pSimulator->dCurTailPos += dOrgTailPosition;
    pSimulator->dCurTailPos -= dOrgHeadPosition;
    pSimulator->dCurTailPos += dDis;

    // �����1�����ܳ��ڵĸְ峤��
    pSimulator->adEntryLen[0]    = pStand->dPosition - pSimulator->dCurTailPos;
    pSimulator->adDeliveryLen[0] = pSimulator->dCurHeadPos - pStand->dPosition;

    return;
}


int HRS_L1Simulator_CalcLoaded(
                         HRS_L1_SIMULATOR *pSimulator, // ģ����ָ��
                         HRS_L1_ALL_STAND *pAllStand,  // ������������ָ��
                         double           dSpeed,      // ������ڹ����ٶ�
                         double           dDeltaGauge, // ����Ŷ���
                         double dOrgHeadPosition,      // �ְ�ͷ��λ��
                         double dOrgTailPosition,      // �ְ�β��λ��
                         double dDeltaTimeMs           // ʱ��
                         )
{
    int    i;
    double dMovDis;         // �����õ���ʱ����
    double dTimeMs;         // �����õ���ʱ����
    double dRestTimeMs;     // �����õ���ʱ����
    double dCurSpeed;       // �����õ���ʱ����
    double dTempSpeed;      // �����õ���ʱ����
    double dEntrySpeed;     // �����õ���ʱ����
    double dDeliverySpeed;  // �����õ���ʱ����
    double dDis;            // �����õ���ʱ����
    HRS_L1_STAND  *pStand;  // �����õ���ʱ����



    if (pSimulator->nFirstLoadNo < 0)
    {
        // û����������
        if (pSimulator->anIsLoad[HRS_FINISHMILL_NUM-1] == HRS_MILL_UNLOADED)
        {
            // ���һ�������Ѿ�ж�أ���ʾ�����������Ѿ�ж�أ�������Ѿ�����
            return ERR_FAILED;
        }
        else
        {
            // ���е���������û�����أ���������������ߵ������֧
            return ERR_FAILED;
        }
    }

    // �ж�nFirstNo�Ƿ��Ѿ�ж����
    int nFirstNo = pSimulator->nFirstLoadNo;
    pStand       = &(pAllStand->aAllStand[nFirstNo]);

    if (pSimulator->dCurHeadPos > pStand->dPosition)
    {
        // ��1������ж����
        pSimulator->anIsLoad[nFirstNo] = HRS_MILL_UNLOADED;
        pSimulator->nFirstLoadNo      += 1;
        nFirstNo                       = pSimulator->nFirstLoadNo;
    }

    //
    // �ȼ����Ƿ���Ҫж��
    // 
    dCurSpeed    = pSimulator->adSteelSpeed[nFirstNo];
    dMovDis      = dCurSpeed * dDeltaTimeMs;

    if ((pSimulator->dCurTailPos + dMovDis)
         > pStand->dPosition )
    {

        // �����Ŷ����¼�������������ٶȡ����ȵ���Ϣ
        dTempSpeed  = dCurSpeed;
        dTempSpeed *= (pStand->dEntryGauge + dDeltaGauge) / pStand->dDeliveryGauge;

        pSimulator->adSteelSpeed[nFirstNo + 1] = dTempSpeed;


        // ���¼���ʣ�µĸ������ܵ��ٶ�
        for (i = nFirstNo + 2; i < HRS_FINISHMILL_NUM; i++)
        { 
            pStand      = &(pAllStand->aAllStand[i-1]);

            dTempSpeed  = pSimulator->adSteelSpeed[i-1];
            dTempSpeed *= pStand->dEntryGauge / pStand->dDeliveryGauge;

            pSimulator->adSteelSpeed[i] = dTempSpeed;
        }

        // 
        pStand = &(pAllStand->aAllStand[nFirstNo]);

        // ����β��λ��
        dTimeMs  = pStand->dPosition - pSimulator->dCurTailPos;
        dTimeMs /= pSimulator->adSteelSpeed[nFirstNo + 1];
        dTimeMs *= 1000.0;

        dRestTimeMs = dDeltaTimeMs - dTimeMs;

        dTempSpeed = pSimulator->adSteelSpeed[nFirstNo + 1];

        dDis = dTempSpeed * dRestTimeMs;

        pSimulator->dCurTailPos = pStand->dPosition + dDis;

        // ����nFirstNo������һ��ʱ��Ƭѭ����ж��
    }
    else
    {
        // ����nFirstNo����Ҫж��

        // ����β��λ��
        pSimulator->dCurTailPos += dMovDis;

        // ���μ��������������ںͳ����ٶȡ����ȵ���Ϣ
    }



    // �ж���һ�������Ƿ�����
    if (pSimulator->nLastLoadNo < (HRS_FINISHMILL_NUM -1))
    {
        // ����������δ���أ���Ҫ������һ�������Ƿ����� 
        int nLastNo = pSimulator->nLastLoadNo;
        pStand = &(pAllStand->aAllStand[nLastNo +1]);

        dCurSpeed = pSimulator->adSteelSpeed[nLastNo + 1];
        
        dMovDis = dCurSpeed * dDeltaTimeMs;
        if ((pSimulator->dCurHeadPos + dMovDis) 
            > pStand->dPosition )
        {
            // ��һ������������

            // ����ʣ��ʱ��

            dDis = pStand->dPosition - pSimulator->dCurHeadPos;

            dTimeMs = dDis / dCurSpeed;

            dTimeMs *= 1000.0;

            dRestTimeMs = dDeltaTimeMs - dTimeMs;

            // �����ٶ�
            dEntrySpeed = pStand->dSetupSpeed;  

            dDeliverySpeed = dEntrySpeed;
            dDeliverySpeed *= (pStand->dEntryGauge / pStand->dDeliveryGauge);

     //       pSimulator->adPrevSteelSpeed[0] = dEntrySpeed;
     //       pSimulator->adPrevSteelSpeed[1] = dDeliverySpeed;
            pSimulator->adSteelSpeed[0]     = dEntrySpeed;
            pSimulator->adSteelSpeed[1]     = dDeliverySpeed;
        }
        else
        {
            // ��һ��δ����, ���°���ͷ��λ�ü���
            pSimulator->dCurHeadPos += dMovDis;
        }       
    }

    pSimulator->anIsLoad[0] = HRS_MILL_IS_LOADED;

    //
    // ���ݹ����ٶȼ������ٶ����¼���headλ�ú�tailλ��
    //

    // ����ҧ��ʱ��
    double dTime;
    double dRestTime;
//    double dEntrySpeed;
//    double dDeliverySpeed;

    dTime = pStand->dPosition - dOrgHeadPosition;
    dTime = dTime / dSpeed;   // ��������ٶȵ���ʱ��

    dTime = dTime * 1000.0;                // ת��Ϊ����
    dRestTime = dDeltaTimeMs - dTime;

    // �����ٶ�
    dEntrySpeed = pStand->dSetupSpeed;  

    dDeliverySpeed = dEntrySpeed;
    dDeliverySpeed *= (pStand->dEntryGauge / pStand->dDeliveryGauge);

 //   pSimulator->adPrevSteelSpeed[0] = dEntrySpeed;
 //   pSimulator->adPrevSteelSpeed[1] = dDeliverySpeed;
    pSimulator->adSteelSpeed[0]     = dEntrySpeed;
    pSimulator->adSteelSpeed[1]     = dDeliverySpeed;

    // ���¸ְ�λ��
    dDis = (dDeliverySpeed * dRestTime) / 1000.0;
    pSimulator->dCurHeadPos = pStand->dPosition + dDis;

    dDis = (dEntrySpeed * dRestTime) / 1000.0;
    pSimulator->dCurTailPos = pStand->dPosition;
    pSimulator->dCurTailPos += dOrgTailPosition;
    pSimulator->dCurTailPos -= dOrgHeadPosition;
    pSimulator->dCurTailPos += dDis;

    // �����1�����ܳ��ڵĸְ峤��
    pSimulator->adEntryLen[0]    = pStand->dPosition - pSimulator->dCurTailPos;
    pSimulator->adDeliveryLen[0] = pSimulator->dCurHeadPos - pStand->dPosition;

    return ERR_SUCCESS;
}


int HRS_L1Simulator_CalcLen(HRS_L1_ALL_STAND *pL1AllStand,
                            double dDeltaTimeMs,            // ʱ��Ƭ
                            double dDeltaGauge,             // ����Ŷ���
                            HRS_L1_SIMULATOR *pSimulator)
{
    int i;
    int nRet;

    double dMoveDis;
    int nFirstLoadNo;    // ��ǰ�����ص�����
    int nLastLoadNo;     // ��������ص�����

    nFirstLoadNo = -1;   // ��ʼ��Ϊ-1
    nLastLoadNo  = -1;   // ��ʼ��Ϊ-1

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        if (pSimulator->anIsLoad[i] == HRS_MILL_NOT_LOADED)
        {
            nFirstLoadNo = -1;
            break;
        }

        if (pSimulator->anIsLoad[i] == HRS_MILL_IS_LOADED)
        {
            nFirstLoadNo = i;
            break;
        }
    }

    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        if (pSimulator->anIsLoad[i] == HRS_MILL_NOT_LOADED)
        {
            nLastLoadNo = i - 1;
            break;
        }
    }

    if (i >= HRS_FINISHMILL_NUM && nFirstLoadNo > 0)
    {
        nLastLoadNo = HRS_FINISHMILL_NUM - 1;
    }

    pSimulator->dCurHeadPos = pL1AllStand->dOrgHeadPosition;
    pSimulator->dCurTailPos = pL1AllStand->dOrgTailPosition;

    pSimulator->nFirstLoadNo = nFirstLoadNo;
    pSimulator->nLastLoadNo  = nLastLoadNo;

    if ( nFirstLoadNo < 0 )
    {
        // ��û���������ص����

        double dHeadPosition;
        HRS_L1_STAND  *pStand;

        pStand = &(pL1AllStand->aAllStand[0]);

        // ����������δ���ص�������ȸ���λ����Ϣ�����жϵ�1�������Ƿ�����
        dMoveDis      = pL1AllStand->dFMEntryRollTableSpeed 
                        * (dDeltaTimeMs / 1000.0);
        dHeadPosition = pL1AllStand->dOrgHeadPosition + dMoveDis;

        if (pStand->dPosition < dHeadPosition )
        {
            // ����1�Ѿ����أ������������
            HRS_L1Simulator_CalcFirstLoaded(pSimulator, 
                                            pStand, 
                                            pL1AllStand->dFMEntryRollTableSpeed,
                                            pL1AllStand->dOrgHeadPosition, 
                                            pL1AllStand->dOrgTailPosition, 
                                            dDeltaTimeMs);
        }
        else
        {
            // ����1δ���أ�ֱ�ӷ��أ����¸�ʱ�����������¼���
            return ERR_SUCCESS;
        }
    }
    else
    {
        // ���������ص����
        nRet = HRS_L1Simulator_CalcLoaded(
                                   pSimulator, 
                                   pL1AllStand, 
                                   pL1AllStand->dFMEntryRollTableSpeed,
                                   dDeltaGauge,
                                   pL1AllStand->dOrgHeadPosition, 
                                   pL1AllStand->dOrgTailPosition, 
                                   dDeltaTimeMs);
    }

    pSimulator->nLoopTimes   += 1;
    pSimulator->dTotalTimeMs += dDeltaTimeMs;


    return ERR_SUCCESS;
}


/** Method:    HRS_Gauge_CalcRollForce
    ���ݺ���Ŷ����������� 

    @param double dGuageRollForce - ���������������仯
    @param double dOrgRollForce - ԭʼ������
    @param double dPrevDeltaRollForce - ֮ǰ�ı仯������
    @param double * pdActRollForce - [out] �������ʵ��������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Simulator_Gauge_CalcRollForce(double dGaugeRollForce,
                            double dOrgRollForce,
                            double dPrevDeltaRollForce,
                            double *pdActRollForce)
{
    double dActRollForce;

    dActRollForce = dOrgRollForce + dPrevDeltaRollForce + dGaugeRollForce;

    *pdActRollForce = dActRollForce;

    return ERR_SUCCESS;
}


/** Method:    HRS_Gauge_CalcAGCAdjust
    ����AGC������ 

    @param double dKAGC         - AGC����������ϵ��
    @param double dOrgRollForce - ԭʼ������
    @param double dActRollForce - ʵ��������
    @param double dModulus      - ���ܸն�ϵ��
    @param double * pdAGCAdjust - [out] �������AGC������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Simulator_Gauge_CalcAGCAdjust(double dKAGC,
                            double dOrgRollForce,
                            double dActRollForce,
                            double dModulus,
                            double *pdAGCAdjust)
{
    double dAGCAdjust;

    if (dModulus < NG_POSITIVE_ZERO 
        || pdAGCAdjust == NULL)
    {
        return ERR_FAILED;
    }

    dAGCAdjust = (dOrgRollForce - dActRollForce);  // ת����ǧţ

    dAGCAdjust /= dModulus;

    dAGCAdjust *= dKAGC;

    *pdAGCAdjust = dAGCAdjust;

    return ERR_SUCCESS;
}


/** Method:    HRS_Gauge_CalcAGCAdjust
    ����AGC������ 

    @param double dKAGC         - AGC����������ϵ��
    @param double dOrgRollForce - ԭʼ������
    @param double dActRollForce - ʵ��������
    @param double dModulus      - ���ܸն�ϵ��
    @param double * pdAGCAdjust - [out] �������AGC������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Simulator_Gauge_CalcAGCAdjust2(double dKAGC,
                            double dOrgRollForce,
                            double dActRollForce,
                            double dModulus,
                            double dPlasticFactor,
                            double dActGap,
                            double dSetupGap,
                            double *pdAGCAdjust)
{
    double dAGCAdjust;
    double dValue;

    if (dModulus < NG_POSITIVE_ZERO 
        || pdAGCAdjust == NULL)
    {
        return ERR_FAILED;
    }

    dAGCAdjust = dPlasticFactor / dModulus;
    dAGCAdjust *= dSetupGap - dActGap;

    dValue = (dModulus + dPlasticFactor) / dModulus;
    dValue /= dModulus;
    dValue *= (dOrgRollForce - dActRollForce);

    dAGCAdjust += dValue;

    dAGCAdjust *= dKAGC;

    *pdAGCAdjust = dAGCAdjust;


    return ERR_SUCCESS;
}


/** Method:    HRS_Gauge_CalcGapActAdjust
    ����AGCʵ�ʵ����� 

    @param double dTargetAdjust - Ŀ�����������Ծ��
    @param double dDeltaTimeMs - �����ʱ�����ڣ���������
    @param double dAGCResponseTimeMs - AGC��Ӧʱ��ϵ������������
    @param double * pdActAGCAdjust - [out] ����������ʵ��AGC������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Simulator_Gauge_CalcGapActAdjust(double dMaxAGCAdjust,
                                         double dAGCTargetAdjust,
                                         double dDeltaTimeMs,
                                         double dAGCResponseTimeMs,
                                         double *pdActAGCAdjust)
{
    double dActAdjust;

    if ( dAGCResponseTimeMs < NG_POSITIVE_ZERO )
    {
        return ERR_FAILED;
    }
#if 0 //...
    dValue = exp((0.0-dDeltaTimeMs) / dAGCResponseTimeMs);

    dValue = 1.0 - dValue;

    dValue *= dTargetAdjust;
#else
    dActAdjust = dAGCTargetAdjust * 0.0;
#endif

    // ��������Ծ��
    double dMaxAdjust = dDeltaTimeMs;

    dMaxAdjust /= 3 * dAGCResponseTimeMs;

    dMaxAdjust *= dMaxAGCAdjust;

#if 1
    if ( fabs(dAGCTargetAdjust) > dMaxAdjust )
    {
        if ( dAGCTargetAdjust < 0.0 )
        {
            dActAdjust = 0.0 - dMaxAdjust;
        }
        else
        {
            dActAdjust = dMaxAdjust;
        }
    }
    else
    {
        dActAdjust = dAGCTargetAdjust;
    }
#endif

    *pdActAGCAdjust = dActAdjust;

    if (dActAdjust < -10.0 || dActAdjust > 10.0 )
    {
        dprintf("!!!����ActAGCAdjust����.\n");
        return ERR_SUCCESS;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_Gauge_CalcGapActAdjust2
    ����AGCʵ�ʵ����� 

    @param double dMaxAGCAdjust - ��������������
    @param double dPrevAdjust   - ��һ�ε�ʵ�ʵ�������������
    @param double dTargetAdjust - Ŀ���������������
    @param double dDeltaTimeMs - �����ʱ�����ڣ���������
    @param double dAGCResponseTimeMs - AGC��Ӧʱ��ϵ������������
    @param double * pdActAGCAdjust - [out] ����������ʵ��AGC������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Simulator_Gauge_CalcGapActAdjust2(double dMaxAGCAdjust,
                                          double dPrevAdjust,
                                         double dAGCTargetAdjust,
                                         double dDeltaTimeMs,
                                         double dAGCResponseTimeMs,
                                         double *pdActAGCAdjust)
{
    double dActAdjust;    // AGCʵ�ʵ�������
    double dStepAdjust;   // AGC����������

    if ( dAGCResponseTimeMs < NG_POSITIVE_ZERO )
    {
        return ERR_FAILED;
    }

    // ��������Ծ��
    double dMaxAdjust = dDeltaTimeMs;

    dMaxAdjust /= 3 * dAGCResponseTimeMs;

    dMaxAdjust *= dMaxAGCAdjust;


    dStepAdjust = dAGCTargetAdjust - dPrevAdjust;

    if ( fabs(dStepAdjust) > dMaxAdjust )
    {
        if ( dStepAdjust < 0.0 )
        {
            dStepAdjust = 0.0 - dMaxAdjust;
        }
        else
        {
            dStepAdjust = dMaxAdjust;
        }
    }
    
    dActAdjust = dPrevAdjust + dStepAdjust;

    if ( dAGCTargetAdjust < 0.0 )
    {
        if ( dActAdjust < dAGCTargetAdjust )
        {
            dActAdjust = dAGCTargetAdjust;
        }
    }
    else
    {
        if ( dActAdjust > dAGCTargetAdjust )
        {
            dActAdjust = dAGCTargetAdjust;
        }
    }

    *pdActAGCAdjust = dActAdjust;

    if (dActAdjust < -10.0 || dActAdjust > 10.0 )
    {
        dprintf("!!!����ActAGCAdjust����.\n");
        return ERR_SUCCESS;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_L1Simulator_CalcOneStand
    ����һ�����ܵĵ����Ŷ����������͹����Ӱ����� 

    @param HRS_L1_ALL_STAND * pAllStand - ���ܲ���
    @param HRS_L1_SIMULATOR * pSimulator - ģ����
    @param double dDeltaGauge - ����Ŷ�
    @param double dDeltaTemp - �¶��Ŷ�
    @param int nStandIndex - ��������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_L1Simulator_CalcOneStand(HRS_L1_ALL_STAND *pAllStand, 
                           HRS_L1_SIMULATOR *pSimulator,
                           double dDeltaGauge,
                           double dDeltaTemp,
                           int nStandIndex)
{
    double dActGaugeRollForce;       // ����Ŷ����ʵ��������

    double dDeltaGaugeRollForce;     // ����Ŷ�������������仯ֵ
   
    double dAGCAdjust;               // AGC������  
    double dDeltaGap;                // ���������
    double dAGCTargetAdjust;         // AGCĿ�������(��Ծ)

    double dActAGCAdjust;            // ʵ��AGC������
    double dActGap;                  // ʵ�ʹ���

    double dDeltaGapRollForce;       // ����������������仯ֵ
    double dDeltaTempRollForce;      // �¶�������������仯ֵ
    double dActRollForce;            // ������ʵ��������
    double dDeliveryGauge;           // �����ܳ��ں��
    double dDraft;                   // ѹ����

    HRS_L1_STAND  *pStand;           // ����ָ��

    int            nRet;

    if (pAllStand == NULL || pSimulator == NULL)
    {
        return ERR_FAILED;
    }

    if (pSimulator->anIsLoad[nStandIndex] == HRS_MILL_NOT_LOADED )
    {
        // δ���أ�������
        return ERR_FAILED;
    }

    dDeltaGap = 0.0;
    dAGCAdjust = 0.0;
    dAGCTargetAdjust = 0.0;
    dActAGCAdjust = 0.0;


    pStand = &(pAllStand->aAllStand[nStandIndex]);

    // ������ں���Ŷ������Ŷ����������
    dDeltaGaugeRollForce = pStand->dGaugeForceFactor * dDeltaGauge;
    pSimulator->adDeltaGaugeRollForce[nStandIndex] = dDeltaGaugeRollForce;

    dActGaugeRollForce  = pStand->dRollForce + dDeltaGaugeRollForce;

    // ...
    dActGaugeRollForce += pSimulator->adDeltaGapRollForce[nStandIndex];

    int nSwitch = NG_GetBitValue(pAllStand->CalcPara.nTempSwitch, nStandIndex);

    if ( nSwitch == 0 )
    {
        dDeltaTempRollForce = 0.0;
    }
    else
    {

        dDeltaTempRollForce = pStand->dTempForceFactor * dDeltaTemp;

        pSimulator->adDeltaTempRollForce[nStandIndex] = dDeltaTempRollForce;
    }

    dActGaugeRollForce += dDeltaTempRollForce;


    dActRollForce = pStand->dRollForce 
                    + dDeltaGaugeRollForce
                    + dDeltaTempRollForce
                    + pSimulator->adDeltaGapRollForce[nStandIndex];
    if ( dActRollForce < 0.0 )
    {
        dActRollForce = 0.0;
    }

    if ( pSimulator->anIsLoad[nStandIndex] == HRS_MILL_IS_LOADED 
        && pSimulator->anLoadedLoopTimes[nStandIndex] > 2 )
    {
        // ����AGC������
        int nAGCModelIndex = pAllStand->CalcPara.nAGCModelIndex; 

        if ( nAGCModelIndex == HRS_AGC_MODEL_DYNAMIC )
        {
            nRet = HRS_Simulator_Gauge_CalcAGCAdjust2(pStand->dAGCFactor, 
                pStand->dRollForce,
                dActRollForce,
                pStand->dModulus, 
                pStand->dPlasticFactor, 
                pSimulator->adActGap[nStandIndex],
                pStand->dGap,
                &dAGCAdjust);

        }
        else 
        {
            nRet = HRS_Simulator_Gauge_CalcAGCAdjust(pStand->dAGCFactor, 
                pStand->dRollForce,
                dActRollForce,
                pStand->dModulus, 
                &dAGCAdjust);
        }
        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        // �������ƫ��
        // dDeltaGap = pSimulator->adDeltaGap[nStandIndex];
        dDeltaGap = pSimulator->adActGap[nStandIndex] - pStand->dGap;
        dDeltaGap += pSimulator->adActAGCAdjust[nStandIndex];

        // �����Ծ��
        //dAGCTargetAdjust = dAGCAdjust - dDeltaGap;


        dAGCTargetAdjust = pStand->dGap - pSimulator->adActGap[nStandIndex];
        dAGCTargetAdjust += dAGCAdjust;

        int nAGCSwitch = pAllStand->CalcPara.nAGCSwitch;
        if ( nAGCSwitch == 0 )
        {
            dActAGCAdjust = 0.0;
        }
        else if ( nAGCSwitch == 1 )
        {
            // �������ʵ�ʵ�����
            nRet = HRS_Simulator_Gauge_CalcGapActAdjust(
                pStand->dMaxAGCAdjust,
                dAGCAdjust,
                pAllStand->dDeltaTimeMs, 
                pStand->dAGCResponseTimeMs, 
                &dActAGCAdjust);
            if (nRet == ERR_FAILED)
            {
                return ERR_FAILED;
            }
        }
        else
        {
            nRet = HRS_Simulator_Gauge_CalcGapActAdjust2(
                pStand->dMaxAGCAdjust,
                pSimulator->adActAGCAdjust[nStandIndex],
                dAGCAdjust,
                pAllStand->dDeltaTimeMs, 
                pStand->dAGCResponseTimeMs, 
                &dActAGCAdjust);
            if (nRet == ERR_FAILED)
            {
                return ERR_FAILED;
            }
        }

//        dActAGCAdjust += pSimulator->adActAGCAdjust[nStandIndex];

    }
    else
    {
#if 0
        if ( pSimulator->anIsLoad[nStandIndex] == HRS_MILL_NOT_LOADED  
            &&  pSimulator->anIsLoad[nStandIndex] == HRS_MILL_NOT_LOADED)
        dDeltaGap = 0.0;
        dAGCAdjust = 0.0;
        dAGCTargetAdjust = 0.0;
        dActAGCAdjust = 0.0;
#endif
    }


    // ���ݹ���ʵ�ʵ���������ʵ�ʹ���
    dActGap = pStand->dGap + dActAGCAdjust;
    //dActGap = pSimulator->adActGap[nStandIndex] + dActAGCAdjust;

    // �����������������ʵ���������仯��
    dDeltaGapRollForce = pStand->dModulus * pStand->dPlasticFactor;
    dDeltaGapRollForce /= (pStand->dModulus + pStand->dPlasticFactor);

    dDeltaGapRollForce *= dActAGCAdjust;
    dDeltaGapRollForce = 0.0 - dDeltaGapRollForce;

    // ����ʵ�ʹ������ʵ��������
    //dActRollForce += dDeltaGapRollForce;
   // dActRollForce = pStand->dRollForce + dDeltaGapRollForce;
    // ����ʵ��������
    dActRollForce = dActGaugeRollForce;

    if ( dActRollForce < 0.0 )
    {
        dActRollForce = 0.0;
    }

    // ����ʵ�ʹ����ʵ������������ʵ�ʳ��ں�Ⱥ�ѹ����
#define ZERO_ROLL_FORCE   1500
    dDeliveryGauge = dActGap;
//    dDeliveryGauge += (dActRollForce - ZERO_ROLL_FORCE) / pStand->dModulus;
//    dDeliveryGauge += (dActRollForce / pStand->dModulus) ;
    dDeliveryGauge += ((dActRollForce - pStand->dZeroForce)
                          / pStand->dModulus);

    dDraft = pStand->dEntryGauge + dDeltaGauge - dDeliveryGauge;


    //
    // ������������ݵ���Ӧ�����������
    //
    int    i;
    i = nStandIndex;

    pSimulator->adDeltaTemp[i]         = dDeltaTemp;          // ����¶��Ŷ�
    pSimulator->adDeltaGauge[i]        = dDeltaGauge;         // ��ں���Ŷ�
    pSimulator->adGaugeRollForce[i]    = dActGaugeRollForce;  // ����Ŷ�������������仯ֵ
    
    pSimulator->adAGCAdjust[i]         = dAGCAdjust;          // AGC������  
    pSimulator->adDeltaGap[i]          = dDeltaGap;           // ���������
    pSimulator->adAGCTargetAdjust[i]   = dAGCTargetAdjust;    // AGCĿ�������(��Ծ)
                                                              
    pSimulator->adActAGCAdjust[i]      = dActAGCAdjust;       // ʵ��AGC������
    pSimulator->adActGap[i]            = dActGap;             // ʵ�ʹ���
                                                              
    pSimulator->adDeltaGapRollForce[i] = dDeltaGapRollForce;  // ����������������仯ֵ
    pSimulator->adActRollForce[i]      = dActRollForce;       // ������ʵ��������
    pSimulator->adDeliveryGauge[i]     = dDeliveryGauge;      // �����ܳ��ں��
  
    pSimulator->adEntryGauge[i]        = pStand->dEntryGauge + dDeltaGauge;

    pSimulator->adDraft[i]             = pSimulator->adEntryGauge[i] 
                                         - pSimulator->adDeliveryGauge[i];

    return ERR_SUCCESS;                                                          
}



/** Method:    HRS_L1Simulator_CalcSpeed
    ������ܵ�ʵ���ٶȺ͵����ٶ� 

    @param HRS_L1_ALL_STAND * pAllStand - HRS_L1_ALL_STANDָ��
    @param HRS_L1_SIMULATOR * pSimulator - [in/out]
    @param int nStandIndex - �������
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_L1Simulator_CalcSpeed(HRS_L1_ALL_STAND *pAllStand, 
                              HRS_L1_SIMULATOR *pSimulator,
                              int nStandIndex)
{
    HRS_L1_STAND *pStand;
    
    double dSetupSpeed;     // �����趨�ٶ�
    double dActSpeed;       // ʵ���ٶ�
    double dDeltaSpeed;     // �ٶ�ƫ��
    double dActSpeedAdjust; // ʵ���ٶȵ�����
    double dForwardSlip;    // ǰ��ϵ��
    double dDeliverySpeed;  // �����ٶ�
    double dEntrySpeed;     // ����ٶ�

    if (pAllStand == NULL || pSimulator == NULL)
    {
        return ERR_FAILED;
    }

    if (nStandIndex < 0 || nStandIndex >= HRS_FINISHMILL_NUM)
    {
        return ERR_FAILED;
    }

    if (pSimulator->anIsLoad[nStandIndex] != HRS_MILL_IS_LOADED)
    {
        return ERR_FAILED;
    }

    pStand = &(pAllStand->aAllStand[nStandIndex]);

    // ��������ٶ��趨ֵ
    dSetupSpeed = pSimulator->adSetupSpeed[nStandIndex];


    dSetupSpeed += pSimulator->adLooperSpeedAdjust[nStandIndex];
    dSetupSpeed += pSimulator->adManualSpeedAdjust[nStandIndex];

    // ��������ٶ�ʵ��ֵ
    dActSpeed = pSimulator->adActSpeed[nStandIndex] 
                + pSimulator->adActSpeedAdjust[nStandIndex]; 

    
    // ������ٶ�
    double dAccer = pSimulator->adAccer[nStandIndex];

    dSetupSpeed += dAccer * pAllStand->dDeltaTimeMs /1000.0;

#if 0
    if ( pSimulator->nProcessState == HRS_PROCESS_STATE_MAX_SPEED )
    {
        double dMaxSpeed;
        double dRatio;

        dRatio = pSimulator->adDeliveryGauge[HRS_FINISHMILL_NUM-1]
        / pSimulator->adDeliveryGauge[nStandIndex];

        dMaxSpeed = dRatio * pAllStand->CalcPara.dMaxF7Speed;

        dSetupSpeed = dMaxSpeed;
    }
    else if ( pSimulator->nProcessState == HRS_PROCESS_STATE_PAOGANG )
    {
        double dMinSpeed;
        double dRatio;

        dRatio = pSimulator->adDeliveryGauge[HRS_FINISHMILL_NUM-1]
        / pSimulator->adDeliveryGauge[nStandIndex];

        dMinSpeed = dRatio * pAllStand->CalcPara.dMinF7Speed;

        dSetupSpeed = dMinSpeed;
    }
#endif
#if 0
    if (dAccer > NG_POSITIVE_ZERO || dAccer < NG_NEGATIVE_ZERO)
    {
        double dMinSpeed;
        double dMaxSpeed;
        double dRatio;

        dRatio = pSimulator->adDeliveryGauge[HRS_FINISHMILL_NUM-1]
                 / pSimulator->adDeliveryGauge[nStandIndex];

        dMaxSpeed = dRatio * pAllStand->CalcPara.dMaxF7Speed;
        dMinSpeed = dRatio * pAllStand->CalcPara.dMinF7Speed;

        if ( dAccer > NG_POSITIVE_ZERO )
        {
            // С������ٶȲż���
            if ( dActSpeed < dMaxSpeed )
            {
                dSetupSpeed += dAccer * pAllStand->dDeltaTimeMs /1000.0;
            }
        }
        else if ( dAccer < NG_NEGATIVE_ZERO)
        {
            double dDecSpeed = dAccer * pAllStand->dDeltaTimeMs /1000.0;
            // ������С�ٶȲż���
            if ( (dSetupSpeed + dDecSpeed) > dMinSpeed )
            {
                dSetupSpeed += dDecSpeed;
            }
            else
            {
                pSimulator->adAccer[nStandIndex] = 0.0;
            }
        }

    }
#endif

    // �����ٶ�ƫ��
    dDeltaSpeed = dSetupSpeed - dActSpeed;

    // ����ʵ���ٶȵ�����
    dActSpeedAdjust = pStand->dSpeedRatio;
//    dActSpeedAdjust += (pAllStand->dDeltaTimeMs / pStand->dTimeForSpeed) / 1000.0;
    dActSpeedAdjust *= dDeltaSpeed;

    // ����ǰ��
#if 0
    nRet = HRS_Calc_ForwardSlip(pSimulator->adDraft[nStandIndex],
                                pStand->dFlatRadius, 
                                pStand->dEntryTemp, 
                                pStand->dEntryGauge, 
                                &dForwardSlip);

    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }
#endif
    dForwardSlip = pSimulator->adForwardSlip[nStandIndex];

    // ��������ٶ�
    dDeliverySpeed = dActSpeed * (1 + dForwardSlip);

    // ��������ٶ�
    dEntrySpeed  = dDeliverySpeed;
    dEntrySpeed *= pSimulator->adDeliveryGauge[nStandIndex];
    dEntrySpeed /= pSimulator->adEntryGauge[nStandIndex]; 

    //
    // ���ø���������ֵ
    //
    int i = nStandIndex;

    pSimulator->adSetupSpeed[i]     = dSetupSpeed;     // �����趨�ٶ�
    pSimulator->adActSpeed[i]       = dActSpeed;       // ʵ���ٶ�
    pSimulator->adActSpeedAdjust[i] = dActSpeedAdjust; // ʵ���ٶȵ�����
    pSimulator->adForwardSlip[i]    = dForwardSlip;    // ǰ��ϵ��
    pSimulator->adDeliverySpeed[i]  = dDeliverySpeed;  // �����ٶ�
    pSimulator->adEntrySpeed[i]     = dEntrySpeed;     // ����ٶ�

    return ERR_SUCCESS;
}


/** Method:    HRS_L1Simulator_CalcSpeedAdjust
    ����ĳ��ʱ������������л��׶Ը������ܵ��ٶȵ����� 

    @param HRS_L1_ALL_STAND * pAllStand - HRS_L1_ALL_STANDָ��
    @param HRS_L1_SIMULATOR * pSimulator - [in/out] 
    @param int nStandIndex - �������
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_L1Simulator_CalcSpeedAdjust(HRS_L1_ALL_STAND *pAllStand, 
                                  HRS_L1_SIMULATOR *pSimulator,
                                  int nStandIndex)
{
    int  i;
    int  k;
    int  nLooperState;
    HRS_L1_STAND  *pStand;

    double         dLooperAdjust;                  // ���׽Ƕȵ�����
    double         dSpeedAdjust;                        // �ٶȵ�����

    if (pAllStand == NULL || pSimulator == NULL)
    {
        return ERR_FAILED;
    }

    // �ж��Ƿ�����
    nLooperState = pSimulator->anLooperState[nStandIndex];

    if (nLooperState != HRS_LOOPER_STATE_FINISH)
    {
        // δ����״̬��������ֱ�ӷ���
        return ERR_FAILED;
    }


    i = nStandIndex;

    pStand = &(pAllStand->aAllStand[i]);

    // �����i�����׽Ƕ�ƫ��
    dLooperAdjust = pStand->dSetupLooperLen - pSimulator->adActLooperLen[i];

    if (pSimulator->anLooperState[i] == HRS_LOOPER_STATE_INIT)
    {
        // ���ڳ�ʼ״̬���������������ٶȵ�Ӱ��
        return ERR_FAILED;
    }

    // �������ƫ�����Χ������Ҫ�����ٶ�
    double dDelta = fabs(dLooperAdjust);

    if ( dDelta > (pStand->dSetupLooperLen * HRS_LOOPER_LEN_ADJUST_RATIO))
    {
        // ����Ա����ܵĵ����������ۼӵ�adSpeedAdjust[i]������
        pSimulator->adLooperSpeedAdjust[i] += 
                             dLooperAdjust * pStand->dLooperAdjustRatio;

        // ���㱾���׶�֮ǰ�����ܽǶȵ����������ۼӵ���Ӧ�����������
        for ( k = i-1; k >= 0; k-- )
        {
            dSpeedAdjust = pSimulator->adDeliveryGauge[i] 
            / pSimulator->adDeliveryGauge[k];
            dSpeedAdjust *= pSimulator->adLooperSpeedAdjust[i];

            pSimulator->adLooperSpeedAdjust[k] += dSpeedAdjust;
        }
    }
    else
    {
#if 0
        // �����ڷ�Χ�ڣ��������ܳ����ٶȺ���һ��������ٶȵ�����һ��
        dSpeedAdjust = pSimulator->adEntrySpeed[i+1] - pSimulator->adDeliverySpeed[i];

        pSimulator->adLooperSpeedAdjust[i] += dSpeedAdjust;
#endif
    }



    return ERR_SUCCESS;
}


/** Method:    HRS_L1Simulator_CalcDeltaTension
    ���������仯ֵ 

    @param HRS_L1_ALL_STAND * pAllStand - HRS_L1_ALL_STANDָ��
    @param HRS_L1_SIMULATOR * pSimulator - L1����ģ����ָ��
    @param int nStandIndex - �������
    @param double * pdDeltaTension - [out] �����仯��
    
    @return void - ��
*/
void HRS_L1Simulator_CalcDeltaTension(HRS_L1_ALL_STAND *pAllStand,
                                      HRS_L1_SIMULATOR *pSimulator,
                                      int nStandIndex,
                                      double *pdDeltaTension)
{
    // ���������ı仯ֵ���������ı仯��
    int i = nStandIndex;


    double dStandDis = pAllStand->aAllStand[i+1].dPosition;
    dStandDis -= pAllStand->aAllStand[i].dPosition;

    double dDeltaTension = HRS_YANG_E;
    dDeltaTension *= pSimulator->adDeltaLooperLen[i];

    dDeltaTension /= dStandDis + pSimulator->adActLooperLen[i];

    dDeltaTension *= pAllStand->dDeltaTimeMs / 1000.0;

    *pdDeltaTension = dDeltaTension;

    return;
}


/** Method:    HRS_Simulator_CalcLooperAngle
    ������׽Ƕ�, ���׹��̺����׹����е��� 

    @param HRS_L1_ALL_STAND * pAllStand - ���л���ָ��
    @param HRS_L1_SIMULATOR * pSimulator - ģ�������ָ��
    @param int nStandIndex - ��������
    
    @return void - ��
*/
void HRS_L1Simulator_CalcLooperAngle(HRS_L1_ALL_STAND *pAllStand, 
                                     HRS_L1_SIMULATOR *pSimulator,
                                     int nStandIndex)
{
    int    i;
    int    nRet;
    int    nLooperState;
    double dTargetAngle;
    double dActAngleAdjust;    // ʵ�ʽǶȵ�����
    double dActAngle;          // ʵ�ʽǶ�
    
    HRS_L1_STAND  *pStand;

    i = nStandIndex;

    nLooperState = pSimulator->anLooperState[i];
    pStand = &(pAllStand->aAllStand[i]);

    if (nLooperState == HRS_LOOPER_STATE_INIT 
        || nLooperState == HRS_LOOPER_STATE_DOWNED)
    {
        // δ����״̬�����������״̬��������
        pSimulator->adActLooperLen[i] = 0.0;
        pSimulator->adDeltaLooperLen[i] = 0.0;
        pSimulator->adActLooperAngle[i] = pStand->dLooperWaitAngle;
        return;
    }

    // �ж�������״̬
    if (nLooperState == HRS_LOOPER_STATE_UPPING)
    {
        dTargetAngle = pStand->dLooperTargetAngle;
    }
    else if (nLooperState == HRS_LOOPER_STATE_DOWNING)
    {
        dTargetAngle = pStand->dLooperWaitAngle;
    }
    else
    {
        dTargetAngle = pSimulator->adLooperTargetAngle[i];
    }

    // �������ʵ�ʽǶȵ�����
    dActAngleAdjust =  dTargetAngle - pSimulator->adActLooperAngle[i];

    double dRatio = pStand->dLooperAngleRatio;

    // ����ģ�⹫ʽ�������ʵ�ʽǶ�
    dActAngle = pSimulator->adActLooperAngle[i];
    dActAngle += dRatio * dActAngleAdjust * pSimulator->adAngleRatio[i];
//    dActAngle += (pAllStand->dDeltaTimeMs * dActAngleAdjust)
//                 / pStand->dTimeForLooper / 1000.0;

    // �������������������
    pSimulator->adActLooperAngle[i] = dActAngle;


    // �����������
    double dLooperLen = 0.0;
    
    nRet = HRS_LooperTable_Find(i, dActAngle, &dLooperLen);

    pSimulator->adDeltaLooperLen[i] = dLooperLen - pSimulator->adActLooperLen[i];

    pSimulator->adActLooperLen[i] = dLooperLen;

#if 0
    // ���������ı仯ֵ���������ı仯��
    if (pSimulator->anLooperState[i] == HRS_LOOPER_STATE_DOWNING)
    {
        double dDeltaTension;

        HRS_L1Simulator_CalcDeltaTension(pAllStand, pSimulator, i, &dDeltaTension);

        pSimulator->adDeltaTension[i] += dDeltaTension;

        pSimulator->adLooperDeltaTension[i] = dDeltaTension;
    }
#endif

    return;
}


// dAngleΪ����
double HRS_CalcLooperX(double dAngle)
{
    double X;

    X = -2.39056e-8;
    X *= powf(dAngle, 5);

    X += (1.53112e-5) * powf(dAngle, 4);

    X += (-0.002195188) * powf(dAngle, 3);
    X += (0.024685011) * powf(dAngle, 2);

    X += (6.970899) * dAngle;
    X += (-54.1461);

    return X;
}


// dOrgAngleΪ�Ƕ�
double HRS_CalcLooperDeltaX(double dOrgAngle)
{
    double X;

    X = (-1.19528e-7) * powf(dOrgAngle, 4.0);
    X += (6.12449e-5) * powf(dOrgAngle, 3.0);
    X -= (0.006585563) * powf(dOrgAngle, 2.0);
    X += (0.049370021) * dOrgAngle;
    X += (6.970899);

    return X;
}


int HRS_CalcDeltaAngle2(HRS_L1_ALL_STAND *pAllStand, 
                       HRS_L1_SIMULATOR *pSimulator,
                       int nStandIndex,
                       double *pdDeltaAngle)
{
    HRS_L1_STAND  *pStand;

    double dOrgAngle;
    double dActAngle;
    double dOrgTension;
    double dActTension;
    double dLooperLen;
    double dOrgX;
    double dActX;
    double dDeltaX;

    double dDeltaAngle;

    int    nRet;

    //
    // �����趨���׳��Ȳ�ѯ���Ƕ�
    //
    pStand = &(pAllStand->aAllStand[nStandIndex]);
    dLooperLen = pStand->dSetupLooperLen;

    nRet = HRS_LooperTable_FindAngle(nStandIndex, dLooperLen, &dOrgAngle);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dLooperLen = pSimulator->adActLooperLen[nStandIndex];
    nRet = HRS_LooperTable_FindAngle(nStandIndex, dLooperLen, &dActAngle);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }
    
    dOrgX = HRS_CalcLooperX(dOrgAngle);
    dActX = HRS_CalcLooperX(dActAngle);

    dOrgTension = pStand->dTension;
    dActTension = pSimulator->adTension[nStandIndex];


    dDeltaAngle = dOrgX * dOrgTension;
    dDeltaAngle -= dActX * dActTension;

    pSimulator->adSetupTensionTorque[nStandIndex] = dOrgX * dOrgTension;
    pSimulator->adActTensionTorque[nStandIndex] = dActX * dActTension;

//    dDeltaAngle -= dOrgX * pSimulator->adDeltaTension[nStandIndex];

    dDeltaAngle /= dOrgTension;

    dDeltaX = HRS_CalcLooperDeltaX(dOrgAngle);

    dDeltaAngle /= dDeltaX;

    // ���������ӻ���ת���ɽǶ�
    dDeltaAngle = dDeltaAngle;

    *pdDeltaAngle = dDeltaAngle;

    return ERR_SUCCESS;
}


int HRS_CalcDeltaAngle(HRS_L1_ALL_STAND *pAllStand, 
                       HRS_L1_SIMULATOR *pSimulator,
                       int nStandIndex,
                       double *pdDeltaAngle)
{
    HRS_L1_STAND  *pStand;

    double dSetupTorque;   // �趨��������
    double dActTorque;   // ʵ��������
    double dDeltaArm;
    double dDeltaAngle;
    double dActArm = -1.0;
    double dTagAngle;
    int    i;

    i = nStandIndex;
    pStand = &(pAllStand->aAllStand[i]);

    // �ȼ����趨������
    dSetupTorque = pStand->dSetupArm * pStand->dTension;

    // ����ʵ�ʻ��׽Ƕȼ���ʵ������

    HRS_LooperTable_FindArmByAngle(pSimulator->adActLooperAngle[i], &dActArm);

    dActTorque = dActArm * pSimulator->adTension[i];


    dDeltaArm = dSetupTorque - dActTorque;
    dDeltaArm /= pStand->dTension;

    HRS_LooperTable_FindAngleByArm(dDeltaArm + dActArm, &dTagAngle);

    dDeltaAngle = dTagAngle;
    dDeltaAngle -= pSimulator->adActLooperAngle[i];

    pSimulator->adActArm[i] = dActArm;
    pSimulator->adDeltaArm[i] = dDeltaArm;

    pSimulator->adSetupTensionTorque[i] = dSetupTorque;
    pSimulator->adActTensionTorque[i]   = dActTorque;

    *pdDeltaAngle = dDeltaAngle;

    return ERR_SUCCESS;
}


/** Method:    HRS_Simulator_CalcTension
    ��������ģ�⺯�� 
    ֻ��������״̬�ŵ����������

    @param HRS_L1_ALL_STAND * pAllStand - ���ܲ���
    @param HRS_L1_SIMULATOR * pSimulator - ģ�������
    @param int nStandIndex - ���ܱ��
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_L1Simulator_CalcTension(HRS_L1_ALL_STAND *pAllStand, 
                                HRS_L1_SIMULATOR *pSimulator,
                                int nStandIndex)
{
//    double dLooperAdjust;
//    double dActLooperAngle;
    double dDeltaTension;
    double dStandDis;
    double dDeltaSpeed;

    double dServoAdjust;
    
    HRS_L1_STAND  *pStand;

    int i = nStandIndex;

    if (pSimulator == NULL || pAllStand == NULL)
    {
        return ERR_FAILED;
    }

    if (pSimulator->anLooperState[i] != HRS_LOOPER_STATE_FINISH)
    {
        pSimulator->adDeltaTension[i]   = 0.0;
        pSimulator->adServoAdjust[i]    = 0.0;

        return ERR_FAILED;
    }

    pStand = &(pAllStand->aAllStand[i]);

    dStandDis = pAllStand->aAllStand[i+1].dPosition;
    dStandDis -= pStand->dPosition;
    
    // ���������仯
    dDeltaSpeed = pSimulator->adEntrySpeed[i+1]- pSimulator->adDeliverySpeed[i];

    // ������������仯��
//    dDeltaTension = pStand->dDeliveryWidth * pSimulator->adDeliveryGauge[i];

    double dE = HRS_YANG_E;   
    dDeltaTension = dE;

    dDeltaTension /= pSimulator->adActLooperLen[i] + dStandDis;

    dDeltaTension *= dDeltaSpeed;

    dDeltaTension *= pAllStand->dDeltaTimeMs / 1000.0;

    pSimulator->adLooperTargetAngle[i] = pSimulator->adActLooperAngle[i];

    pSimulator->adTension[i] =pStand->dTension + dDeltaTension;

    double dDelta = (pStand->dTension - pSimulator->adTension[i]);

 //   if (fabs(dDelta) > (pStand->dTension * HRS_TENSION_ADJUST_RATIO) )
    {
        // �������������Χ
        // ������׽Ƕȱ仯��
        double dDeltaAngle; 
        HRS_CalcDeltaAngle2(pAllStand, 
                           pSimulator, 
                           i,
                           &dDeltaAngle);

        pSimulator->adLooperTargetAngle[i] += dDeltaAngle;

        pSimulator->adLooperAngleAdjust[i] = dDeltaAngle;
    }

#if 0
    dLooperAdjust = dDeltaSpeed * pAllStand->dDeltaTimeMs / 1000.0;

    // ����ʵ�ʻ�������
    pSimulator->adActLooperLen[i] += dLooperAdjust;   // ���������

    // �����������׽�
    dActLooperAngle = pSimulator->adActLooperAngle[i];
    HRS_LooperTable_FindAngle(i, 
        pSimulator->adActLooperLen[i], 
        &dActLooperAngle
        );
#endif


    // �������������ŷ���������
    dServoAdjust = dDeltaTension  * pStand->dTensionServoRatio;

    // �������ݵ���Ӧ�����������
//    pSimulator->adActLooperAngle[i] = dActLooperAngle;
//    pSimulator->adDeltaLooperLen[i] = dLooperAdjust;
    pSimulator->adDeltaTension[i]   = dDeltaTension;
    pSimulator->adServoAdjust[i]    = dServoAdjust;

    return ERR_SUCCESS;
}


void HRS_L1Simulator_BuildLine_Double(double *pdData,
                                      int nDataCount,
                                      char *pszPrefix,
                                      char *pszBuf)
{
    int  i;
    char szItem[512];

    pszBuf[0] = '\0';
    strcat(pszBuf, pszPrefix);
    for ( i = 0; i < nDataCount; i++ )
    {
        sprintf(szItem, "%.6f ", pdData[i]);

        strcat(pszBuf, szItem);
    }
    strcat(pszBuf, "\r\n");

    return;
}


void HRS_L1Simulator_BuildLine_Int(int *pnData,
                                   int nDataCount,
                                   char *pszPrefix,
                                   char *pszBuf)
{
    int  i;
    char szItem[256];
    
    pszBuf[0] = '\0';

    strcat(pszBuf, pszPrefix);
    for ( i = 0; i < nDataCount; i++ )
    {
        sprintf(szItem, "[%d]:%d", i, pnData[i]);

        strcat(pszBuf, szItem);
        strcat(pszBuf, ", ");
    }
    strcat(pszBuf, "\r\n");

    return;
}



/** Method:    HRS_L1Simulator_DumpStr
    ���������������ַ��������ڵ���ʱ�۲����� 

    @param HRS_L1_SIMULATOR * pSimulator - L1������ָ��
    
    @return char * - �������ɵ��ַ���������ֵ��Ҫ�ɵ�������NG_free�ͷ�
*/
char * HRS_L1Simulator_DumpStr(HRS_L1_SIMULATOR *pSimulator)
{
    char szMsg[32768];   // ����Ĵ�Сһ�㲻����8K,��32K���������㹻��
    char szBuf[4096];    // ��ʱ������
    char *pszRet;        // ����ֵ������szMsg�Ŀ���


    strcpy(szMsg, "############################## L1Simulator Data ############################\r\n");

    sprintf(szBuf, "nLoopTimes = %d, dTotalTimeMs = %f\r\n", 
            pSimulator->nLoopTimes, pSimulator->dTotalTimeMs);
    strcat(szMsg, szBuf);

    sprintf(szBuf, "dCurHeadPos = %f, dCurTailPos = %f\r\n", 
            pSimulator->dCurHeadPos, pSimulator->dCurTailPos);
    strcat(szMsg, szBuf);

    sprintf(szBuf, "nFirstLoadNo = %d, nLastLoadNo = %d\r\n", 
           pSimulator->nFirstLoadNo, pSimulator->nLastLoadNo);
    strcat(szMsg, szBuf);

    //
    //  �¶�
    //
    HRS_L1Simulator_BuildLine_Double(pSimulator->adEntryTemp,
                                     HRS_FINISHMILL_NUM,
                                     "adEntryTemp         : ",
                                     szBuf
                                     );
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeliveryTemp,
                                     HRS_FINISHMILL_NUM,
                                     "adDeliveryTemp      : ",
                                     szBuf
                                     );
    strcat(szMsg, szBuf);

    //
    // ��Ⱥ�ѹ����
    // 
    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaGauge,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaGauge        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeliveryGauge,
                                     HRS_FINISHMILL_NUM,
                                     "adDeliveryGauge     : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adEntryGauge,
                                     HRS_FINISHMILL_NUM,
                                     "adEntryGauge        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adDraft,
                                     HRS_FINISHMILL_NUM,
                                     "adDraft             : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");


    //
    //  �ٶ�
    //
    HRS_L1Simulator_BuildLine_Int(pSimulator->anIsLoad,
                                  HRS_FINISHMILL_NUM,
                                  "Stand Load State    : ",
                                  szBuf
                                  );
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adAccer,
                                     HRS_FINISHMILL_NUM,
                                     "adAccer             : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adSetupSpeed,
                                     HRS_FINISHMILL_NUM,
                                     "adSetupSpeed        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adSteelSpeed,
                                     HRS_FINISHMILL_NUM+1,
                                     "adSteelSpeed        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    
    
    HRS_L1Simulator_BuildLine_Double(pSimulator->adActSpeed,
                                     HRS_FINISHMILL_NUM,
                                     "adActSpeed          : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");

    HRS_L1Simulator_BuildLine_Double(pSimulator->adEntrySpeed,
                                     HRS_FINISHMILL_NUM,
                                     "adEntrySpeed        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeliverySpeed,
                                     HRS_FINISHMILL_NUM,
                                     "adDeliverySpeed     : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adLooperSpeedAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adLooperSpeedAdjust : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adActSpeedAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adActSpeedAdjust    : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adActLooperLen,
                                     HRS_FINISHMILL_NUM,
                                     "adActLooperLen      : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaLooperLen,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaLooperLen    : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adActLooperAngle,
                                     HRS_FINISHMILL_NUM,
                                     "adActLooperAngle    : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adLooperAngleAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adLooperAngleAdjust : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adTension,
                                     HRS_FINISHMILL_NUM,
                                     "adTension           : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaTension,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaTension      : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adLooperDeltaTension,
                                     HRS_FINISHMILL_NUM,
                                     "adLooperDeltaTension: ", 
                                     szBuf);
    strcat(szMsg, szBuf);


    HRS_L1Simulator_BuildLine_Double(pSimulator->adActArm,
                                     HRS_FINISHMILL_NUM,
                                     "adActArm            : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaArm,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaArm          : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adSetupTensionTorque,
                                     HRS_FINISHMILL_NUM,
                                     "adSetupTensionTorque: ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adActTensionTorque,
                                     HRS_FINISHMILL_NUM,
                                     "adActTensionTorque  : ", 
                                     szBuf);
    strcat(szMsg, szBuf);


    strcat(szMsg, "\r\n");


    //
    //  ���׺��ٶȵ�����
    //
    HRS_L1Simulator_BuildLine_Double(pSimulator->adForwardSlip,
                                     HRS_FINISHMILL_NUM,
                                     "adForwardSlip       : ", 
                                     szBuf);
    strcat(szMsg, szBuf);


    HRS_L1Simulator_BuildLine_Double(pSimulator->adManualSpeedAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adManualSpeedAdjust : ", 
                                     szBuf);
    strcat(szMsg, szBuf);


    strcat(szMsg, "\r\n");

    //
    //  ������
    //
    HRS_L1Simulator_BuildLine_Int(pSimulator->anLooperState,
                                  HRS_FINISHMILL_NUM,
                                  "Looper State        : ",
                                  szBuf
                                  );
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adRollForce,
                                     HRS_FINISHMILL_NUM,
                                     "adRollForce         : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaGauge,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaGauge        : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaGaugeRollForce,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaGaugeRollForce: ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaTemp,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaTemp         : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaTempRollForce,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaTempRollForce: ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaGapRollForce,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaGapRollForce : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adActRollForce,
                                     HRS_FINISHMILL_NUM,
                                     "adActRollForce      : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");


    //
    // �����AGC����
    //
    HRS_L1Simulator_BuildLine_Double(pSimulator->adGap,
                                     HRS_FINISHMILL_NUM,
                                     "adGap               : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeltaGap,
                                     HRS_FINISHMILL_NUM,
                                     "adDeltaGap          : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adActGap,
                                     HRS_FINISHMILL_NUM,
                                     "adActGap            : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adAGCAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adAGCAdjust         : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    HRS_L1Simulator_BuildLine_Double(pSimulator->adActAGCAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adActAGCAdjust      : ", 
                                     szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adAGCTargetAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adAGCTargetAdjust   : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");
    

    //
    // �������ŷ���������
    //
    HRS_L1Simulator_BuildLine_Double(pSimulator->adServoAdjust,
                                     HRS_FINISHMILL_NUM,
                                     "adServoAdjust       : ", 
                                     szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");

    //
    // ������Ϣ
    //
    HRS_L1Simulator_BuildLine_Double(pSimulator->adEntryLen, 
        HRS_FINISHMILL_NUM,
        "adEntryLen          : ", 
        szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adDeliveryLen,
        HRS_FINISHMILL_NUM,
        "adDeliveryLen       : ", 
        szBuf);
    strcat(szMsg, szBuf);

    HRS_L1Simulator_BuildLine_Double(pSimulator->adTotalRestLen,
        HRS_FINISHMILL_NUM,
        "adTotalRestLen      : ", 
        szBuf);
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");

    pszRet = StrCopy(szMsg);

    return pszRet;
}


char *HRS_L1Stand_DumpStr(HRS_L1_STAND *pStand)
{
    char szMsg[4096];

    char szBuf[256];

    szMsg[0] = '\0';

    sprintf(szBuf, "dAGCFactor        : %f\r\n", pStand->dAGCFactor);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dAGCResponseTimeMs: %f\r\n", pStand->dAGCResponseTimeMs);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dDeliveryGauge    : %f\r\n", pStand->dDeliveryGauge);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dDeliveryTemp     : %f\r\n", pStand->dDeliveryTemp);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dDeliveryWidth    : %f\r\n", pStand->dDeliveryWidth);
    strcat(szMsg, szBuf);

    sprintf(szBuf, "dEntryGauge       : %f\r\n", pStand->dEntryGauge);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dEntryTemp        : %f\r\n", pStand->dEntryTemp);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dEntryWidth       : %f\r\n", pStand->dEntryWidth);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dFlatRadius       : %f\r\n", pStand->dFlatRadius);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dGap              : %f\r\n", pStand->dGap);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dGaugeForceFactor : %f\r\n", pStand->dGaugeForceFactor);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dLooperAdjustRatio: %f\r\n", pStand->dLooperAdjustRatio);
    strcat(szMsg, szBuf);

    sprintf(szBuf, "dLooperAngleRatio : %f\r\n", pStand->dLooperAngleRatio);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dLooperTargetAngle: %f\r\n", pStand->dLooperTargetAngle);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dLooperWaitAngle  : %f\r\n", pStand->dLooperWaitAngle);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dLowerLooperRestLen: %f\r\n", pStand->dLowerLooperRestLen);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dModulus          : %f\r\n", pStand->dModulus);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dPlasticFactor    : %f\r\n", pStand->dPlasticFactor);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dPosition         : %f\r\n", pStand->dPosition);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dRollForce        : %f\r\n", pStand->dRollForce);
    strcat(szMsg, szBuf);


    sprintf(szBuf, "dSetupLooperAngle   : %f\r\n", pStand->dSetupLooperAngle);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dSetupLooperLen   : %f\r\n", pStand->dSetupLooperLen);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dSetupSpeed       : %f\r\n", pStand->dSetupSpeed);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dSpeedRatio       : %f\r\n", pStand->dSpeedRatio);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dTempForceFactor  : %f\r\n", pStand->dTempForceFactor);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dTensionServoRatio: %f\r\n", pStand->dTensionServoRatio);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dTimeForLooper    : %f\r\n", pStand->dTimeForLooper);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dTimeForSpeed     : %f\r\n", pStand->dTimeForSpeed);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dWorkingRollerRadius: %f\r\n", pStand->dWorkingRollerRadius);
    strcat(szMsg, szBuf);

    sprintf(szBuf, "dSetupArm           : %f\r\n", pStand->dSetupArm);
    strcat(szMsg, szBuf);


    char *pszRet = StrCopy(szMsg);

    return pszRet;
}


/** Method:    HRS_L1AllStand_DumpAllStand
    ��HRS_L1_ALL_STAND�ṹ���ڸ���Ա��Ϣ��ӡ���ַ����� 

    @param HRS_L1_ALL_STAND * pAllStand - Ҫ��ӡ�Ľṹ��ָ��
    
    @return char * - �����ַ���������ֵ��Ҫʹ��NG_free�ͷŵ�
*/
char *HRS_L1AllStand_DumpAllStand(HRS_L1_ALL_STAND *pAllStand)
{
    char szMsg[16384];
    char szBuf[1024];
    int i;
    char *pszStand;
    
    // 
    szMsg[0] = '\0';

    strcpy(szMsg, "---------------All Stand Message -----------------\r\n");

    NG_NetTime_ToSecondStr(&(pAllStand->StartTime), szBuf, sizeof(szBuf)-1);
    strcat(szMsg, "Time: ");
    strcat(szMsg, szBuf);
    strcat(szMsg, "\r\n");

    sprintf(szBuf, "dAccerPos              = %f\r\n", pAllStand->dAccerPos);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dDeltaTimeMs           = %f\r\n", pAllStand->dDeltaTimeMs);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dFMEntryRollTableSpeed = %f\r\n", 
            pAllStand->dFMEntryRollTableSpeed);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dOrgHeadPosition       = %f\r\n", pAllStand->dOrgHeadPosition);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dOrgTailPosition       = %f\r\n", pAllStand->dOrgTailPosition);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dPaoGangPos            = %f\r\n", pAllStand->dPaoGangPos);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dPowerAccer            = %f\r\n", pAllStand->dPowerAccer);
    strcat(szMsg, szBuf);
    sprintf(szBuf, "dTempAccer             = %f\r\n", pAllStand->dTempAccer);
    strcat(szMsg, szBuf);


    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        pszStand = HRS_L1Stand_DumpStr(&(pAllStand->aAllStand[i]));

        sprintf(szBuf, "-------Stand: %d  info as following:--------\r\n", i);

        strcat(szMsg, szBuf);
        strcat(szMsg, pszStand);

        NG_free(pszStand);
    }

    char *pszRet = StrCopy(szMsg);

    return pszRet;
}

