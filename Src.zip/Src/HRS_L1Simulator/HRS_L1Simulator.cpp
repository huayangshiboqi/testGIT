#include "NG.h"
#include "RW_string.h"
#include "NG_sock.h"
#include "NG_CheckSum.h"
#include "HRS_L1Comm.h"
#include "HRS_CalcData.h"
#include "HRS_TempCalc.h"
#include "CHRS_L1Trace.h"

#include "Temperature.h"

#define _USE_COMM            1

#define HRS_L1COMM_LOOP_TIME   3      // ms
#define HRS_L1COMM_CFG_FILE    "HRS_L1Comm.cfg"


MTASK      *g_pHRSL1MTask = NULL;


void HRS_L1SimuLator_Exit()
{
    MTask_SetExitFlag(g_pHRSL1MTask, MTASK_EXIT);

    MTask_Destroy(g_pHRSL1MTask);

    g_pHRSL1MTask = NULL;

    return;
}


/** Method:    HRS_L1Simulator_Entry
    L1���������ں���

    
    @return   int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_L1Simulator_Entry()
{
    char       *pszBuf;
    int         nRecvLen;
    int         nBufLen;
    UINT        uExitFlag;
    HRS_L1COMM *pComm;
    int         nLoopTimes;


    // ��ʼ���¶��½���������
    HRS_TempCalc_SysInit();

    nBufLen = sizeof(HRS_RM_ALL_DATA);
    printf("RM ALL Data size = %ld\n", nBufLen);


    nBufLen = sizeof(HRS_FM_DATA);
    printf("FM SCHED DATA size = %ld\n", nBufLen);

    nBufLen = sizeof(HRS_FM_SCHED);
    printf("RM SCHED size = %ld\n", nBufLen);


    g_pHRSL1MTask = MTask_Create();

#if _USE_COMM
    pComm = HRS_L1Comm_Open(HRS_L1COMM_CFG_FILE);

    if (pComm == NULL)
    {
        HRS_TempCalc_SysClose();

        return -1;
    }
#endif

    nBufLen += 128;
    pszBuf = (char *)NG_malloc(nBufLen);
    if (pszBuf == NULL)
    {
        HRS_TempCalc_SysClose();

        return -1;
    }

    CHRS_L1Trace   Trace;


    int nRet = Trace.Init();
    if (nRet == ERR_FAILED)
    {
        return -1;
    }

    double dDeltaTimeMs = 100;   // 100ms
    nLoopTimes = 0;

    //
    // ��ѭ��
    //
    HRS_FM_DATA   TempFMData;

    MTask_EnterTask(g_pHRSL1MTask);
    for (;;)
    {
        uExitFlag = MTask_GetExitFlag(g_pHRSL1MTask);
        if (uExitFlag == MTASK_EXIT)
        {
            break;
        }

        Trace.Update(dDeltaTimeMs);

        if (Trace.IsFinish())
        {
#if _USE_COMM
            // ���͹�����ݸ�VR
            HRS_FM_DATA   FMData;
            Trace.BuildSched(&FMData);
            Trace.ClacFMActualAve(&FMData);

            FMData.PackHead.sTelDataLength = 0;

            uint32 uCheckSum = GetByteCheckSum((char *)&(FMData.PackHead), 
                sizeof(HRS_PACK_HEAD) - sizeof(short));

            FMData.PackHead.sHeaderSun = (short)uCheckSum;    //[-]����ͷ���ֽ�У���

            // ��������
            nRet = HRS_L1Comm_SendData(pComm, &FMData, sizeof(HRS_FM_DATA));
            if ( nRet == ERR_FAILED )
            {
                printf("Send Data Failed.\n");
            }
#endif
            // д��¼
            Trace.DumpPosition();
            Trace.DumpAllSimulatorData();

            Trace.ReInit();
            
#if _USE_COMM
            continue;
#else
            break;
#endif
        }


        if (Trace.IsHaveSteel())
        {
#if _USE_COMM
            // ���͹�����ݸ�VR
            HRS_FM_DATA   FMData;
            Trace.BuildSched(&FMData);

            // ��������
            nRet = HRS_L1Comm_SendData(pComm, &FMData, sizeof(HRS_FM_DATA));
            if ( nRet == ERR_FAILED )
            {
                printf("Send Data Failed.\n");
            }
            memcpy(&TempFMData, &FMData, sizeof(HRS_FM_DATA));
#endif
            continue;
        }

#if _USE_COMM
        // ������������
        nRecvLen = HRS_L1Comm_RecvData(pComm, pszBuf, nBufLen-1);
        if (nRecvLen <= 1 )
        {
            NGClock_DelayMs(HRS_L1COMM_LOOP_TIME);
            continue;
        }

        // �жϱ������ͣ����б��Ĵ���
        HRS_DATA_HEAD  *pHead;

        LogPrint("L1Comm.log", "Received Data. LoopTimes = %d\r\n", nLoopTimes);
        nLoopTimes += 1;
#if 1
        FILE *fp = fopen("FMSched.log", "wb");

        if (fp != NULL)
        {
            fwrite(pszBuf, nRecvLen, 1, fp);
            fclose(fp);
        }
#endif
        pHead = (HRS_DATA_HEAD *)pszBuf;

        HRS_FM_SCHED  *pSched;

        pSched = (HRS_FM_SCHED *)pHead;

        double dHeadPos = 244.80;
        double dTailPos = 194.0;

        double dGauge = pSched->PreCalcDataF[0].fEntryGauge;
        double dWidth = pSched->PreCalcDataF[0].fEntryWidth;

        double dFMEntryRollTableSpeed = pSched->PreCalcDataF[0].fSpeed;

        // ���ü���
        Trace.PrepareData(pSched, dHeadPos, dTailPos, 
            dFMEntryRollTableSpeed, dDeltaTimeMs);

        Trace.DumpAllStand();

        Trace.DumpSched();

        Trace.Login(dHeadPos, dTailPos, dGauge, dWidth);
#endif
    }

    NG_free(pszBuf);

    MTask_LeaveTask(g_pHRSL1MTask);

    MTask_Destroy(g_pHRSL1MTask);

#if _USE_COMM
    HRS_L1Comm_Destroy(pComm);
#endif

    HRS_TempCalc_SysClose();

    return 0;
}

