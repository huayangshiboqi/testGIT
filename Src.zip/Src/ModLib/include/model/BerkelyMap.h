#pragma once

#include "berkeley_db/db_cxx.h"
#include <string>
#include <vector>

using namespace std;


template<typename TKey,typename TVal>
class BerkelyMap
{
public:
	 BerkelyMap(string file);
	~BerkelyMap(){close();}
	
private:
	bool _init;
	Db _db;
	string _dbfile;	

private:
	void close();

public:
	void init();

	int get(TKey* key, TVal* value);

	int put(TKey* key,TVal* value, bool commit = true);

	int del(TKey* key, bool commit=true);

	char* get_db_errinfo(int errno);

	void commit();

	Dbc* get_cursor();
	int get_next(Dbc *cursor,  TKey *key, TVal *val);
	void close_cursor(Dbc*);
};


struct STKey
{
	int thickClass;
	int widthClass;
	int tempClass;
};


struct STVal
{
	float f1;
	float f2;
	float f3;
	float f4;
	float f5;
	float f6;
	float f7;
};



class BerkelyMap2
{
public:
	BerkelyMap2(string file);
	~BerkelyMap2(){close();}

private:
	bool _init;
	Db _db;
	string _dbfile;	

private:
	void close();

public:
	void init();


	void commit();
};