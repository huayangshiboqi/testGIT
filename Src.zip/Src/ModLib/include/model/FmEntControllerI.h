#ifndef __SCC_d__ng1780_trunk_include_SCC_FmEntControllerI_h__
#define __SCC_d__ng1780_trunk_include_SCC_FmEntControllerI_h__

#include <pace/parameter.h>
//#include "CalcInfo.h"
#include "Controller.h"
#include <model/Temperature.h>

namespace SCC
{

struct FmEntControlData //extends ControllerData
{
   float   tension;
   float   entrySpeed;        /* FMENT speed */
   float   massFlow;          /* EMENT mass flow */
   float   radiTime;          /* air cooling time */
   float   airTempDrop;          /* air cooling temp drop */
};


class FmEntControllerI : virtual public ::SCC::Controller
{
public:

	/**
	* \brief ����
	*/   	
	FmEntControllerI();


	/**
	* \brief ����
	*/ 	
	~FmEntControllerI();
	/**
	* \brief ��������¶�
	* \param[in] int 
	* \ int sfc,    ���ִ���
	* \ int laynum, ��ֲַ���
	* \ float envtemp,  �����¶�
	* \ int adapflag,   ��ѧϰ��ʶ
	* \ float corrtemp  �¶�������
	* \��ϸ�μ�FmEntController.ice�Ķ���
	*/ 
	//vector<float> calcExitTemp(int,int,float, float, int, float );
   vector<float> calcExitTemp(int sfc, int laynum, float envtemp, int adapflag, float corrtemp);

	//void setCalcInfo(FM::CalcInfo& ifo)	{info=ifo;};

//private:
	//FM::CalcInfo info;


     //TemperatureI tempcalc;

	  FmEntControlData fment;

};
}
#endif
