// **********************************************************************
//
// Copyright (c) 1978-2005 Baosteel, Inc. All rights reserved.
//
// **********************************************************************
#ifndef __PACE_MYDATETIME_H__
#define __PACE_MYDATETIME_H__

//#include <Ice/Config.h>
//#include <string.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
using namespace std;
//typedef long Long;
typedef long Long;


class DateTime
{
public:
	DateTime(){};
	DateTime(Long t)
		:_t(t)
	{};

	DateTime(const int year, 
		const int mon,
		const int day,
		const int hour=0,
		const int min=0, 
		const int sec=0)
	{
		struct tm _tm;
		_tm.tm_sec = sec;
		_tm.tm_min = min;
		_tm.tm_hour = hour;
		_tm.tm_mday =  day;
		_tm.tm_mon = mon - 1;
		_tm.tm_year = year - 1900;
		_tm.tm_isdst = -1;

		_t = /*Time::seconds*/(mktime(&_tm));
	}; 

	static Long  toDateTime(const int year, 
							const int mon,
							const int day,
							const int hour=0,
							const int min=0, 
							const int sec=0)
	{  
		//IceUtil::Time  cur_tm;
		struct tm _tm;
		_tm.tm_sec = sec;
		_tm.tm_min = min;
		_tm.tm_hour = hour;
		_tm.tm_mday =  day;
		_tm.tm_mon = mon - 1;
		_tm.tm_year = year - 1900;
		_tm.tm_isdst = -1;		   
		//cur_tm = IceUtil::Time::seconds(mktime(&_tm));

		return (long)(mktime(&_tm));
	}
	void SetDateTime(string  str_datetime)  //str_datetime like '20100512234356' 
	{
		int  year,mon,day,hour,minute,sec;
		year = atoi((str_datetime.substr(0,4)).c_str());
		mon  = atoi((str_datetime.substr(4,2)).c_str());
		day  = atoi((str_datetime.substr(6,2)).c_str());
		hour = atoi((str_datetime.substr(8,2)).c_str());
		minute = atoi((str_datetime.substr(10,2)).c_str());
		sec  = atoi((str_datetime.substr(12,2)).c_str());
		struct tm _tm;
		_tm.tm_sec = sec;
		_tm.tm_min = minute;
		_tm.tm_hour = hour;
		_tm.tm_mday =  day;
		_tm.tm_mon = mon - 1;
		_tm.tm_year = year - 1900;
		_tm.tm_isdst = -1;
		_t = /*Time::seconds*/(mktime(&_tm));
	}
	static DateTime now()
	{
		time_t tm;
		return DateTime(static_cast<long>(time(&tm)));
	};

	Long toSeconds() const
	{
		return static_cast<long>(_t);
	};

	std::string toString() const
	{
		struct tm* when;
		string str("YYYY-MM-DD HH:MM:SS");

		char buf[50];
		when = localtime( &_t );

		sprintf( buf,"%4d-%.2d-%.2d %.2d:%.2d:%.2d", when->tm_year+1900,when->tm_mon+1,when->tm_mday, when->tm_hour,when->tm_min,when->tm_sec );
		str = buf;
		return str;

	};


	std::string toString14() const
	{
		struct tm* when;
		string str("YYYYMMDDHHMMSS");

		char buf[50];
		when = localtime( &_t );

		sprintf( buf,"%4d%.2d%.2d%.2d%.2d%.2d", when->tm_year+1900,when->tm_mon+1,when->tm_mday, when->tm_hour,when->tm_min,when->tm_sec );
		str = buf;
		return str;

	};

	void AddYears(int years)
	{
		struct tm* _tm;
		_tm = localtime(&_t );
		_tm->tm_year+=years;

		_t = /*Time::seconds*/(mktime(_tm));
	}

	void AddDays(int days)
	{
		struct tm* _tm;
		_tm = localtime(&_t );
		_tm->tm_mday += days;

		_t = /*Time::seconds*/(mktime(_tm));
	}

	void AddMins(int mins)
	{
		struct tm* _tm;
		_tm = localtime(&_t );
		_tm->tm_min += mins;

		_t = /*Time::seconds*/(mktime(_tm));
	}

	void AddSeconds(int seconds)
	{
		struct tm* _tm;
		_tm = localtime(&_t );
		_tm->tm_sec += seconds;

		_t = /*Time::seconds*/(mktime(_tm));
	}

	int year() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_year + 1900 ;
	};

	int month() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_mon + 1;
	};

	int day() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_mday ;
	};

	int hour() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_hour ;
	};

	int minute() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_min ;
	};

	int second() const
	{
		struct tm* _tm;

		_tm = localtime(&_t );
		return _tm->tm_sec ;
	};


	DateTime operator-() const
	{
		return DateTime(static_cast<long>(-_t));
	};
	DateTime operator-(const DateTime& rhs) const
	{
		return DateTime(static_cast<long>(_t - rhs._t));
	};
	DateTime& operator-=(const DateTime& rhs)
	{
		_t -= rhs._t;
		return *this;
	};
	DateTime operator+(const DateTime& rhs) const
	{
		return DateTime(static_cast<long>(_t + rhs._t));
	};
	DateTime& operator+=(const DateTime& rhs)
	{
		_t += rhs._t;
		return *this;
	};

	bool operator<(const DateTime& rhs) const
	{
		return _t<rhs._t;
	};
	bool operator>(const DateTime& rhs) const
	{
		return _t>rhs._t;
	};
	bool operator<=(const DateTime& rhs) const
	{
		return _t<=rhs._t;
	};
	bool operator>=(const DateTime& rhs) const
	{
		return _t>=rhs._t;
	};
	bool operator==(const DateTime& rhs) const
	{
		return _t==rhs._t;
	};
	bool operator!=(const DateTime& rhs) const
	{
		return _t!=rhs._t;
	};
	double operator/(const DateTime& rhs) const
	{
		return static_cast<double>(_t / rhs._t);
	};
	template<typename T> 
		double operator*(T rhs) const
	{
		return _t / rhs;
	};
	template<typename T> 
		DateTime& operator/=(T rhs) const
	{
		_t /= rhs._t;
		return *this;
	};
	template<typename T> 
		DateTime& operator*=(T rhs) const
	{
		_t*=rhs._t;
		return *this;
	};

private:
	time_t  _t;
};

#endif
