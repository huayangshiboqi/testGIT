////#pragma once

#ifndef _RMC_WidthAdaption_h_
#define _RMC_WidthAdaption_h_

#include <vector>
#include "WidthModel.h"

using namespace std;

struct widthAdaptionException 
{
	int code;
	char info[100];
};

namespace RMC
{

	//-----------width Model Process structure----------
	struct ActualData
	{

		float Mean;
		float Confid;
		float Std;
		float Max;
		float Min;
	};

	struct RMSpreadInherProcess
	{	
	
		float E1LongQNO[3];     
		float E1DogLongQNO[2];  
		float E2LongQNO[7];     
		float E2DogLongQNO[4];	

		float E1Long[3];
		float E1DogLong[2];
		float E2Long[7];
		float E2DogLong[4];	
		
		float E1Short[3];
		float E1DogShort[2];
		float E2Short[7];
		float E2DogShort[4];
	};

	struct RMSpreadInherProcessVec
	{	

		vector<float> E1LongQNO;     //float E1LongQNO[3];     
		vector<float> E1DogLongQNO;  //float E1DogLongQNO[2];  
		vector<float> E2LongQNO;     //float E2LongQNO[7];     
		vector<float> E2DogLongQNO;  //float E2DogLongQNO[4];		
						  
		vector<float> E1Long;		  //float E1Long[3];
		vector<float> E1DogLong;	  //float E1DogLong[2];
		vector<float> E2Long;		  //float E2Long[7];
		vector<float> E2DogLong;	  //float E2DogLong[4];	
						  
		vector<float> E1Short;		  //float E1Short[3];
		vector<float> E1DogShort;	  //float E1DogShort[2];
		vector<float> E2Short;		  //float E2Short[7];
		vector<float> E2DogShort;	  //float E2DogShort[4];
	};


	struct PostEdgerDraft
	{
		vector<float > postE1Spread;
		vector<float > postE1Dog;
		vector<float > postE2Spread;
		vector<float > postE2Dog;
		vector<float > postR1Width;
		vector<float > postR2Width;
		vector<float > targetR1Width;
		vector<float > targetR2Width;
		float OpMod;
		RMwidthGlobalData GlobalInher;
	};

	struct FMSpreadInherProcess
	{
		float inherLongQNO;    
		float inherLong;		
		float inherShort;
		float inherLongQNONew;    
		float inherLongNew;		
		float inherShortNew;
		FMNSError NSError;
	};

	    //float paraShort[5];
		//float HkShort[5];
		//float KkShort[5];
		//float PkShort[5][5];
		//float NS_Error;

	struct RdwMarginInherProcess
	{
		float MarginTotalLongQNO;
		float MarginHeadLongQNO; 
		float MarginBodyLongQNO; 
		float MarginTailLongQNO; 

		float MarginTotalLong;
		float MarginHeadLong;
		float MarginBodyLong;
		float MarginTailLong;

		float MarginTotalShort;
		float MarginHeadShort;
		float MarginBodyShort;
		float MarginTailShort;
////		int stripAccumNum;
	};

	struct RdwGlobalInherProcess
	{	
		float RdwGlobalInherTotalLongQNO;  
		float RdwGlobalInherHeadLongQNO;   
		float RdwGlobalInherMiddleLongQNO; 
		float RdwGlobalInherTailLongQNO;   

		float RdwGlobalInherTotalLong;           
		float RdwGlobalInherHeadLong;
		float RdwGlobalInherMiddleLong;
		float RdwGlobalInherTailLong;

		float RdwGlobalInherTotalShort;
		float RdwGlobalInherHeadShort;
		float RdwGlobalInherMiddleShort;
		float RdwGlobalInherTailShort;

		//float RdwGlobalInherTotalLong;           
		//float RdwGlobalInherHeadLong;
		//float RdwGlobalInherMiddleLong;
		//float RdwGlobalInherTailLong;
		//float RdwGlobalInherTotalShort;
		//float RdwGlobalInherHeadShort;
		//float RdwGlobalInherMiddleShort;
		//float RdwGlobalInherTailShort;
	};

	struct WidthGlobalInherProcess
	{	
		float WidthGlobalInherTotalLongQNO ;  
		float WidthGlobalInherHeadLongQNO  ;   
		float WidthGlobalInherMiddleLongQNO; 
		float WidthGlobalInherTailLongQNO  ;   

		float WidthGlobalInherTotalLong  ;           
		float WidthGlobalInherHeadLong   ;
		float WidthGlobalInherMiddleLong ;
		float WidthGlobalInherTailLong   ;
		float WidthGlobalInherTotalShort ;
		float WidthGlobalInherHeadShort  ;
		float WidthGlobalInherMiddleShort;
		float WidthGlobalInherTailShort  ;
	};

	struct SSCOptimaeCropData
	{
		float slabThick;
		float slabCropLengthHead     ;
		vector<int> MeasureNumHead   ;
		vector<float> slabHeadPos    ;
		vector<float> slabWidthHeadE1;
		vector<float> slabWidthHeadE2;
		vector<float> slabWidthHeadE3;
		vector<float> slabWidthHeadE4;
		vector<float> slabWidthHeadE5;
		vector<float> slabWidthHeadE6;

		float slabCropLengthTail     ;
		vector<int> MeasureNumTail   ;
		vector<float> slabTailPos    ;
		vector<float> slabWidthTailE1;
		vector<float> slabWidthTailE2;
		vector<float> slabWidthTailE3;
		vector<float> slabWidthTailE4;
		vector<float> slabWidthTailE5;
		vector<float> slabWidthTailE6;
	};

	struct SSCSetCalData
	{
		float SlabThick      ;                  //����¯����
		float SlabWidth      ;                  //����¯����
		float RM1ExitWidth[3];
		float RM2ExitWidth[7];
		float RM1ExitThick[3];
		float RM2ExitThick[7];
		float E1dWidthHead[2];          //SscSetPointData�� dWidthHeadW
		float E2dWidthHead[4];
		float E1dWidthTail[2];
		float E2dWidthTail[4];
		float E1LengthHead[2];
		float E1LengthTail[2];
		float E2LengthHead[4];
		float E2LengthTail[4];

	};

	struct SSCInherProcess
	{
		float SCCOptCropVolumH[3];
		float SCCOptCropVolumT[3];
		float SCCTargetWidthH[3];
		float SCCTargetWidthT[3];
		//Length inher
		float E1LHInherLong[2];
		float E1LTInherLong[2];
		float E1LHInherShort[2];
		float E1LTInherShort[2];

		float E2LHInherLong[4];
		float E2LTInherLong[4];
		float E2LHInherShort[4];
		float E2LTInherShort[4];
		//dW  inher
		float E1dWHInherLong[2];
		float E1dWTInherLong[2];
		float E1dWHInherShort[2];
		float E1dWTInherShort[2];

		float E2dWHInherLong[4];
		float E2dWTInherLong[4];
		float E2dWHInherShort[4];
		float E2dWTInherShort[4];

		float KTargetHead;
		float KTargetTail;
		float HeadBalanceFlag;
		float TailBalanceFlag;
		float LearnStatusHead;
		float LearnStatusTail;
		int KTrendHead;
		int KTrendTail;
		int HeadNotInher;
		int TailNotInher;
		int HeadTrendChangeNum;
		int	TailTrendChangeNum;
		int SCCInherModeHead;
		int SCCInherModeTail;

		int SCCstripLearnAccumNum;
		int AdjustBalanceHeadAccumNum;
		int AdjustBalanceTailAccumNum;
	};

	struct SSCInherModProcess
	{
		vector<float> E1HeadInherLong;
		vector<float>  E1HeadInherLongQNO;	
		vector<float>  E1HeadInherShort;	
    	vector<float>  E2HeadInherLong;
		vector<float>  E2HeadInherLongQNO;
		vector<float>  E2HeadInherShort;

		vector<float> E1TailInherLong;
		vector<float>  E1TailInherLongQNO;	
		vector<float>  E1TailInherShort;	
		vector<float>  E2TailInherLong;
		vector<float>  E2TailInherLongQNO;
		vector<float>  E2TailInherShort;
		
	};

	struct CncInherProcess
	{
		float CncStartInherLongQNO;
		float CncLengthInherLongQNO;
		float CncWidthInherLongQNO;

		float CncStartInherLong;
		float CncLengthInherLong;
		float CncWidthInherLong;
		float CncStartInherShort;
		float CncLengthInherShort;
		float CncWidthInherShort;
	////	int stripAccumNum;
	};

	struct LongSSCWidthInherProcess
	{
		vector <float>  DCWHeadInherQNO;
		vector <float>  DCWTailInherQNO;
		vector <float>  DCWHeadInherShort;
		vector <float>  DCWTailInherShort;
		vector <float>  DCWHeadInherLong;
		vector <float>  DCWTailInherLong;
	};

	struct FMWidthInherData
	{
		////������Ȼ��չ�����data
		int Calmode;
		SteelInfomation SteelInfo;
		FmSpreadCalData FMData;
		SteelIndexCode CodeOld;       ////ָ��������Ŵ��Ĵ���
		SteelIndexCode CodeNew;      ////ָ������ô���
		FMSpreadPara paraL;
		//FMSpreadInherData paraInher;    //ģ�ͼ���ѡ�õ��Ŵ�ϵ����������ʱ�Ͷ�ʱ
		int FMDelay;
		StripRollNum stripAccumNum;
		FMSpreadData fmSpread;
		///////////////////////������Ȼ��չѧϰ
		ActualData FMThickAct;    //Actual value
		ActualData FMWidthAct;
		ActualData FMTalDraftRatioAct;
		ActualData FDTempAct;
		ActualData RMWidthAct;
		//FMSpreadData postFMSpread;
		float E3ReduAct;
		float postE3Dog;
		//FMSpreadInherProcess& FMSpreadAdaData;//����ȫ��ѧϰdata//
		//int SteelChange;  ԭ���ⲿ���룬Ŀǰģ�����Լ�����
		float OPMod;
		//ActualData RMWidthAct;
		ActualData RMWidthActHead;
		ActualData RMWidthActTail;
		ActualData RMWidthActMiddle;
		//ActualData FMWidthAct;
		ActualData FMWidthActHead;
		ActualData FMWidthActTail;
		ActualData FMWidthActMiddle;
		RdwTargetData rdwTarget;
		float FMWTargetPDI;  //Cool value
		RdwMarginInherData Margin;
		RM3WTargetMod  WidMod;
	};

		//float FmDelThick;
		//float FmDelWidth;
		//float FmTalDraft; 
		//float FDTemp;
	    //StripRollNum stripAccumNum;
		//RdwGlobalInherProcess&  RdwGlobalInherData;
		///////////////////����Ŀ��ѧϰdata
		//ActualData FDWidth;
		//ActualData FDWidthHead;
		//ActualData FDWidthTail;
		//ActualData FDWidthBody;
		//StripRollNum stripAccumNum;
		//RdwMarginInherProcess& RdwMarginInherCal;


	struct FMImpactComInherData
	{
		vector <float> ImpactInherEquip;
		vector <float> ImpactInherLongSFC;
		vector <float> ImpactInherLongQNO;
		vector <float> ImpactInherShort;
		vector <float> LooperAngleMax1;
		vector <float> LooperAngleMax2;
		vector <float> LooperAngleAve;
		vector <float> LooperAngle;		
	};

	struct FMImpactComAct
	{
		vector <float> SpeedF2;   vector <float> AngleF2 ;  vector <float> SampleTimeF2;	   vector <float> OpModSpeedF1;     
		vector <float> SpeedF3;   vector <float> AngleF3 ;  vector <float> SampleTimeF3;	   vector <float> OpModSpeedF2;     
		vector <float> SpeedF4;   vector <float> AngleF4 ;  vector <float> SampleTimeF4;	   vector <float> OpModSpeedF3;     
		vector <float> SpeedF5;   vector <float> AngleF5 ;  vector <float> SampleTimeF5;	   vector <float> OpModSpeedF4;     
		vector <float> SpeedF6;   vector <float> AngleF6 ;  vector <float> SampleTimeF6;	   vector <float> OpModSpeedF5;     
		vector <float> SpeedF7;   vector <float> AngleF7 ;  vector <float> SampleTimeF7;	   vector <float> OpModSpeedF6;     
	};																																														

	struct CNCStripWidthData
	{
		vector<float> slabPos;
		vector<float> slabWidth;
		int CNCStart;
		int CNCNum;
	};


	//---------------------------------------------------------------------
	//  Clamp
	//������ֵǯλ��[min max]֮��
	// Clamp an input value to lie within the min and max values inclusive.
	//---------------------------------------------------------------------
	inline  int  Clamp(int x, int min, int max)
	{
		if (x < min)
			return min;
		if (x > max)
			return max;
		return x;
	}

	inline  float Clamp(float x, float min, float max)
	{
		if (x  < min)
			return min;
		if (x > max)
			return max;
		return x;
	}

	inline  double  Clamp(double x, double min, double max)
	{
		if (x < min)
			return min;
		if (x > max)
			return max;
		return x;
	}


class WidthAdaption
{

	widthAdaptionException errinfo;
private:
	////Log on Config
	int RMWidthInherCalLogOn    ;
	int RdwGlobalInherCalLogOn  ;
	int WidthGlobalInherCalLogOn;
	int FMSpreadInherCalLogOn   ;
	int SSCInherCalLogOn        ;
	int RdwTargetInherCalLogOn  ;
	int CNCInherCalLogOn        ;
	int DCWidthInherCalLogOn    ;
	int FMImpactComInherCalLogOn;
	
	////Inherit on
	int RMWidthInherCalOn  ;
	int RdwGlobalInherCalOn;
	int FMSpreadInherCalOn ;
	int SSCInherCalOn      ;
	int SSCInherModCalOn   ;
	int RdwTargetInherCalOn;
	int CNCInherCalOn	   ;
	int WidthGlobalInherCalOn;
	int DCWidthInherCalOn    ;
	int FMImpactComInherCalOn;
	
	////Inherit Use
	int RMWidthInherUse  ;
	int RdwGlobalInherUse;
	int FMSpreadInherUse ;
	int SSCInherUse      ;
	int RdwTargetInherUse;
	int CNCInherUse	     ;
	int WidthGlobalInherUse;
	int MarginInherUse   ;

	//paramT.ConfigFile;
	float GainConfid     ;
	int SlabInnherNumMax ;
	//ģ��ѧϰ����������
	//��չmodel
	float   FM_SPREAD_LONG_MAX ;
	float	FM_SPREAD_LONG_MIN ;
	float	FM_SPREAD_SHORT_MAX;
	float	FM_SPREAD_SHORT_MIN;
	float	RM_SPREAD_LONG_MAX ;
	float	RM_SPREAD_LONG_MIN ;
	float	RM_SPREAD_SHORT_MAX;
	float	RM_SPREAD_SHORT_MIN;
	float	RM_DOG_LONG_MAX  ;
	float	RM_DOG_LONG_MIN  ;
	float	RM_DOG_SHORT_MAX ;
	float	RM_DOG_SHORT_MIN ;

	float	E2_DOG_LONG_MAX  ; 
	float	E2_DOG_LONG_MIN  ; 
	float	E2_DOG_SHORT_MAX ; 
	float	E2_DOG_SHORT_MIN ; 


	float RMWidthInherWeight;

	//ͷ�����г�	
	float SSC_L_HEAD_LONG_MAX;
	float SSC_L_HEAD_LONG_MIN;
	float SSC_L_HEAD_SHORT_MAX;
	float SSC_L_HEAD_SHORT_MIN;
	float SSC_W_HEAD_LONG_MAX;
	float SSC_W_HEAD_LONG_MIN;
	float SSC_W_HEAD_SHORT_MAX;
	float SSC_W_HEAD_SHORT_MIN;

	//β�����г�
	float SSC_L_TAIL_LONG_MAX;
	float SSC_L_TAIL_LONG_MIN;
	float SSC_L_TAIL_SHORT_MAX;
	float SSC_L_TAIL_SHORT_MIN;
	float SSC_W_TAIL_LONG_MAX;
	float SSC_W_TAIL_LONG_MIN;
	float SSC_W_TAIL_SHORT_MAX;
	float SSC_W_TAIL_SHORT_MIN;
	///--------read config file FN width spread model-------------
	float RWSpeadAlfaE1L   ;
	float RWSpeadAlfaE1S   ;
	float RWDogAlfaE1L     ;
	float RWDogAlfaE1S     ;
	float RWSpeadAlfaE2L   ;
	float RWSpeadAlfaE2S   ;
	float RWDogAlfaE2L     ;
	float RWDogAlfaE2S     ;
	float RWSpeadAlfaAdjust;

	int RMwidthInherMode;

	///--------read config file FMNS -------------
	float FMNSLongAlfa ;
	float FMNSShortAlfa;
	int   FMNSLearnMode  ;
	int   FMNSShortMode  ;
	float FMNSKI      ;
	float FMNSKP       ;
	float FMNSKD       ;
	float FMNSParaMax  ;

///////////////////////////////////////////////
	///Width global inherit
	float alfaRdwGlobalInherL ;
	float alfaRdwGlobalInherS ;
	float alfaRdwGlobalInherLM;
	float alfaRdwGlobalInherSM;
	float alfaRdwGlobalInherLH;
	float alfaRdwGlobalInherSH;
	float alfaRdwGlobalInherLT;
	float alfaRdwGlobalInherST;
	float RdwGlobalK  ;
	float RdwGlobalMAX;
	float RdwGlobalMIN;


	float alfaWidthGlobalInherL ; ////Width.alfaWidthGlobalInherL   =  0.2f;         #Total longtime
	float alfaWidthGlobalInherS ; ////Width.alfaWidthGlobalInherS   =  0.3f;         #Total shorttime
	float alfaWidthGlobalInherLM; ////Width.alfaWidthGlobalInherLM  =  0.2f;         #middle longtime
	float alfaWidthGlobalInherSM; ////Width.alfaWidthGlobalInherSM  =  0.3f;         #middle shorttime
	float alfaWidthGlobalInherLH; ////Width.alfaWidthGlobalInherLH  =  0.2f;         #Head longtime
	float alfaWidthGlobalInherSH; ////Width.alfaWidthGlobalInherSH  =  0.3f;         #Head shorttime
	float alfaWidthGlobalInherLT; ////Width.alfaWidthGlobalInherLT  =  0.2f;         #Tail longtime
	float alfaWidthGlobalInherST; ////Width.alfaWidthGlobalInherST  =  0.3f;         #Tail shorttime
	float RWSpeadAlfaMod;
	float RWSpeadBeta   ;
	float RWInherDataMin;
	float RWInherDataMax;

	float RMWInherOpModalfa1    ;    //RM width inher OpMod alfa
	float RMWInherOpModalfa2    ;
	float RMWInherRdwGlobalalfa1;
	float RMWInherRdwGlobalalfa2;


	
	float WidthGlobalK          ; ////Width.WidthGlobalK            =  0.2f;
	float WidthGlobalMAX        ; ////Width.WidthGlobalMAX          =  2.5f;
	float WidthGlobalMIN        ; ////Width.WidthGlobalMIN          = -2.5f;
	float WidthGlobalLongMAX      ;
	float WidthGlobalLongMIN      ;
	float WidthGlobalShortMAX     ;
	float WidthGlobalShortMIN     ;

	float WidthFMWeight;
	float betaWidthGlobalInherS;
	float betaWidthGlobalInherL;
	float WidthGlobalFastInher;
	float OPModAlfa;
	float OPModAlfaL;
	float OPModAlfaS;

	//////////CNC  Inherit----------------------------------

	float CNCMaxLength;
	float CNC_WIDTH_COMP_MAX;
	float CNC_WIDTH_COMP_MIN;
	float CNCStartLimit;
	float CNCLengthLimit;
	/////*CncKStartS=0.5f
	////	Width.CncKLengthS=0.35f
	////	Width.CncKWidthS=0.35f
	////	Width.CncKStartL=0.35f
	////	Width.CncKLengthL=0.15f
	////	Width.CncKWidthL=0.15f

	////	Width.CncKRangeL=0.2f
	////	Width.CncKRangeS=0.2f
	////	Width.CNCInherDeadZone=0.5f            #CNC ѧϰ��������С�������Χ����ѧϰ
	////	Width.CNCGain��1.0f    */
	float CncKStartS;
	float CncKLengthS;
	float CncKWidthS;     //Config File
	float CncKStartL;
	float CncKLengthL;
	float CncKWidthL;     //Config File
	float CncKRangeL;   //��ʱѧϰϵ���仯��Χ���仯��
	float CncKRangeS;   //��ʱѧϰϵ���仯��Χ���仯��
	float CNCInherDeadZone;   //CNC ѧϰ��������С�������Χ����ѧϰ
	float CNCGain   ;			////(A��i��-FMWMean)< dW*K���ǣ������´ο��� ��

	////Dc width inherit 
	int DCwidthInherLimit  ;
	float DCWInherAlfaQNO  ;
	float DCWInherAlfaShort;
	float DCWInherAlfaLong ;
	float DCWLengthLimitadjust;
	float DCWInherMax      ;
	float DCWInherMin      ; 
	vector <float> DCInherPosition;

	////FM width inherit 
	float FMwidthInherLimit;
	float FMWInherAlfaQNO  ;
	float FMWInherAlfaShort;
	float FMWInherAlfaLong ;
	float FMWLengthLimitadjust;
	float FMWInherMax      ;
	float FMWInherMin      ; 
	vector <float> FMInherPosition;
	float FMSpreadE3CalOn  ;


	float FMDCDistance    ;
	float FMSTANDDistance ;
	float CoilDistance    ;
	////  ��������
	float RdwMarginInherL;
	float RdwMarginInherS;
	float RdwMarginTotalK;
	float RdwMarginBodyK;
	float RdwMarginHeadK;
	float RdwMarginTailK;
	float KMeanBody;
	float KMeanHead;
	float KMeanTail;
	float WIDTH_MARGIN_MIN;
	float WIDTH_MARGIN_MAX;
	float RDWMarginBase   ;
	float MarginInherAlfa ;

	float widthTolGain;
	int HeatValueUse;

	////  SCC����ѧϰ
	float SSCInherk1;
	float SSCInherk2;   
	float SSCInherAlfaLengthLong;
	float SSCInherAlfaLengthShort;
	float SSCInherLengthKp;
	float SSCInherAlfaWidthLong;
	float SSCInherAlfaWidthShort;
	float SSCInherWidthKp;
	float SSCInherBetaL;
	float SSCInherBetaW;
	float SSCInherBetaWE1;
	float SSCInherKw2;
	float SSCInherKw3;
	//int SCCOptCropInherMode;
	float SCCHeadThreshold;
	float SCCTailThreshold;
	int   SCCLearnModeHead;
	int   SCCLearnModeTail;
	float SCCLostToControlHead;
	float SCCLostToControlTail;

	float SSCHeadAlfaLong;
	float SSCTailAlfaLong;
	float SSCHeadAlfaShort;
	float SSCTailAlfaShort;
	float SSCPassAlfaMod;
	float SSCHeadBeta;
	float SSCTailBeta;
	float SSCErrAssign;
	float SSCInherMod_MIN;
	float SSCInherMod_MAX;

	float targetWeightk1,targetWeightk2,targetWeightk3;
	float KFishHead  ;
	float KTongeHead ;
	float KFishTail  ;
	float KTongeTail ;

	float SCCdwK1 ;
	float SCCdwK2 ;
	float SCCdwK3 ;
	float SCCdwK4 ;

	float SCCLInherMin,SCCLInherMax;



	////  FM�������ѧϰ
	float ImpactComAlfaInherEquip;
	float ImpactComBetaInherEquip;
	float ImpactComAlfaInherLong;
	float ImpactComAlfaInherShort;
	float ImpactComBetaInherShort;
	float ImpactComBetaInherLong;
	vector <float> AngleAveBeta;
	int ImpactComInherMethod;

	vector <float> FMImpactAngleAveTime;

	vector <float> ImpactComInherMin;
	vector <float> ImpactComInherMax;
	vector <float> LoopH1;
	vector <float> LoopL ;
	vector <float> LoopL1;
	vector <float> LoopR1;
	vector <float> LoopR2;
	vector <float>  FMImpactInherBeta    ;
	vector <float>  FMImpactInherPassTime;


public:

	void ReadWidthConfig();        //read the config parameter

	WidthAdaption();      

	~WidthAdaption(void);
	//������չѧϰ
	////void RMWidthInherCal (SteelInfomation SteelInfo,int StandNum,int R1TotalPass,int R2TotalPass,int InherStartPass,int InherEndPass,
	////	//int PassNo,int StandNum,int R1TotalPass,int R2TotalPass,
	////										int R1widthMeasureStatus,
	////										ActualData RMWidthAct,
	////										PostEdgerDraft PostEdgerDraftData,
	////										StripRollNum stripAccumNum,
	////										RMSpreadInherProcess&  RMWidthInherDataCal);

	void RMWidthInherCalVec (SteelInfomation SteelInfo,int StandNum,int R1TotalPass,int R2TotalPass,int InherStartPass,int InherEndPass,
		//int PassNo,int StandNum,int R1TotalPass,int R2TotalPass,
		int R1widthMeasureStatus,
		ActualData RMWidthAct,
		PostEdgerDraft PostEdgerDraftData,
		StripRollNum stripAccumNum,
		RMSpreadInherProcessVec&  RMWidthInherDataCal);


	void RdwGlobalInherCal (SteelInfomation SteelInfo,
		                    ActualData RMWidthAct,
							ActualData RMWidthActFDWidthHead,
							ActualData RMWidthActTail,
							ActualData RMWidthActBody,
							RdwTargetData& rdwTarget,
							StripRollNum stripAccumNum,
							RdwGlobalInherProcess&  RdwGlobalInherData);

	void WidthGlobalInherCal (SteelInfomation SteelInfo,
							int SteelChange,
							float OPMod,
							ActualData RMWidthAct,
							ActualData RMWidthActHead,
							ActualData RMWidthActTail,
							ActualData RMWidthActMiddle,
							ActualData FMWidthAct,
							ActualData FMWidthActHead,
							ActualData FMWidthActTail,
							ActualData FMWidthActMiddle,
							RdwTargetData& rdwTarget,
							float FMwTarget,  //cool value
							float FDTemp,
							RdwMarginInherData Margin,
							RM3WTargetMod  WidMod,
							StripRollNum stripAccumNum,
							RdwGlobalInherProcess&  WidthGlobalInherData);

	////void WidthGlobalInherCal (SteelInfomation SteelInfo,
	////						ActualData RMWidthAct,
	////						ActualData RMWidthActHead,
	////						ActualData RMWidthActTail,
	////						ActualData RMWidthActMiddle,
	////						ActualData FMWidthAct,
	////						ActualData FMWidthActHead,
	////						ActualData FMWidthActTail,
	////						ActualData FMWidthActMiddle,
	////						RdwTargetData& rdwTarget,
	////						StripRollNum stripAccumNum,
	////						RdwGlobalInherProcess&  WidthGlobalInherData);

	//������Ȼ��չ����Ӧģ��

	void FMSpreadInherCal(SteelInfomation SteelInfo,
		//float FmDelThick,           //PDI Value
		//float FmDelWidth, 
		//float FmTalDraftRatio,
		//float FDTemp,
		ActualData FmThickAct,    //Actual value
		ActualData FmWidthAct, 
		ActualData FmTalDraftRatioAct,
		ActualData FDTempAct,
		ActualData RMWidthAct,
		FMSpreadData postFMSpread, 
		FMSpreadData precalFMSpread, 
		float E3ReduAct,
		float postE3Dog,
		//FMNSError& CalError,
		StripRollNum stripAccumNum,
		FMSpreadInherProcess& FMSpreadAdaData);

	void RdwTargetInherCal (SteelInfomation SteelInfo,ActualData FDWidth,
		ActualData FDWidthHead,
		ActualData FDWidthTail,
		ActualData FDWidthBody,
		StripRollNum stripAccumNum,
		RdwMarginInherProcess& RdwMarginInherCal);


	void FMWidthInherCal(FMWidthInherData FMWInher,
		                FMSpreadInherProcess& FMSpreadAdaData,
						RdwGlobalInherProcess&  RdwGlobalInherData,
						RdwMarginInherProcess& RdwMarginInherCal);


	//���г̿�������Ӧ
	//void SSCOptCropInherCal (SteelInfomation SteelInfo,int E2PassNo, int E1PassNo,
	//						float SimpleDW,
	//						float CropLengthHead[250],
	//						float CropLengthTail[250],
	//						float SlabThick,
	//						float Slabwidth,
	//						//vector<float> RMPassEntryWidthPost,
	//						//vector<float> RMPassEntryThickPost,
	//						//SSCOptimaeCropData  SSCCropData,
	//						SSCInherProcess& SSCInherDataCal,
	//						StripRollNum stripAccumNum );

	//void SSCInherCal  (SteelInfomation SteelInfo,int E2PassNo, int E1PassNo,
	//	ActualData SlabwidthAct,
	//	float SlabThick,
	//	vector<float> RMPassEntryWidthPost,
	//	vector<float> RMPassEntryThickPost,
	//	SSCOptimaeCropData  SSCCropData,
	//	SSCInherProcess& SSCInherDataCal,
	//	StripRollNum stripAccumNum,
	//	int SSCOptimaeCropDataOK);


	void SSCWidthInherCal (SteelInfomation SteelInfo,int E1PassNo, int E2PassNo,
		vector<float> RMPassEntryThick,         //each pass
		vector<float> RMPassEntryWidth,        //each pass
		vector<float> RMSSCLengthHead,     //each Edger pass
		vector<float> RMSSCLengthTail,      //each Edger pass
		vector<float> RMwidthActHead,        //
		vector<float> RMwidthPosHead,
		vector<float> RMwidthActTail,        //
		vector<float> RMwidthPosTail,
		float  RDWActAve,
		float  RDHActAve,
		SSCInherModProcess& SSCInherModData,
		StripRollNum stripAccumNum);

	void SSCInherCal (SteelInfomation SteelInfo,int E2PassNo, int E1PassNo,
		float SimpleDW,//���ȷ���������
		float CropLengthHead[],//���е�ͷ����״����
		float CropLengthTai[],//���е�β����״����
		int CropDataNum,         //���鳤�ȣ�250
	    float SimpleDL,       //���ȷ���������
		float WidthHead[],     //ͷ����������
		float WidthTail[],     //β����������
		int WidthDataNum,        //���鳤�ȣ�250
		ActualData WidthMidAct,//����ȫ��ƽ��ֵ
		SSCSetCalData CalData,//���г��趨����
		SSCInherProcess& SSCInherDataCal,//���г��Ŵ�����
		StripRollNum stripAccumNum ); //��������������Ϣ

	void FMWidthInherCal (SteelInfomation SteelInfo,
		vector <float> RMwidthExit,
		vector <float> FMwidthExit,
		float StripLength,
		LongSSCWidthInherProcess& FMWInher);

	void FMImpactComInherCal (SteelInfomation SteelInfo,
		FMImpactComAct ActData,
		vector <float> ImpactComAct,
		vector <float> TimeLoopOn,
		vector <float> AngleSet,										 
		vector <float> SpeedSet,
		vector <float> SpeedTransTime,
		vector <float> ImpactDelayTime,
		vector <float> BackSlip,
		vector <float> ImpactComTech,
		int ImpactComInherUse,
		FMImpactComInherData& ImpactComInherData);

   //����ʽ���ȿ��Ƶ�ѧϰ


	////void RdwTargetInherCalLClass (SteelInfomation SteelInfo,int LengthClass,
	////	ActualData FDWidth,
	////	ActualData FDWidthHead,
	////	ActualData FDWidthTail,
	////	ActualData FDWidthBody,
	////	StripRollNum stripAccumNum,
	////	RdwMarginInherProcess& RdwMarginInherCal);

	//CNC���Ȳ�����Ӧ
	//void CNCInherCal (SteelInfomation SteelInfo,CNCStripWidthData CncInherDataAct,     //CNC width error Data for Inherit, 3 times of actual control data
	//	ActualData CncWidthErrorAct,
	//	ActualData FDWTatalErrorAct,
	//	StripRollNum stripAccumNum,
	//	CncInherProcess& CncInherDataCal);

	//void DCWidthInherCal(SteelInfomation SteelInfo,
	//	vector <float> DCwidthEnter,
	//	vector <float> FMwidthExit,
	//	int DCNum,float StripLength,
	//	LongSSCWidthInherProcess& DCWInher);

};

}
#endif