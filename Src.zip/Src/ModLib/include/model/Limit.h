#ifndef _FM_Limit_H_
#define _FM_Limit_H_
#include <iostream>
#include <vector>
#include <pace/parameter.h>

namespace FM
{
	class Limit
	{

	public:
		static Limit* getInstance()
		{
			if(_instance == NULL)
			{
				_instance = new Limit();
			}
			return _instance;
		}
	private:
		static Limit* _instance;

	public:
		Limit(){};
		~Limit(){};

		//----------------------------------------------------------------------------
		// description : Check limt of delivered value and return a useful range
		//
		//----------------------------------------------------------------------------
		template <typename T> 
		void limitCheck( T& iValue, T iMin, T iMax, string szName,std::vector< std::string >& vecLimitErrors )
		{
			if( iValue < iMin )
			{
				std::stringstream strErr;
				strErr << "Bad range received for " << szName << ": " << iValue << " < " << iMin << std::ends;
				vecLimitErrors.push_back( strErr.str() );

				iValue = iMin;
			}
			else if( iValue > iMax )
			{
				std::stringstream strErr;
				strErr << "Bad range received for " << szName << ": " << iValue << " > " << iMax << std::ends;
				vecLimitErrors.push_back( strErr.str() );

				iValue = iMax;
			}
		}
		////----------------------------------------------------------------------------
		//// description : Check limt of delivered value and return true / false
		////
		////----------------------------------------------------------------------------
		////template < typename T  >
		////bool limitCheck(T iValue,T iMax,T iMin ,string szName,std::vector< std::string >& vecLimitErrors)
		////{
		////	if( iValue < iMax || iValue > iMin )
		////	{
		////		std::stringstream strErr;
		////		strErr << "Bad range received for " << szName << ": " << iValue << " < " << iMin << std::ends;
		////		vecLimitErrors.push_back( strErr.str() );
		////		return false;
		////	}
		////	else
		////	{
		////		return true;   
		////	}
		////}

		//----------------------------------------------------------------------------
		// description : Check limt of delivered value and return true / false
		//
		//----------------------------------------------------------------------------
		template < typename T  >
		bool limitCheck(T iValue,T iMax,T iMin )
		{
			if( iValue < iMin || iValue > iMax )
			{
				return false;
			}
			else
			{
				return true;   
			}
		}

		//----------------------------------------------------------------------------
		// description : Check limt of delivered value and return true / false
		//
		//----------------------------------------------------------------------------
		template < typename T  >
		bool limitCheck(T iValue,std::vector<T> iT )
		{
			if( iValue > iT.at(1) || iValue < iT.at(0) )
			{
				return false;
			}
			else
			{
				return true;   
			}
		}

	};
};



#endif