#ifndef _SCC_Controller_H_
#define _SCC_Controller_H_
#include <iostream>
#include <vector>
#include "Common.h"

using namespace std;

namespace SCC
{

   struct ControlValue
   {
      float thick;
      float thickConf;
      float width;
      float widthConf;
      float tempave;
      float tempaveConf;
      float tempsurf;
      float tempsurfConf;
      vector<float> temp;
      float length;
      float segLen;
      float speed;

   };


   struct ControlValue2
   {
	   float thick;
	   float width;
	   float length;
	   float segLen;
	   float speed;

	   float tempave;
	   float tempsurf;
	   float temp[FM::TEMP_LAYNUM];

   };

	class Controller
	{
		public:
			Controller(){};
			~Controller(){};

		public:

	     string controlName;
		 ControlValue entry;
		 ControlValue exit;

		private:


	};
};

#endif