#ifndef __FM_Draft_H__
#define __FM_Draft_H__

#include "Common.h"
#include <vector>

/* input : load ratio -- first 

entry thick, exit thick , force

   output: exit thick for stands
*/
           

namespace FM
{


	class Draft
	{

	public:
		static Draft* getInstance()
		{
			if(_instance == NULL)
			{
				_instance = new Draft();
			}
			return _instance;
		}
	private:
		static Draft* _instance;

	public:
		Draft();
		~Draft();

	public:


		void setParam(float _alpha, float _damp, int _max_iter, int _limit_iter,float _conv_crit);

		bool distribute(std::vector<float>& exH,int cnt, bool&  v_draft_error);

		bool firstCalc(std::vector<float>& exH);

		bool ifConverge();

		bool ifDraftOk();		

		bool setInit(const float& H, const float& h, const int& activeStands, std::vector<float>& ratio);	
		
		bool calcDraft();

		bool initDraft(const int& activeStands,std::vector<float>& exH);
        bool initDraft2(const int &activeStands, float &m_entryThick, std::vector<float> &exH);

		//set force draft sensitive coeff into class
		bool setDfDh(const std::vector<float> );
		//set force into class
		bool setForce(const std::vector<float>);

		bool resolve(std::vector<float>& newDraft,int cnt, bool&  v_draft_error);
		std::vector<float> getRfratio();
		bool   setRfratio(std::vector<float> ra);
		void  setCounter(int nx);
		bool normilize(std::vector<float>&,float&,float&);

	private:

		bool init();			

		bool iterate();
		
		// = load_ratio / (enH - exH)
		void calcLoadFactor(int);
		
		// calc adjustment factor
		bool calcAdjustFactor();



		//bool resolve();

		float xDfDh();

		float findLargest(std::vector<float>);

		int	counter;		// calc times counter for same strip


	private:

		bool        b_draft_ok;             
		float       m_draft_sum_init;   //total draft taken by mill after initial closure   
		float       m_draft_sum;        //final total draft taken by mill    
		float       m_load_sum;			//sum of the preferred loads for each pass    
		float       m_lf_sum;			// sum of the calculated load factors        
		float       m_draft_adj;            
		float       m_damp;
		float		m_max_load;

		int         n_num_passes;           
		int         n_active_passes;        
		int         ndft_pass_init;

		int         n_firstpass;            
		int         n_lastpass;             
		int         n_firstactivepas;       
		int         n_lstdftpas;            
		int         n_icount;               
		bool        b_ifconverge;           

		int         n_dft_iterat;           
		int         n_dftlim_iterat;        
		bool        b_initial_guess;		// first time to calc?   
		float       m_entryThick;
		float		m_exitThick;
		
		std::vector<float>		v_tabRatio;		// load ration in table
		std::vector<float>		v_draft;		// draft for each stand
		std::vector<float>		v_load_act;		// load draft 
		std::vector<float>       v_load_fac;    //initial load factors for each pass
		std::vector<float>       v_lf;			//calculated load factors for each pass  
		std::vector<float>       v_dlf_dd;		//calculated load factor partials for each pass
		std::vector<float>       v_ddraft;      //calculated draft adjustment for each pass
		std::vector<float>       v_load_init;   //initial load for each pass
		std::vector<float>       v_draft_init;  //initial drafts after first convergence for each pass  -- h0_i = h0_i-1 * pow((H/h),1/n)
		std::vector<float>       v_passnum_init;//initial pass number pattern
		std::vector<float>       v_save_draft;  //saved drafts for logging
		std::vector<float>       v_save_force;  //saved force for logging
		std::vector<float>       v_save_power;  //saved power for logging

		std::vector<float>		v_entryThick;
		std::vector<float>		v_exitThick;

		std::vector<float>		v_force;

		//damping factor

		//const float	

		// Configurable constants			//���� 
		//draftModeEnum   dmode;
		float           alpha;              // initial damping factor	��ʼ����ϵ��
		float           damp_mpy;           // multiplier on damping factor, usually 1.0
		float           conv_crit;          // convergence criterion on loading    ��������
		int             max_dft_iter;       // maximum iterations to converge on a load distribution	//���������������
		int             max_dftlim_iter;    // maximum iterations to resolve limits						//����������
		float           dft_crit;           // convergence criterion on resolving draft limits			//
		float           frc_crit;           // convergence criterion on resolving force limits
		float           pwr_crit;           // convergence criterion on resolving power limits

	};
}
#endif

