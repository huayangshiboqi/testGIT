#ifndef __SCC_d__ng1780_trunk_include_SCC_IscControllerI_h__
#define __SCC_d__ng1780_trunk_include_SCC_IscControllerI_h__

#include <pace/parameter.h>
#include "Controller.h"
//#include "CalcInfo.h"
#include <model/Temperature.h>

namespace SCC
{

	struct IscControlData //extends ControllerData
	{
		float   flow;
		float	maxFlow;
		float	minFlow;
		float   coolDrop;
		bool	status;
		float	dtdq;
	};

class IscControllerI : virtual public ::SCC::Controller
{
public:

	/**
	* \brief 
	*/   	
	IscControllerI();


	/**
	* \brief 
	*/ 	
	~IscControllerI();

	float    calcCoolDrop(int spraynum,int laynum,int adapflag, float corrtemp,int sfc);
	void     setStatus(bool status);
	void     setFlow(float flow);


	//void setCalcInfo(FM::CalcInfo& ifo)	{info=ifo;};

//private:
	//FM::CalcInfo info;

     //TemperatureI tempcalc;
	 	
	 IscControlData isc;

};

}

#endif
