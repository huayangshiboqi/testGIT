//����
#ifndef PARAMAP_H
#define PARAMAP_H

#include <map>
#include <vector>
#include <iostream>
#include <log4cplus/LOG.h>
#include <berkeley_db/BerkeleyDBWrap.h>

using namespace std;

static const int numofchem    = 10;

struct ModelParaIndex
{
	int family;
	int type;    
};

struct ModelParaData
{
	float kChem;	    
	vector<float> ak;
	vector<float> bk;
	vector<float> am;
};

struct ModelParaData2
{
	float kChem;	    
	float ak[11];
	float bk[10];
	float am[5];
};

struct ParaRecord
{
	char flag;
    ModelParaIndex  idx;
    ModelParaData2  dat;
};


struct kflowIndex
{
	int family; 
	int kerclass;
	int tempclass;
	int standno;   
};

struct kflowData
{
	float kflow;	  
	int   ncount; 
};

typedef map< long, ModelParaData > ModelParaMap;
typedef ModelParaMap::value_type  modelpara_valType;

//-------------------------------------------------------------------
// cRollbite class definition
//-------------------------------------------------------------------
class cParaMap
{

public:

	static cParaMap* getInstance()
	{
		if(_instance == NULL)
		{
			 _instance = new cParaMap();
		}
		return _instance;
	}


private:

	static cParaMap* _instance;

	ModelParaMap  _mapfmforce;

	BerkeleyDbWrap*  db;


public:

		int csv2file();

		ModelParaData _getFmForcePara(const ModelParaIndex& index);

		kflowData          getKflowPara(const kflowIndex& index);

		kflowData          getKflowPara(const kflowIndex& index, float ker, float temp);

		int tempDataCal(int igrade,int standno, float& tempLow, float& tempHigh);

		int kerDataCal(int igrade,int standno, float& kerLow, float& kerHigh );

		void readmap();

		void writemap();


private:
	cParaMap(void);
	~cParaMap(){ };

	int getsfc0(int sfc);
	int ma_fmforcepara(int order);
	int rfpara(int order);
	vector<string>  list_item(string buffer);				

	void decode(long total, int& family, int& std);
	long encode(int family, int std);

	 kflowData  _getKflowPara3(const kflowIndex& index);

     float           limitJudge(float datalearn,float datalimit);


}; //  END Roll Bite Calculation class definition.

#endif // PARAMAP_H
