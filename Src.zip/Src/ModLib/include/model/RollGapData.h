
#ifndef __RollGapData_h__
#define __RollGapData_h__

using namespace std;

namespace MODELKIT
{
/**
 * 4Hi-Roll basic information
 * �Ĺ�����������������Ϣ����Ҫ�ڻ���ʱ���и��¡�
 **/
struct RollBasicInfoFourHi
{
	string rollIDUpBK;                 //  ��֧�й����ţ�ID��
	string rollIDUpWK;                 //  �Ϲ��������ţ�ID��
	float  rollDiaUpBK;                //  ��֧�й�ֱ����mm��
	float  rollDiaUpWK;                //  �Ϲ�����ֱ����mm��
	float  initialCrownWorkRoll;       //  ��������ԭʼ͹�ȣ�mm-3��

    bool operator==(const RollBasicInfoFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollIDUpBK != __rhs.rollIDUpBK)
        {
            return false;
        }
        if(rollIDUpWK != __rhs.rollIDUpWK)
        {
            return false;
        }
        if(rollDiaUpBK != __rhs.rollDiaUpBK)
        {
            return false;
        }
        if(rollDiaUpWK != __rhs.rollDiaUpWK)
        {
            return false;
        }
        if(initialCrownWorkRoll != __rhs.initialCrownWorkRoll)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollBasicInfoFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollIDUpBK < __rhs.rollIDUpBK)
        {
            return true;
        }
        else if(__rhs.rollIDUpBK < rollIDUpBK)
        {
            return false;
        }
        if(rollIDUpWK < __rhs.rollIDUpWK)
        {
            return true;
        }
        else if(__rhs.rollIDUpWK < rollIDUpWK)
        {
            return false;
        }
        if(rollDiaUpBK < __rhs.rollDiaUpBK)
        {
            return true;
        }
        else if(__rhs.rollDiaUpBK < rollDiaUpBK)
        {
            return false;
        }
        if(rollDiaUpWK < __rhs.rollDiaUpWK)
        {
            return true;
        }
        else if(__rhs.rollDiaUpWK < rollDiaUpWK)
        {
            return false;
        }
        if(initialCrownWorkRoll < __rhs.initialCrownWorkRoll)
        {
            return true;
        }
        else if(__rhs.initialCrownWorkRoll < initialCrownWorkRoll)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollBasicInfoFourHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollBasicInfoFourHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollBasicInfoFourHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollBasicInfoFourHi& __rhs) const
    {
        return !operator<(__rhs);
    }
};
/**
 * 4Hi-Roll auxilary information
 * �Ĺ�����������������Ϣ��
 **/
struct RollAuxInfoFourHi
{
	/**
	 * Roll bending compensationfactors
	 * ����Թ���Ӱ��ϵ����
	 **/
	float mb;            //  Ϊ�����Ӱ��ϵ��(kN/mm)����Ҫͨ������ȷ��
	float kf0;           //  Ϊģ��ϵ����
	float df;            //  Ϊ�������ܹ���������������Ӱ��ϵ������λ��1/mm��
	float pb0;           //  ���ƽ������kN��

	/**
	 * Roll shifting compensationfactors
	 * �ܹ��Թ���Ӱ��ϵ����
	 **/
    float rollShiftBasicData;        //  Ϊ�������ܹ�λ�öԹ���Ĳ���������λ��mm��

	/**
	 * Roll wear basic factor
	 * ����ĥ�����ϵ����
	 **/
    float wearBasicData;             //  k1Ϊ��λ�����ϵ������������Ƴ��ȶ�ĥ���Ӱ��������λ��1/kN��

	/**
	 * Roll thermal characteristics
	 * ���������ͼ���������ݡ�
	 **/
    float thermalMax;                  //  Ϊ��������͹�ȼ���ֵ����λ��mm��
    float timeConstRolling;            //  Ϊ����״̬�µ�ʱ�䳣������λ���룩
    float timeConstInMaxFlow;          //  Ϊ������ڲ�������ȴͶ�����ʱ��ʱ�䳣������λ���룩
    float timeConstInMinFlow;          //  Ϊ������ڲ�������ȴͶ����Сʱ��ʱ�䳣������λ���룩
    float timeConstExMaxFlow;          //  Ϊ�������ڲ�������ȴͶ�����ʱ��ʱ�䳣������λ���룩
    float timeConstExMinFlow;          //  Ϊ�������ڲ�������ȴͶ����Сʱ��ʱ�䳣������λ���룩
    float timeConstOff;                //  Ϊ������ȴˮ�ر�����µ�ʱ�䳣������λ���룩

    // Limit values
    float limitLowWorkRollDia;
    float limitUpWorkRollDia;
    float limitLowBackUpRollDia;
    float limitUpBackUpRollDia;
    float limitLowRollForce;
    float limitUpRollForce;
    float limitLowBendForce;
    float limitUpBendForce;
    float limitLowShift;
    float limitUpShift;
    float limitLowRollingSpeed;
    float limitUpRollingSpeed;
    float limitLowGap;
    float limitUpGap;
    float limitLowRollWear;
    float limitUpRollWear;
    float limitLowRollTherm;
    float limitUpRollTherm;
    float limitLowCorrZeroPoint;
    float limitUpCorrZeroPoint;
    float limitLowCorrRollGapA;
    float limitUpCorrRollGapA;
    float limitLowCorrRollGapB;
    float limitUpCorrRollGapB;

    bool operator==(const RollAuxInfoFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(mb != __rhs.mb)
        {
            return false;
        }
        if(kf0 != __rhs.kf0)
        {
            return false;
        }
        if(df != __rhs.df)
        {
            return false;
        }
        if(pb0 != __rhs.pb0)
        {
            return false;
        }
        if(rollShiftBasicData != __rhs.rollShiftBasicData)
        {
            return false;
        }
        if(wearBasicData != __rhs.wearBasicData)
        {
            return false;
        }
        if(thermalMax != __rhs.thermalMax)
        {
            return false;
        }
        if(timeConstRolling != __rhs.timeConstRolling)
        {
            return false;
        }
        if(timeConstInMaxFlow != __rhs.timeConstInMaxFlow)
        {
            return false;
        }
        if(timeConstInMinFlow != __rhs.timeConstInMinFlow)
        {
            return false;
        }
        if(timeConstExMaxFlow != __rhs.timeConstExMaxFlow)
        {
            return false;
        }
        if(timeConstExMinFlow != __rhs.timeConstExMinFlow)
        {
            return false;
        }
        if(timeConstOff != __rhs.timeConstOff)
        {
            return false;
        }
        if(limitLowWorkRollDia != __rhs.limitLowWorkRollDia)
        {
            return false;
        }
        if(limitUpWorkRollDia != __rhs.limitUpWorkRollDia)
        {
            return false;
        }
        if(limitLowBackUpRollDia != __rhs.limitLowBackUpRollDia)
        {
            return false;
        }
        if(limitUpBackUpRollDia != __rhs.limitUpBackUpRollDia)
        {
            return false;
        }
        if(limitLowRollForce != __rhs.limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce != __rhs.limitUpRollForce)
        {
            return false;
        }
        if(limitLowBendForce != __rhs.limitLowBendForce)
        {
            return false;
        }
        if(limitUpBendForce != __rhs.limitUpBendForce)
        {
            return false;
        }
        if(limitLowShift != __rhs.limitLowShift)
        {
            return false;
        }
        if(limitUpShift != __rhs.limitUpShift)
        {
            return false;
        }
        if(limitLowRollingSpeed != __rhs.limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed != __rhs.limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap != __rhs.limitLowGap)
        {
            return false;
        }
        if(limitUpGap != __rhs.limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear != __rhs.limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear != __rhs.limitUpRollWear)
        {
            return false;
        }
        if(limitLowRollTherm != __rhs.limitLowRollTherm)
        {
            return false;
        }
        if(limitUpRollTherm != __rhs.limitUpRollTherm)
        {
            return false;
        }
        if(limitLowCorrZeroPoint != __rhs.limitLowCorrZeroPoint)
        {
            return false;
        }
        if(limitUpCorrZeroPoint != __rhs.limitUpCorrZeroPoint)
        {
            return false;
        }
        if(limitLowCorrRollGapA != __rhs.limitLowCorrRollGapA)
        {
            return false;
        }
        if(limitUpCorrRollGapA != __rhs.limitUpCorrRollGapA)
        {
            return false;
        }
        if(limitLowCorrRollGapB != __rhs.limitLowCorrRollGapB)
        {
            return false;
        }
        if(limitUpCorrRollGapB != __rhs.limitUpCorrRollGapB)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollAuxInfoFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(mb < __rhs.mb)
        {
            return true;
        }
        else if(__rhs.mb < mb)
        {
            return false;
        }
        if(kf0 < __rhs.kf0)
        {
            return true;
        }
        else if(__rhs.kf0 < kf0)
        {
            return false;
        }
        if(df < __rhs.df)
        {
            return true;
        }
        else if(__rhs.df < df)
        {
            return false;
        }
        if(pb0 < __rhs.pb0)
        {
            return true;
        }
        else if(__rhs.pb0 < pb0)
        {
            return false;
        }
        if(rollShiftBasicData < __rhs.rollShiftBasicData)
        {
            return true;
        }
        else if(__rhs.rollShiftBasicData < rollShiftBasicData)
        {
            return false;
        }
        if(wearBasicData < __rhs.wearBasicData)
        {
            return true;
        }
        else if(__rhs.wearBasicData < wearBasicData)
        {
            return false;
        }
        if(thermalMax < __rhs.thermalMax)
        {
            return true;
        }
        else if(__rhs.thermalMax < thermalMax)
        {
            return false;
        }
        if(timeConstRolling < __rhs.timeConstRolling)
        {
            return true;
        }
        else if(__rhs.timeConstRolling < timeConstRolling)
        {
            return false;
        }
        if(timeConstInMaxFlow < __rhs.timeConstInMaxFlow)
        {
            return true;
        }
        else if(__rhs.timeConstInMaxFlow < timeConstInMaxFlow)
        {
            return false;
        }
        if(timeConstInMinFlow < __rhs.timeConstInMinFlow)
        {
            return true;
        }
        else if(__rhs.timeConstInMinFlow < timeConstInMinFlow)
        {
            return false;
        }
        if(timeConstExMaxFlow < __rhs.timeConstExMaxFlow)
        {
            return true;
        }
        else if(__rhs.timeConstExMaxFlow < timeConstExMaxFlow)
        {
            return false;
        }
        if(timeConstExMinFlow < __rhs.timeConstExMinFlow)
        {
            return true;
        }
        else if(__rhs.timeConstExMinFlow < timeConstExMinFlow)
        {
            return false;
        }
        if(timeConstOff < __rhs.timeConstOff)
        {
            return true;
        }
        else if(__rhs.timeConstOff < timeConstOff)
        {
            return false;
        }
        if(limitLowWorkRollDia < __rhs.limitLowWorkRollDia)
        {
            return true;
        }
        else if(__rhs.limitLowWorkRollDia < limitLowWorkRollDia)
        {
            return false;
        }
        if(limitUpWorkRollDia < __rhs.limitUpWorkRollDia)
        {
            return true;
        }
        else if(__rhs.limitUpWorkRollDia < limitUpWorkRollDia)
        {
            return false;
        }
        if(limitLowBackUpRollDia < __rhs.limitLowBackUpRollDia)
        {
            return true;
        }
        else if(__rhs.limitLowBackUpRollDia < limitLowBackUpRollDia)
        {
            return false;
        }
        if(limitUpBackUpRollDia < __rhs.limitUpBackUpRollDia)
        {
            return true;
        }
        else if(__rhs.limitUpBackUpRollDia < limitUpBackUpRollDia)
        {
            return false;
        }
        if(limitLowRollForce < __rhs.limitLowRollForce)
        {
            return true;
        }
        else if(__rhs.limitLowRollForce < limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce < __rhs.limitUpRollForce)
        {
            return true;
        }
        else if(__rhs.limitUpRollForce < limitUpRollForce)
        {
            return false;
        }
        if(limitLowBendForce < __rhs.limitLowBendForce)
        {
            return true;
        }
        else if(__rhs.limitLowBendForce < limitLowBendForce)
        {
            return false;
        }
        if(limitUpBendForce < __rhs.limitUpBendForce)
        {
            return true;
        }
        else if(__rhs.limitUpBendForce < limitUpBendForce)
        {
            return false;
        }
        if(limitLowShift < __rhs.limitLowShift)
        {
            return true;
        }
        else if(__rhs.limitLowShift < limitLowShift)
        {
            return false;
        }
        if(limitUpShift < __rhs.limitUpShift)
        {
            return true;
        }
        else if(__rhs.limitUpShift < limitUpShift)
        {
            return false;
        }
        if(limitLowRollingSpeed < __rhs.limitLowRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitLowRollingSpeed < limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed < __rhs.limitUpRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitUpRollingSpeed < limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap < __rhs.limitLowGap)
        {
            return true;
        }
        else if(__rhs.limitLowGap < limitLowGap)
        {
            return false;
        }
        if(limitUpGap < __rhs.limitUpGap)
        {
            return true;
        }
        else if(__rhs.limitUpGap < limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear < __rhs.limitLowRollWear)
        {
            return true;
        }
        else if(__rhs.limitLowRollWear < limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear < __rhs.limitUpRollWear)
        {
            return true;
        }
        else if(__rhs.limitUpRollWear < limitUpRollWear)
        {
            return false;
        }
        if(limitLowRollTherm < __rhs.limitLowRollTherm)
        {
            return true;
        }
        else if(__rhs.limitLowRollTherm < limitLowRollTherm)
        {
            return false;
        }
        if(limitUpRollTherm < __rhs.limitUpRollTherm)
        {
            return true;
        }
        else if(__rhs.limitUpRollTherm < limitUpRollTherm)
        {
            return false;
        }
        if(limitLowCorrZeroPoint < __rhs.limitLowCorrZeroPoint)
        {
            return true;
        }
        else if(__rhs.limitLowCorrZeroPoint < limitLowCorrZeroPoint)
        {
            return false;
        }
        if(limitUpCorrZeroPoint < __rhs.limitUpCorrZeroPoint)
        {
            return true;
        }
        else if(__rhs.limitUpCorrZeroPoint < limitUpCorrZeroPoint)
        {
            return false;
        }
        if(limitLowCorrRollGapA < __rhs.limitLowCorrRollGapA)
        {
            return true;
        }
        else if(__rhs.limitLowCorrRollGapA < limitLowCorrRollGapA)
        {
            return false;
        }
        if(limitUpCorrRollGapA < __rhs.limitUpCorrRollGapA)
        {
            return true;
        }
        else if(__rhs.limitUpCorrRollGapA < limitUpCorrRollGapA)
        {
            return false;
        }
        if(limitLowCorrRollGapB < __rhs.limitLowCorrRollGapB)
        {
            return true;
        }
        else if(__rhs.limitLowCorrRollGapB < limitLowCorrRollGapB)
        {
            return false;
        }
        if(limitUpCorrRollGapB < __rhs.limitUpCorrRollGapB)
        {
            return true;
        }
        else if(__rhs.limitUpCorrRollGapB < limitUpCorrRollGapB)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollAuxInfoFourHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollAuxInfoFourHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollAuxInfoFourHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollAuxInfoFourHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 * 2Hi-Roll information
 * ��������������Ϣ��
 **/
struct RollInfoTwoHi
{
	string rollIDUpWK;                 //  �Ϲ���������
	float  rollDiaUpWK;                //  �Ϲ�������������λ��mm��

    bool operator==(const RollInfoTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollIDUpWK != __rhs.rollIDUpWK)
        {
            return false;
        }
        if(rollDiaUpWK != __rhs.rollDiaUpWK)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollInfoTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollIDUpWK < __rhs.rollIDUpWK)
        {
            return true;
        }
        else if(__rhs.rollIDUpWK < rollIDUpWK)
        {
            return false;
        }
        if(rollDiaUpWK < __rhs.rollDiaUpWK)
        {
            return true;
        }
        else if(__rhs.rollDiaUpWK < rollDiaUpWK)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollInfoTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollInfoTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollInfoTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollInfoTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};
/**
 * 2Hi-Roll auxilary information
 * ��������������������Ϣ��
 **/
struct RollAuxInfoTwoHi
{
    float limitLowWorkRollDia;
    float limitUpWorkRollDia;
    float limitLowRollForce;
    float limitUpRollForce;
    float limitLowRollingSpeed;
    float limitUpRollingSpeed;
    float limitLowGap;
    float limitUpGap;
    float limitLowRollWear;
    float limitUpRollWear;

    bool operator==(const RollAuxInfoTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(limitLowWorkRollDia != __rhs.limitLowWorkRollDia)
        {
            return false;
        }
        if(limitUpWorkRollDia != __rhs.limitUpWorkRollDia)
        {
            return false;
        }
        if(limitLowRollForce != __rhs.limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce != __rhs.limitUpRollForce)
        {
            return false;
        }
        if(limitLowRollingSpeed != __rhs.limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed != __rhs.limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap != __rhs.limitLowGap)
        {
            return false;
        }
        if(limitUpGap != __rhs.limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear != __rhs.limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear != __rhs.limitUpRollWear)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollAuxInfoTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(limitLowWorkRollDia < __rhs.limitLowWorkRollDia)
        {
            return true;
        }
        else if(__rhs.limitLowWorkRollDia < limitLowWorkRollDia)
        {
            return false;
        }
        if(limitUpWorkRollDia < __rhs.limitUpWorkRollDia)
        {
            return true;
        }
        else if(__rhs.limitUpWorkRollDia < limitUpWorkRollDia)
        {
            return false;
        }
        if(limitLowRollForce < __rhs.limitLowRollForce)
        {
            return true;
        }
        else if(__rhs.limitLowRollForce < limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce < __rhs.limitUpRollForce)
        {
            return true;
        }
        else if(__rhs.limitUpRollForce < limitUpRollForce)
        {
            return false;
        }
        if(limitLowRollingSpeed < __rhs.limitLowRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitLowRollingSpeed < limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed < __rhs.limitUpRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitUpRollingSpeed < limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap < __rhs.limitLowGap)
        {
            return true;
        }
        else if(__rhs.limitLowGap < limitLowGap)
        {
            return false;
        }
        if(limitUpGap < __rhs.limitUpGap)
        {
            return true;
        }
        else if(__rhs.limitUpGap < limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear < __rhs.limitLowRollWear)
        {
            return true;
        }
        else if(__rhs.limitLowRollWear < limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear < __rhs.limitUpRollWear)
        {
            return true;
        }
        else if(__rhs.limitUpRollWear < limitUpRollWear)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollAuxInfoTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollAuxInfoTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollAuxInfoTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollAuxInfoTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 * Edger-Roll information
 * ��������������Ϣ��
 **/
struct RollInfoEdger
{
	string rollIDDriveSide;            //  ��������������
	float  rollDiaDriveSide;           //  ������������������λ��mm��

    bool operator==(const RollInfoEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollIDDriveSide != __rhs.rollIDDriveSide)
        {
            return false;
        }
        if(rollDiaDriveSide != __rhs.rollDiaDriveSide)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollInfoEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollIDDriveSide < __rhs.rollIDDriveSide)
        {
            return true;
        }
        else if(__rhs.rollIDDriveSide < rollIDDriveSide)
        {
            return false;
        }
        if(rollDiaDriveSide < __rhs.rollDiaDriveSide)
        {
            return true;
        }
        else if(__rhs.rollDiaDriveSide < rollDiaDriveSide)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollInfoEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollInfoEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollInfoEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollInfoEdger& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

struct RollAuxInfoEdger
{
    float limitLowDriveSideRollDia;
    float limitUpDriveSideRollDia;
    float limitLowRollForce;
    float limitUpRollForce;
    float limitLowRollingSpeed;
    float limitUpRollingSpeed;
    float limitLowGap;
    float limitUpGap;
    float limitLowRollWear;
    float limitUpRollWear;

    bool operator==(const RollAuxInfoEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(limitLowDriveSideRollDia != __rhs.limitLowDriveSideRollDia)
        {
            return false;
        }
        if(limitUpDriveSideRollDia != __rhs.limitUpDriveSideRollDia)
        {
            return false;
        }
        if(limitLowRollForce != __rhs.limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce != __rhs.limitUpRollForce)
        {
            return false;
        }
        if(limitLowRollingSpeed != __rhs.limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed != __rhs.limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap != __rhs.limitLowGap)
        {
            return false;
        }
        if(limitUpGap != __rhs.limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear != __rhs.limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear != __rhs.limitUpRollWear)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollAuxInfoEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(limitLowDriveSideRollDia < __rhs.limitLowDriveSideRollDia)
        {
            return true;
        }
        else if(__rhs.limitLowDriveSideRollDia < limitLowDriveSideRollDia)
        {
            return false;
        }
        if(limitUpDriveSideRollDia < __rhs.limitUpDriveSideRollDia)
        {
            return true;
        }
        else if(__rhs.limitUpDriveSideRollDia < limitUpDriveSideRollDia)
        {
            return false;
        }
        if(limitLowRollForce < __rhs.limitLowRollForce)
        {
            return true;
        }
        else if(__rhs.limitLowRollForce < limitLowRollForce)
        {
            return false;
        }
        if(limitUpRollForce < __rhs.limitUpRollForce)
        {
            return true;
        }
        else if(__rhs.limitUpRollForce < limitUpRollForce)
        {
            return false;
        }
        if(limitLowRollingSpeed < __rhs.limitLowRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitLowRollingSpeed < limitLowRollingSpeed)
        {
            return false;
        }
        if(limitUpRollingSpeed < __rhs.limitUpRollingSpeed)
        {
            return true;
        }
        else if(__rhs.limitUpRollingSpeed < limitUpRollingSpeed)
        {
            return false;
        }
        if(limitLowGap < __rhs.limitLowGap)
        {
            return true;
        }
        else if(__rhs.limitLowGap < limitLowGap)
        {
            return false;
        }
        if(limitUpGap < __rhs.limitUpGap)
        {
            return true;
        }
        else if(__rhs.limitUpGap < limitUpGap)
        {
            return false;
        }
        if(limitLowRollWear < __rhs.limitLowRollWear)
        {
            return true;
        }
        else if(__rhs.limitLowRollWear < limitLowRollWear)
        {
            return false;
        }
        if(limitUpRollWear < __rhs.limitUpRollWear)
        {
            return true;
        }
        else if(__rhs.limitUpRollWear < limitUpRollWear)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollAuxInfoEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollAuxInfoEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollAuxInfoEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollAuxInfoEdger& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

typedef vector< float> MillCurveCoeff;

/**
 * The roll calibration data to be stored in object cache
 * ����������ݡ�
 **/
struct CaliData
{
	float caliRollForce;  //�������������λ��kN��
	float caliBendForce;  //������������λ��kN��
	float caliGap;        //������죨��λ��mm��
	float caliSpeed;      //����ٶȣ���λ��m/s��

    bool operator==(const CaliData& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(caliRollForce != __rhs.caliRollForce)
        {
            return false;
        }
        if(caliBendForce != __rhs.caliBendForce)
        {
            return false;
        }
        if(caliGap != __rhs.caliGap)
        {
            return false;
        }
        if(caliSpeed != __rhs.caliSpeed)
        {
            return false;
        }
        return true;
    }

    bool operator<(const CaliData& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(caliRollForce < __rhs.caliRollForce)
        {
            return true;
        }
        else if(__rhs.caliRollForce < caliRollForce)
        {
            return false;
        }
        if(caliBendForce < __rhs.caliBendForce)
        {
            return true;
        }
        else if(__rhs.caliBendForce < caliBendForce)
        {
            return false;
        }
        if(caliGap < __rhs.caliGap)
        {
            return true;
        }
        else if(__rhs.caliGap < caliGap)
        {
            return false;
        }
        if(caliSpeed < __rhs.caliSpeed)
        {
            return true;
        }
        else if(__rhs.caliSpeed < caliSpeed)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const CaliData& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const CaliData& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const CaliData& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const CaliData& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 * Roll oil film characteristics to be stored in object cache
 * ֧�й���Ĥ������ݡ�
 **/
struct OilFilmDataSpeed
{
	float rollSpeed;      //����ת�١�����λ��m/s��
	float oilThick;       //��Ĥ��ȡ�����λ��mm��

    bool operator==(const OilFilmDataSpeed& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        if(oilThick != __rhs.oilThick)
        {
            return false;
        }
        return true;
    }

    bool operator<(const OilFilmDataSpeed& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        if(oilThick < __rhs.oilThick)
        {
            return true;
        }
        else if(__rhs.oilThick < oilThick)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const OilFilmDataSpeed& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const OilFilmDataSpeed& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const OilFilmDataSpeed& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const OilFilmDataSpeed& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

struct OilFilmDataForce
{
	float rollForce;      //������������λ��kN��
	float oilThick;       //��Ĥ��ȡ�����λ��mm��

    bool operator==(const OilFilmDataForce& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(oilThick != __rhs.oilThick)
        {
            return false;
        }
        return true;
    }

    bool operator<(const OilFilmDataForce& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(oilThick < __rhs.oilThick)
        {
            return true;
        }
        else if(__rhs.oilThick < oilThick)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const OilFilmDataForce& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const OilFilmDataForce& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const OilFilmDataForce& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const OilFilmDataForce& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 * The effect of strip width to stand modulus to be stored in object cache
 * ���ֿ��ȶ������ն�Ӱ��ϵ����
 **/
struct WidthToModulus
{
	float constCoeff;         //C3�����ȶ������ն�Ӱ�졣�����
	float firstOrderCoeff;    //C4�����ȶ������ն�Ӱ�졣һ���
	float secondOrderCoeff;   //C5�����ȶ������ն�Ӱ�졣������

    bool operator==(const WidthToModulus& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(constCoeff != __rhs.constCoeff)
        {
            return false;
        }
        if(firstOrderCoeff != __rhs.firstOrderCoeff)
        {
            return false;
        }
        if(secondOrderCoeff != __rhs.secondOrderCoeff)
        {
            return false;
        }
        return true;
    }

    bool operator<(const WidthToModulus& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(constCoeff < __rhs.constCoeff)
        {
            return true;
        }
        else if(__rhs.constCoeff < constCoeff)
        {
            return false;
        }
        if(firstOrderCoeff < __rhs.firstOrderCoeff)
        {
            return true;
        }
        else if(__rhs.firstOrderCoeff < firstOrderCoeff)
        {
            return false;
        }
        if(secondOrderCoeff < __rhs.secondOrderCoeff)
        {
            return true;
        }
        else if(__rhs.secondOrderCoeff < secondOrderCoeff)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const WidthToModulus& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const WidthToModulus& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const WidthToModulus& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const WidthToModulus& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

typedef vector< OilFilmDataSpeed> OFDSDATA;

typedef vector< OilFilmDataForce> OFDFDATA;
/**
 * Data structure for screw down set-up values
 * Setup values
 **/
struct ScrewDownData
{
	float  rollGapSet;      //sset  roll gap setting value (mm)
	float  rollGapZero;     //sz    roll gap in zeroing (mm)
	float  rollGapTrue;     //s0    true roll gap (mm)
	float  rollGapOilRoll;  //soil  oil film thickness rolling (mm)
	float  rollGapBend;     //sb    roll bending comp. (mm)
	float  rollGapShift;    //swrs  wr shift comp. (mm)
	float  rollGapInitCrown;//swrc  wr init crown comp. (mm)
	float  rollGapRollWear; //srw   wr wear comp. (mm)
	float  rollGapRollTherm;//srh   wr thermal crown comp. (mm)
	float  rollGapLearn;    //zbs   learning term (bar to bar) (mm)
	float  rollGapIndicator;//szset indicator setting value zeroing (mm)
	float  millStretchZero; //sm0   mill stretch zeroing (mm)
	float  oilFilmZero;     //soil0 oil film thickness zeroing (mm)
	float  exThick;         //h     delivery thickness (mm)
	float  millStretchRoll; //sm    mill stretch rolling (mm)

    bool operator==(const ScrewDownData& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollGapSet != __rhs.rollGapSet)
        {
            return false;
        }
        if(rollGapZero != __rhs.rollGapZero)
        {
            return false;
        }
        if(rollGapTrue != __rhs.rollGapTrue)
        {
            return false;
        }
        if(rollGapOilRoll != __rhs.rollGapOilRoll)
        {
            return false;
        }
        if(rollGapBend != __rhs.rollGapBend)
        {
            return false;
        }
        if(rollGapShift != __rhs.rollGapShift)
        {
            return false;
        }
        if(rollGapInitCrown != __rhs.rollGapInitCrown)
        {
            return false;
        }
        if(rollGapRollWear != __rhs.rollGapRollWear)
        {
            return false;
        }
        if(rollGapRollTherm != __rhs.rollGapRollTherm)
        {
            return false;
        }
        if(rollGapLearn != __rhs.rollGapLearn)
        {
            return false;
        }
        if(rollGapIndicator != __rhs.rollGapIndicator)
        {
            return false;
        }
        if(millStretchZero != __rhs.millStretchZero)
        {
            return false;
        }
        if(oilFilmZero != __rhs.oilFilmZero)
        {
            return false;
        }
        if(exThick != __rhs.exThick)
        {
            return false;
        }
        if(millStretchRoll != __rhs.millStretchRoll)
        {
            return false;
        }
        return true;
    }

    bool operator<(const ScrewDownData& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollGapSet < __rhs.rollGapSet)
        {
            return true;
        }
        else if(__rhs.rollGapSet < rollGapSet)
        {
            return false;
        }
        if(rollGapZero < __rhs.rollGapZero)
        {
            return true;
        }
        else if(__rhs.rollGapZero < rollGapZero)
        {
            return false;
        }
        if(rollGapTrue < __rhs.rollGapTrue)
        {
            return true;
        }
        else if(__rhs.rollGapTrue < rollGapTrue)
        {
            return false;
        }
        if(rollGapOilRoll < __rhs.rollGapOilRoll)
        {
            return true;
        }
        else if(__rhs.rollGapOilRoll < rollGapOilRoll)
        {
            return false;
        }
        if(rollGapBend < __rhs.rollGapBend)
        {
            return true;
        }
        else if(__rhs.rollGapBend < rollGapBend)
        {
            return false;
        }
        if(rollGapShift < __rhs.rollGapShift)
        {
            return true;
        }
        else if(__rhs.rollGapShift < rollGapShift)
        {
            return false;
        }
        if(rollGapInitCrown < __rhs.rollGapInitCrown)
        {
            return true;
        }
        else if(__rhs.rollGapInitCrown < rollGapInitCrown)
        {
            return false;
        }
        if(rollGapRollWear < __rhs.rollGapRollWear)
        {
            return true;
        }
        else if(__rhs.rollGapRollWear < rollGapRollWear)
        {
            return false;
        }
        if(rollGapRollTherm < __rhs.rollGapRollTherm)
        {
            return true;
        }
        else if(__rhs.rollGapRollTherm < rollGapRollTherm)
        {
            return false;
        }
        if(rollGapLearn < __rhs.rollGapLearn)
        {
            return true;
        }
        else if(__rhs.rollGapLearn < rollGapLearn)
        {
            return false;
        }
        if(rollGapIndicator < __rhs.rollGapIndicator)
        {
            return true;
        }
        else if(__rhs.rollGapIndicator < rollGapIndicator)
        {
            return false;
        }
        if(millStretchZero < __rhs.millStretchZero)
        {
            return true;
        }
        else if(__rhs.millStretchZero < millStretchZero)
        {
            return false;
        }
        if(oilFilmZero < __rhs.oilFilmZero)
        {
            return true;
        }
        else if(__rhs.oilFilmZero < oilFilmZero)
        {
            return false;
        }
        if(exThick < __rhs.exThick)
        {
            return true;
        }
        else if(__rhs.exThick < exThick)
        {
            return false;
        }
        if(millStretchRoll < __rhs.millStretchRoll)
        {
            return true;
        }
        else if(__rhs.millStretchRoll < millStretchRoll)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const ScrewDownData& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const ScrewDownData& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const ScrewDownData& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const ScrewDownData& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 * Data structure for L1 AGC set-up
 **/
struct AGCSetUpData
{
	float  gaugeMeterConst;   //      gauge meter constant
	float  millStretchConst1; // C1   mill stretch calculation const C1
	float  millStretchConst2; // C2   mill stretch calculation const C2
	float  millStretchConstKB;// KB   mill stretch calculation const KB
	float  oilFilmSoilHE;     // Soil-HE oil film thickness Soil-HE
	float  oilFilmKoil;       // Koil oil film adjustment coefficient Koil
	OFDSDATA filmSpeedData;   // Nb Sv  oil film thickness coefficient Nb
	OFDFDATA filmForceData;   // P  Kp  oil film thickness coefficient Sv
	float  tailComp;          //      F2-7 roll gap tail end compensation β������
	float  bendMB;            // MB   bending mill const in rolling MB
	float  bendKF0;           // KF0  bending force compensation coefficient KF0 ���������ϵ��
	float  shiftBendDF;       // DF   WR shift to bending influence coef DF �ܹ����������Ӱ��ϵ��
	float  bendCompSbHE;      // SbHE bending force compensation at head Sb-HE  �������ͷ����Ӱ��
	float  shiftCompKWRS;     // KWRS F5-7 WR shift compen coefficient �������ܹ�Ӱ��ϵ��
	float  shiftCompSWRS;     // Swrs F5-7 WR shift compensation value
	float  rollThemalTRC;     // TRC  Roll thermal expansion comp. time const TRC
	float  rollThemalSRC;     // SRC  Roll thermal expansion final value deltaSRC
	float  rollThemalSrhHE;   // SrhHERoll thermal expansion comp.at head Srh-HE

    bool operator==(const AGCSetUpData& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(gaugeMeterConst != __rhs.gaugeMeterConst)
        {
            return false;
        }
        if(millStretchConst1 != __rhs.millStretchConst1)
        {
            return false;
        }
        if(millStretchConst2 != __rhs.millStretchConst2)
        {
            return false;
        }
        if(millStretchConstKB != __rhs.millStretchConstKB)
        {
            return false;
        }
        if(oilFilmSoilHE != __rhs.oilFilmSoilHE)
        {
            return false;
        }
        if(oilFilmKoil != __rhs.oilFilmKoil)
        {
            return false;
        }
        if(filmSpeedData != __rhs.filmSpeedData)
        {
            return false;
        }
        if(filmForceData != __rhs.filmForceData)
        {
            return false;
        }
        if(tailComp != __rhs.tailComp)
        {
            return false;
        }
        if(bendMB != __rhs.bendMB)
        {
            return false;
        }
        if(bendKF0 != __rhs.bendKF0)
        {
            return false;
        }
        if(shiftBendDF != __rhs.shiftBendDF)
        {
            return false;
        }
        if(bendCompSbHE != __rhs.bendCompSbHE)
        {
            return false;
        }
        if(shiftCompKWRS != __rhs.shiftCompKWRS)
        {
            return false;
        }
        if(shiftCompSWRS != __rhs.shiftCompSWRS)
        {
            return false;
        }
        if(rollThemalTRC != __rhs.rollThemalTRC)
        {
            return false;
        }
        if(rollThemalSRC != __rhs.rollThemalSRC)
        {
            return false;
        }
        if(rollThemalSrhHE != __rhs.rollThemalSrhHE)
        {
            return false;
        }
        return true;
    }

    bool operator<(const AGCSetUpData& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(gaugeMeterConst < __rhs.gaugeMeterConst)
        {
            return true;
        }
        else if(__rhs.gaugeMeterConst < gaugeMeterConst)
        {
            return false;
        }
        if(millStretchConst1 < __rhs.millStretchConst1)
        {
            return true;
        }
        else if(__rhs.millStretchConst1 < millStretchConst1)
        {
            return false;
        }
        if(millStretchConst2 < __rhs.millStretchConst2)
        {
            return true;
        }
        else if(__rhs.millStretchConst2 < millStretchConst2)
        {
            return false;
        }
        if(millStretchConstKB < __rhs.millStretchConstKB)
        {
            return true;
        }
        else if(__rhs.millStretchConstKB < millStretchConstKB)
        {
            return false;
        }
        if(oilFilmSoilHE < __rhs.oilFilmSoilHE)
        {
            return true;
        }
        else if(__rhs.oilFilmSoilHE < oilFilmSoilHE)
        {
            return false;
        }
        if(oilFilmKoil < __rhs.oilFilmKoil)
        {
            return true;
        }
        else if(__rhs.oilFilmKoil < oilFilmKoil)
        {
            return false;
        }
        if(filmSpeedData < __rhs.filmSpeedData)
        {
            return true;
        }
        else if(__rhs.filmSpeedData < filmSpeedData)
        {
            return false;
        }
        if(filmForceData < __rhs.filmForceData)
        {
            return true;
        }
        else if(__rhs.filmForceData < filmForceData)
        {
            return false;
        }
        if(tailComp < __rhs.tailComp)
        {
            return true;
        }
        else if(__rhs.tailComp < tailComp)
        {
            return false;
        }
        if(bendMB < __rhs.bendMB)
        {
            return true;
        }
        else if(__rhs.bendMB < bendMB)
        {
            return false;
        }
        if(bendKF0 < __rhs.bendKF0)
        {
            return true;
        }
        else if(__rhs.bendKF0 < bendKF0)
        {
            return false;
        }
        if(shiftBendDF < __rhs.shiftBendDF)
        {
            return true;
        }
        else if(__rhs.shiftBendDF < shiftBendDF)
        {
            return false;
        }
        if(bendCompSbHE < __rhs.bendCompSbHE)
        {
            return true;
        }
        else if(__rhs.bendCompSbHE < bendCompSbHE)
        {
            return false;
        }
        if(shiftCompKWRS < __rhs.shiftCompKWRS)
        {
            return true;
        }
        else if(__rhs.shiftCompKWRS < shiftCompKWRS)
        {
            return false;
        }
        if(shiftCompSWRS < __rhs.shiftCompSWRS)
        {
            return true;
        }
        else if(__rhs.shiftCompSWRS < shiftCompSWRS)
        {
            return false;
        }
        if(rollThemalTRC < __rhs.rollThemalTRC)
        {
            return true;
        }
        else if(__rhs.rollThemalTRC < rollThemalTRC)
        {
            return false;
        }
        if(rollThemalSRC < __rhs.rollThemalSRC)
        {
            return true;
        }
        else if(__rhs.rollThemalSRC < rollThemalSRC)
        {
            return false;
        }
        if(rollThemalSrhHE < __rhs.rollThemalSrhHE)
        {
            return true;
        }
        else if(__rhs.rollThemalSrhHE < rollThemalSrhHE)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const AGCSetUpData& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const AGCSetUpData& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const AGCSetUpData& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const AGCSetUpData& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 *  Input data structure for Four-Hi stand
 *  �Ĺ������趨�����������ݽӿ�
 **/
struct InputDataFourHi
{
	bool  standStatus;    //��������״̬
	float entryThick;     //��ں�ȣ���λ��mm��
	float delivThick;     //���ں�ȣ���λ��mm��
	float stripWidth;     //���ֿ��ȣ���λ��mm��
	float rollForce;      //����������λ��kN��
	float bendForce;      //���������λ��kN��
	float rollSpeed;      //�����ٶȣ���λ��m/s��
	float looperAngle;    //���׽Ƕ�
	float rollShift;      //�����ܹ�������λ��mm��
	float rateEntryRollCooling; //��ڲ���ȴˮ����(��λ��%)
	float rateExitRollCooling;  //���ڲ���ȴˮ����(��λ��%)
	float predictTime;            //ʱ�䲽������λ��s��
	float corrZeroPoint;  //Zero point correction
	float corrRollGapA;
	float corrRollGapB;

    bool operator==(const InputDataFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(entryThick != __rhs.entryThick)
        {
            return false;
        }
        if(delivThick != __rhs.delivThick)
        {
            return false;
        }
        if(stripWidth != __rhs.stripWidth)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(bendForce != __rhs.bendForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        if(looperAngle != __rhs.looperAngle)
        {
            return false;
        }
        if(rollShift != __rhs.rollShift)
        {
            return false;
        }
        if(rateEntryRollCooling != __rhs.rateEntryRollCooling)
        {
            return false;
        }
        if(rateExitRollCooling != __rhs.rateExitRollCooling)
        {
            return false;
        }
        if(predictTime != __rhs.predictTime)
        {
            return false;
        }
        if(corrZeroPoint != __rhs.corrZeroPoint)
        {
            return false;
        }
        if(corrRollGapA != __rhs.corrRollGapA)
        {
            return false;
        }
        if(corrRollGapB != __rhs.corrRollGapB)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(entryThick < __rhs.entryThick)
        {
            return true;
        }
        else if(__rhs.entryThick < entryThick)
        {
            return false;
        }
        if(delivThick < __rhs.delivThick)
        {
            return true;
        }
        else if(__rhs.delivThick < delivThick)
        {
            return false;
        }
        if(stripWidth < __rhs.stripWidth)
        {
            return true;
        }
        else if(__rhs.stripWidth < stripWidth)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(bendForce < __rhs.bendForce)
        {
            return true;
        }
        else if(__rhs.bendForce < bendForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        if(looperAngle < __rhs.looperAngle)
        {
            return true;
        }
        else if(__rhs.looperAngle < looperAngle)
        {
            return false;
        }
        if(rollShift < __rhs.rollShift)
        {
            return true;
        }
        else if(__rhs.rollShift < rollShift)
        {
            return false;
        }
        if(rateEntryRollCooling < __rhs.rateEntryRollCooling)
        {
            return true;
        }
        else if(__rhs.rateEntryRollCooling < rateEntryRollCooling)
        {
            return false;
        }
        if(rateExitRollCooling < __rhs.rateExitRollCooling)
        {
            return true;
        }
        else if(__rhs.rateExitRollCooling < rateExitRollCooling)
        {
            return false;
        }
        if(predictTime < __rhs.predictTime)
        {
            return true;
        }
        else if(__rhs.predictTime < predictTime)
        {
            return false;
        }
        if(corrZeroPoint < __rhs.corrZeroPoint)
        {
            return true;
        }
        else if(__rhs.corrZeroPoint < corrZeroPoint)
        {
            return false;
        }
        if(corrRollGapA < __rhs.corrRollGapA)
        {
            return true;
        }
        else if(__rhs.corrRollGapA < corrRollGapA)
        {
            return false;
        }
        if(corrRollGapB < __rhs.corrRollGapB)
        {
            return true;
        }
        else if(__rhs.corrRollGapB < corrRollGapB)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataFourHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataFourHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataFourHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataFourHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 *  Input data structure for Two-Hi stand
 *  ���������趨�����������ݽӿ�
 **/
struct InputDataTwoHi {
    bool  standStatus;    //��������״̬
    float entryThick;     //entry strip width for edger mills
    float delivThick;     //delivery strip width for edger mills
    float stripWidth;     //strip thickness for edger mill
    float rollForce;      //����������λ��kN��
    float rollSpeed;      //�����ٶȣ���λ��m/s��

    bool operator==(const InputDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(entryThick != __rhs.entryThick)
        {
            return false;
        }
        if(delivThick != __rhs.delivThick)
        {
            return false;
        }
        if(stripWidth != __rhs.stripWidth)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(entryThick < __rhs.entryThick)
        {
            return true;
        }
        else if(__rhs.entryThick < entryThick)
        {
            return false;
        }
        if(delivThick < __rhs.delivThick)
        {
            return true;
        }
        else if(__rhs.delivThick < delivThick)
        {
            return false;
        }
        if(stripWidth < __rhs.stripWidth)
        {
            return true;
        }
        else if(__rhs.stripWidth < stripWidth)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 *  Input data structure for Edger stand
 *  ���������趨�����������ݽӿ�
 **/
struct InputDataEdger
{
	bool  standStatus;    //��������״̬
	float entryWidth;     //��ڿ��ȣ���λ��mm��
	float delivWidth;     //���ڿ��ȣ���λ��mm��
	float stripThick;     //���ֺ�ȣ���λ��mm��
	float rollForce;      //����������λ��kN��
	float rollSpeed;      //�����ٶȣ���λ��m/s��

    bool operator==(const InputDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(entryWidth != __rhs.entryWidth)
        {
            return false;
        }
        if(delivWidth != __rhs.delivWidth)
        {
            return false;
        }
        if(stripThick != __rhs.stripThick)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(entryWidth < __rhs.entryWidth)
        {
            return true;
        }
        else if(__rhs.entryWidth < entryWidth)
        {
            return false;
        }
        if(delivWidth < __rhs.delivWidth)
        {
            return true;
        }
        else if(__rhs.delivWidth < delivWidth)
        {
            return false;
        }
        if(stripThick < __rhs.stripThick)
        {
            return true;
        }
        else if(__rhs.stripThick < stripThick)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataEdger& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};
/**
 *  Postcalculation input data structure for Four-Hi stand
 *  �Ĺ�����������������ݽӿ�
 **/
struct InputDataPostFourHi {
    bool  standStatus;    //��������״̬
    float stripWidth;     //���ֿ��ȣ���λ��mm��
    float rollForce;      //����������λ��kN��
    float bendForce;      //���������λ��kN��
    float rollSpeed;      //�����ٶȣ���λ��m/s��
    float looperAngle;    //���׽Ƕ�
    float rollShift;      //�����ܹ�������λ��mm��
    float rollGap;        //���ܹ��죨��λ��mm��
    float corrZeroPoint;  //Zero point correction
    float corrRollGapA;
    float corrRollGapB;

    bool operator==(const InputDataPostFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(stripWidth != __rhs.stripWidth)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(bendForce != __rhs.bendForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        if(looperAngle != __rhs.looperAngle)
        {
            return false;
        }
        if(rollShift != __rhs.rollShift)
        {
            return false;
        }
        if(rollGap != __rhs.rollGap)
        {
            return false;
        }
        if(corrZeroPoint != __rhs.corrZeroPoint)
        {
            return false;
        }
        if(corrRollGapA != __rhs.corrRollGapA)
        {
            return false;
        }
        if(corrRollGapB != __rhs.corrRollGapB)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataPostFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(stripWidth < __rhs.stripWidth)
        {
            return true;
        }
        else if(__rhs.stripWidth < stripWidth)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(bendForce < __rhs.bendForce)
        {
            return true;
        }
        else if(__rhs.bendForce < bendForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        if(looperAngle < __rhs.looperAngle)
        {
            return true;
        }
        else if(__rhs.looperAngle < looperAngle)
        {
            return false;
        }
        if(rollShift < __rhs.rollShift)
        {
            return true;
        }
        else if(__rhs.rollShift < rollShift)
        {
            return false;
        }
        if(rollGap < __rhs.rollGap)
        {
            return true;
        }
        else if(__rhs.rollGap < rollGap)
        {
            return false;
        }
        if(corrZeroPoint < __rhs.corrZeroPoint)
        {
            return true;
        }
        else if(__rhs.corrZeroPoint < corrZeroPoint)
        {
            return false;
        }
        if(corrRollGapA < __rhs.corrRollGapA)
        {
            return true;
        }
        else if(__rhs.corrRollGapA < corrRollGapA)
        {
            return false;
        }
        if(corrRollGapB < __rhs.corrRollGapB)
        {
            return true;
        }
        else if(__rhs.corrRollGapB < corrRollGapB)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataPostFourHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataPostFourHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataPostFourHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataPostFourHi& __rhs) const
    {
        return !operator<(__rhs);
    }

};

/**
 *  Postcalculation input data structure for Two-Hi stand
 *  ��������������������ݽӿ�
 **/
struct InputDataPostTwoHi {
    bool  standStatus;    //��������״̬
    float stripWidth;     //���ֿ��ȣ���λ��mm��
    float rollForce;      //����������λ��kN��
    float rollSpeed;      //�����ٶȣ���λ��m/s��
    float rollGap;        //���ܹ��죨��λ��mm��

    bool operator==(const InputDataPostTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(stripWidth != __rhs.stripWidth)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        if(rollGap != __rhs.rollGap)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataPostTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(stripWidth < __rhs.stripWidth)
        {
            return true;
        }
        else if(__rhs.stripWidth < stripWidth)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        if(rollGap < __rhs.rollGap)
        {
            return true;
        }
        else if(__rhs.rollGap < rollGap)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataPostTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataPostTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataPostTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataPostTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};


/**
 *  Postcalculation input data structure for Edger stand
 *  ��������������������ݽӿ�
 **/
struct InputDataPostEdger {
    bool  standStatus;    //��������״̬
    float stripThick;     //���ֺ�ȣ���λ��mm��
    float rollForce;      //����������λ��kN��
    float rollSpeed;      //�����ٶȣ���λ��m/s��
    float rollGap;        //���ܹ��죨��λ��mm��

    bool operator==(const InputDataPostEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(standStatus != __rhs.standStatus)
        {
            return false;
        }
        if(stripThick != __rhs.stripThick)
        {
            return false;
        }
        if(rollForce != __rhs.rollForce)
        {
            return false;
        }
        if(rollSpeed != __rhs.rollSpeed)
        {
            return false;
        }
        if(rollGap != __rhs.rollGap)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataPostEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(standStatus < __rhs.standStatus)
        {
            return true;
        }
        else if(__rhs.standStatus < standStatus)
        {
            return false;
        }
        if(stripThick < __rhs.stripThick)
        {
            return true;
        }
        else if(__rhs.stripThick < stripThick)
        {
            return false;
        }
        if(rollForce < __rhs.rollForce)
        {
            return true;
        }
        else if(__rhs.rollForce < rollForce)
        {
            return false;
        }
        if(rollSpeed < __rhs.rollSpeed)
        {
            return true;
        }
        else if(__rhs.rollSpeed < rollSpeed)
        {
            return false;
        }
        if(rollGap < __rhs.rollGap)
        {
            return true;
        }
        else if(__rhs.rollGap < rollGap)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataPostEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataPostEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataPostEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataPostEdger& __rhs) const
    {
        return !operator<(__rhs);
    }

    
    
};

/**
 *  Setup data structure
 *  �Ĺ������趨ֵ���ݽṹ
 **/
struct RollGapSetDataFourHi
{
    string stdId;               //���ܱ�ʶ��"R2","F1","F2","F3","F4","F5","F6","F7"
    ScrewDownData sDData;       //�����趨ֵ���ݽӿڡ�
    AGCSetUpData  agcData;      //AGC�����趨ֵ�ӿڡ�
	CaliData	  cData;
    float         millModulus;  //�����նȡ�����λ��mm/kN��

    bool operator==(const RollGapSetDataFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(stdId != __rhs.stdId)
        {
            return false;
        }
        if(sDData != __rhs.sDData)
        {
            return false;
        }
        if(agcData != __rhs.agcData)
        {
            return false;
        }
        if(cData != __rhs.cData)
        {
            return false;
        }
        if(millModulus != __rhs.millModulus)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollGapSetDataFourHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(stdId < __rhs.stdId)
        {
            return true;
        }
        else if(__rhs.stdId < stdId)
        {
            return false;
        }
        if(sDData < __rhs.sDData)
        {
            return true;
        }
        else if(__rhs.sDData < sDData)
        {
            return false;
        }
        if(agcData < __rhs.agcData)
        {
            return true;
        }
        else if(__rhs.agcData < agcData)
        {
            return false;
        }
        if(cData < __rhs.cData)
        {
            return true;
        }
        else if(__rhs.cData < cData)
        {
            return false;
        }
        if(millModulus < __rhs.millModulus)
        {
            return true;
        }
        else if(__rhs.millModulus < millModulus)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollGapSetDataFourHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollGapSetDataFourHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollGapSetDataFourHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollGapSetDataFourHi& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Setup data structure for 2-Hi Stand
 *  ���������趨ֵ���ݽṹ
 **/
struct RollGapSetDataTwoHi
{
    string stdId;           //���ܱ�ʶ��"R1"
    float rollGapSet;       //�趨���죨��λ��mm��
    float millModulus;      //�����նȡ�����λ��mm/kN��
    float rollWearDynamic;  //����ĥ����������λ��mm��
    float rollGapLearn;

    bool operator==(const RollGapSetDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(stdId != __rhs.stdId)
        {
            return false;
        }
        if(rollGapSet != __rhs.rollGapSet)
        {
            return false;
        }
        if(millModulus != __rhs.millModulus)
        {
            return false;
        }
        if(rollWearDynamic != __rhs.rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn != __rhs.rollGapLearn)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollGapSetDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(stdId < __rhs.stdId)
        {
            return true;
        }
        else if(__rhs.stdId < stdId)
        {
            return false;
        }
        if(rollGapSet < __rhs.rollGapSet)
        {
            return true;
        }
        else if(__rhs.rollGapSet < rollGapSet)
        {
            return false;
        }
        if(millModulus < __rhs.millModulus)
        {
            return true;
        }
        else if(__rhs.millModulus < millModulus)
        {
            return false;
        }
        if(rollWearDynamic < __rhs.rollWearDynamic)
        {
            return true;
        }
        else if(__rhs.rollWearDynamic < rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn < __rhs.rollGapLearn)
        {
            return true;
        }
        else if(__rhs.rollGapLearn < rollGapLearn)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollGapSetDataTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollGapSetDataTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollGapSetDataTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollGapSetDataTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Setup data structure for edger Stand
 *  ���������趨ֵ���ݽṹ
 **/
struct RollGapSetDataEdger
{
    string stdId;           //���ܱ�ʶ��"E2","F1E"
    float rollGapSet;       //�趨���죨��λ��mm��
    float millModulus;      //�����նȡ�����λ��mm/kN��
    float rollWearDynamic;  //����ĥ����������λ��mm��
    float rollGapLearn;

    bool operator==(const RollGapSetDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(stdId != __rhs.stdId)
        {
            return false;
        }
        if(rollGapSet != __rhs.rollGapSet)
        {
            return false;
        }
        if(millModulus != __rhs.millModulus)
        {
            return false;
        }
        if(rollWearDynamic != __rhs.rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn != __rhs.rollGapLearn)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollGapSetDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(stdId < __rhs.stdId)
        {
            return true;
        }
        else if(__rhs.stdId < stdId)
        {
            return false;
        }
        if(rollGapSet < __rhs.rollGapSet)
        {
            return true;
        }
        else if(__rhs.rollGapSet < rollGapSet)
        {
            return false;
        }
        if(millModulus < __rhs.millModulus)
        {
            return true;
        }
        else if(__rhs.millModulus < millModulus)
        {
            return false;
        }
        if(rollWearDynamic < __rhs.rollWearDynamic)
        {
            return true;
        }
        else if(__rhs.rollWearDynamic < rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn < __rhs.rollGapLearn)
        {
            return true;
        }
        else if(__rhs.rollGapLearn < rollGapLearn)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollGapSetDataEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollGapSetDataEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollGapSetDataEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollGapSetDataEdger& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Input data structure for Roll Wear calculation
 *  ĥ������������ݽӿڡ�
 **/
struct InputDataWear 
{
//  string stdId;                //���ܱ�ʶ��"R1","R2","F1","F2","F3","F4","F5","F6","F7","E2","F1E"
    bool   rollingStatus;        //��������״̬
    float  rollSpeedActual;      //ʵ�������ٶȣ���λ��m/s��
    float  rollForceActual;      //ʵ������������λ��kN��
    float  stripWidth;           //���ֿ��ȣ���λ��mm��
    float  deltaTime;            //ʱ�䲽������λ��s��

    bool operator==(const InputDataWear& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollingStatus != __rhs.rollingStatus)
        {
            return false;
        }
        if(rollSpeedActual != __rhs.rollSpeedActual)
        {
            return false;
        }
        if(rollForceActual != __rhs.rollForceActual)
        {
            return false;
        }
        if(stripWidth != __rhs.stripWidth)
        {
            return false;
        }
        if(deltaTime != __rhs.deltaTime)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataWear& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollingStatus < __rhs.rollingStatus)
        {
            return true;
        }
        else if(__rhs.rollingStatus < rollingStatus)
        {
            return false;
        }
        if(rollSpeedActual < __rhs.rollSpeedActual)
        {
            return true;
        }
        else if(__rhs.rollSpeedActual < rollSpeedActual)
        {
            return false;
        }
        if(rollForceActual < __rhs.rollForceActual)
        {
            return true;
        }
        else if(__rhs.rollForceActual < rollForceActual)
        {
            return false;
        }
        if(stripWidth < __rhs.stripWidth)
        {
            return true;
        }
        else if(__rhs.stripWidth < stripWidth)
        {
            return false;
        }
        if(deltaTime < __rhs.deltaTime)
        {
            return true;
        }
        else if(__rhs.deltaTime < deltaTime)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataWear& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataWear& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataWear& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataWear& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Input data structure for Roll Thermal Expansion calculation
 *  ���������ͼ����������ݽӿڡ�
 **/
struct InputDataThermal 
{
//  string stdId;                //���ܱ�ʶ��"F1","F2","F3","F4","F5","F6","F7"
    bool   rollingStatus;        //��������״̬ On �� Off
    float  rateEntryRollCooling; //��ڲ���ȴˮ����(��λ��%)
    float  rateExitRollCooling;  //���ڲ���ȴˮ����(��λ��%)
    float  deltaTime;            //ʱ�䲽������λ��s��

    bool operator==(const InputDataThermal& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(rollingStatus != __rhs.rollingStatus)
        {
            return false;
        }
        if(rateEntryRollCooling != __rhs.rateEntryRollCooling)
        {
            return false;
        }
        if(rateExitRollCooling != __rhs.rateExitRollCooling)
        {
            return false;
        }
        if(deltaTime != __rhs.deltaTime)
        {
            return false;
        }
        return true;
    }

    bool operator<(const InputDataThermal& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(rollingStatus < __rhs.rollingStatus)
        {
            return true;
        }
        else if(__rhs.rollingStatus < rollingStatus)
        {
            return false;
        }
        if(rateEntryRollCooling < __rhs.rateEntryRollCooling)
        {
            return true;
        }
        else if(__rhs.rateEntryRollCooling < rateEntryRollCooling)
        {
            return false;
        }
        if(rateExitRollCooling < __rhs.rateExitRollCooling)
        {
            return true;
        }
        else if(__rhs.rateExitRollCooling < rateExitRollCooling)
        {
            return false;
        }
        if(deltaTime < __rhs.deltaTime)
        {
            return true;
        }
        else if(__rhs.deltaTime < deltaTime)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const InputDataThermal& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const InputDataThermal& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const InputDataThermal& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const InputDataThermal& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Store data structure for Four-roll stand
 *  �Ĺ��������ڲ����ݴ����ṹ��
 **/
    struct RollGapStoreDataFourHi
    {
        string stdId;                           //���ܱ�ʶ��"R2","F1","F2","F3","F4","F5","F6","F7"
        float  rollBarrelLength;                //�������������ȣ�mm����������ϵͳ���޴�������
        float  rollForceBreakPoint;             //ѡȡ��ͬ�����ն����ߵ��������ֽ�ֵ
        RollBasicInfoFourHi rBasicInfoFourHi;   //����������Ϣ
        RollAuxInfoFourHi rAuxInfoFourHi;       //����������Ϣ
        MillCurveCoeff screwToForceCoeffLowRF;  //����ѹ�����ߡ����ö���ʽϵ���������һ��������
        MillCurveCoeff screwToForceCoeffHighRF; //����ѹ�����ߡ����ö���ʽϵ���������һ��������
        CaliData cData;                         //�����������
//      MillModulusTestData mModulusTestData; //����ѹ�����ݡ�Ϊ������,���������ĵ�ԡ�
        OFDSDATA oSpeedData;                    //�ٶȶ���Ĥ���Ӱ������
        OFDFDATA oForceData;                    //����������Ĥ���Ӱ������
        WidthToModulus wToModulus;              //���ȶ������ն�Ӱ��ϵ��
        float    oCompFactor;                   //GoilΪ��Ĥ�������������ϵ��
        float rollWearDynamic;                  //����ĥ��������λ��mm��
        float rollThermalDynamic;               //����������������λ��mm��
        float rollGapLearn;                     //����ѧϰ����������λ��mm��

		bool operator==(const RollGapStoreDataFourHi& __rhs) const
		{
			if(this == &__rhs)
			{
				return true;
			}
			if(stdId != __rhs.stdId)
			{
				return false;
			}
			if(rollBarrelLength != __rhs.rollBarrelLength)
			{
				return false;
			}
			if(rollForceBreakPoint != __rhs.rollForceBreakPoint)
			{
				return false;
			}
			if(rBasicInfoFourHi != __rhs.rBasicInfoFourHi)
			{
				return false;
			}
			if(rAuxInfoFourHi != __rhs.rAuxInfoFourHi)
			{
				return false;
			}
			if(screwToForceCoeffLowRF != __rhs.screwToForceCoeffLowRF)
			{
				return false;
			}
			if(screwToForceCoeffHighRF != __rhs.screwToForceCoeffHighRF)
			{
				return false;
			}
			if(cData != __rhs.cData)
			{
				return false;
			}
			if(oSpeedData != __rhs.oSpeedData)
			{
				return false;
			}
			if(oForceData != __rhs.oForceData)
			{
				return false;
			}
			if(wToModulus != __rhs.wToModulus)
			{
				return false;
			}
			if(oCompFactor != __rhs.oCompFactor)
			{
				return false;
			}
			if(rollWearDynamic != __rhs.rollWearDynamic)
			{
				return false;
			}
			if(rollThermalDynamic != __rhs.rollThermalDynamic)
			{
				return false;
			}
			if(rollGapLearn != __rhs.rollGapLearn)
			{
				return false;
			}
			return true;
		}

		bool operator<(const RollGapStoreDataFourHi& __rhs) const
		{
			if(this == &__rhs)
			{
				return false;
			}
			if(stdId < __rhs.stdId)
			{
				return true;
			}
			else if(__rhs.stdId < stdId)
			{
				return false;
			}
			if(rollBarrelLength < __rhs.rollBarrelLength)
			{
				return true;
			}
			else if(__rhs.rollBarrelLength < rollBarrelLength)
			{
				return false;
			}
			if(rollForceBreakPoint < __rhs.rollForceBreakPoint)
			{
				return true;
			}
			else if(__rhs.rollForceBreakPoint < rollForceBreakPoint)
			{
				return false;
			}
			if(rBasicInfoFourHi < __rhs.rBasicInfoFourHi)
			{
				return true;
			}
			else if(__rhs.rBasicInfoFourHi < rBasicInfoFourHi)
			{
				return false;
			}
			if(rAuxInfoFourHi < __rhs.rAuxInfoFourHi)
			{
				return true;
			}
			else if(__rhs.rAuxInfoFourHi < rAuxInfoFourHi)
			{
				return false;
			}
			if(screwToForceCoeffLowRF < __rhs.screwToForceCoeffLowRF)
			{
				return true;
			}
			else if(__rhs.screwToForceCoeffLowRF < screwToForceCoeffLowRF)
			{
				return false;
			}
			if(screwToForceCoeffHighRF < __rhs.screwToForceCoeffHighRF)
			{
				return true;
			}
			else if(__rhs.screwToForceCoeffHighRF < screwToForceCoeffHighRF)
			{
				return false;
			}
			if(cData < __rhs.cData)
			{
				return true;
			}
			else if(__rhs.cData < cData)
			{
				return false;
			}
			if(oSpeedData < __rhs.oSpeedData)
			{
				return true;
			}
			else if(__rhs.oSpeedData < oSpeedData)
			{
				return false;
			}
			if(oForceData < __rhs.oForceData)
			{
				return true;
			}
			else if(__rhs.oForceData < oForceData)
			{
				return false;
			}
			if(wToModulus < __rhs.wToModulus)
			{
				return true;
			}
			else if(__rhs.wToModulus < wToModulus)
			{
				return false;
			}
			if(oCompFactor < __rhs.oCompFactor)
			{
				return true;
			}
			else if(__rhs.oCompFactor < oCompFactor)
			{
				return false;
			}
			if(rollWearDynamic < __rhs.rollWearDynamic)
			{
				return true;
			}
			else if(__rhs.rollWearDynamic < rollWearDynamic)
			{
				return false;
			}
			if(rollThermalDynamic < __rhs.rollThermalDynamic)
			{
				return true;
			}
			else if(__rhs.rollThermalDynamic < rollThermalDynamic)
			{
				return false;
			}
			if(rollGapLearn < __rhs.rollGapLearn)
			{
				return true;
			}
			else if(__rhs.rollGapLearn < rollGapLearn)
			{
				return false;
			}
			return false;
		}

		bool operator!=(const RollGapStoreDataFourHi& __rhs) const
		{
			return !operator==(__rhs);
		}
		bool operator<=(const RollGapStoreDataFourHi& __rhs) const
		{
			return operator<(__rhs) || operator==(__rhs);
		}
		bool operator>(const RollGapStoreDataFourHi& __rhs) const
		{
			return !operator<(__rhs) && !operator==(__rhs);
		}
		bool operator>=(const RollGapStoreDataFourHi& __rhs) const
		{
			return !operator<(__rhs);
		}


	};

/**
 *  Store data structure for two-roll stand
 *  �����������ڲ����ݴ����ṹ��
 **/
struct RollGapStoreDataTwoHi
{
    string stdId;                         //���ܱ�ʶ��"R1"
    RollInfoTwoHi rInfoTwoHi;             //����������Ϣ
    RollAuxInfoTwoHi rAuxInfoTwoHi;       //����������Ϣ
    float  millModulus;                   //�����ն�    ����λ��mm/kN��
    float  rollBarrelLength;              //�������������ȣ���λ��mm��
    float  wearBasicData;                 //k1��Ϊ��λ�����ϵ������������Ƴ��ȶ�ĥ���Ӱ��������λ��1/kN��
    float rollWearDynamic;                //����ĥ��������λ��mm��
    float rollGapLearn;                   //����ѧϰ����������λ��mm��

    bool operator==(const RollGapStoreDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(stdId != __rhs.stdId)
        {
            return false;
        }
        if(rInfoTwoHi != __rhs.rInfoTwoHi)
        {
            return false;
        }
        if(rAuxInfoTwoHi != __rhs.rAuxInfoTwoHi)
        {
            return false;
        }
        if(millModulus != __rhs.millModulus)
        {
            return false;
        }
        if(rollBarrelLength != __rhs.rollBarrelLength)
        {
            return false;
        }
        if(wearBasicData != __rhs.wearBasicData)
        {
            return false;
        }
        if(rollWearDynamic != __rhs.rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn != __rhs.rollGapLearn)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollGapStoreDataTwoHi& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(stdId < __rhs.stdId)
        {
            return true;
        }
        else if(__rhs.stdId < stdId)
        {
            return false;
        }
        if(rInfoTwoHi < __rhs.rInfoTwoHi)
        {
            return true;
        }
        else if(__rhs.rInfoTwoHi < rInfoTwoHi)
        {
            return false;
        }
        if(rAuxInfoTwoHi < __rhs.rAuxInfoTwoHi)
        {
            return true;
        }
        else if(__rhs.rAuxInfoTwoHi < rAuxInfoTwoHi)
        {
            return false;
        }
        if(millModulus < __rhs.millModulus)
        {
            return true;
        }
        else if(__rhs.millModulus < millModulus)
        {
            return false;
        }
        if(rollBarrelLength < __rhs.rollBarrelLength)
        {
            return true;
        }
        else if(__rhs.rollBarrelLength < rollBarrelLength)
        {
            return false;
        }
        if(wearBasicData < __rhs.wearBasicData)
        {
            return true;
        }
        else if(__rhs.wearBasicData < wearBasicData)
        {
            return false;
        }
        if(rollWearDynamic < __rhs.rollWearDynamic)
        {
            return true;
        }
        else if(__rhs.rollWearDynamic < rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn < __rhs.rollGapLearn)
        {
            return true;
        }
        else if(__rhs.rollGapLearn < rollGapLearn)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollGapStoreDataTwoHi& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollGapStoreDataTwoHi& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollGapStoreDataTwoHi& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollGapStoreDataTwoHi& __rhs) const
    {
        return !operator<(__rhs);
    }


};

/**
 *  Store data structure for edger-roll stand
 *  �����������ڲ����ݴ����ṹ��
 **/
struct RollGapStoreDataEdger
{
    string stdId;                         //���ܱ�ʶ��"E2","F1E"
    RollInfoEdger rInfoEdger;             //����������Ϣ
    RollAuxInfoEdger rAuxInfoEdger;       //����������Ϣ
    float  millModulus;                   //�����ն�    ����λ��mm/kN��
    float  rollBarrelLength;              //�������������ȣ���λ��mm��
    float  wearBasicData;                 // k1��Ϊ��λ�����ϵ������������Ƴ��ȶ�ĥ���Ӱ��������λ��1/kN��
    float rollWearDynamic;                //����ĥ��������λ��mm��
    float rollGapLearn;                   //����ѧϰ����������λ��mm��

    bool operator==(const RollGapStoreDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return true;
        }
        if(stdId != __rhs.stdId)
        {
            return false;
        }
        if(rInfoEdger != __rhs.rInfoEdger)
        {
            return false;
        }
        if(rAuxInfoEdger != __rhs.rAuxInfoEdger)
        {
            return false;
        }
        if(millModulus != __rhs.millModulus)
        {
            return false;
        }
        if(rollBarrelLength != __rhs.rollBarrelLength)
        {
            return false;
        }
        if(wearBasicData != __rhs.wearBasicData)
        {
            return false;
        }
        if(rollWearDynamic != __rhs.rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn != __rhs.rollGapLearn)
        {
            return false;
        }
        return true;
    }

    bool operator<(const RollGapStoreDataEdger& __rhs) const
    {
        if(this == &__rhs)
        {
            return false;
        }
        if(stdId < __rhs.stdId)
        {
            return true;
        }
        else if(__rhs.stdId < stdId)
        {
            return false;
        }
        if(rInfoEdger < __rhs.rInfoEdger)
        {
            return true;
        }
        else if(__rhs.rInfoEdger < rInfoEdger)
        {
            return false;
        }
        if(rAuxInfoEdger < __rhs.rAuxInfoEdger)
        {
            return true;
        }
        else if(__rhs.rAuxInfoEdger < rAuxInfoEdger)
        {
            return false;
        }
        if(millModulus < __rhs.millModulus)
        {
            return true;
        }
        else if(__rhs.millModulus < millModulus)
        {
            return false;
        }
        if(rollBarrelLength < __rhs.rollBarrelLength)
        {
            return true;
        }
        else if(__rhs.rollBarrelLength < rollBarrelLength)
        {
            return false;
        }
        if(wearBasicData < __rhs.wearBasicData)
        {
            return true;
        }
        else if(__rhs.wearBasicData < wearBasicData)
        {
            return false;
        }
        if(rollWearDynamic < __rhs.rollWearDynamic)
        {
            return true;
        }
        else if(__rhs.rollWearDynamic < rollWearDynamic)
        {
            return false;
        }
        if(rollGapLearn < __rhs.rollGapLearn)
        {
            return true;
        }
        else if(__rhs.rollGapLearn < rollGapLearn)
        {
            return false;
        }
        return false;
    }

    bool operator!=(const RollGapStoreDataEdger& __rhs) const
    {
        return !operator==(__rhs);
    }
    bool operator<=(const RollGapStoreDataEdger& __rhs) const
    {
        return operator<(__rhs) || operator==(__rhs);
    }
    bool operator>(const RollGapStoreDataEdger& __rhs) const
    {
        return !operator<(__rhs) && !operator==(__rhs);
    }
    bool operator>=(const RollGapStoreDataEdger& __rhs) const
    {
        return !operator<(__rhs);
    }


};

}

#endif
