// cMatl_Code	��̼��/ ���ַ���                                                                      
//   1	0.0005 - 0.045	��̼��                                                                      
//   2	.046-.075	��̼��                                                                            
//   3	.076-.10	��̼��                                                                            
//   4	.101-.135	��̼��                                                                            
//   5	.136-.165	��̼��                                                                            
//   6	.166-.200	��̼��                                                                            
//   7	.201-.245	��̼��                                                                            
//   8	.246-.300	��̼��                                                                            
//   9	.301-.35	��̼��                                                                            
//   10	.36-.40	��̼��                                                                              
//   11	.41-.520	��̼��                                                                            
//   12	.521-.605	��̼��                                                                            
//   13	.606-.690	��̼��                                                                            
//   14	.691-.770	��̼��                                                                            
//   15	.771	��̼��                                                                                
//   16	̼����<50ppm��Nb��Ti��ǿ�ĸ��֣�Nb>0.0%��Ti>0.0%	Ultra Low Carbon/IF                       
//   17	0.2<̼������0.5�� Nb��0.015% �� ��0.03�� Ti>=0.04%	1880 �ͺϽ��                           
//   18	����Cu + Cr + Ni + Mo + P���� 1.0%	�Ͻ��                                                  
//   19	Mn>1.5%	1880 ���̸�High Mn                                                                  
//   20	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�(˫��) DP             
//   21	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�(��������) MP         
//   22	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�TRIP                  
//   23	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�CP                    
//   24	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	�����׸֣�F��B��              
//   25	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�                      
//   26	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�                      
//   27	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�                      
//   28	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�                      
//   29	�����տ�������ߴ���ǿ�ȵĸ��֣���DP��TRIP����������ȴ�ĸ���	��ǿ�ȸ�                      
//   30	��H75xy��z	NSGO1                                                                           
//   31	��H76xy��z	NSGO2                                                                           
//   32	��H77xy��z	NSGO3                                                                           
//   33	��H78 xy��z	NSGO4                                                                           
//   34		NSGO5 (Ԥ��)                                                                              
//   35		NSGO6 (Ԥ��)                                                                              
//   36		NSGO7 (Ԥ��)                                                                              
//   37		NSGO8 (Ԥ��)                                                                              
//   38		NSGO9(Ԥ��)                                                                               
//   39		NSGO10(Ԥ��)                                                                              
//   40		NSGO11(Ԥ��)                                                                              
//   41		NSGO12(Ԥ��)                                                                              
//   42		NSGO13(Ԥ��)                                                                              
//   43		NSGO14(Ԥ��)                                                                              
//   44		NSGO15(Ԥ��)                                                                              
//   45		NSGO16(Ԥ��)                                                                              
//   46	��H85 xy��z	SGO1                                                                            
//   47	��H86 xy��z	SGO2                                                                            
//   48	��H87 xy��z	SGO3                                                                            
//   49	��H88 xy��z	SGO4                                                                            
//   50		SGO5(Ԥ��)                                                                                
//   51		SGO6(Ԥ��)                                                                                
//   52		SGO7(Ԥ��)                                                                                
//   53		SGO8(Ԥ��)                                                                                
//   54	��H95 xy��z	CGO1                                                                            
//   55	��H96 xy��z	CGO2                                                                            
//   56	��H97 xy��z	CGO3                                                                            
//   57	��H98 xy��z	CGO4                                                                            
//   58		CGO5 (Ԥ��)                                                                               
//   59		CGO6 (Ԥ��)                                                                               
//   60		CGO7 (Ԥ��)                                                                               
//   61	AW9122Q1	CGO8 (Ԥ��)                                                                       
//   62	��W91 xy��z	�е��ƺ�                                                                        
//   63	��W92 xy��z	�е��ƺ�                                                                        
//   64	��W93 xy��z	�е��ƺ�                                                                        
//   65	��W94 xy��z	�е��ƺ�                                                                        
//   66	��W95 xy��z	�е��ƺ�                                                                        
//   67		�е��ƺ�(Ԥ��)                                                                            
//   68		�е��ƺ�(Ԥ��)                                                                            
//   69	��W96 xy��z	���ƺ�                                                                          
//   70	��W97 xy��z	���ƺ�                                                                          
//   71	��W98 xy��z	���ƺ�                                                                          
//   72	��W99 xy��z	���ƺ�                                                                          
//   73		���ƺ�                                                                                    
//   74		���ƺ�                                                                                    
//   75		���ƺ�                                                                                    
//   76		���ƺ�(Ԥ��)                                                                              
//   77		���ƺ�(Ԥ��)                                                                              
//   78		���ƺ�(Ԥ��)                                                                              
//   79		���ƺ�(Ԥ��)                                                                              
//   80		���ƺ�(Ԥ��)                                                                              
//   81		���ƺ�(Ԥ��)                                                                              
//   82	��W9* xy��z	��Ч                                                                            
//   83	��W9* xy��z	��Ч                                                                            
//   84		��Ч(Ԥ��)                                                                                
//   85		��Ч(Ԥ��)                                                                                
//   86		��Ч(Ԥ��)                                                                                
//   87		��Ч(Ԥ��)                                                                                
//   88		��Ч(Ԥ��)                                                                                
//   89		��Ч(Ԥ��)                                                                                
//   90		��Ч(Ԥ��)                                                                                
//   91		��Ч(Ԥ��)                                                                                
//   92		��Ч(Ԥ��)                                                                                
//   93		��Ч(Ԥ��)    
#ifndef FM_MATL_H
#define FM_MATL_H
 

#pragma once

#include <iostream>
#include <map>
#include <cmath>
#include <string>

#define Physcon_abstmp_k 273;
#define Physcon_tol4 0.0001

#define MATL_LIST     T(matl_undef), T(matl_steel), T(matl_roll), T(matl_water)


namespace FM
{
class cMatl
{
public:
#define T(x) x
	enum matlEnum  { MATL_LIST };
#undef  T
  

public:
	float  x_tmp_start;   
    float  x_tmp_end;     
    float  x_const1;      
    float  x_const2;      

	cMatl():
	 x_tmp_start(800),
     x_tmp_end(700),
     x_const1 (10),
     x_const2 (10)
	 {}
	~cMatl(void);
    //-----------------------------------------------------------------------
    // limitChecked ABSTRACT:
    //     The input temperature is limit checked.  If the temperature is
    //     unreasonable, it is clamped and alarmed.
    //-----------------------------------------------------------------------
    float limitChecked(float matl_temp);   //  material temperature [C]
  
    //-----------------------------------------------------------------------
    // Check_Matl_Code ABSTRACT:
    //  Check the material code.  Returns true if the material code is valid
    //  for the given material classification.  Returns false if either the
    //  classification or code is invalid.
    //-----------------------------------------------------------------------
    bool    Check_Matl_Code (
        const matlEnum matl_class,  //  material classification (steel, rollmatl)
        const int      matl_code);  //  material code [-]

//-----------------------------------------------------------------------
// Check_Matl_Classification ABSTRACT:
//  Check the material enumeration.  Return true if the enumeration is
//  valid.
//-----------------------------------------------------------------------
bool    Check_Matl_Classification ( cMatl::matlEnum matl_class );


    //-----------------------------------------------------------------------
    // MATLCONDUCT ABSTRACT:
    //     The conductivity is determined by interpolating on a set of data
    //     points for a given material classification and code at the given
    //     temperature.  All calculations are done in metric and converted to
    //     the proper units for the units system being used.
    //-----------------------------------------------------------------------
    float Conductivity (
        const matlEnum matl_class,  //  material classification (steel,rollmatl )
        const int      matl_code,   //  material code [-]
        const float    matl_temp ); //  material temperature [C, F or C]

  
    //-----------------------------------------------------------------------
    // MATLEMISS ABSTRACT:
    //     The algorithm for the emissivity of steel is based upon a paper by
    //     Seredynski, J., Journal of The Iron and Steel Institute,
    //     March 1973, pp.197-203.
    //     The emissivity for rolls is determined by interpolating
    //     on a set of data points for the given material classification and
    //     code at the given temperature.  All calculations are done in metric
    //     and converted to the proper units for the units system being used.
	//     Emissivity is dimensionless.
    //-----------------------------------------------------------------------
    float Emissivity (
        const matlEnum matl_class,  //  material classification (steel,rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp);  //  material temperature [C, F or C]


    //-----------------------------------------------------------------------
    // MATLEXPAN ABSTRACT:
    //     The total expansion is determined by interpolating on a set of data
    //     points for a given material classification and code at the given
    //     temperature.  All calculations are done in metric and converted to
    //     the proper units for the units system being used.
    //-----------------------------------------------------------------------
    float Expansion (
        const matlEnum matl_class,  //  material classification (steel,rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp ); //  material temperature [C, F or C]
	//-----------------------------------------------------------------------
    // MATLFAM ABSTRACT:
    //     This function returns a material family code that is used for
    //     reading and writing model tables.  This code is a mapping of many
    //     matl_code  's to fewer family codes.
    //-----------------------------------------------------------------------
    int Steel_Family (
        const matlEnum matl_class,  //  material classification (steel,)
        const int      matl_code ); //  material code [-]


    //-----------------------------------------------------------------------
    // MATLSPECHEAT ABSTRACT:
    //     The specific heat is determined by interpolating on a set of data
    //     points for a given material classification and code at the given
    //     temperature.  Because the magnitude of the specific heat value is
    //     not different between English and metric calculations for the same
    //     temperature, (1 btu/lb/deg F = 1 kcal/kg/deg C) all specific heat
    //     curves and calculations are done in metric.
    //-----------------------------------------------------------------------
    float Specific_Heat (
        const matlEnum matl_class,  //  material classification (steel,or rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp);  //  material temperature [C, F or C]

	//This is for vector return testing
	float Specific_Heat1 (
        const matlEnum matl_class,  //  material classification (steel,or rollmatl)
        const int      matl_code);  //  material temperature [C, F or C]



    //-----------------------------------------------------------------------
    // Form of Specific Heat requiring ferrite fraction as an input
    //-----------------------------------------------------------------------
    float Specific_Heat (
        const matlEnum matl_class,  //  material classification (steel,rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp,   //  material temperature [C, F or C]
        const float    fer_fract ); //  fraction of ferrite formed [-]

    //-----------------------------------------------------------------------
    // MATLDENS ABSTRACT:
    //     The density is determined by taking the cold density (ambient) and
    //     dividing it by the cube of the total material expansion for a given
    //     material classification and code at the given temperature.
    //-----------------------------------------------------------------------
    float Density (
        const matlEnum matl_class,  //  material classification (steel,or rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp ); //  material temperature [C, F or C]
                                    //       kg/mm**3
	                                //       lb/in**3
	                                //       kg/m**3      SI


    //-----------------------------------------------------------------------
    // MATLDIFFUS ABSTRACT:
    //     Diffusivity is defined as:
    //                                         thermal conductivity
    //                                        ---------------------
    //                                        density * specific heat
    // 
    //    Therefore, diffusivity will be calculated by calling the thermal
    //    conductivity, density and specific heat functions and then performing
    //    the above calculation.
	//
	//    The units for diffusivity are         Volume  *  Minor_Length
	//                                          -----------------------
	//                                            Area  *  seconds
	//
	//                      in**3  *  in
	//    English           -------------  =   in**2/sec
	//                      in**2  * sec
	//
	//
	//                      mm**3  *  mm
	//    Metric            -------------  =    mm**2/sec
	//                      mm**2  *  sec
	//
	//                      m**3 * mm
	//    SI                -------------        SI does not simplify
	//                      mm**2  * sec
	//
    //-----------------------------------------------------------------------
    float Diffusivity (
        const matlEnum matl_class,  //  material classification (steel,or rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp ); //  material temperature [C, F or C]

    //-----------------------------------------------------------------------
    // Form of Diffusivity requiring ferrite fraction as an input
    //-----------------------------------------------------------------------
    float Diffusivity (
        const matlEnum matl_class,  //  material classification (steel,or rollmatl)
        const int      matl_code,   //  material code [-]
        const float    matl_temp,   //  material temperature [C, F or C]
        const float    fer_fract ); //  fraction of ferrite formed [-]

  	//-----------------------------------------------------------------------
    // MATLKINVISC ABSTRACT:
    //     The Kinematic Viscosity is determined by interpolating on a set of data
    //     points for a given material classification and code at the given
    //     temperature.  All calculations are done in metric and converted to
    //     the proper units for the units system being used.
	//     This function works only for  matl_class == matl_water
	//     Returns zero otherwise.
    //-----------------------------------------------------------------------
    float KinVisc (
        const matlEnum matl_class,  //  material classification (water)
        const int      matl_code,   //  material code [-]
        const float    matl_temp ); //  material temperature [C, F or C]
                                    // returns [mm2/s_in2/s_mm2/s]

    //-----------------------------------------------------------------------
    // FERRITE FRACTION ABSTRACT:
    //     This function returns the fraction of ferrite formed at the given
    //     average material temperature.
    //-----------------------------------------------------------------------
    float Ferrite_Fraction (
        const matlEnum  matl_class,   //  material classification (steel,or rollmatl)
        const float     matl_temp,
		const int      matl_code);  //  average material temp [C_F]

    //-----------------------------------------------------------------------
    // LATENT HEAT ABSTRACT:
    //     This function calculates the latent heat of transformtaion of
    //     iron.  This quantity is defined as the difference between the
    //     total enthalpy of austenitic iron and the total enthalpy of
    //     ferritic iron at any given material temperature.  
    //-----------------------------------------------------------------------
    float Latent_Heat (
        const float    matl_temp ); //  material temperature [C, F or C]
                                    //       [kcal/kg or
                                    //        btu/lb or
                                    //        joules/kg]
                                    // returns [mm2/s_in2/s_mm2/s]

 
    //-----------------------------------------------------------------------
    // POISSON ABSTRACT:
    //     The Poisson Ratio is determined by interpolating on a set of data
    //     points for a given material classification and code.  This value
    //     has no units.
    //-----------------------------------------------------------------------
    float Poisson (
        const matlEnum matl_class,  //  material classification (steel,rollmatl)
        const int      matl_code ); //  material code [-]
 
   //interpolation 
    float   interpolation (float *x, float *xa, float *ya, int *n);
    
    
    //calc steel family code by chemical 
    
    int SteelFamilyCode(    float C  ,  //̼
                            float Mn ,  //��
                            float Si ,  //��
                            float Cr ,  //��
                            float V  ,  //��
                            float Nb ,  //��
                            float Mo ,  //��
                            float Ti ,  //��
                            float Cu ,  //ͭ 
                            float Ni ,  //��  
                            float P  ,  //��
                            float &CEQ,  //̼����
                            const ::std::string& steel_category, //���ִ���
                            const ::std::string& steel_grade, //�����ƺ�
                            int &sfc,
                            int &sfc01,
                            int &sfc02
                            
    );


    int SteelFamilyCodeXinYu(    float C  ,  //̼
                            float Mn ,  //��
                            float Si ,  //��
                            float Cr ,  //��
                            float V  ,  //��
                            float Nb ,  //��
                            float Mo ,  //��
                            float Ti ,  //��
                            float Cu ,  //ͭ 
                            float Ni ,  //��  
                            float P  ,  //��
                            float &CEQ,  //̼����
                            const ::std::string& steel_category, //���ִ���
                            const ::std::string& steel_grade, //�����ƺ�
                            int &sfc,
                            int &sfc01,
                            int &sfc02
                            
    );
	float Expansion(const float temp);
};


};
#endif