

//ͷ��β3�ε�����
struct KPointData
{
	//float len;			//����
	//bool  messdataflag; //ʵ��ֵ��־
	//MeasureData wid;	//����
	//MeasureData tmp;	//�¶�
	//MeasureData force;	//������
	vector<float>    temp;
	
}

class CKeyPoint
{
public:
	CKeyPoint();
	~CKeyPoint();
public:
	KPointData  pnts[3];
	KPointData  *pHead,*pMid,*pTail;

public:
	void Initial();
	void HeadTailConvert();


};

CKeyPoint::CKeyPoint()
{
	pHead=pMid=pTail=NULL;
}


void CKeyPoint::Initial()
{
	*pHead = pnts[0];
	*pMid  = pnts[1];
	*pTail = pnts[2];
}

void CKeyPoint::HeadTailConvert()
{
	*pHead = pnts[2];
	
	*pTail = pnts[0];
}
