//File Width.h Class
//Define Width Model Class
//Author: Zhang jinmin, For Meishan steel 1780 Hotmill , Copyright Baosteel,Co,ltd.
//version: 12.8 

//Author: Zhang jinmin, For Ningbao steel 1780 Hotmill , Copyright Baosteel,Co,ltd.
//version: 4.0  2014.5.22 

#ifndef _RMCWidth_Model_h_
#define _RMCWidth_Model_h_

#include <vector>
#include <math.h>
//#include <pace/pace.h>

using namespace std;

struct widthException 
{
	int code;
	char info[100];
};

namespace RMC
{

	//struct RMDraftData
	//{
	//	int   R1PassNum;          //R1 rolling pass
	//	int   R2PassNum;          //R2 rolling pass
	//	vector<float> eps;        //���ѹ����
	//	vector<int>   mode;       //������Ի�ģʽ��1��������Ի���0��������ֵ��������Ի�
	//	float EntryThick;         //
	//	vector<float> ExitThick;  //
	//	vector<float> DraftH;     // ��Ⱦ���ѹ����
	//};

	//struct RMLoadData
	//{
	//	int   R1PassNum;             //R1 rolling pass
	//	int   R2PassNum;			 //R2 rolling pass
	//	float EntryThick;
	//	vector<float> eps;			 //���ѹ����
	//	vector<int>   mode;			 //������Ի�ģʽ��1��������Ի���0��������ֵ��������Ի�
	//	vector<float> speed;
	//	vector<float> forceCal;      //����������
	//	vector<float> forceMax;
	//	vector<float> force2eps;     //�������������ѹ�����ĸжȣ�
	//	vector<float> powerCal;      //�������ƹ���
	//	vector<float> powerMax;      //�������ƹ���
	//	vector<float> ExitThick;
	//	vector<float> DraftH;        // ��Ⱦ���ѹ����
	//	vector<float> LoadWeight;
	//	float PowerLimitCof;
	//};


	struct SteelInfomation
	{
		//string StripNum;          //
		char StripNum[15];
		int SFC;
		int SFC01;
		int SFC02;
		int WidthClass;           //
		int FMThickClass;         //
		int RMRedClass;           //
		int StandNum;             //
		int PassNum;              //
		float coilwidthcontroll;
		float coilwidthcontrolu;
	};

	struct StripRollNum
	{
		int stripAccumNum;
		int stripLongAccumNum;
		int stripShortAccumNum;
	};

    //-----------Model parameter structure-----------
	struct RMDogBonePara				//DogBoneCal Parameter
	{
		float da;
		float db;
		float dc;
		float dd;
		float de;
		float EdgerTypeDogboneK;   //�������ζԹ��ǵ�Ӱ��
	};

	struct RMDogBoneParaAllPass				//DogBoneCal Parameter
	{
		vector<float> da;
		vector<float> db;
		vector<float> dc;
		vector<float> dd;
		vector<float> de;
		vector<float> EdgerTypeDogboneK;   //�������ζԹ��ǵ�Ӱ��
	};

	struct RMSpreadPara
	{
		float paraSa;
		float paraSb;
		float paraSc;
	};

	struct FMSpreadPara
	{
		float paraA0;
		float paraA1;
		float paraA2;
		float paraA3;
		float paraA4;
		float paraA5;
		float paraA6;
	};

	struct FmSpreadCalData
	{
		float FMWidth;   //cool
		float FM7Thick;
		float FM0Thick;
		float RollDiamF1;
		float RollDiamF2;
		float RollDiamF3;
		float RollDiamF4;
		float RollDiamF5;
		float RollDiamF6;
		float RollDiamF7;
		float RelReduF1;
		float RelReduF2;
		float RelReduF3;
		float RelReduF4;
		float RelReduF5;
		float RelReduF6;
		float RelReduF7;
		float RDTemp;
		float EntryTempF1;
		float EntryTempF2;
		float EntryTempF3;
		float EntryTempF4;
		float EntryTempF5;
		float EntryTempF6;
		float EntryTempF7;
		float FDTemp  ; 
		float EntrytensionF2;
		float EntrytensionF3;
		float EntrytensionF4;
		float EntrytensionF5;
		float EntrytensionF6;
		float EntrytensionF7;
		float CARBON;
		float SILICON;
		float MANGANESE;
		float COPPER;
		float NICKEL;
		float CHROMIUM;
		float VANADIUM;
		float TITANIUM;
		float NIOBIUM;
		float BORON;
		float MOLYBDENUM;
		float FMSPREAD;
		float FM_PROFILE;
	};

	//----------- Model calculation results structure------
	struct FMNSError
	{
		float E1;
		float E2;
		float E3;
		//float EE1;
		//float EE2;
		//float EE3;
	};

	struct FMSpreadData
	{
		float FMSpreadLong;
		float FMSpreadShort;
		float FMSpreadLongNew;
		float FMSpreadShortNew;
	//	float FMSpreadShort;
		float FMSpread;
	};



	struct RM3WTargetMod
	{
		float MarginTotalMod;  //��������
		float MarginHeadMod; 
		float MarginMiddleMod; 
		float MarginTailMod; 
		float RM3WHeadLengthMod;
		float RM3WTailLengthMod;
	};

	struct SteelIndexCode
	{
		int SFC;
		int WidthClass;
		int ThickClass;
		int TempClass;
	};

	//////struct RdwTargetData
	//////{
	//////	float E3dogSpread;
	//////	float E3ReduEffect;
	//////	FMSpreadData FmSpreadStuct;
	//////	float RdwTargetTotal;
	//////	float RdwTargetHead;
	//////	float RdwTargetTail;
	//////	float RdwTargetMiddle;
	//////	float RdwTargetTotalHot;
	//////	float RdwTargetHeadHot;
	//////	float RdwTargetTailHot;
	//////	float RdwTargetMiddleHot;
	//////	float RdwTargetHeadLength;
	//////	float RdwTargetHeadLengthHot;
	//////	float RdwTargetTailLength;
	//////	float RdwTargetTailLengthHot;
	//////};

	struct RdwTargetData
	{
		float E3dogSpread;
		float E3ReduEffect;
		FMSpreadData FmSpreadStuct;
		float RdwTargetTotal;
		float RdwTargetHead;
		float RdwTargetTail;
		float RdwTargetMiddle;
		float RdwTargetHeadLength;
		float RdwTargetTailLength;
	};

	struct FMWidthTargetData
	{
		float FMWidthTarget;
		float FMMargin;
		float Margin;
	};

	struct EdgerDraftData	   // RM EdgerDraft model calculation results output
	{
		float dogSpread;
		float natureSpread;
		float effectEDraft;
		float absRedu;
	};

	struct RMSpreadSeq	   // RM EdgerDraft model calculation results output
	{
		vector<float>R1Spread;
		vector<float>R2Spread;
		float RMSpreadSum;
	};

	struct RMWidthTargetSeq	   // RM EdgerDraft model calculation results output
	{
		vector<float>R1Target;
		vector<float>R2Target;
		vector<float>E1Draft;
		vector<float>E2Draft;
		vector<float> R1Temp;
		vector<float> R2Temp;
	};

	struct SscPoint
	{
		float position;
		float width;
	};

	struct SlabWidthData
	{
		vector<float> slabPos;
		vector<float> slabWidth;
	};

	struct TSlabWidthData
	{
		vector<float> slabPos;
		vector<float> slabWidth;
		float TSlabBegin;
		float TSlabEnd;
		float HeadWidth;
		float TailWidth;
	};

	struct SscSetPointData				// SSC control point sequence data
	{
		vector<SscPoint> head;
		vector<SscPoint> tail;
		float ExitWidthHead;
		float ExitWidthTail;
		float ExitWidth;
		float LengthHead;
		float LengthTail;
		float dWidthHead;
		float dWidthTail;
		float dWidthHead1;
		float dWidthTail1;
		float dWidthHead2;
		float dWidthTail2;
		float dWidthHead3;
		float dWidthTail3;
	};

	struct LongSscSetPointData
	{
		vector <SscPoint> middle;
		vector <float> SSEntryHeadWidth;	
		vector <float> SSHeadWidth;
		vector <float> SSHeadOffset;    //Position from head
		vector <float> SSHeadGap;
		vector <float> SSHeadEForce;

		vector <float> SSEntryTailWidth;
		vector <float> SSTailWidth;
		vector <float> SSTailOffset;     //Position from Tail
		vector <float> SSTailGap;
		vector <float> SSTailEForce;
	};

	struct SSCHeadTailCal  //SSC head and tail shape modle calcuation results	
	{
		float DWHead;
		float DWTail;
		float LWHead;
		float LWTail;
	};

	struct SSCParaData
	{
		float ParaA0;
		float ParaA1;
		float ParaA2;
		float ParaA3;
		float ParaA4;
		float ParaA5;

		float ParaB0;
		float ParaB1;
		float ParaB2;
		float ParaB3;
		float ParaB4;
		float ParaB5;

		float ParaC0;
		float ParaC1;
		float ParaC2;
		float ParaC3;
		float ParaC4;
		float ParaC5;

		float ParaD0;
		float ParaD1;
		float ParaD2;
		float ParaD3;
		float ParaD4;
		float ParaD5;

		float KWHead1;
		float KWHead2;
		float KWHead3;
		float KWTail1;
		float KWTail2;
		float KWTail3;
	
	};


	struct SSCModData
	{
		float LHMod;
		float LTMod;
		float dWHMod1;
		float dWHMod2;
		float dWHMod3;
		float dWTMod1;
		float dWTMod2;
		float dWTMod3;
	};

	//CNC control calculation data
	struct CncSetData
	{
		float StartPoint;
		float EndPoint;
		float WidthComp;
	};

	//-----------width Model Inherit structure----------
	struct RMSpreadInherData
	{
		float E1SpreadInher[3];
		float E1DogInher[2];
		float E2SpreadInher[7];		
		float E2DogInher[4];
	};

	struct DraftPara
	{
		vector <float> E1WidthDraftWeight;       //// = 1.2f, 1.08f
		vector <float> E2WidthDraftWeight;       ////  = 1.06f, 0.96f, 0.90f, 0.86f
	};

	//struct FMSpreadInherProcess
	//{
	//	float inherLong;
	//	float inherShort;
	//	float paraShort[5];
	//	float paraLong[5];
	//	float HkShort[5];
	//	float KkShort[5];
	//	float PkShort[5][5];
	//	float HkLong[5];
	//	float KkLong[5];
	//	float PkLong[5][5];
	//	float E3DogLong;
	//	float E3DogShort;
	//	float FMWError;
	//	int stripAccumNum;
	//	int stripLongAccumNum;
	//	int stripShortAccumNum;
	//};

	struct FMSpreadInherData
	{
		float inherLong;
		float inherShort;
		float inherLongNew;
		float inherShortNew;
		FMNSError NSError;
		StripRollNum stripAccumNum;
	};

	//		float paraShort[5];
	///		float paraLong[5];
		////float E3DogLong;
		////float E3DogShort;
		////int stripAccumNum;
		////int stripLongAccumNum;
		////int stripShortAccumNum;


	struct RdwMarginInherData
	{
		float MarginTotal;
		float MarginHead;
		float MarginMiddle;
		float MarginTail;
	};

	struct SSCInherData
	{
		float LHInher;
		float LTInher;
		float dWHInher;
		float dWTInher;
	};

	struct CncInherData
	{
		float CncStartInher;
		float CncLengthInher;
		float CncWidthInher;
	};
	
	struct RMwidthGlobalData
	{
		float RdwGlobalInherTotal;
		float RdwGlobalInherHead;
		float RdwGlobalInherMiddle;
		float RdwGlobalInherTail;
	};

	struct DCWidthInherData
	{
		vector <float>  DCWHeadInher;
		vector <float>  DCWTailInher;
	};

	struct DataStatistcis
	{
		int DataInputNum;
		int DataOutputNum;
		float Mean;
		float Confid;
		float Std;
		float Max;
		float Min;
		vector<float> Data;
	};
/////////////////////////////////////////////////////////////////////////
	//width model class define
	class WidthModel
	{
		widthException errinfo;
	private:
		RMSpreadPara paraSA;
		vector<float> RMSpreadPara0;
		vector<float> RMSpreadPara1;
		vector<float> RMSpreadPara2;
		vector<float> RMSpreadPara3;
		vector<float> RMSpreadPara4;
		vector<float> RMSpreadPara5;
		vector<float> RMSpreadPara6;
		vector<float> RMSpreadPara7;
		vector<float> RMSpreadPara8;
		vector<float> RMSpreadPara9;
		vector<float> RMSpreadPara10;
		vector<float> RMSpreadPara11;
		vector<float> RMSpreadPara12;
		vector<float> RMSpreadPara13;
		vector<float> RMSpreadPara14;
		vector<float> RMSpreadPara15;
		vector<float> RMSpreadPara16;
		vector<float> RMSpreadPara17;
		vector<float> RMSpreadPara18;
		vector<float> RMSpreadPara19;
		vector<float> RMSpreadPara20;

		vector<float> RMSpreadCalGain;  ////= 1.0f

	/////////modle Gain
	    float BklLmitCalGain       	;  ////= 1.0f
		float FmSpreadCalGain    	;  ////= 1.0f
		float DogBoneCalGain        ;  ////= 1.0f
		float RMSpreadCalzhiyuanGain;  ////= 1.0f
		float EdgerDraftGain        ;  ////= 1.0f
		float SscSetupCalGain       ;  ////= 1.0f
		float RdwTargetCalGain      ;  ////= 1.0f
		float NeckCompCalGain       ;  ////= 1.0f
		float FurFeedForwardCalGain ;  ////= 1.0f
		float TSlabControlGain      ;  ////= 1.0f    
		float RM3TargetControlGain  ;  ////= 1.0f
		float WidthAssignDraftGain   ;  ////= 1.0f
		int   WidthAssignDraftMod    ;
		int   LastE2DarftTargetOn   ;
		float LastE2DarftAssignMin   ;
		float LastE2DarftAssignMax   ;
		int DogBoneCalLogOn;
		float LastE2DarftTarget;

		int   HeatValueUse;							   
		float RMWidthInherCalGain   ;  ////= 1.0f
		float RdwGlobalInherCalGain ;  ////= 1.0f
		float FMSpreadInherCalGain  ;  ////= 1.0f
		float SSCInherCalGain       ;  ////= 1.0f
		float RdwTargetInherCalGain ;  ////= 1.0f
		float CNCInherCalGain       ;  ////= 1.0f

		float FmSpreadCalMod        ;  //Constant value
		vector<int>   FmSpreadCalIndex      ;     
		vector<float> FmSpreadCalModClass   ;

		vector<int>   DogBoneCalGainIndex   ;  
		vector<float> DogBoneCalGainClass   ;
		vector<int>   DogBoneRedGainIndex   ;  
		vector<float> DogBoneRedGainClass   ;

		float DogRecoveryMaxE1 ;
		float DogRecoveryMaxE2 ;
		float DogRecoveryMaxE3 ;
		float FMSpreadE3CalOn;


		float E3DogBoneCalGain;

        int FME1Use;

		//Log using 
		int BklLmitCalLogOn;
		int FmSpreadCalLogOn;
		int RMSpreadCalLogOn;
		int RMSpreadCalzhiyuanLogOn;
		int EdgerDraftLogOn;
		int SscSetupCalLogOn;

		int PreSscDataLogOn;		
		int StandSpreadCalLogOn;
		int SscSetupCalHeadTailLogOn;
		int WidthAssignDraftLogOn;
		int RMDCWidthControlLogOn;

		int RdwTargetCalLogOn;
		int NeckCompCalLogOn;
		int FurFeedForwardCalLogOn;
		int TSlabControlLogOn;
		int RM3TargetControlLogOn;

		int DCWidthControlUse;
		int RM3TargetControlUse;
		int E2LastSCCUse;

		int RMWidthInherUse   ;  
		int FMSpreadInherUse   ; 
		int SSCInherUse         ;
		int CNCInherUse	      	;
		int WidthGlobalInherUse ;
		int MarginInherUse      ;
		int DCWidthInherCalUse;



		/////SCC model
		float SscSetPointLimitMaxE1;
		float SscSetPointLimitMinE1;
		float SscSetPointLimitMaxE2;
		float SscSetPointLimitMinE2;
		float SscSetPointLimitMaxE3;
		float SscSetPointLimitMinE3;
		float SscdWModMax;
		float SscdWModMin;

		vector<float>SscHeadCurve1;
		vector<float>SscTailCurve1;

		vector<float>SscHeadCurve2;
		vector<float>SscTailCurve2;

		vector<float>SscHeadCurve3;
		vector<float>SscTailCurve3;

		vector<float>SscHeadCurve4;
		vector<float>SscTailCurve4;

		vector<float>SscHeadCurve5;
		vector<float>SscTailCurve5;

		vector<float>SscHeadCurve6;
		vector<float>SscTailCurve6;

		vector<float>SscHeadCurve7;
		vector<float>SscTailCurve7;

		vector<float>SscHeadCurve8;
		vector<float>SscTailCurve8;

		vector<float>SscHeadCurve9;
		vector<float>SscTailCurve9;

		vector<float>SscHeadCurve10;
		vector<float>SscTailCurve10;

		vector<float>SSCPosCof;    //SSC positon cof

		//// ���г�ͷ���������
		vector<float>SCCHeadGainPass1;
		vector<float>SCCHeadGainPass2;
		vector<float>SCCHeadGainPass3;
		vector<float>SCCHeadGainPass4;
		vector<float>SCCHeadGainPass5;


		float SmallHeadLength;
		float SmallTailLength;
		float E1Pass1SmallHeadTailGain;
		float E1Pass2SmallHeadTailGain;
		float E2Pass1SmallHeadTailGain;
		float E2Pass2SmallHeadTailGain;


		//FM Spread Config parameter
		float FMSShortModelSelect;    //two short model selection parameter
		float FMSpreadShortLimit;      //the Limit value  of short model2 base on short model1
		int FMS_LS_USEBARNUM;   //The FMS LS method using condition
		float FmSpreadMin;  //������Ȼ��չ��Сֵ
		float FmSpreadMax;  //������Ȼ��չ���ֵ
		vector<float> FMNSPara;
		vector<float> FMNSPara1;
		vector<float> FMNSPara2;
		vector<float> FMNSPara3;
		vector<float> FMNSPara4;
		vector<float> FMNSPara5;
		vector<float> FMNSPara6;
		vector<float> FMNSPara7;
		vector<float> FMNSPara8;
		vector<float> FMNSPara9;
		vector<float> FMNSPara10;
		vector<float> FMNSPara11;
		vector<float> FMNSPara12;
		vector<float> FMNSPara13;
		vector<float> FMNSPara14;
		vector<float> FMNSPara15;
		vector<float> FMNSPara16;
		vector<float> FMNSPara17;
		vector<float> FMNSPara18;
		vector<float> FMNSPara19;
		vector<float> FMNSPara20;

		float HeatValueadjust;
		//WidthAssignDraft
		int WidthDraftIterativeNum;
		vector<float> E1WidthDraftWeight;
		vector<float> E2WidthDraftWeight;
		float WidthDraftWeightPara1;
		float WidthDraftWeightPara2;


		///RMSpreadCal Config parameter
		float E1MaxRedu;
		float E2MaxRedu;
		float E3MaxRedu;
		float E1MinOutWidth;
		float E2MinOutWidth;


		///////CncSetData WidthModel::NeckCompCal
		float CncK;
		float CncWidthMax;
		float CncWidthMin;
		////RDW����Ŀ���������

		vector<float> DCInherPosition;
		float DCWInherMax ;
		float DCWInherMin ;

		float RDWMarginBase;
		float widthTolGain;

		vector<float> ConfDcLen;
  ///--------read config file test variable-------------

////----------------------------------------------------
	public:
		////roll mill equipment parameter
		float FMDCDistance ;   
		float FMSTANDDistance ;	
		float CoilDistance;

		//���ɷ��������ļ�
		float PowerLimitCof;
		//Width�๹�캯��


		WidthModel();

		//Width�����������
		~WidthModel();

		void ReadWidthConfig();

		float BklLmitCal(float EntryWidth,
						 float EntryThick,
						 float& RelRedu);

		FMSpreadData FmSpreadCal(int Calmode,SteelInfomation SteelInfo,
						 float FmDelThick,
						 float FmDelWidth, 
						 float FmTalDraft, 
						 float FDTemp,
						 float RDTemp,
						// float FMWError,
						 SteelIndexCode CodeOld,
						 SteelIndexCode CodeNew,
						 const FMSpreadPara paraL, 
						 const FMSpreadInherData paraInher,
						 int FMDelay,
						 StripRollNum stripAccumNum,
						 FMSpreadData& fmSpread);


		FMSpreadData WidthModel::FmSpreadCalNew(int Calmode,SteelInfomation SteelInfo,
			FmSpreadCalData FmData,
			float FmDelThick,
			float FmDelWidth, 
			float FmTalDraft, 
			float FDTemp,
			float RDTemp,
		//	float FMWError,
			SteelIndexCode CodeOld,       ////ָ��������Ŵ��Ĵ���
			SteelIndexCode CodeNew,      ////ָ������ô���
			const FMSpreadPara paraL,
			const FMSpreadInherData paraInher,
			int FMDelay,
			int& NewModelOK,
			StripRollNum stripAccumNum,
			FMSpreadData& fmSpread);

		float DogBoneCal(int Calmode,SteelInfomation SteelInfo,
						 float EntryThick,
						 float EntryWidth,
						 float EDraft,
						 float EDiam,
						 const RMDogBonePara para,
						 float DogBoneInher,
						 float& effectEDraft);

		float RMSpreadCal(int Calmode,SteelInfomation SteelInfo,
						  float EntryThick,
						  float EntryWidth,
						  float RDraft,
						  float Temp,
						  float RDiam,
						  float RSpreadInher);

		float RMSpreadCalzhiyuan(int Calmode,SteelInfomation SteelInfo,
							float EntryThick,
							float EntryWidth,
							float RDraft,
							float Temp,
							float RDiam,
							float RSpreadInher);

		EdgerDraftData WidthModel::EdgerDraft(int Calmode,SteelInfomation SteelInfo,
			int StandNum,
			float EntryWidth,    
			float EntryThick,
			float StandWidthTarget,
			float Temp,
			float EDiam,
			float RDraft,
			float RDiam,
			float RSpreadInher,
			float DogBoneInher,
			float EdgePassMaxWidthRedu,
			const RMDogBonePara& para);

		void RdwTargetCal(int Calmode,SteelInfomation SteelInfo,                                   //Calmode=1, Precalculation,  Calmode=0, Postcalculation;
			float	FmDelThick, 
			float	FmDelWidth,
			float	FmTalDraft,
			float   FDTemp,
			float   RDTemp,
			float   FMSpreadErrLast,
			SteelIndexCode CodeOld,
			SteelIndexCode CodeNew,
			const FMSpreadPara paraL, 
			const FMSpreadInherData paraInher,
			FMSpreadData& fmSpread,
			RM3WTargetMod  WidMod,
			float	FEDiam,
			int		E3UseMode,
			float	E3Draft,
			float   E3DogBoneInher,
			const  RMDogBonePara dogPara,
			RdwMarginInherData Margin,
			int FMDelay,
			RMwidthGlobalData GlobalInher,
			StripRollNum stripAccumNum,
			RdwTargetData& rdwTarget);

		void WidthModel::RdwTargetCalNew(int Calmode,SteelInfomation SteelInfo,
			FmSpreadCalData FmData,
			float FmDelThick, 
			float FmDelWidth,
			float FmTalDraft,
			float FDTemp,
			float RDTemp,
			float FMSpreadErrLast,
			SteelIndexCode CodeOld,
			SteelIndexCode CodeNew,
			const FMSpreadPara paraL, 
			const FMSpreadInherData paraInher,
			FMSpreadData& fmSpread,
			RM3WTargetMod  WidMod,
			float FEDiam,
			int	 E3UseMode,
			float  E3Draft,
			float   E3DogBoneInher,
			const RMDogBonePara dogPara,
			RdwMarginInherData Margin,   //Include MarginHead, tail ,middle, and total margin
			int FMDelay,
			RMwidthGlobalData GlobalInher,
			StripRollNum stripAccumNum,
			RdwTargetData& rdwTarget) ;


		RMSpreadSeq StandSpreadCal(int Calmode,SteelInfomation SteelInfo,
							 float EntryThick,
							 float EntryWidth,
							 vector<float> R1Temp,
							 vector<float> R2Temp,
							 vector<float> R1Expandcoff,							 
							 vector<float> R2Expandcoff,
			                 vector<float> R1ReduSeq,
							 float R1Diam,
							 vector<float> R2ReduSeq,
							 float R2Diam,
							 vector<float> R1SpreadInher,
							 vector<float> R2SpreadInher,
							 RMSpreadSeq& RSpread );
	
		////RMWidthTargetSeq  WidthAssign(int Calmode,SteelInfomation SteelInfo,
		////					float EntryThick,
		////					float EntryWidth,
		////					float Temp,
		////					vector<float> R1ReduSeq,
		////					float R1Diam,
		////					vector<float> R2ReduSeq,
		////					float R2Diam,
		////					vector<float> R1SpreadInher,
		////					vector<float> R2SpreadInher,
		////					RMSpreadSeq& RSpread,  
		////					float RMWidthTarget,
		////	                RMWidthTargetSeq  WidthTargetSeq   );

		RMWidthTargetSeq WidthAssignDraft(int Calmode,SteelInfomation SteelInfo,
			float EntryThick,
			float EntryWidth,
			vector<float> R1Temp, 
			vector<float> R2Temp,
			vector<float> R1Expandcoff,
			vector<float> R2Expandcoff,
			int R1Use,
			int E1Use,
			int E2Use,
			int RollPass,
			vector<float> R1ReduSeq,
			float E1Diam,
			float R1Diam,
			vector<float> R2ReduSeq,
			float E2Diam,
			float R2Diam,
			vector<float> R1SpreadInher,
			vector<float> R2SpreadInher,
			vector<float> R1DogBoneInher,
			vector<float> R2DogBoneInher,
			RMSpreadSeq& RSpread,  
			float RMWidthTarget,
			vector<float> E1MaxWidthRedu,
			vector<float> E2MaxWidthRedu,
			const RMDogBoneParaAllPass& Dogpara );

		RMWidthTargetSeq WidthModel::WidthAssignDraftPara(int Calmode,SteelInfomation SteelInfo,
			float EntryThick,
			float EntryWidth,
			vector<float> R1Temp,
			vector<float> R2Temp,
			vector<float> R1Expandcoff,
			vector<float> R2Expandcoff,
			int R1Use,
			int E1Use,
			int E2Use,
			int RollPass,
			vector<float> R1ReduSeq,
			float E1Diam,
			float R1Diam,
			vector<float> R2ReduSeq,
			float E2Diam,
			float R2Diam,
			vector<float> R1SpreadInher,
			vector<float> R2SpreadInher,
			vector<float> R1DogBoneInher,
			vector<float> R2DogBoneInher,
			RMSpreadSeq& RSpread,  
			float RMWidthTarget,
			// float EdgePassMaxWidthRedu,
			vector<float> E1MaxWidthRedu,
			vector<float> E2MaxWidthRedu,
			const RMDogBoneParaAllPass& Dogpara,
			const DraftPara& widthdraftpara);

		////////SscSetPointData SscSetupCal(int Calmode,SteelInfomation SteelInfo,
		////////					 float EntryWidth,
		////////	     			 float EntryThick,
		////////					 float RDraft,
		////////					 float EDraft,
		////////					 float rollDia,		//ˮƽ���뾶
		////////					 float Edgertype,   //��������
		////////					 const SSCParaData SSCPara,
		////////					 SSCInherData SSCInher,
		////////					 SSCModData SSCMod,
		////////					 SscSetPointData& SscSetPoint);

		SscSetPointData WidthModel::SscSetupCalxx(int Calmode,SteelInfomation SteelInfo,
			int StandNum,
			float EntryWidth,
			float EntryThick,
			float RDraft,
			float EDraft,
			float rollDia,		//ˮƽ���뾶
			float Edgertype,      //��������
			const SSCParaData SSCPara,
			SSCInherData SSCInher,
			SSCModData SSCMod,
			SscSetPointData& SscSetPoint);

		SscSetPointData WidthModel::SscSetupCal(int Calmode,SteelInfomation SteelInfo,
			int StandNum,
			int R1passNum, int R2passNum,
			float EntryWidth,
			float EntryThick,
			float RDraft,
			float EDraft,
			float rollDia,		//ˮƽ���뾶
			float Edgertype,      //��������
			const SSCParaData SSCPara,
			SSCInherData SSCInher,
			SSCModData SSCMod,
			SscSetPointData& SscSetPoint);


		SscSetPointData WidthModel::SscSetupCalHeadTailxx(int Calmode,SteelInfomation SteelInfo,
			int StandNum,
			int R1passNum, int R2passNum,
			float EntryWidthHead,
			float EntryWidthTail,
			float EntryThick,
			float RDraft,
			float EDraftHead,
			float EDraftTail,
			float rollDia,		//ˮƽ���뾶
			float Edgertype,      //��������
			const SSCParaData SSCPara,
			SSCInherData SSCInher,
			SSCModData SSCMod,
			SscSetPointData& SscSetPoint);

		SscSetPointData WidthModel::SscSetupCalHeadTail(int Calmode,SteelInfomation SteelInfo,
			int StandNum,
			int R1passNum, int R2passNum,
			float EntryWidthHead,
			float EntryWidthTail,
			float EntryThick,
			float RDraft,
			float EDraftHead,
			float EDraftTail,
			float rollDia,		//ˮƽ���뾶
			float Edgertype,      //��������
			const SSCParaData SSCPara,
			SSCInherData SSCInher,
			SSCModData SSCMod,
			SscSetPointData& SscSetPoint);

		CncSetData NeckCompCal(int Calmode,SteelInfomation SteelInfo,
							float FmEntryThick,
							float FmEntryWidth,
							float FmExitThick,
							float FmExitWidth,
							int DCNum,
							CncInherData CncInher,
							CncSetData& CncSet);

     //����ͷβ��״Ԥ�����	
		SSCHeadTailCal PreSscData(int Calmode,SteelInfomation SteelInfo,
							float entWidth,		//�������Ͽ���
							float entThick,		//�������Ϻ��
							float edgerDraft,		//��ѹ��
							float exiThick,		//ˮƽ���ƺ�İ������
							float rollDia,		//ˮƽ���뾶
							float &deltaWidthHead,
							float &deltaWidthTail,
							float &deltaLengthfh,
							float &deltaLengthft);

		//����¯���ǰ������
		LongSscSetPointData FurFeedForwardCal(int Calmode,SteelInfomation SteelInfo,
							int  StandNum,
							float EdgePassMaxWidthRedu,
							SlabWidthData SlabWidth,
							float EntryThick,
							float RStandWidthTarget,
							float Temp,
							float EDiam,
							float RDraft,
							float RDiam,
							float RSpreadInher,
							float DogBoneInher,
							const RMDogBonePara& para,
							SscSetPointData& SscSetPoint,
							float SlabLength);

		//T�������Ƽ���		
		LongSscSetPointData WidthModel:: TSlabControl(int Calmode,SteelInfomation SteelInfo,
							int  StandNum,int R1passNum,int R2passNum,
							float EdgePassMaxWidthRedu,
							TSlabWidthData TSlabWidth,
							float EntryThick,
							float RStandWidthTarget,
							float Temp,
							float EDiam,
							float RDraft,
							float RDiam,
							float RSpreadInher,
							float DogBoneInher,
							const RMDogBonePara& para,
							SscSetPointData& SscSetPoint,
							float SlabLength,
							float Edgertype,      //��������
							const SSCParaData SSCPara,
							SSCInherData SSCInher,
							SSCModData SSCMod);

		//3��ʽ���ȿ����趨	
		LongSscSetPointData RM3TargetControl(int Calmode,SteelInfomation SteelInfo,
							int  StandNum,int R1passNum,int R2passNum,
							float EdgePassMaxWidthRedu,
							SlabWidthData EntryWidth,
							float EntryThick,
							float FMDThick,
							float FMDWidth,
							RdwTargetData WidthTargetData,
							float Temp,
							float EDiam,
							float RDraft,
							float RDiam,
							float RSpreadInher,
							float DogBoneInher,
							const RMDogBonePara& para,
							SscSetPointData& SscSetPoint,
							float SlabLength,
							float Edgertype,      //��������
							const SSCParaData SSCPara,
							SSCInherData SSCInher,
							SSCModData SSCMod);

		LongSscSetPointData   RMDCWidthControl(int Calmode,SteelInfomation SteelInfo,
			int  StandNum,int R1passNum,int R2passNum,
			float EdgePassMaxWidthRedu,
			SlabWidthData EntryWidth,
			float EntryThick,
			float FMDThick,
			float FMDWidth,
			RdwTargetData WidthTargetData,
			float Temp,
			float EDiam,
			float RDraft,
			float RDiam,
			float RSpreadInher,
			float DogBoneInher,
			const RMDogBonePara& para,
			SscSetPointData& SscSetPoint,
			float SlabLength,
			float Edgertype,      //��������
			const SSCParaData SSCPara,
			SSCInherData SSCInher,
			SSCModData SSCMod,
			int DCNum,
			DCWidthInherData DCwidthInher);


		////�������ɷ�����Ի�
		//RMLoadData RMDraftRel(RMLoadData RMDraft,float Hin,float HTarget);

		////type:1,���������ޣ���Ȩ�������������ӵ��β�������
		////type:2,�����ɵ�������Ϊ�޶�����ƽ���������ɣ��̶��õ��Σ�����������Ի����������ӵ��β�������
		////type:3�����ʳ��ޣ����ٶ����ȣ����ӵ��β�������
		////type:4,���ʳ��ޣ����������ȣ����ӵ��β�������

		////type:5,�����ɵ�������Ϊ�޶����ɵ�90~95���̶��õ��Σ�����������Ի����������ӵ���������
		////type:6�����ʳ��ޣ����ӵ���������
		//RMLoadData RMLoadAssign(int type,RMLoadData RMLoadt,float Hin,float HTarget);

		float  interpolation (float x, vector <float> xa, vector<float> ya);

		DataStatistcis DataProcess(vector <float> xa,float LimitMax,float LimitMin );
		
		DataStatistcis DataProcessPara(vector <float> xa,float LimitMax,float LimitMin,int CClass );

		inline float MeanAbsRateCal(vector <float> xa)
		{
			float Calresult=0.0f;
			int num=xa.size();
			
			if (num==0) Calresult=0.0f;
			else
			{
				for (int i=0;i<num;i++)
				{
					Calresult=Calresult+abs(xa.at(i));
				}
			}
			Calresult=Calresult/num;
			return Calresult;
		};


		inline float SumCal(vector <float> xa)
		{
			float Calresult=0.0f;
			int num=xa.size();
			if (num==0) Calresult=0.0f;
			else
			{
				for (int i=0;i<num;i++)
				{
					Calresult=Calresult+xa.at(i);
				}
			}

			return Calresult;
		};

		inline float MeanCal(vector <float> xa)
		{
			float Calresult=0.0f;
			int num=xa.size();
			if (num==0) Calresult=0.0f;
			else
			{
				Calresult=SumCal(xa)/num;
			}

			return Calresult;
		};

		inline float StdCal(vector <float> xa)
		{
			float Calresult=0.0f;
			float yaa=0.0f;
			float mean;
			mean=MeanCal(xa);
			int num=xa.size();
			int i;
			float zs;
			if (num==0) Calresult=0.0f;
			else
			{
				for (i=0;i<num;i++)
				{
					zs=(xa.at(i)-mean)*(xa.at(i)-mean);
					yaa=yaa+zs;
					
				}
				if(num>1) Calresult=sqrt(yaa/(num));
			}

			return Calresult;
		};



		inline float StudentDis(int num)
		{
			vector <float> X;
			vector <float> Y;
			float aa;
			aa=(float)num;
			float Tv;
			X.push_back(2.0f);   Y.push_back(8.9845f );
			X.push_back(3.0f);   Y.push_back(2.4843f );
			X.push_back(4.0f);   Y.push_back(1.5910f );
			X.push_back(5.0f);   Y.push_back(1.2415f );
			X.push_back(6.0f);   Y.push_back(1.0949f );
			X.push_back(7.0f);   Y.push_back(0.9249f );
			X.push_back(8.0f);   Y.push_back(0.8362f );
			X.push_back(9.0f);   Y.push_back(0.7667f );
			X.push_back(10.0f);  Y.push_back(0.7153f );
			X.push_back(11.0f);  Y.push_back(0.6718f );
			X.push_back(12.0f);  Y.push_back(0.6354f );
			X.push_back(13.0f);  Y.push_back(0.6043f );
			X.push_back(14.0f);  Y.push_back(0.5774f );
			X.push_back(15.0f);  Y.push_back(0.5538f );
			X.push_back(16.0f);  Y.push_back(0.5329f );
			X.push_back(17.0f);  Y.push_back(0.5142f );
			X.push_back(18.0f);  Y.push_back(0.4973f );
			X.push_back(19.0f);  Y.push_back(0.4820f );
			X.push_back(20.0f);  Y.push_back(0.4680f );
			X.push_back(21.0f );  Y.push_back(0.4552f );
			X.push_back(22.0f );  Y.push_back(0.4434f );
			X.push_back(23.0f );  Y.push_back(0.4324f );
			X.push_back(24.0f );  Y.push_back(0.4223f );
			X.push_back(25.0f );  Y.push_back(0.4128f );
			X.push_back(26.0f );  Y.push_back(0.4039f );
			X.push_back(27.0f );  Y.push_back(0.3956f );
			X.push_back(28.0f );  Y.push_back(0.3878f );
			X.push_back(29.0f );  Y.push_back(0.3804f );
			X.push_back(30.0f );  Y.push_back(0.3734f );
			X.push_back(31.0f );  Y.push_back(0.3668f );
			X.push_back(32.0f );  Y.push_back(0.3604f );
			X.push_back(33.0f );  Y.push_back(0.3546f );
			X.push_back(34.0f );  Y.push_back(0.3489f );
			X.push_back(35.0f );  Y.push_back(0.3485f );
			X.push_back(36.0f );  Y.push_back(0.3383f );
			X.push_back(37.0f );  Y.push_back(0.3334f );
			X.push_back(38.0f );  Y.push_back(0.3287f );
			X.push_back(39.0f );  Y.push_back(0.3242f );
			X.push_back(40.0f );  Y.push_back(0.3198f );
			X.push_back(41.0f );  Y.push_back(0.3156f );
			X.push_back(42.0f );  Y.push_back(0.3116f );
			X.push_back(43.0f );  Y.push_back(0.3078f );
			X.push_back(44.0f );  Y.push_back(0.3040f );
			X.push_back(45.0f );  Y.push_back(0.3002f );
			X.push_back(50.0f );  Y.push_back(0.2841f );
			X.push_back(60.0f );  Y.push_back(0.2581f );
			X.push_back(70.0f );  Y.push_back(0.2383f );
			X.push_back(80.0f );  Y.push_back(0.2224f );
			X.push_back(90.0f );  Y.push_back(0.2094f );
			X.push_back(100.0f ); Y.push_back(0.1984f );
			X.push_back(150.0f ); Y.push_back(0.1663f );
			X.push_back(200.0f ); Y.push_back(0.1344f );

			if(aa<1) Tv=10;
			else if (aa>200) Tv=0.1344f;
			else Tv=interpolation (aa, X,Y);

			return Tv;
		};


		inline float MaxCal(vector <float> xa)
		{
			float Calresult=0.0f;
			int num=xa.size();
			if (num==0) Calresult=0.0f;
			else
			{
				Calresult=xa.at(0);
				for (int i=0;i<num;i++)
				{
					if(xa.at(i)>Calresult) Calresult=xa.at(i);
				}
			}

			return Calresult;
		};

		inline float MinCal(vector <float> xa)
		{
			float Calresult=0.0f;
			int num=xa.size();
			if (num==0) Calresult=0.0f;
			else
			{
				Calresult=xa.at(0);
				for (int i=0;i<num;i++)
				{
					if(xa.at(i)<Calresult) Calresult=xa.at(i);
				}
			}
			return Calresult;
		};
	};
}
#endif
