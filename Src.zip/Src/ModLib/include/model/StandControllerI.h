#ifndef __SCC_d__ng1780_trunk_include_SCC_StandControllerI_h__
#define __SCC_d__ng1780_trunk_include_SCC_StandControllerI_h__


#include "PieceData.h"
//#include "CalcInfo.h"
#include "Controller.h"
#include <model/Temperature.h>
#include <model/ROLLBITE.h>
#include <model/RollGap.h>

namespace SCC
{
	struct StandControlData
	{

		bool    active;         /* stand dummy mode */
		//float   wrCool;         /* stand coolant cooling percent (%) */
		float   rollTime;       /* stand rolling time (s) */
		float	relReduc;       /* relative reduction F1-F7 */
		float	arcLen;         /* rolling contact arc length (mm)*/
		float	massFlow;       /* material flow volume F1-F7,MH */
		float	gaugeThick;     /* gauge thickness for same point */
		//float	gaugeThickConf; /* gauge thickness confidence for same point */
		float	gaugeThickSnap;     /* gauge thickness for same point */
		float	forwardSlip;    /* forward slip F1-F7 */
		float	backwardSlip;   /* backward slip F1-F7 */
		float	forSpecTension; /* stand tension forward */
		float	backSpecTension;/* stand tension backward */

		float	looperAngle;	/* looper angle */
		float	rollPower;		/* rolling power F1-F7 [KW] */
		float	rollTorque;		/* rolling torque F1-F7 [KNm] */
		float	rollForce;		/* rolling force F1-F7 [KN] */
		float	bendForce;		/* bending force F1-F7 [KN] */
		float	screwDown;		/* screw down F1-F7 [mm] */
		float	circumSpeed; 	/* circumfence speed F1-F7 [mm/s] */
		//float	pcAngle;		/* pc angle [degC] F1-F4 */
		float	shiftPos;		/* shift position [mm] F5-F7 */

		float	  thermalCrown;	/*roll thermal crown F1-F7 (mm)*/
		float	  rollWear;		/* roll wear  F1-F7  (mm) */
		float   radiTime;		/* air cooling time after stands */
		float   airTempAveEnt;    /* air cooling zone entry temp = stand deforming zone exit temp */
		float   airTempSurfEnt;   /* air cooling zone entry temp = stand deforming zone exit temp */
		float   airTempEntSeq[FM::TEMP_LAYNUM];    /* air cooling zone entry temp = stand deforming zone exit temp */
	    
		//MODELKIT::ScrewDownData	sDData;
		//MODELKIT::AGCSetUpData	agcData;
		//MODELKIT::CaliData	cData;
	    
		float   rollDia;        /* work roll diameter TOP (mm)*/
		float   rollTemp;       /* work roll temperatur degC */
		int      rolllMatCode;   /* work roll material code */
	    
		float   km;                 /* Average flow stress calculated value [MPa]  */
		float   plasticCoeff;       /* material plasticity coefficient  [kN/mm] */
		float   millModulus;        /* Mill modulus [kN/mm] */
		float   formTempIncreas;    /* Temperature increase due to forming F1-F7 [MAX_STAND_NO]*/
		float   airTempDrop;        /* Temperature decrease due to radiation F1-F7 [MAX_STAND_NO]*/
		
		bool	  flakeState;
		float   flakeTempDrop;		//flake water temp drop
		float   rfTenComp;
	   
		float   kChem;              /* chemical coeff */
		float   strainRate;         /* strain rate */
		float   Qp;                 /* friction coeff */
		float   Rd;                 /* deform radius */
		float   TenKm;              /* kmTen coefficient factor of tension on KM  */
		float   kmAct;              /* postcalc kmAct */
	    
		float  dfdh;
		float  corrZero;
		int     IDKerTempPre;		//�ڲ��������������key
		float  kflowtab;
	    
	};


//////////////////////////////////////////////////////////////////////////////////////////

	class StandControllerI : virtual public ::SCC::Controller
	{

	public:

		StandControllerI();

		~StandControllerI();

		void setStdClassCoefs(FlowStressCoef& stds);

		bool    setStatus(bool status);
		void    setFlakeState(bool bFlakeState);

		float   calcDeformTempIncrease();

		float   calcContactTempDrop();

		int     checkData();

		float	calcExitThick();

		 vector<float> calcExitTemp(int sfc, int laynum, float envtemp, int adapflag, float corrtemp);
		
		 float calcStripSpeed(float thick, float speed);
		
		 float calcScrewDown(int stand);
		
		 float calcBackwordTension();
		
		 float setRelReduction(float eps);
		 
		 float setForSpecTens(float spectension);
		 
		 float setBackSpecTens(float spectension);

	   /**
		* \brief ������ں��,���ݵ������̷���
	   */  
		float calcGaugeThick(int stand);
	   /**
		* \brief �����������,������������ʽ����
		* \ V1H1 = V2H2 = .... = V7H7
		* \param[float]: _ref_massflow, ��׼������ ����������ܳ���������
		* \param[float]: _speed, ����ͬʱ���ٶ�
	   */     
		float calcFlowThick(float massflow, float speed);
	    
	   /**
		* \brief ������ܵ�������
	   */  
		float calcMassFlow(float speed , float thick , float slip);
		

		float calcForce(int, int,int,bool,bool,
									   const ::SCC::PDIChem&,
									   const ::SCC::ForceInherStand&);

		float calcForceSens(int ,int ,int ,
										const ::SCC::PDIChem& ,
										const ::SCC::ForceInherStand& );

		float calcSlip(int, float kfslip);


		//void setCalcInfo(FM::CalcInfo& ifo)	{info=ifo;};

		StandControlData pass;

		int standNo;

	private:

		//FM::CalcInfo info;

		 FlowStressCoef stdClassCoefs ;
	};

}

#endif
