#ifndef _FM_Strategy_H_
#define _FM_Strategy_H_
#include <iostream>
#include <vector>
#include "Param.h"
#include "Limit.h"
#include "cMatl.h"
#include "PieceData.h"

namespace FM
{


	class StrategyI
	{
	public:
		StrategyI();
		~StrategyI();
	public:
		bool calc();

		void setOperatorInput(SCC::OperatorInput op);

		void setPDI(SCC::PdiInput pdi);

		void setStratDat(SCC::StratInput stratin);

		//void setStripClass(const SCC::StripClass& sc);

		//SCC::StripClass  getStripClass();

		SCC::Strategy  getStrategy();

		SCC::PdiInput         getPDI();

	private:

		/**
		*@brief ���ݴ��ֵ�����(��ȡ��¶ȡ����ȵ�)���õ���Ӧ�ĵȼ� 
		*@param mode,
		*          = 0, val <= class_limit[i]
		*          = 1, val >= class_limit[i]
		*          = 2, val <  class_limit[i]
		*          = 3, val >  class_limit[i]
		*@param count : �ȼ��ֵ���
		*@return int : �ȼ�ֵ
		*@param class_limit : �ֵ�ֵ
		**/
		int calcClass(int mode, float  val,std::vector<float> classlimit);

		void setClass();

		void pdiCheck();

		void target();

		void rmdata();

		void load();

		void speed();

		void wrdata();

		void tension();

		void inherit();

		void operInput();

		//void inheritForce();

		//void inheritTemp();

		//void inheritGap();

		//void inheritStand();


	private:

		//std::auto_ptr<FM::Limit> limit;
		FM::Limit *limit;

		FM::Param *param;

		SCC::OperatorInput op;

		SCC::PdiInput pdi;

		//SCC::StripClass sc;

		SCC::Strategy st;

		 SCC::StratInput  stratin;	

		 std::vector<std::string> vecLimitErrors;
	
	};

};
#endif