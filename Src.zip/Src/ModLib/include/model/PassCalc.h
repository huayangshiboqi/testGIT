#ifndef _FM_PassCalc_H_
#define _FM_PassCalc_H_

#include "Strategy.h"
#include "IscControllerI.h"
#include "StandControllerI.h"
#include "FmEntControllerI.h"
#include "FmExtControllerI.h"
#include "Draft.h"

using namespace SCC;


namespace FM
{

	//����ṹ��
	struct PassCalcData
	{

		//��������
		Strategy stratdata;

		//����2��ʱ��
		float     timeRdt2Fsb;   //ָRDT��Fsb���λ�õ�ʱ��
		float     timeFsb2F1;     //ָFSB���ڵ㵽F1���ܵ�ʱ��

		//ֻ���ڼ�¼FET���¶�
		ControlValue2	pFetTemp;

		//�������
		ControlValue2 	pFmEntdat; 

		//��������
		StandControlData passdata[FM::MAX_STAND];

		//���������
		ControlValue2 passentry[FM::MAX_STAND];

		//�����γ���
		ControlValue2 passexit[FM::MAX_STAND];

		//���ܼ���ȴˮ
		IscControlData iscdata[FM::MAX_STAND-1];


	};



class PassCalc
{
	public:
		PassCalc();

		~PassCalc();

	private:
		string calctime;
		string path ;
		float threadSpeedAdjPersent;

	public:

		 PassOutput __fastcall precalc2(PassInput indata);

	     PassCalcData __fastcall precalc(PdiInput pdi, StratInput stratin,  FlowStressCoef stdCoef[7]);

		 void adjustTension( StratInput &stratin );

		void setPDI(SCC::PdiInput pdi)
		{
			this->pdi = pdi;
		};
		void setStratDat(SCC::StratInput& stratin)
		{						
			this->stratin = stratin;
		};
		SCC::Strategy getStratDat()
		{
			return strat;
		};

		void SavePrecalcRes(FM::PassCalcData dat );

		void WriteFmInput(string stripNo,SCC::PdiInput pdiinput,SCC::StratInput stratinput);

	private:
		void SaveCalcData(SCC::SavePoint point,
										PdiInput pdi, 
										StratInput stratin,
										FlowStressCoef stdCoef[7]);
		void SaveResult();

		void init();

		void segmentLength();

		void doCalc();

		void adjustForceByRang();

		void adjustForceLoop();

		void f7ForceLeastProtect();

		int entryCalc( bool firstCalc); 
		
		int forceDraft( );

		void loopCalc();

		int reduction();
		int reduction2(int start_no);

		int speed(int,float);

		int speedlink(float thread_speed, bool firstCalc);

		int speedlink2( );

		int rollSpeed(int nStand);

		int modifySpray(float & temp_error);
		int modifySprayXy();

		int modifySpeed(float& temp_error);

		void width();

		int tempForce(int,int,bool,bool);

		void gap();

		void entryTemp();

		int relative(int& , int&  , int * , float&  , float&  , float *, int &);

		void save();

		void inputCheck(	PdiInput pdi, StratInput stratin);

private:

	   float     timeRdt2Fsb;   //ָRDT��Fsb���λ�õ��ʱ��
	   float     timeFsb2F1;     //ָFSB���ڵ㵽F1���ܵ�ʱ��

		float _thread_speed_old;
		PassCalcData passcalcdata;

		FM::Param *param;
		FM::Limit *limit;
		FM::Draft *draft;
		FM::StrategyI*   pStrategy;

		SCC::FmEntControllerI*     pFmEnt;
		SCC::FmExtControllerI*     pFmExt;
		SCC::StandControllerI*      pStand[FM::MAX_STAND];
		SCC::IscControllerI*          pIsc[FM::MAX_STAND-1];
		//SCC::StripClass sc;
		SCC::PdiInput pdi;
		SCC::Strategy strat;
	    SCC::StratInput  stratin;

		float maxflow[6];
		float minflow[6];
		float maxflow_percent[6];
		float minflow_percent[6];
		float tension_input_adj[7];	

		std::vector<std::string> vecLimitErrors;

	};

};
#endif