#ifndef _FM_Common_H_
#define _FM_Common_H_
#include <iostream>
#include <vector>
#include <math.h>

#define  isnan(x) ((x) != (x))
#define isinf(x) ( !isnan(x) && isnan(x-x) )


namespace FM
{
	typedef std::vector<float> floatseq_type;

	typedef std::vector<int>	intseq_type;


	//exception FMprecalException
	//{
	//	string elog;
	//};


	enum STRIPPOSI
	{
		HEAD,BODY,TAIL
	};

	enum EVENTLEVEL
	{
		HIGH,
		LOW,
	};

	enum STEELCATEGORY
	{
		CARBON_STEEL,
		SI_STEEL,
	};

	enum LOAD_TYPE
	{
		REL_THICK,
		ABS_THICK,
		ABS_FORCE,
		DUMMY,
	};

	enum FM_STAND
	{
		F1,
		F2,
		F3,
		F4,
		F5,
		F6,
		F7
	};

	#define PC_STANDS 6  // pair cross stands  BAO-1580 

	#define MIN_FLOAT_ZERO 1e-6
	#define YES true
	#define OK true
	#define NO false
	#define NG false

	const int TIMER1_FM_STRATEGY = 15;   // fm strategy timer1 [sec]

	const int TIMER2_FM_STRATEGY = 15;   // fm strategy timer2 [sec]

	const int TEMP_LAYNUM = 5;

	const int MAX_STAND = 7;

	//const float PI =3.1415926f;

	const double FM_THICK_CLASS_FOR_TRANS[10] = {1.2, 2.5, 4.0, 6.5, 10.0, 14.0, 16.0, 20.0, 60.0, 60.0};

	const double RM_THICK_CLASS[10] = {38.0, 40.0, 42.0, 46.0, 48.0, 52.0, 55.0, 58.0, 60.0, 62.0 };

	const double MAX_RM_THICK  = 72.;            /* Max rm thickness [mm] */
										  
	const double MIN_RM_THICK  = 32.;            /* Min rm thickness [mm] */

	const double DEFAULT_DESCFLOW = 300.;


#define M_2_MM 1.0e3
#define MM_2_M 1.0e-3

#ifndef BC_TRY_CATCH
#define BC_BEGIN_TRY()
#define BC_END_TRY( fn )
#else
#define BC_BEGIN_TRY() try {
#define BC_END_TRY( fn )   }                                        \
	BCEXCEPTION_CATCH_ALL( throw_BCException2( "Error while ", fn ) ) \
	BCEXCEPTION_CATCH_END( fn )
#endif
//
//#define BEGIN_TRY() 	try \
//	{ 
//
//#define END_TRY() 	} \
//	catch (Ice::Exception &e) \
//	{ \
//		log.Error()<<"ICE exception "<<e.what()<<" "<<__FILE__<<" "<<__LINE__<<endl; \
//	} \
//	catch(std::exception &e) \
//	{ \
//		log.Error()<<"std exception "<<e.what()<<" "<<__FILE__<<" "<<__LINE__<<endl; \
//	} \
//	catch(...) \
//	{ \
//		log.Error()<<"unknown exception catched "<<__FILE__<<" "<<__LINE__<<endl; \
//	} 
//

#define MY_ZERO(var_ins,var_type) do{static var_type p; var_ins = p;}while(0);
										
};
#endif