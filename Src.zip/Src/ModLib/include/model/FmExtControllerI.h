#ifndef __SCC_d__ng1780_trunk_include_SCC_FmExtControllerI_h__
#define __SCC_d__ng1780_trunk_include_SCC_FmExtControllerI_h__
#include "Controller.h"

namespace SCC
{

	struct FmExtControlData //extends ControllerData
	{
	   float   backTension;
	   float   entrySpeed;        /* FMEXT speed */
	   float   massFlow;          /* FMEXT mass flow */
	};

	class FmExtControllerI : virtual public ::SCC::Controller
	{
        public:
			FmExtControllerI(){};
			~FmExtControllerI(){};

			FmExtControlData fmext;

	};

}

#endif
