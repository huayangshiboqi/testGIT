#ifndef _FM_Param_H_
#define _FM_Param_H_

#include <pace/parameter.h>
#include "Common.h"
#include <model/Temperature.h>
#include <model/ROLLBITE.h>
#include <model/RollGap.h>

namespace FM
{

	class Param
	{
	public:
		static Param* getInstance(bool breload=false)
		{
			if(_instance == NULL || breload)
			{
				if (_instance)
				{
					delete _instance;
				}
				
				_instance = new Param();
			}
			return _instance;
		}

		static RollGap* getGapInstance()
		{
			if(rGap == NULL)
			{
				rGap = new RollGap();
			}
			return rGap;
		}

		static TemperatureI* getTempInstance()
		{
			if(rTemp == NULL)
			{
				rTemp = new TemperatureI();
			}
			return rTemp;
		}

		static cRollbite* getForceInstance()
		{
			if(rForce == NULL)
			{
				rForce = new cRollbite();
			}
			return rForce;
		}
	private:
		static Param* _instance;
		static RollGap* rGap;
		static TemperatureI* rTemp;
		static cRollbite* rForce;

		Param()
		{

			Parameter params ("D:\\conf\\fm.conf");

			v_CLASS_STRIPWIDTH = params.getFloatSeq("FM.CLASS.STRIPWIDTH");
			v_CLASS_BARTHICK = params.getFloatSeq("FM.CLASS.BARTHICK");
			v_CLASS_STRIPTHICK = params.getFloatSeq("FM.CLASS.STRIPTHICK");

			v_CLASS_FDT = params.getFloatSeq("FM.CLASS.FDT");

			v_PARAM_ISCFLOW_MAX = params.getFloatSeq("FM.MAX.ISCFLOW");
			v_PARAM_ISCFLOW_MIN = params.getFloatSeq("FM.MIN.ISCFLOW");
			v_PARAM_ISCFLOW_DEFAULT = params.getFloatSeq("FM.DEFAULT.ISCFLOW");

			v_PARAM_ISCACTIVE= params.getIntSeq("FM.SPDSCH.ISCACTIVE");

			v_PARAM_BALANCE_BENDING = params.getFloatSeq("FM.DEFAULT.BENDFORCE");

			m_segmentTimes = params.getFloat("FM.SEGMENT.TIMES");

			m_loopTempError = params.getFloat("FM.TEMPERR");

			m_max_draft_loop = params.getInt("FM.MAXDRAFTLOOP");

			v_alfan_RDT = params.getFloat("FM.AlfanRDT");

			m_GAP_ALPHA = params.getFloat("FM.INHERIT.GAP_ALPHA");

			v_LIMIT_THREADSPEED = params.getFloatSeq("FM.LIMIT.THREADSPEED");

			v_THREADSPEED_PRECENT = params.getFloat("FM.LIMIT.THREADSPEED_PERCENT");

			v_LIMIT_ACC1 = params.getFloatSeq("FM.LIMIT.ACC1");

			v_LIMIT_ACC2 = params.getFloatSeq("FM.LIMIT.ACC2");

			v_LIMIT_MAXSPEED = params.getFloatSeq("FM.LIMIT.MAXSPEED");

			v_LIMIT_MULTISPEED = params.getFloatSeq("FM.LIMIT.MULTISPEED");

			v_LIMIT_SWITCHSTAND = params.getIntSeq("FM.LIMIT.SWITCHSTAND");

			v_LIMIT_FET = params.getFloatSeq("FM.LIMIT.FET");

			v_LIMIT_FDT =params.getFloatSeq("FM.LIMIT.FDT");

			v_LIMIT_FDH =params.getFloatSeq("FM.LIMIT.FDH");

			v_LIMIT_FDW =params.getFloatSeq("FM.LIMIT.FDW");

			v_LIMIT_RDT =params.getFloatSeq("FM.LIMIT.RDT");

			v_LIMIT_RDH =params.getFloatSeq("FM.LIMIT.RDH");

			v_LIMIT_RDW =params.getFloatSeq("FM.LIMIT.RDW");

			v_LIMIT_RDL = params.getFloatSeq("FM.LIMIT.RDL");

			v_LIMIT_CROWN=params.getFloatSeq("FM.LIMIT.CROWN");

			v_LIMIT_FLATNESS=params.getFloatSeq("FM.LIMIT.FLATNESS");

			m_maxLoop = params.getInt("FM.MAXLOOP");

			v_MAX_ROLLFORCE	= params.getFloatSeq("FM.MAX.FORCE");

			v_MAX_ROLLTORQUE = params.getFloatSeq("FM.MAX.TORQUE");

			m_layout_distance_rdt_fet = params.getFloat("FM.LAYOUT.RDT2FET");

			m_layout_distance_fet_chip = params.getFloat("FM.LAYOUT.FET2CHIP");

			m_layout_distance_chip_fsb = params.getFloat("FM.LAYOUT.CHIP2FSB");

			m_layout_distance_tvdfsb = params.getFloat("FM.LAYOUT.TVDFSB");

			m_layout_distance_fsb_f1 = params.getFloat("FM.LAYOUT.FSB2F1");

			m_speed_rdt_fet = params.getFloat("FM.SPEED.RDT2FET");

			m_speed_fet_chip = params.getFloat("FM.SPEED.FET2CHIP");

			//m_speed_chip_fsb = params.getFloat("FM.SPEED.CHIP2FSB");

			m_layout_distance_rm2rdt = params.getFloat("FM.LAYOUT.RM2RDT");

			m_layout_distance_hmd2fet = params.getFloat("FM.LAYOUT.HMD2FET");

			m_layout_distance_f1e_f1 = params.getFloat("FM.LAYOUT.F1EF1");

			m_layout_distance_stands = params.getFloat("FM.LAYOUT.STANDS");

			m_flake_waterFlow = params.getFloat("FM.FLAKEWATER.FLOW");
			if (m_flake_waterFlow<0 || m_flake_waterFlow>300)
			{
				m_flake_waterFlow = 80;
			}
			

			m_layout_distance_f7_mfg = params.getFloat("FM.LAYOUT.F7MFG");

			v_LIMIT_MAX_CORRZERO = params.getFloatSeq("FM.MAX.CORRZERO");
			v_LIMIT_MIN_CORRZERO = params.getFloatSeq("FM.MIN.CORRZERO");

			v_LIMIT_MAX_KFORCE = params.getFloatSeq("FM.MAX.KFORCE");
			v_LIMIT_MIN_KFORCE = params.getFloatSeq("FM.MIN.KFORCE");

			v_LIMIT_MAX_KFSLIP = params.getFloatSeq("FM.MAX.KFSLIP");
			v_LIMIT_MIN_KFSLIP = params.getFloatSeq("FM.MIN.KFSLIP");


			v_LIMIT_MAX_KTORQUE = params.getFloatSeq("FM.MAX.KTORQUE");
			v_LIMIT_MIN_KTORQUE = params.getFloatSeq("FM.MIN.KTORQUE");
			v_LIMIT_MAX_KFLOW = params.getFloatSeq("FM.MAX.KFLOW");
			v_LIMIT_MIN_KFLOW= params.getFloatSeq("FM.MIN.KFLOW");

			v_LIMIT_MAX_corrWaterCool = params.getFloatSeq("FM.MAX.corrWaterCool");
			v_LIMIT_MIN_corrWaterCool = params.getFloatSeq("FM.MIN.corrWaterCool");
			v_LIMIT_MAX_corrDeform = params.getFloatSeq("FM.MAX.corrDeform");
			v_LIMIT_MIN_corrDeform= params.getFloatSeq("FM.MIN.corrDeform");

			b_InheritForce = params.getBool("FM.INHERIT.FORCE");
			b_InheritFslip = params.getBool("FM.INHERIT.FSLIP");
			b_InheritFslipMode = params.getBool("FM.INHERIT.FSLIPMODE");
			b_InheritTemp = params.getBool("FM.INHERIT.TEMP");
			b_InheritZero = params.getBool("FM.INHERIT.ZERO");
			b_InheritFlow = params.getBool("FM.INHERIT.FLOW");
			b_InheriThick = params.getBool("FM.INHERIT.THICK");

			b_InheritForceUse = params.getBool("FM.INHERITUSE.FORCE");
			b_InheritFslipUse = params.getBool("FM.INHERITUSE.FSLIP");
			b_InheritTempUse = params.getBool("FM.INHERITUSE.TEMP");
			b_InheritZeroUse = params.getBool("FM.INHERITUSE.ZERO");
			b_InheritFlowUse = params.getBool("FM.INHERITUSE.FLOW");
			b_InheriThickUse = params.getBool("FM.INHERITUSE.THICK");


			//m_SegNo_InheritThick = params.getInt("FM.INHERIT.SEGNO.THICK");
			m_SegNo_InheritForce = params.getInt("FM.INHERIT.FORCE.SEGNO");
			m_SegNo_InheritTemp = params.getInt("FM.INHERIT.TEMP.SEGNO");
			m_SegNo_InheritZero = params.getInt("FM.INHERIT.ZERO.SEGNO");

			if (m_SegNo_InheritForce>2)
			{
				m_SegNo_InheritForce = 2;
			}
			if (m_SegNo_InheritTemp>2)
			{
				m_SegNo_InheritTemp = 2;
			}
			if (m_SegNo_InheritZero>2)
			{
				m_SegNo_InheritZero = 2;
			}

			m_force_adjust_state = params.getBool("FM.FORCE_ADJUST_STATE");
			m_force_adjust_startNo = params.getInt("FM.FORCE_ADJUST_START_STAND");
			if (m_force_adjust_startNo<1)
			{
				m_force_adjust_startNo = 1;
			}
			m_force_adjust_corr = params.getFloat("FM.FORCE_ADJUST_CORR");
			v_force_adjust_max= params.getFloatSeq("FM.FORCE_ADJUST_MAX");
			v_force_adjust_min= params.getFloatSeq("FM.FORCE_ADJUST_MIN");
			v_force_scale_rang = params.getFloatSeq("FM.FORCE_SCALE_RANG");
			v_force_adjust_max_reduc = params.getFloatSeq("FM.FORCE_ADJUST_MAX_REDUC");
			if (v_force_scale_rang.size()<2)
			{
				v_force_scale_rang.clear();
				v_force_scale_rang.push_back(0.3f);
				v_force_scale_rang.push_back(0.5f);
			}
			m_f7_min_force = params.getFloat("FM.F7_MIN_FORCE");
			
			v_force_tension_comp = params.getFloatSeq("FM.FORCE_TENSION_COMP");
		
			v_force_draft_eps = params.getFloatSeq("FM.FORCE_DRAFT_EPS");


			m_balance_state = params.getBool("FM.BALANCE_STATE");
			m_shutdown_type = params.getInt("FM.SHUTDOWN_TYPE");
			m_single_minflow = params.getFloat("FM.SINGLE_MINFLOW");

			v_TENSION_ADJ_CORR = params.getFloatSeq("FM.TENSION_ADJ_CORR");

			v_TENSION_RF_CORR = params.getFloatSeq("FM.TENSION_RF_CORR");

			v_FSLIP_ADJ_CORR = params.getFloatSeq("FM.FSLIP_ADJ_CORR");

			v_threadspeed_class = params.getFloatSeq("FM.THREADSPEED_CLASS");
			v_threadspeed_persents = params.getFloatSeq("FM.LIMIT.THREADSPEED_PERCENTS");

			v_adaptThick_kps = params.getFloat("FM.adaptThick.kps");
			v_adaptThick_kis = params.getFloat("FM.adaptThick.kis");

			v_adaptThick_kpl = params.getFloat("FM.adaptThick.kpl");
			v_adaptThick_kil = params.getFloat("FM.adaptThick.kil");

			v_adaptThick_kkk = params.getFloat("FM.adaptThick.kkk");

			v_adaptThick_thkCorrLimit = params.getFloat("FM.adaptThick.thkCorrLimit");
			v_adaptThick_thkErrorMax = params.getFloat("FM.adaptThick.thkErrorMax");

			v_ALFAN_FSLIP=params.getFloat("FM.FSLIP.ALFAN");
			v_SEGNO_FSLIP=params.getInt("FM.FSLIP.SEGNO");

			v_RVMODE_FSLIP=params.getBool("FM.FSLIP.RVMODE");
			v_LEARNMODE_GAP=params.getBool("FM.GAP.LEARNMODE");

		};


		~Param(){};



	public:


		floatseq_type	stripWidthClass(){return v_CLASS_STRIPWIDTH;};

		floatseq_type	stripThickClass(){ return v_CLASS_STRIPTHICK;}

		floatseq_type	fdtClass(){return v_CLASS_FDT;};

		floatseq_type	barThickClass(){return v_CLASS_BARTHICK;};

		floatseq_type	iscFlowMax(){return v_PARAM_ISCFLOW_MAX;}

		floatseq_type	iscFlowMin(){return v_PARAM_ISCFLOW_MIN;}

		floatseq_type	iscFlowDefault(){return v_PARAM_ISCFLOW_DEFAULT;}

		floatseq_type	balanceBending(){return v_PARAM_BALANCE_BENDING;}

		float	segmentTimes(){return m_segmentTimes;}

		float	loopTempError(){return m_loopTempError;}

		floatseq_type	limitThreadSpeed(){return v_LIMIT_THREADSPEED;}

		float	                limitThreadSpeedPercent(){return abs(v_THREADSPEED_PRECENT/100.0f);}

		floatseq_type	limitAcc1(){return v_LIMIT_ACC1;}

		floatseq_type	limitAcc2(){return v_LIMIT_ACC2;}

		floatseq_type	limitMaxSpeed(){return v_LIMIT_MAXSPEED;}

		floatseq_type	limitDecc(){return v_LIMIT_DECC;}

		floatseq_type	limitMultiSpeed(){return v_LIMIT_MULTISPEED;}

		intseq_type		limitSwitchStand(){return v_LIMIT_SWITCHSTAND;}

		floatseq_type	limitFET(){return v_LIMIT_FET;}

	    float                AlfanRDT(){return v_alfan_RDT;}

		floatseq_type	limitFDT(){return v_LIMIT_FDT;}

		floatseq_type	limitFDH(){return v_LIMIT_FDH;}

		floatseq_type	limitFDW(){return v_LIMIT_FDW;}

		floatseq_type	limitRDT(){return v_LIMIT_RDT;}

		floatseq_type	limitRDH(){return v_LIMIT_RDH;}

		floatseq_type	limitRDW(){return v_LIMIT_RDW;}

		floatseq_type	limitRDL(){return v_LIMIT_RDL;}

		floatseq_type	limitCrown(){return v_LIMIT_CROWN;}

		floatseq_type	limitFlatness(){return v_LIMIT_FLATNESS;}

		int	maxLoop(){return m_maxLoop;}

		floatseq_type	rollForceMax(){return v_MAX_ROLLFORCE;}

		floatseq_type	rollTorqueMax(){return v_MAX_ROLLTORQUE;}

		float distanceF1EF1(){return m_layout_distance_f1e_f1;}

		float distanceStands(){return m_layout_distance_stands;}

		float flakeWaterFlow(){return m_flake_waterFlow;}

		float distanceF7MFG(){return m_layout_distance_f7_mfg;}

		floatseq_type limitCorrZeroMax(){return v_LIMIT_MAX_CORRZERO;}

		floatseq_type limitCorrZeroMin(){return v_LIMIT_MIN_CORRZERO;}


		bool ifInheritForce(){return b_InheritForce;}
		bool ifInheritFslip(){return b_InheritFslip;}
		bool ifInheritThick(){return b_InheriThick;}
		bool ifInheritTemp(){return b_InheritTemp;}
		bool ifInheritFlow(){return b_InheritFlow;}
		bool ifInheritZero(){return b_InheritZero;}

		bool ifInheritFslipUse(){return b_InheritFslipUse;}
		bool ifInheritForceUse(){return b_InheritForceUse;}
		bool ifInheritThickUse(){return b_InheriThickUse;}
		bool ifInheritTempUse(){return b_InheritTempUse;}
		bool ifInheritFlowUse(){return b_InheritFlowUse;}
		bool ifInheritZeroUse(){return b_InheritZeroUse;}

		int segNoInheritThick(){return m_SegNo_InheritThick;}
		int segNoInheritForce(){return m_SegNo_InheritForce;}
		int segNoInheritTemp(){return m_SegNo_InheritTemp;}
		int segNoInheritGap(){return m_SegNo_InheritGap;}
		int segNoInheritStand(){return m_SegNo_InheritStand;}
		int segNoInheritZero(){return m_SegNo_InheritZero;}


		bool FORCE_ADJUST_STATE(){return m_force_adjust_state;}
		int FORCE_ADJUST_STARTNO(){return m_force_adjust_startNo;}
		float FORCE_ADJUST_CORR(){return m_force_adjust_corr;}
		floatseq_type FORCE_ADJUST_MAX(){return v_force_adjust_max;}
		floatseq_type FORCE_ADJUST_MIN(){return v_force_adjust_min;}
		floatseq_type FORCE_SCALE_RANG(){return v_force_scale_rang;}

		floatseq_type FORCE_ADJUST_MAX_REDUC(){return v_force_adjust_max_reduc;}

		float F7_MIN_FORCE(){return m_f7_min_force;}


		//�����ˮ
		//bool	m_balance_state;
		bool BALANCE_STATE(){return m_balance_state;}
		int SHUTDOWN_TYPE(){return m_shutdown_type;}
		float SINGLE_MINFLOW(){return m_single_minflow;}

		//������������������С
		floatseq_type TENSION_ADJ_CORR(){return v_TENSION_ADJ_CORR;}

		//�ٶȵȼ���Χ
		floatseq_type V_THREADSPEED_CLASS(){return v_threadspeed_class;}
		//���ٶȵȼ������ٶȵ���������Χ
		floatseq_type V_THREADSPEED_PERSENTS(){return v_threadspeed_persents;}


		floatseq_type v_FSLIP_ADJ_CORR;
		intseq_type     v_PARAM_ISCACTIVE;
		int v_SEGNO_FSLIP;
		bool v_RVMODE_FSLIP;
		bool v_LEARNMODE_GAP, b_InheritFslipMode;

		float v_adaptThick_kps,v_adaptThick_kis, v_adaptThick_kkk;
		float v_adaptThick_kpl,v_adaptThick_kil;
		float v_adaptThick_thkCorrLimit,v_adaptThick_thkErrorMax;



	private:

		floatseq_type   v_CLASS_STRIPWIDTH;
		floatseq_type   v_CLASS_BARTHICK;
		floatseq_type   v_CLASS_STRIPTHICK;
		floatseq_type   v_CLASS_STRIPTHICKSI;
		floatseq_type   v_CLASS_FDT;


		floatseq_type	v_MAX_ROLLFORCE;
		floatseq_type	v_MAX_ROLLTORQUE;

		floatseq_type	v_LIMIT_RDT;
		floatseq_type	v_LIMIT_RDH;
		floatseq_type	v_LIMIT_RDW;
		floatseq_type	v_LIMIT_RDL;
		floatseq_type	v_LIMIT_FET;
		floatseq_type	v_LIMIT_FDT;
		floatseq_type	v_LIMIT_FDH;
		floatseq_type	v_LIMIT_FDW;
		floatseq_type	v_LIMIT_THREADSPEED;
		float                 v_THREADSPEED_PRECENT;
		float                 v_alfan_RDT;
		floatseq_type	v_LIMIT_ACC1;
		floatseq_type	v_LIMIT_ACC2;
		floatseq_type	v_LIMIT_MAXSPEED;
		floatseq_type	v_LIMIT_DECC;
		floatseq_type	v_LIMIT_MULTISPEED;
		intseq_type		v_LIMIT_SWITCHSTAND;
		floatseq_type	v_LIMIT_CROWN;
		floatseq_type	v_LIMIT_FLATNESS;


		//post calc

		floatseq_type	v_LIMIT_MAX_CORRZERO;
		floatseq_type	v_LIMIT_MIN_CORRZERO;
		floatseq_type	v_LIMIT_CONF;
		//floatseq_type	
		
		bool	b_InheriThick,b_InheriThickUse;
		bool	b_InheritForce,b_InheritForceUse;
		bool	b_InheritFslip,b_InheritFslipUse;

		bool	b_InheritTemp,b_InheritTempUse;
		bool	b_InheritZero,b_InheritZeroUse;
		bool b_InheritFlow,b_InheritFlowUse;
		
		int		m_SegNo_InheritThick;
		int		m_SegNo_InheritForce;
		int		m_SegNo_InheritTemp;
		int		m_SegNo_InheritGap;
		int		m_SegNo_InheritStand;
		int		m_SegNo_InheritZero;


		// isc flow parameter

		floatseq_type v_PARAM_ISCFLOW_MAX;
		floatseq_type v_PARAM_ISCFLOW_MIN;
		floatseq_type v_PARAM_ISCFLOW_DEFAULT;

		// bending balance

		floatseq_type v_PARAM_BALANCE_BENDING;

		float	m_segmentTimes;

		float	m_loopTempError;

		int	    m_maxLoop;
		float	m_layout_distance_f1e_f1;
		float	m_layout_distance_stands;
		float	m_layout_distance_f7_mfg;

		float	m_flake_waterFlow;

		//�����������ò���
		bool	m_force_adjust_state;
		int		m_force_adjust_startNo;
		float	m_force_adjust_corr;
		floatseq_type v_force_adjust_max;
		floatseq_type v_force_adjust_min;
		floatseq_type v_force_scale_rang;
		floatseq_type v_force_adjust_max_reduc;

		float	m_f7_min_force;

		//�����ˮ
		bool	m_balance_state;
		int		m_shutdown_type;
		float	m_single_minflow;

	public:
		floatseq_type v_force_tension_comp;
		floatseq_type v_force_draft_eps;
		
		int    m_max_draft_loop;
		float	m_layout_distance_rdt_fet;
		float	m_layout_distance_fet_chip;
		float	m_layout_distance_chip_fsb;
		float	m_layout_distance_tvdfsb;
		float	m_layout_distance_fsb_f1;
		float m_layout_distance_rm2rdt;
		float m_layout_distance_hmd2fet;

		float	m_speed_rdt_fet;
		float	m_speed_fet_chip;
		//float	m_speed_chip_fsb;
		//float	m_speed_tvdfsb;
		//float	m_speed_fsb_f1;
		float m_GAP_ALPHA;

		float v_ALFAN_FSLIP;

		floatseq_type v_LIMIT_MAX_KFORCE;
		floatseq_type v_LIMIT_MIN_KFORCE;
		floatseq_type v_LIMIT_MAX_KFSLIP;
		floatseq_type v_LIMIT_MIN_KFSLIP;

		floatseq_type v_LIMIT_MAX_KTORQUE;
		floatseq_type v_LIMIT_MIN_KTORQUE;
		floatseq_type v_LIMIT_MAX_KFLOW;
		floatseq_type v_LIMIT_MIN_KFLOW;

		floatseq_type v_LIMIT_MAX_corrWaterCool;
		floatseq_type v_LIMIT_MIN_corrWaterCool;

		floatseq_type v_LIMIT_MAX_corrDeform;
		floatseq_type v_LIMIT_MIN_corrDeform;

		floatseq_type v_TENSION_ADJ_CORR;
		floatseq_type v_TENSION_RF_CORR;

		floatseq_type v_threadspeed_class;
		floatseq_type v_threadspeed_persents;

	};

};



#endif