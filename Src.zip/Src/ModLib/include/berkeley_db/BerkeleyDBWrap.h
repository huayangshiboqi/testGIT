//#pragma once
#ifndef  __BerkeleyDbWrap_h__
#define  __BerkeleyDbWrap_h__
#include "berkeley_db/db_cxx.h"
#include <string>
#include <vector>

using namespace std;

class BerkeleyDbWrap
{
private:
	bool _init;
	Db _db;
	string _dbfile;

public:
	BerkeleyDbWrap(string file);
	~BerkeleyDbWrap(){close();}
	

private:
	void close();

public:
	void init();
	int get(void *key, size_t key_len, void *value, size_t value_len);
	int put(void *key, size_t key_len, void *value, size_t value_len, bool commit = true);
	Dbc* get_cursor();
	int get_next(Dbc*, vector<char>&, vector<char>&);
	void close_cursor(Dbc*);
	char* get_db_errinfo(int errno);
	void commit();

};
#endif