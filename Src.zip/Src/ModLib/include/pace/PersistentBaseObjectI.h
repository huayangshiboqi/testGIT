#ifndef __PersistentBaseObjectI_h__
#define __PersistentBaseObjectI_h__

#include <pace/PersistentBaseObject.h>
#include <pace/FreezeBaseObject.h>

namespace iPlature
{

class PersistentBaseObjectI : virtual public PersistentBaseObject,
                              virtual public ::iPlature::FreezeBaseObject
{
public:
	PersistentBaseObjectI():PersistentBaseObject(false, 0){}

    virtual void DeleteObject(const Ice::Current&);

    virtual bool Deletable(int KeepDay, const Ice::Current&);
};

}

#endif
