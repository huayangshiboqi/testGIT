#ifndef SIMPLE_CAST_INCLUDE
#define SIMPLE_CAST_INCLUDE

#include <sstream>

namespace iPlature
{
//exception
class bad_simple_cast : public std::bad_cast
{
public:
	  bad_simple_cast(){}
	  virtual ~bad_simple_cast() throw(){}
	  virtual const char *what() const throw()
	  {
		  return "bad simple cast: "
			  "source type value could not be interpreted as target";
	  }  
};

template<typename Target, typename Source>
Target simple_cast(Source arg)
{
	std::ostringstream o;
	o<<std::fixed;
	if(!(o << arg))throw(bad_simple_cast());
	std::istringstream i(o.str());
	Target result;
	if(!(i >> result))throw(bad_simple_cast());
	return result;
}


}//namespace iPlature

#endif


