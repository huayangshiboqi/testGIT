// **********************************************************************
//
//  genericdef.h���ڶ�������ʹ�õ��ĳ��� 
//
//
// **********************************************************************


#ifndef __GenericDef_h__
#define __GenericDef_h__

// pace

const int iPlature_success = 0;

// iMultilink

// Tag

// DB Access

// File DB

// HMI 

// Log


#endif

