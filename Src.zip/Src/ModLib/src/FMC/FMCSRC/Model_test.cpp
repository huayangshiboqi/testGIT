
#include <string>
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <vector>

#include <model/PassCalc.h>
#include <model/PostCalc.h>
#include <log4cplus/LOG.h>
#include <model/DateTime.h>

using namespace std;


int main( )
{

	LOG::doConfigure("G:\\ModLib\\conf\\FMLog.cfg");

	//LOG log;
	//ջ�Ϸ����ڴ棬1~4M,�������оֲ�����
	//PassCalc PassCalc;
	//new���ڶ��Ϸ����ڴ棬�ռ�Ƚϴ�, 2G

	
	FM::PassCalc passcal;
    SCC::PassInput indata;
   	SCC::PassOutput outdata;

   indata.sfc = 1001;
   indata.qualNo=100;
   indata.rmThick= 40;
   indata.rdtTemp= 1080;
   indata.fetTemp = 1020;
   indata.fdtTemp = 820;
   indata.fmThick = 2.0;
   indata.fmWidth = 1100;

   	for(int stdno=0;stdno<FM::MAX_STAND;stdno++)
	{
		indata.standActive[stdno]=true;
		if (stdno < FM::MAX_STAND-1)
		{
				indata.iscActive[stdno]=  true;
				indata.iscSprayMax[stdno]=  95;
				indata.iscSprayMin[stdno]=  0;
		}
	}
	
	float wrdiam[7]={850.0f, 850.0f,850.0f,850.0f, 800.0f, 780.0f, 780.0f};
    float rfaim[7]={1.0,0.98,0.88,0.78,0.62,0.45,0.36};
	float _eps_fm[7]={52.0f,47.0f,38.0f,33.0f,29.0f,20.0f,9.0f};

	 for(int stdno=0;stdno<FM::MAX_STAND;stdno++)
	{
		indata.wrdiam[stdno]=wrdiam[stdno];
				
		indata.rfk[stdno]=rfaim[stdno];
						
		indata.eps[stdno]=_eps_fm[stdno];

	}

	 indata.threadSpeed = 10;
	 indata.descEntOn= true;
	 indata.descExtOn= true;
	 indata.mode= 1;


	 outdata = passcal.precalc2(indata);

	 int aa=1;
}

