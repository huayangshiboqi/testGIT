#include <string>
#include <sstream>
#include <fstream>
#include "math.h"

using namespace std;

#ifndef _licence_h_
#define _licence_h_

class licence
{
public:
	licence() ;
    ~licence();
	int get1780ModelLicence(float FMStandDis,int slabAccNum);
	int getRMWidthLicence(float FMStandDis,int slabAccNum); 
	//int getRMWidthInherLicence();
	//int getFMModelLicence();
	//int getFMInherLicence();
	//int getFMForceLicence();
private:
	int year ;
	int mon ;
	int day ;
	float widthproduct  ;   
	float productwidthMIN  ;
	float productwidthMAX  ;
	float productThickMin  ;
	float productThickMAX  ;
	float SlabWidthMin     ;
	float FMSTANDDistance;
	int ProductACCNum;
	int licenceOK;
	int mode;

};

#endif
