#include <string>
#include <sstream>
#include <fstream>
#include "DateTime.h"
//#include "pace/Parameter.h"
#include "licence.h"
//#include <stdio.h>
//#include <iostream>

using namespace std;

licence::licence()
{

}
licence::~licence()
{

}
int licence::get1780ModelLicence(float FMStandDis,int slabAccNum)
{
	int AAAA;
	int UseNumAct,UseNumLimit;

	string path = "d:\\conf\\ModelLicence.conf";
	std::ifstream fin_fm(path.c_str(), std::ios::binary);
	fin_fm.read((char*)& UseNumAct,sizeof(float));
	fin_fm.read((char*)& UseNumLimit,sizeof(float));

	//for disturbe
	for (int i=0;i<20;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}

	//��Ʒ�ߴ緶Χ�� 
	fin_fm.read((char*)& productwidthMIN,sizeof(float));
	fin_fm.read((char*)& productwidthMAX,sizeof(float));
	fin_fm.read((char*)& productThickMin,sizeof(float));
	fin_fm.read((char*)& productThickMAX,sizeof(float));
	fin_fm.read((char*)& SlabWidthMin,   sizeof(float));
	fin_fm.read((char*)& FMSTANDDistance,sizeof(float));

	for (int i=0;i<20;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& year, sizeof(int));
	for (int i=0;i<8;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}

	fin_fm.read((char*)& mon, sizeof(int));

	for (int i=0;i<2;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& day, sizeof(int));
	for (int i=0;i<2;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& ProductACCNum, sizeof(int));
	fin_fm.read((char*)& mode, sizeof(int));
	fin_fm.close();

	//std::ofstream fout_fm(path.c_str(), std::ios::binary|ios::ate);
	//UseNumAct = UseNumAct + 1;
	//fout_fm.write((char*)& UseNumAct, sizeof(float));
	//fout_fm.close();


	DateTime nowtime;
	DateTime LimitTime(year,mon,day,0,0,0);

	nowtime=DateTime::now();
	long secMax,secnow;
	secMax = LimitTime.toSeconds();
	secnow = nowtime.toSeconds();

	licenceOK=0;
	if (mode<=0)
	{	
		if (nowtime<LimitTime)
		{
			licenceOK=666;
		}
	}

	if (mode>=1)
	{	
		if (nowtime<LimitTime && abs(FMStandDis-FMSTANDDistance)<1 && (slabAccNum<ProductACCNum) )
		{
			licenceOK=666;
		}
	}

	if (mode>=2)
	{	
		if (nowtime<LimitTime && abs(FMStandDis-FMSTANDDistance)<1 && (slabAccNum<ProductACCNum )
			&& (UseNumAct<UseNumLimit) )
		{
			licenceOK=666;
		}
	}


	if (mode == 19681998)
	{
		licenceOK=666;
	}
	
	return licenceOK;

} 


int licence::getRMWidthLicence(float FMStandDis,int slabAccNum)
{
	int AAAA;
	int UseNumAct,UseNumLimit;

	string path = "d:\\conf\\ModelLicence.conf";
	std::ifstream fin_fm(path.c_str(), std::ios::binary);
	fin_fm.read((char*)& UseNumAct,sizeof(float));
	fin_fm.read((char*)& UseNumLimit,sizeof(float));

	//for disturbe
	for (int i=0;i<20;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}

	//��Ʒ�ߴ緶Χ�� 
	fin_fm.read((char*)& productwidthMIN,sizeof(float));
	fin_fm.read((char*)& productwidthMAX,sizeof(float));
	fin_fm.read((char*)& productThickMin,sizeof(float));
	fin_fm.read((char*)& productThickMAX,sizeof(float));
	fin_fm.read((char*)& SlabWidthMin,   sizeof(float));
	fin_fm.read((char*)& FMSTANDDistance,sizeof(float));

	for (int i=0;i<20;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& year, sizeof(int));
	for (int i=0;i<8;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}

	fin_fm.read((char*)& mon, sizeof(int));

	for (int i=0;i<2;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& day, sizeof(int));
	for (int i=0;i<2;i++)
	{
		fin_fm.read((char*)& AAAA, sizeof(int));
	}
	fin_fm.read((char*)& ProductACCNum, sizeof(int));
	fin_fm.read((char*)& mode, sizeof(int));
	fin_fm.close();

	//std::ofstream fout_fm(path.c_str(), std::ios::binary|ios::ate);
	//UseNumAct = UseNumAct + 1;
	//fout_fm.write((char*)& UseNumAct, sizeof(float));
	//fout_fm.close();


	mon=mon+3;
	if (mon>12)
	{
		mon=mon-12;
		year=year+1;
	}

	DateTime nowtime;
	DateTime LimitTime(year,mon,day,0,0,0);

	nowtime=DateTime::now();
	long secMax,secnow;
	secMax = LimitTime.toSeconds();
	secnow = nowtime.toSeconds();

	licenceOK=0;
	if (mode<=0)
	{	
		if (nowtime<LimitTime)
		{
			licenceOK=666;
		}
	}

	if (mode>=1)
	{	
		if (nowtime<LimitTime && abs(FMStandDis-FMSTANDDistance)<1 && (slabAccNum<ProductACCNum) )
		{
			licenceOK=666;
		}
	}

	if (mode>=2)
	{	
		if (nowtime<LimitTime && abs(FMStandDis-FMSTANDDistance)<1 && (slabAccNum<ProductACCNum )
			&& (UseNumAct<UseNumLimit) )
		{
			licenceOK=666;
		}
	}


	if (mode == 19681998)
	{
		licenceOK=666;
	}

	return licenceOK;

} 
