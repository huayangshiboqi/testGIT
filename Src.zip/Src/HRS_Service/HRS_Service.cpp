// HRSService.cpp : �������̨Ӧ�ó������ڵ㡣
//

//#define _WIN32_WINNT    0x0501

#include "NG_sock.h"
#include "RW.h"
#include "MP_Comm.h"
#include "NG_threads.h"
#include "NG_Path.h"
#include "TestApi.h"
#include "MP_FindPackMgr.h"


#define   _MEM_CHECK_FLAG         1
#define   HRS_SERVICE_NAME    "HRSService"

SERVICE_STATUS          HRSServiceStatus; 
SERVICE_STATUS_HANDLE   HRSServiceStatusHandle; 

VOID WINAPI  HRSServiceStart (DWORD argc, LPTSTR *argv); 
VOID WINAPI  HRSServiceCtrlHandler (DWORD opcode); 
DWORD HRSServiceInitialization (DWORD argc, LPTSTR *argv, 
                                      DWORD *specificError); 
VOID HRSSvcDebugOut(LPSTR String, DWORD Status) ;

static HANDLE HRS_CreateThread();

static void * HRS_ThreadFunc(void *pArg);
static void HRS_StopService();


HANDLE   g_hMainProcess = NULL;


void Usage(void)
{
    printf("HRSService                   #������������Ҫ��Service��ʽ����\n");
    printf("HRSService -d nWaitTimeMs    #����������ͨ�������б��ڵ���\n\n");

//    printf("%s\n", HRS_MOD_NAME_CSteelMgr);
    return;
}


VOID  main( ) 
{ 
    char **ppszArgv;
    int  argc;

    printf("HRSService running.\n");

    SERVICE_TABLE_ENTRY   DispatchTable[] = 
    { 
        {  TEXT(HRS_SERVICE_NAME), HRSServiceStart }, 
        { NULL,              NULL            } 
    }; 

    NG_malloc_init();

    //�����ļ�·��

    char szPath[512];
    int nRet = NG_Path_GetRunPath(szPath, sizeof(szPath)-1);
    if ( nRet == ERR_FAILED )
    {
        return;
    }
    NG_Path_SetCurPath(szPath);

#if 1
    LPTSTR lpstr = GetCommandLine();  // Windowsϵͳ����

    char *pszCmdLine = (char *)(LPSTR)lpstr;

    printf("CmdLine = %s\n", pszCmdLine);

    argc = 0;
    ppszArgv = NULL;

    ppszArgv = GetCommandArray(pszCmdLine, &argc);

    if ( ppszArgv == NULL )
    {   //�����������ʧ�ܣ��ԣ�
        Usage();
        printf("Parse Command Para failed.\n");
        return;
    }
#endif
    if ( argc == 3 )
    {
        if ( ppszArgv[1][0] == '-' 
            && (ppszArgv[1][1] == 'd' || ppszArgv[1][1] == 'D') )
        {
            int nWaitTimeMs = atoi(ppszArgv[2]);

            HRS_ThreadFunc(NULL);
			//�����HRS_ThreadFunc����(HRS_Service.cpp)�е���HRE_Entry.cpp�е�HRSService_Main����
			//��HRSService_Main�����е���pCTrack->CalcData();�����pCTrack�е�����CHRS_Track������HRS_Track.hͷ�ļ�
			//�������õ�CalcData()������HRS_Track.cpp�ļ��ж��壬
			//CalcData�����е���RMSchedClac�����������Դ�����һЩ�������м��㡣RMSchedClac������HRS_Track.cpp�ж���
			//���ԣ�

            NGClock_Delay(nWaitTimeMs);

            NG_FreeArray((void **)ppszArgv);

            HRS_StopService();

            printf("HRSSerice normal exit .\n");

            return;
        }
    }
    else if ( argc > 1 )
    {
        Usage();

        printf("HRSSerice exit .\n");

        NG_FreeArray((void **)ppszArgv);

        NG_malloc_close();

        return;
    }

    printf("HRSSerice exit 2. argc = %d, argv[0] = %s\n", argc, ppszArgv[0]);

    NG_FreeArray((void **)ppszArgv);


    if (!StartServiceCtrlDispatcher( DispatchTable)) 
    { 
        HRSSvcDebugOut(" [HRS_SERVICE_NAME] StartServiceCtrlDispatcher error = \
                             %d\n", GetLastError()); 
    }


    return;
} 


VOID HRSSvcDebugOut(LPSTR String, DWORD Status) 
{ 
    CHAR  Buffer[1024]; 
    if (strlen(String) < 1000) 
    { 
        sprintf(Buffer, String, Status); 
        //WinPrint(Buffer); 
    } 
} 


void WINAPI 
HRSServiceStart (DWORD argc, LPTSTR *argv) 
{ 
    DWORD status; 
    DWORD specificError; 

    HRSServiceStatus.dwServiceType        = SERVICE_WIN32; 
    HRSServiceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    HRSServiceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP | 
        SERVICE_ACCEPT_PAUSE_CONTINUE; 
    HRSServiceStatus.dwWin32ExitCode      = 0; 
    HRSServiceStatus.dwServiceSpecificExitCode = 0; 
    HRSServiceStatus.dwCheckPoint         = 0; 
    HRSServiceStatus.dwWaitHint           = 0; 

    HRSServiceStatusHandle = RegisterServiceCtrlHandler( 
        TEXT(HRS_SERVICE_NAME), 
        HRSServiceCtrlHandler); 

    if (HRSServiceStatusHandle == (SERVICE_STATUS_HANDLE)0) 
    { 
        HRSSvcDebugOut(" [HRS_SERVICE_NAME] RegisterServiceCtrlHandler \
                             failed %d\n", GetLastError()); 
        return; 
    } 

    // Initialization code goes here. 
    status = HRSServiceInitialization(argc,argv, &specificError); 

    // Handle error condition 
    if (status != NO_ERROR) 
    { 
        HRSServiceStatus.dwCurrentState       = SERVICE_STOPPED; 
        HRSServiceStatus.dwCheckPoint         = 0; 
        HRSServiceStatus.dwWaitHint           = 0; 
        HRSServiceStatus.dwWin32ExitCode      = status; 
        HRSServiceStatus.dwServiceSpecificExitCode = specificError; 

        SetServiceStatus (HRSServiceStatusHandle, &HRSServiceStatus); 
        return; 
    } 

    // Initialization complete - report running status. 
    HRSServiceStatus.dwCurrentState       = SERVICE_RUNNING; 
    HRSServiceStatus.dwCheckPoint         = 0; 
    HRSServiceStatus.dwWaitHint           = 0; 

    if (!SetServiceStatus (HRSServiceStatusHandle, &HRSServiceStatus)) 
    { 
        status = GetLastError(); 
        HRSSvcDebugOut(" [HRS_SERVICE_NAME] SetServiceStatus error\
                             %ld\n",status); 
    } 

    // This is where the service does its work. 
    // CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)HRS_thread,  NULL, 0, &dwThreadId);
    g_hMainProcess = HRS_CreateThread();

    HRSSvcDebugOut(" [HRS_SERVICE_NAME] Returning the Main Thread \n",0); 

    return; 
} 


// Stub initialization function. 
DWORD HRSServiceInitialization(DWORD   argc, LPTSTR  *argv, 
                                     DWORD *specificError) 
{ 
    argv; 
    argc; 
    specificError; 
    return(0); 
} 


VOID WINAPI HRSServiceCtrlHandler (DWORD Opcode) 
{ 
    DWORD status; 

    switch(Opcode) 
    { 
    case SERVICE_CONTROL_PAUSE: 
        // Do whatever it takes to pause here. 
        HRSServiceStatus.dwCurrentState = SERVICE_PAUSED; 
        break; 

    case SERVICE_CONTROL_CONTINUE: 
        // Do whatever it takes to continue here. 
        HRSServiceStatus.dwCurrentState = SERVICE_RUNNING; 
        break; 

    case SERVICE_CONTROL_STOP: 
        // Do whatever it takes to stop here. 
        HRSServiceStatus.dwWin32ExitCode = 0; 
        HRSServiceStatus.dwCurrentState  = SERVICE_STOPPED; 
        HRSServiceStatus.dwCheckPoint    = 0; 
        HRSServiceStatus.dwWaitHint      = 0;

        // ֹͣ���񣬻�����Դ
        HRS_StopService();

        if (!SetServiceStatus (HRSServiceStatusHandle, 
            &HRSServiceStatus))
        { 
            status = GetLastError(); 
            HRSSvcDebugOut(" [HRS_SERVICE_NAME] SetServiceStatus error \
                                 %ld\n",status); 
        } 

        HRSSvcDebugOut(" [HRS_SERVICE_NAME] Leaving HRSService \n",0); 
        return; 

    case SERVICE_CONTROL_INTERROGATE: 
        // Fall through to send current status. 
        break; 

    default: 
        HRSSvcDebugOut(" [HRS_SERVICE_NAME] Unrecognized opcode %ld\n", 
            Opcode); 
    } 

    // Send current status. 
    if (!SetServiceStatus (HRSServiceStatusHandle,  &HRSServiceStatus)) 
    { 
        status = GetLastError(); 
        HRSSvcDebugOut(" [HRS_SERVICE_NAME] SetServiceStatus error \
                             %ld\n",status); 
    } 
    return; 
} 


HANDLE HRS_CreateThread(void)
{
    HANDLE hThread;

    hThread = NG_CreateThread(HRS_ThreadFunc, NULL, NGTHREAD_RUNNING);

    return hThread ;
}


MTASK *g_pMtask = NULL;

void HRS_StopService()
{
    MTask_Destroy(g_pMtask);
    g_pMtask = NULL;

    NG_CloseHandle(g_hMainProcess);

    g_hMainProcess = NULL;

    MP_FindPackMgr_Close();

    NGSock_SysClose();

    NG_malloc_close();

}

extern "C" int HRSService_Main(MTASK *pMtask);


void * HRS_ThreadFunc(void *pArg)
{
    NGSock_SysInit();

    MP_FindPackMgr_Init();
    g_pMtask = MTask_Create();

    //WinPrint(" HRS_ThreadFunc Begin \n");

    //MTASK *pMTask = (MTASK* )pArg;
    if (NULL == g_pMtask)
    {
        return NULL;
    }

    if (ERR_FAILED == HRSService_Main(g_pMtask))//����HRSService_Main����
    {
        //WinPrint(" ThreadFunc Begin Failed\n");
    }

    NGClock_Delay(1000);

    return NULL;
}
