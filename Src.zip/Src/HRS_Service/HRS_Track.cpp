
#include "HRS_RMCalc.h"
#include "HRS_FMCalc.h"

#include "HRS_Track.h"

#include "HRS_ServerCfg.h"
#include "HRS_ModuleName.h"

CHRS_Track::CHRS_Track()
{
    m_pPlanData = NULL;
    m_pModule   = NULL;

    m_nTotalPackNum = 0;
    m_nFMCurPackNo  = 0;

    const int nMsgBuffLen(1000);

    m_L1FMMsgQue = MsgQueue_Create(nMsgBuffLen);

    m_nCommTime = 0;

    m_nTelTotalTime = 0;
}


CHRS_Track::~CHRS_Track()
{
    if (NULL != m_pRunTable)
    {
        delete m_pRunTable;
    }

    if (NULL != m_pOnLinePlate)
    {
        delete m_pOnLinePlate;
    }

    if (NULL != m_pRMSched)
    {
        NG_free(m_pRMSched);
    }

    if (NULL != m_pModule)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);
    }

    if (NULL != m_L1FMMsgQue)
    {
        MsgQueue_Destroy(m_L1FMMsgQue, NG_free);
    }
}


/** Method:    TrackDataInit
    ���ƽ���һ��գ������¸ְ�ʱ����ģ���������ݳ�ʼ�� 

    @return int - �ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CHRS_Track::TrackDataInit()
{
    memset(m_pPlanData, 0, sizeof(HRS_PLAN_DATA));
    memset(&m_RMAllOutData, 0 , sizeof(HRS_RM_ALL_OUT_DATA));

    memset(&m_RMGUIData, 0 , sizeof(HRS_RM_DATA_FROM_GUI));

    m_nGetRMDataState = ERR_FAILED;
    m_nClacRMState    = ERR_FAILED;

    m_nSetSteelInfo  = ERR_SUCCESS;
    m_nSetGUIRMState = ERR_SUCCESS;
    m_nGetGUIRMState = ERR_FAILED;

    memset(&m_FMAllOutData, 0 , sizeof(HRS_FM_ALL_OUT_DATA));
    memset(&m_FMSched, 0 , sizeof(HRS_FM_SCHED));

    memset(&m_FMStrData, 0 , sizeof(HRS_FM_STRATEGY_DATA));

    m_nGetFMDataState = ERR_FAILED;
    m_nClacFMState    = ERR_FAILED;

    m_nSetFMDataState   = ERR_FAILED;
    m_nSetGUIFMState    = ERR_SUCCESS;
    m_nGetGUIFMState    = ERR_FAILED;

    m_nSetL1FMState = ERR_FAILED;
    m_nGetL1FMState = ERR_FAILED;

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));
    memset(&m_FMData, 0 , sizeof(HRS_FM_DATA));

    memset(&m_RollInfo, 0 , sizeof(HRS_ROLL_INFO));
    memset(&m_VROperation, 0 , sizeof(HRS_VR_OPERATION));

    m_nGetVRRollInfoState = ERR_FAILED;
    m_nGetVROperState     = ERR_FAILED;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;
    m_nSetVRFMState  = ERR_FAILED;

    m_nGetVRActState = ERR_FAILED;
    m_nGetVRRMState  = ERR_FAILED;
    m_nGetVRFMState  = ERR_FAILED;

    m_nPlateOnLineState = ERR_FAILED;
    m_nLogoutState      = ERR_SUCCESS;

    m_nTrackStart = ERR_FAILED;
    m_nCalcL1Ave  = ERR_FAILED;
    m_nSetGUIL1Ave = ERR_SUCCESS;

    m_nGetRMSchedState = ERR_FAILED;
    m_nGetFMSchedState = ERR_FAILED;

    m_nFinish = ERR_FAILED;

    return ERR_SUCCESS;
}


/** Method:    Initial
    ����ģ���ʼ�� 

    @return int - �ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CHRS_Track::Initial()
{
    int nRet = -1;

    m_pModule = (CHRSEquipParaMgr *)CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, m_pModule);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    m_pRunTable  = new CRMRunTable;
    if (NULL == m_pRunTable)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        return ERR_FAILED;
    }

    m_pOnLinePlate = new CHRS_Plate;
    if (NULL == m_pOnLinePlate)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        return ERR_FAILED;
    }

    //����ͨ��ʵ��(gui)
    m_pCServerGUIComm = new CHRSServerComm;
    if (NULL == m_pCServerGUIComm)
    {
        error_log("HRSService.log", 
            "m_pCServerGUIComm Failed.\r\n");

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        return ERR_FAILED;
    }

    nRet = m_pCServerGUIComm->ServerCommCreate(HRS_SERVER_GUI_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        error_log("HRSServiceComm.log", "Connect GUI  Filed!\n");

        /*printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
               HRS_SERVER_GUI_COMM_CFG);
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerGUIComm;

        return ERR_FAILED;*/
    }

    //����ͨ��ʵ��(L1)
    m_pCServerL1Comm = new CHRSServerComm;
    if (NULL == m_pCServerL1Comm)
    {
        error_log("HRSService.log", 
            "m_pCServerL1Comm Failed.\r\n");

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;

        return ERR_FAILED;
    }

    nRet = m_pCServerL1Comm->ServerCommCreate(HRS_SERVER_L1_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        error_log("HRSServiceComm.log", "Connect L1  Filed!\n");

        /*printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
            HRS_SERVER_L1_COMM_CFG);

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;

        return ERR_FAILED;*/
    }

    //����ͨ��ʵ��(VR)
    m_pCServerVRComm = new CHRSServerComm;
    if (NULL == m_pCServerVRComm)
    {
        error_log("HRSService.log", 
                   "m_pCServerVRComm Failed.\r\n");

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pRunTable;
        delete m_pOnLinePlate;
        return ERR_FAILED;
    }

    nRet = m_pCServerVRComm->ServerCommCreate(HRS_SERVER_VR_COMM_CFG);
    if (nRet == ERR_FAILED)
    {
        /*printf("m_pCServerGUIComm->ServerCommCreate(%s) Failed.\r\n", 
            HRS_SERVER_L1_COMM_CFG);

        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;*/

        error_log("HRSServiceComm.log", "Connect VR  Filed!\n");
    }

    memset(&m_FMAllData, 0 , sizeof(HRS_FM_ALL_DATA));
    memset(&m_RMAllData, 0 , sizeof(HRS_RM_ALL_DATA));

    m_pCServerIBAComm = new CHRSServerComm;
    if (NULL != m_pCServerIBAComm)
    {
        nRet = m_pCServerIBAComm->ServerIBACommCreate();
        if (nRet == ERR_FAILED)
        {
            error_log("HRSServiceComm.log", "Connect iba  Filed!\n");
        }
    }

    // ��ȡ������
    nRet = m_pModule->GetAllStandPara(&m_FMAllData.AllStandPara);
    if (nRet == ERR_FAILED)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    nRet = m_pModule->GetAllStandPara(&m_RMAllData.AllStandPara);
    if (nRet == ERR_FAILED)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    m_pEquipInfo = new CHRS_EquipInfo;
    if (NULL == m_pEquipInfo)
    {
        CHRSEquipParaMgr_Destroy(m_pModule);

        delete m_pRunTable;
        delete m_pOnLinePlate;
        delete m_pCServerL1Comm;
        delete m_pCServerGUIComm;
        delete m_pCServerVRComm;

        return ERR_FAILED;
    }

    m_pPlanData   = (HRS_PLAN_DATA *)NG_malloc(sizeof(HRS_PLAN_DATA));
    memset(m_pPlanData, 0, sizeof(HRS_PLAN_DATA));

    m_pRMSched    = (HRS_RM_SCHED *)NG_malloc(sizeof(HRS_RM_SCHED));

    memset(&m_RMAllOutData, 0 , sizeof(HRS_RM_ALL_OUT_DATA));

    memset(&m_RMGUIData, 0 , sizeof(HRS_RM_DATA_FROM_GUI));

    m_nGetRMDataState = ERR_FAILED;
    m_nClacRMState    = ERR_FAILED;

    m_nSetSteelInfo  = ERR_SUCCESS;

    m_nSetGUIRMState = ERR_SUCCESS;
    m_nGetGUIRMState = ERR_FAILED;

    memset(&m_FMAllOutData, 0 , sizeof(HRS_FM_ALL_OUT_DATA));
    memset(&m_FMSched, 0 , sizeof(HRS_FM_SCHED));

    memset(&m_FMStrData, 0 , sizeof(HRS_FM_STRATEGY_DATA));

    m_nGetFMDataState = ERR_FAILED;
    m_nClacFMState    = ERR_FAILED;

    m_nSetFMDataState   = ERR_FAILED;
    m_nSetGUIFMState    = ERR_SUCCESS;
    m_nGetGUIFMState    = ERR_FAILED;

    m_nSetL1FMState = ERR_FAILED;
    m_nGetL1FMState = ERR_FAILED;

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));
    memset(&m_FMData, 0 , sizeof(HRS_FM_DATA));

    memset(&m_RollInfo, 0 , sizeof(HRS_ROLL_INFO));
    memset(&m_VROperation, 0 , sizeof(HRS_VR_OPERATION));

    m_nGetVRRollInfoState = ERR_FAILED;
    m_nGetVROperState     = ERR_FAILED;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;
    m_nSetVRFMState  = ERR_FAILED;

    m_nGetVRActState = ERR_FAILED;
    m_nGetVRRMState  = ERR_FAILED;
    m_nGetVRFMState  = ERR_FAILED;

    m_nPlateOnLineState = ERR_FAILED;
    m_nLogoutState      = ERR_SUCCESS;

    printf("CHRS_Track::Initial() Successful.\r\n");

    m_nTrackStart = ERR_FAILED;
    m_nCalcL1Ave  = ERR_FAILED;
    m_nSetGUIL1Ave = ERR_SUCCESS;

    m_nGetRMSchedState = ERR_FAILED;
    m_nGetFMSchedState = ERR_FAILED;

    m_nFinish = ERR_FAILED;
    return ERR_SUCCESS;
}


/** Method:    Login
    ������¼ 

    @return int - �ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CHRS_Track::Login()
{
    if (NULL == m_pPlanData || NULL == m_pOnLinePlate 
        || HRS_DATA_TYPE_L1_SIMULATE == m_FMGUIData.DataHead.nDataType)
    {
        return ERR_FAILED;
    }

    int nRet = -1;
    //����û�иְ壬�ְ��¼
    if (ERR_FAILED == m_pRunTable->GetTableState()
        && ERR_FAILED == m_nPlateOnLineState)
    {
        //�ְ����ݳ�ʼ��
        /*if (ERR_SUCCESS == m_nClacRMState 
            && ERR_SUCCESS == m_nClacFMState 
            && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())*/
        if (ERR_SUCCESS == m_nGetRMSchedState
            && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())
        {
            m_pPlanData->SlabData     = m_L1RMSched.SlabData;
            m_pPlanData->dTargetGauge = m_L1RMSched.dTargetGauge;
            m_pPlanData->dTargetWidth = m_L1RMSched.dTargetGauge;

            nRet = m_pOnLinePlate->PlateLogIn(m_pPlanData);
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            //�������ݳ�ʼ��
            nRet = m_pRunTable->RunTableInit();
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            int nPackNum = m_pCServerL1Comm->GetL1FMNum();

            m_pEquipInfo->SetRMSched(&m_L1RMSched.stRoughRollSched);
            m_pEquipInfo->SetEquipFM(m_pCServerL1Comm->GetL1FMSteelTail());

            m_pRunTable->SetEquipF7Speed(m_pCServerL1Comm->GetF7Speed());
            m_pRunTable->SetEquipF7TableEnd(m_pCServerL1Comm->GetL1FMSteelTail());

            nRet = m_pRunTable->SetTableInfo(&m_L1RMSched, 
                                      nPackNum, 
                                      m_pCServerL1Comm->GetF7SteelLen());
            if (ERR_FAILED == nRet)
            {
                return ERR_FAILED;
            }

            m_nTotalPackNum = nPackNum;

            m_nPlateOnLineState = ERR_SUCCESS;

            printf("�ְ��¼�ɹ���\n");

            return ERR_SUCCESS;
        }
    }

    return ERR_FAILED;
}


/** Method:    Logout
    ����ע�� 

    @param void - ��
    
    @return int - �ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CHRS_Track::Logout(void)
{
    if (ERR_SUCCESS == m_pRunTable->GetTableState())
    {
        m_nTrackStart = ERR_SUCCESS;
        return ERR_FAILED;
    }
    else if (ERR_SUCCESS == m_nGetRMSchedState 
             && ERR_SUCCESS == m_nTrackStart)
    {
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n");
        printf("�ְ�ע���ɹ���\n\n\n\n");

        m_pCServerL1Comm->SetL1FMState();

        TrackDataInit();

        m_nFMCurPackNo = 0;
    }

    //if (ERR_SUCCESS == m_nPlateOnLineState && ERR_SUCCESS == m_nLogoutState)
    //{
    //    return ERR_SUCCESS;
    //}

    ////�ְ���Ϣ��ʼ��
    //int nRet = m_pOnLinePlate->PlateLogOut();

    ////������Ϣ��ʼ��
    //m_pRunTable->RunTableInit();

    ////����������ݳ�ʼ��
    ////m_pRMSched = NULL;

    //m_nPlateOnLineState = ERR_FAILED;

    return ERR_SUCCESS;
}


int  CHRS_Track::VRAactionDataInit()
{
    m_VRAactionData.sRMDeviceCommand            = 0x00;
    m_VRAactionData.sHeatRetentionCoversCommand = 0x00;
    m_VRAactionData.sFMDeviceCommand            = 0x80;
    m_VRAactionData.sPowerCooling1Top           = 0x00;
    m_VRAactionData.sPowerCooling1Bottom        = 0x00;
    m_VRAactionData.sRegularCoolingTop          = 0x00;
    m_VRAactionData.sRegularCoolingBottom       = 0x00;
    m_VRAactionData.sPowerCooling2Top           = 0x00;
    m_VRAactionData.sPowerCooling2Bottom        = 0x00;
    m_VRAactionData.sTrimmingCoolingTop         = 0x00;
    m_VRAactionData.sTrimmingCoolingBottom      = 0x00;
    m_VRAactionData.sSideSprayInterzone         = 0x00;
    m_VRAactionData.sSideSprayEntryExit         = 0x00;
    m_VRAactionData.fWD1EnterRollerTableSpeed   = 0;
    m_VRAactionData.fWD1RollerTableSpeed        = 0;
    m_VRAactionData.fWD1ExitRollerTableSpeed    = 0;
    m_VRAactionData.fR1EnterRollerTableSpeed    = 0;
    m_VRAactionData.fE1Speed                    = 1.5;
    m_VRAactionData.fR1Speed                    = 1.5;
    m_VRAactionData.fR1ExitRollerTableSpeed     = 0;
    m_VRAactionData.fR2EnterRollerTableSpeed    = 0;
    m_VRAactionData.fE2Speed                    = 1.5;
    m_VRAactionData.fR2Speed                    = 1.5;
    m_VRAactionData.fR2ExitRollerTableSpeed     = 0;
    m_VRAactionData.fMiddleRollerTableSpeed     = 0;
    m_VRAactionData.fCSExitRollerTableSpeed     = 0;
    m_VRAactionData.fWD2RollerTableSpeed        = 0;
    m_VRAactionData.fE3Speed                    = 1.5;
    m_VRAactionData.fRunOutRollerTableSpeed     = 0;
    m_VRAactionData.fACCRollerTableSpeed        = 0;
    m_VRAactionData.fE1EntrySGWidth             = 1780;
    m_VRAactionData.fE1Gap                      = 1780;
    m_VRAactionData.fR1Gap                      = 300;
    m_VRAactionData.fR1ExitSGWidth              = 1780;
    m_VRAactionData.fE2EntrySGWidth             = 1780;
    m_VRAactionData.fE2Gap                      = 1780;
    m_VRAactionData.fR2Gap                      = 300;
    m_VRAactionData.fR2ExitSGWidth              = 1780;
    m_VRAactionData.fCSEntrySGWidth             = 1780;
    m_VRAactionData.fF2EntrySGWidth             = 1780;
    m_VRAactionData.fF3EntrySGWidth             = 1780;
    m_VRAactionData.fF4EntrySGWidth             = 1780;
    m_VRAactionData.fF5EntrySGWidth             = 1780;
    m_VRAactionData.fF6EntrySGWidth             = 1780;
    m_VRAactionData.fE3Gap                      = 1780;

    for (int i = 0; i < 7; i++)
    {
        if (i < 4)
        {
            m_VRAactionData.VRGap[i].fF1DGap = 70;
            m_VRAactionData.VRGap[i].fF1OGap = 70;
        }
        else
        {
            m_VRAactionData.VRGap[i].fF1DGap = 60;
            m_VRAactionData.VRGap[i].fF1OGap = 60;
        }

        if (i < 6)
        {
            m_VRAactionData.fL1Angle[i] = 10;
        }
        m_VRAactionData.fFMSpeed[i]      = 1.5;
    }

    return ERR_SUCCESS;
}


int  CHRS_Track::RMDataInit()
{
    m_RMData.sPlateBasicID1                     = 1;
    m_RMData.sFurnaceID1                        = 1;
    m_RMData.sPlateBasicID2                     = 0;
    m_RMData.sFurnaceID2                        = 0;
    m_RMData.sPlateBasicID3                     = 0;
    m_RMData.sFurnaceID3                        = 0;
    m_RMData.sPlateBasicID4                     = 0;
    m_RMData.sFurnaceID4                        = 0;

    m_RMData.fslabThickness1                    = 0;
    m_RMData.fslabWidth1                        = 0;
    m_RMData.fslabLength1                       = 0;
    m_RMData.fStripThickness1                   = 0;
    m_RMData.fStripWidth1                       = 0;
    m_RMData.fStripLength1                      = 0;
    m_RMData.fStrip1HeadPosition                = 0;
    m_RMData.fStrip1tailPosition                = 0;
    m_RMData.fSlabThickness2                    = 0;
    m_RMData.fSlabWidth2                        = 0;
    m_RMData.fSlabLength2                       = 0;
    m_RMData.fStripThickness2                   = 0;
    m_RMData.fStripWidth2                       = 0;
    m_RMData.fStripLength2                      = 0;
    m_RMData.fStrip2HeadPosition                = 0;
    m_RMData.fStrip2tailPosition                = 0;
    m_RMData.fSlabThickness3                    = 0;
    m_RMData.fSlabWidth3                        = 0;
    m_RMData.fSlabLength3                       = 0;
    m_RMData.fStripThickness3                   = 0;
    m_RMData.fStripWidth3                       = 0;
    m_RMData.fStripLength3                      = 0;
    m_RMData.fStrip3HeadPosition                = 0;
    m_RMData.fStrip3tailPosition                = 0;
    m_RMData.fSlabThickness4                    = 0;
    m_RMData.fSlabWidth4                        = 0;
    m_RMData.fSlabLength4                       = 0;
    m_RMData.fStripThickness4                   = 0;
    m_RMData.fStripWidth4                       = 0;
    m_RMData.fStripLength4                      = 0;
    m_RMData.fStrip4HeadPosition                = 0;
    m_RMData.fStrip4tailPosition                = 0;
    m_RMData.fSlabDeleted                       = 0;

    m_RMData.sR1TotalPassNum                    = 0;
    m_RMData.sR1CurPassNum                      = 0;
    m_RMData.sR2TotalPassNum                    = 0;
    m_RMData.sR2CurPassNum                      = 0;

    m_RMData.RM1Data.fR1SpeedReference          = 1.5;
    m_RMData.RM1Data.fR1SpeedActualTopWorkRoll  = 1.5;
    m_RMData.RM1Data.fR1SpeedActualBotWorkRoll  = 1.5;
    m_RMData.RM1Data.fR1SpeedBal1               = 0;
    m_RMData.RM1Data.fR1SpeedBal2               = 0;
    m_RMData.RM1Data.fR1SGEntryWidthReference   = 1780;
    m_RMData.RM1Data.fR1SGEntryWidthActual      = 1780;
    m_RMData.RM1Data.fR1SGEntryForceReference   = 0;
    m_RMData.RM1Data.fR1SGEntryForceActual      = 0;
    m_RMData.RM1Data.fE1GapReference            = 890;
    m_RMData.RM1Data.fE1GapActual               = 890;
    m_RMData.RM1Data.fE1ForceReference          = 0;
    m_RMData.RM1Data.fE1ForceActual             = 0;
    m_RMData.RM1Data.fR1GapAvgReference         = 300;
    m_RMData.RM1Data.fR1GapAvgActual            = 300;
    m_RMData.RM1Data.fR1GapWSReference          = 300;
    m_RMData.RM1Data.fR1GapWSActual             = 300;
    m_RMData.RM1Data.fR1GapDSReference          = 300;
    m_RMData.RM1Data.fR1GapDSActual             = 300;
    m_RMData.RM1Data.fR1GapTiltReference        = 0;
    m_RMData.RM1Data.fR1GapTiltActual           = 0;
    m_RMData.RM1Data.fR1ForceReference          = 0;
    m_RMData.RM1Data.fR1ForceActual             = 0;
    m_RMData.RM1Data.fR1SGExitWidthReference    = 1780;
    m_RMData.RM1Data.fR1SGExitWidthActual       = 1780;
    m_RMData.RM1Data.fR1SGExitForceReference    = 0;
    m_RMData.RM1Data.fR1SGExitForceActual       = 0;

    m_RMData.RM2Data.fR2SpeedReference          = 1.5;
    m_RMData.RM2Data.fR2SpeedActualTopWorkRoll  = 1.5;
    m_RMData.RM2Data.fR2SpeedActualBotWorkRoll  = 1.5;
    m_RMData.RM2Data.fR2SpeedBal1               = 0;
    m_RMData.RM2Data.fR2SpeedBal2               = 0;
    m_RMData.RM2Data.fR2SGEntryWidthReference   = 1780;
    m_RMData.RM2Data.fR2SGEntryWidthActual      = 1780;
    m_RMData.RM2Data.fR2SGEntryForceReference   = 0;
    m_RMData.RM2Data.fR2SGEntryForceActual      = 0;
    m_RMData.RM2Data.fE2GapReference            = 890;
    m_RMData.RM2Data.fE2GapActual               = 890;
    m_RMData.RM2Data.fE2ForceReference          = 0;
    m_RMData.RM2Data.fE2ForceActual             = 0;
    m_RMData.RM2Data.fR2GapAvgReference         = 300;
    m_RMData.RM2Data.fR2GapAvgActual            = 300;
    m_RMData.RM2Data.fR2GapWSReference          = 300;
    m_RMData.RM2Data.fR2GapWSActual             = 300;
    m_RMData.RM2Data.fR2GapDSReference          = 300;
    m_RMData.RM2Data.fR2GapDSActual             = 300;
    m_RMData.RM2Data.fR2GapTiltReference        = 0;
    m_RMData.RM2Data.fR2GapTiltActual           = 0;
    m_RMData.RM2Data.fR2ForceReference          = 0;
    m_RMData.RM2Data.fR2ForceActual             = 0;
    m_RMData.RM2Data.fR2SGExitWidthReference    = 1780;
    m_RMData.RM2Data.fR2SGExitWidthActual       = 1780;
    m_RMData.RM2Data.fR2SGExitForceReference    = 0;
    m_RMData.RM2Data.fR2SGExitForceActual       = 0;

    return ERR_SUCCESS;
}


/** Method:    SetEquipState
    �趨�豸״̬ 

    
    @return int - �ɹ�����ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CHRS_Track::SetEquipState()
{
    //�ְ��¼״̬
    if (ERR_FAILED == m_nPlateOnLineState)
    {
        return ERR_FAILED;
    }

    //��ȡ������Ϣ
    if (NULL == m_pRunTable)
    {
        return ERR_FAILED;
    }

    memset(&m_VRAactionData, 0 , sizeof(HRS_VR_ACTION));
    memset(&m_RMData, 0 , sizeof(HRS_RM_DATA));

    VRAactionDataInit();
    RMDataInit();

    m_RMData.fslabThickness1 = m_RMGUIData.PlanData.SlabData.dSlabGauge;
    m_RMData.fslabWidth1 = m_RMGUIData.PlanData.SlabData.dSlabWidth;
    m_RMData.fslabLength1 = m_RMGUIData.PlanData.SlabData.dSlabLen;

    m_RMData.fStripThickness1 = m_RMGUIData.PlanData.dTargetGauge;
    m_RMData.fStripWidth1 = m_RMGUIData.PlanData.dTargetWidth;
    if (ERR_SUCCESS == m_pEquipInfo->GetFMState())
    {
        m_RMData.fStrip1HeadPosition =
                                   m_FMData.OnePlateData[0].fStripHeadPosition;
        m_RMData.fStrip1tailPosition = 
                                   m_FMData.OnePlateData[0].fStriptailPosition;

        m_RMData.fStripLength1 = m_FMData.OnePlateData[0].fStripLength;
    }
    else
    {
        m_RMData.fStripLength1 = 
                   m_RMData.fStrip1HeadPosition - m_RMData.fStrip1tailPosition;
    }

    m_RMData.RM1Data.fR1SGEntryWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM1Data.fR1SGEntryWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;

    m_RMData.RM2Data.fR2SGEntryWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM2Data.fR2SGEntryWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;


    m_RMData.RM1Data.fR1SGExitWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM1Data.fR1SGExitWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;

    m_RMData.RM2Data.fR2SGExitWidthReference = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;
    m_RMData.RM2Data.fR2SGExitWidthActual    = 
                                        m_RMGUIData.PlanData.dTargetWidth + 10;

    if (HRS_VR_PLATE_NO < strlen(m_RMGUIData.PlanData.SlabData.szStripNo))
    {
        memcpy(m_RMData.szPlateNo1, 
               m_RMGUIData.PlanData.SlabData.szStripNo, 
               HRS_VR_PLATE_NO);
    }
    else
    {
        strcpy(m_RMData.szPlateNo1, m_RMGUIData.PlanData.SlabData.szStripNo);
    }

    m_pRunTable->GetTableInfo(m_VRAactionData, m_RMData);
    //�õ����������Ϣ���ڴ˺����л��еõ��ְ�λ����Ϣ�ĺ��������ܽ�һ���ҵ�λ����Ϣ���㺯�����ԣ�
	//�������m_RMData�е�ֵ���ڸú����еõ�����

    if (ERR_FAILED == m_pRunTable->GetTableState())
    {
        return ERR_FAILED;
    }

    //�����豸״̬
    if (NULL == m_pEquipInfo)
    {
        return ERR_FAILED;
    }

    m_pEquipInfo->GetRMEquipData(m_VRAactionData, m_RMData);

    if(m_RMData.sR1CurPassNum > 0)
    {
        printf("sR1CurPassNum");
    }

    if(m_RMData.sR2CurPassNum > 0)
    {
        printf("sR2CurPassNum");
    }

    m_nGetVRActState = ERR_SUCCESS;
    m_nGetVRRMState  = ERR_SUCCESS;

    m_nSetVRActState = ERR_FAILED;
    m_nSetVRRMState  = ERR_FAILED;

    return ERR_SUCCESS;
}


int CHRS_Track::SendOnLineData()
{
    int nRet = -1;

    if (NULL == m_pCServerGUIComm
        && NULL == m_pCServerL1Comm 
        && NULL == m_pCServerVRComm)
    {
        return ERR_FAILED;
    }

    //���ʹ�����̵�GUI
    if (ERR_FAILED == m_nSetGUIRMState && ERR_SUCCESS == m_nClacRMState)
    {
        nRet = m_pCServerGUIComm->SetRMSched(m_pRMSched);

        m_nSetGUIRMState = ERR_SUCCESS;

        m_nClacRMState   = ERR_FAILED;
    }

    //���;�����̵�GUI
    if (ERR_FAILED == m_nSetGUIFMState && ERR_SUCCESS == m_nClacFMState)
    {
        nRet = m_pCServerGUIComm->SetFMSched(&m_FMSched);

        m_nSetGUIFMState = ERR_SUCCESS;

        m_nClacFMState   = ERR_FAILED;
    }

    //����ͨ��״̬��GUI
    if (ERR_SUCCESS == GetServiceCommState())
    {
        m_pCServerGUIComm->SetServiceCommState(&m_ServiceCommState);
    }

    //���;�ֵ��GUI
    if (ERR_FAILED == m_nSetGUIL1Ave 
        && ERR_FAILED == m_nCalcL1Ave
        && ERR_SUCCESS == m_pCServerL1Comm->GetL1FMState())
    {
        //��ȡ��ֵ
        HRS_FM_DATA *pFMData = m_pCServerL1Comm->GetL1AveData();
                 //�����ֵHRS_FM_DATA�������У�����Щ���ݣ����ԣ�
                 //�о�����ѹ���������������ȣ����ȣ��ٶȣ��ܷ��С�����ݣ�ȫ�Ǿ����ķ���������ݣ�
				 //�ܽ��ýṹ��д��һ�������ƣ���һ�������������Ҫ�õ������ݣ�ͨ��һ���ṹ���װ��һ���ڼ��㡢��ֵ��ֵ����������ʱ�����Թ�ͬ����������һ��д��һ�������У���ֹ������������ĸ�����

        if (ERR_SUCCESS == GetL1Ave(pFMData))
        {
            //��ֵ����    //�����ֵ���ͣ����ǰ���һ���õ��ľ�ֵ�����͵�GUI��
            nRet = m_pCServerGUIComm->SetL1AveData(&m_stSunL1Ave);

            m_nSetGUIL1Ave = ERR_SUCCESS;

            m_nCalcL1Ave = ERR_SUCCESS;
        }
        else
        {
            //�ݲ�����
        }
    }

    //���͸ְ�λ�õ�GUI     
	//����Ըְ�λ����Ϣ�������и��µı���m_RMData��������ѭ������µ��趨�豸״̬��SetEquipState()�����еõ����µģ��ԣ�
    if (ERR_SUCCESS == m_nPlateOnLineState && ERR_SUCCESS == m_nSetSteelInfo)
    {
        m_nSetSteelInfo = ERR_FAILED;
        m_SteelInfo.fStrip1HeadPosition = m_RMData.fStrip1HeadPosition;
        m_SteelInfo.fStrip1tailPosition = m_RMData.fStrip1tailPosition;  
	    //��ϴ���ʣ�²��ֶ�m_SteelInfo�ṹ����fStrip1HeadPosition��fStrip1TailPosition��Ա�ĸ�����������֣���������λ�ñ�������Ч��ֵ���������䣨�ԣ�
		//���Խṹ�����m_RMData�г�Ա���и��µĺ��������Ǹ��ļ��У���˺������ڵ�����һ������CHRS_Track::SetEquipState()��������еĸ��£���ĵط�û��
    }

    if (ERR_SUCCESS == m_nPlateOnLineState && ERR_FAILED == m_nSetSteelInfo )
    {
        //���͵��ְ�λ�õ�GUI
        if (ERR_SUCCESS == m_nFinish)
        {
            m_SteelInfo.fStrip1HeadPosition = 0;
            m_SteelInfo.fStrip1tailPosition = 0;                    //������������˸ְ�ĵ�ǰͷβλ�ã��ԣ�

            nRet = m_pCServerGUIComm->SetSteelInfo(&m_SteelInfo);   //����������Ϊm_SteelInfo��������������в�û�жԸýṹ��m_SteelInfo�����еĸְ�λ����Ϣ���и��£��ԣ�

            m_nFinish = ERR_FAILED;
        }
        else if (m_SteelInfo.fStrip1HeadPosition > 0)
        {
            m_nTelTotalTime = 0;
            nRet = m_pCServerGUIComm->SetSteelInfo(&m_SteelInfo);
        }
				else
				{
					m_nTelTotalTime++;
					if (m_nTelTotalTime >= 50)
					{
						m_nFinish = ERR_SUCCESS;
					}

					error_log("HRSService.log", "���ڸְ�ͷ��Ϊ0�����ݣ�\r\n");
					//��ִ�з��Ͳ���
				}

        if (0 == m_SteelInfo.fStrip1HeadPosition)
        {
            printf("���͸ְ�λ�õ�GUI�ɹ���%f, %f\n\n\n\n\n", 
                   m_SteelInfo.fStrip1HeadPosition, 
                   m_SteelInfo.fStrip1tailPosition);
        }

        m_nSetSteelInfo = ERR_SUCCESS;
    }

    //���͸ְ�λ�õ�GUI
    if (ERR_SUCCESS == m_nFinish)
    {
        m_SteelInfo.fStrip1HeadPosition = 0;
        m_SteelInfo.fStrip1tailPosition = 0;

        nRet = m_pCServerGUIComm->SetSteelInfo(&m_SteelInfo);
        m_nSetSteelInfo = ERR_SUCCESS;

        m_nFinish = ERR_FAILED;
    }

    //���;�����̵�L1
    if (ERR_FAILED == m_nSetL1FMState && ERR_SUCCESS == m_nGetFMSchedState)
    {
        nRet = m_pCServerL1Comm->SetL1FMClac(&m_L1FMSched.stFinishRollSched);
        m_nSetL1FMState  = ERR_SUCCESS;
        m_nGetL1FMState = ERR_FAILED;
        m_nGetFMSchedState = ERR_FAILED;

#if _DEBUG
        printf("����FM��L1�ɹ���");
        LogPrint("TRACKL1Comm.log", "Send Data.  To L1 LoopTimes\r\n");
#endif
    }

    //����RMData��VR
    if (ERR_SUCCESS == m_nGetVRRMState && ERR_FAILED == m_nSetVRRMState)
    {
        nRet = m_pCServerVRComm->SetRMData(&m_RMData);

        if (ERR_SUCCESS == nRet)
        {
            printf("����RM�ɹ���\n");

            m_nSetVRRMState = nRet;
            m_nGetVRRMState = ERR_FAILED;
        } 
    }

    //����VRAaction��VR
    if (ERR_SUCCESS == m_nGetVRActState && ERR_FAILED == m_nSetVRActState)
    {
        nRet = m_pCServerVRComm->SetVRAactionData(&m_VRAactionData);
        if (ERR_SUCCESS == nRet)
        {
            printf("����VR�ɹ���\n");

            m_nSetVRActState = nRet;
            m_nGetVRActState = ERR_FAILED;
        }
    }

    //����FMData��VR
    if (ERR_SUCCESS == m_nGetVRFMState && ERR_FAILED == m_nSetVRFMState)
    {
        nRet = m_pCServerVRComm->SetFMData(&m_FMData);

#if _DEBUG
        printf("����FM�ɹ���\n");
        printf("FMCurPackNo = %d��\n",m_nFMCurPackNo);
#endif
        m_nGetL1FMState = ERR_FAILED;
        m_nSetVRFMState = ERR_SUCCESS;
    }

    if (NULL != m_pCServerIBAComm)
    {
        m_pCServerIBAComm->SetIbaData(&m_FMData);
    }

    //���øְ巢�ͽ�����ʶ
    if (m_nFMCurPackNo > 0 && (m_nTotalPackNum == m_nFMCurPackNo || m_nTelTotalTime >= 100))
    {
        printf("����FM������m_nTotalPackNum = %d\n\n\n\n", m_nTotalPackNum);

        if (m_nTelTotalTime >= 100)
        {
            error_log("HRSService.log", "�ְ��쳣������\r\n\r\n\r\n\r\n");
        }

        m_pEquipInfo->SetFMState(ERR_FAILED);
        m_pRunTable->SetTableState(ERR_FAILED);

        m_nTelTotalTime = 0;
    }

    return ERR_SUCCESS;
}




int CHRS_Track::RecvGUIOnLineData()
{
    int nRet = -1;

    //ͨ�Ż�ȡ����(����GUI)
    if (ERR_FAILED == m_nGetRMDataState && ERR_SUCCESS == m_nSetGUIRMState)
    {
        nRet = m_pCServerGUIComm->GetRMData(m_RMGUIData);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetRMDataState = ERR_SUCCESS;
            m_nSetGUIRMState  = ERR_FAILED;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //��������GUI
    if (ERR_FAILED == m_nGetFMDataState && ERR_SUCCESS == m_nSetGUIFMState)
    {
        nRet = m_pCServerGUIComm->GetFMData(m_FMGUIData);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetFMDataState = ERR_SUCCESS;
            m_nSetGUIFMState  = ERR_FAILED;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //�����������
    if (ERR_FAILED == m_nGetRMSchedState)
    {
        nRet = m_pCServerGUIComm->GetRMSched(m_L1RMSched);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetRMSchedState = ERR_SUCCESS;
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    //�����������
    if (ERR_FAILED == m_nGetFMSchedState)
    {
        nRet = m_pCServerGUIComm->GetFMSched(m_L1FMSched);
        if (ERR_SUCCESS == nRet)
        {
            m_nGetFMSchedState = ERR_SUCCESS;
            m_nSetL1FMState     = ERR_FAILED;

            m_nCalcL1Ave  = ERR_FAILED;

            m_nSetGUIL1Ave = ERR_FAILED;
            //�ӽ������FM��̣��·���L1SIMULATOR,L1���Ϸ������������
            //��˶����в��������ݱ�����ն�������
            m_pCServerL1Comm->ServerCommMsgQueEmpty(HRS_SERVER_FM_L1_PACK,
                                                    HRS_Comm_PackInfo_Destory);

            m_pCServerL1Comm->SetL1FMState();
        }
        else
        {
            //������
        }
    }
    else
    {
        //������
    }

    return ERR_SUCCESS;
}

#if 1


int CHRS_Track::GetL1Ave(void *pData)
{
    if (NULL == pData)
    {
        return ERR_FAILED;
    }

    HRS_FM_DATA *pFMData = (HRS_FM_DATA *)pData;

    memset(&m_stSunL1Ave, 0, sizeof(m_stSunL1Ave));

    //������ֵ��
    HRS_ONE_FM_DATA  *pOneFMData;
    HRS_ONE_FX_DATA  *pOneFXData;

    float  *pfDeliveryGauge = &pFMData->OnePlateData[1].fBarThickness;
    float  *pfDrafRatio = &pFMData->OnePlateData[1].fStriptailPosition;

    for (int i = 0; i < 6; i++)
    {
        pOneFMData = &(pFMData->OneEquitData[i].OneFMData);
        pOneFXData = &(pFMData->OneEquitData[i].OneFXData);

        m_stSunL1Ave.FMActualData[i].dAveDeliveryGauge = *pfDeliveryGauge;
        m_stSunL1Ave.FMActualData[i].dAveDraftRatio = *pfDrafRatio;    
        m_stSunL1Ave.FMActualData[i].dAveRollingForce = pOneFMData->fSumForceActual;
        m_stSunL1Ave.FMActualData[i].dAveTension = pOneFXData->fVRTensionActual;
        m_stSunL1Ave.FMActualData[i].dAveGap = pOneFMData->fGapAvgActual;

        pfDeliveryGauge++;
        pfDrafRatio++;
    }

    m_stSunL1Ave.FMActualData[6].dAveDeliveryGauge = *pfDeliveryGauge;
    m_stSunL1Ave.FMActualData[6].dAveDraftRatio = *pfDrafRatio;
    m_stSunL1Ave.FMActualData[6].dAveRollingForce = pFMData->stFM7Data.fSumForceActual;
    m_stSunL1Ave.FMActualData[6].dAveGap = pFMData->stFM7Data.fGapAvgActual;

    m_stSunL1Ave.FMActualData[6].dAveTension = 0.0;

    return ERR_SUCCESS;
}
#endif


int CHRS_Track::RecvOnLineData()
{
    int nRet = -1;

    //����GUI����
    if (NULL == m_pCServerGUIComm
         && NULL == m_pCServerL1Comm 
         && NULL == m_pCServerVRComm) 
    {
        return ERR_FAILED;
    }

    //����û�иְ�ʱ�������淢�͵�����
    if (ERR_FAILED == m_pRunTable->GetTableState())
    {
        if (NULL != m_pCServerGUIComm)
        {
            RecvGUIOnLineData();
        }
    }
    else
    {
        //������
    }

    //�ְ����е�FM����ʱ����L1�������ݶ����н���FM��������
    if ((ERR_FAILED == m_nGetL1FMState || ERR_FAILED == m_nSetSteelInfo)
        && ERR_SUCCESS == m_pEquipInfo->GetFMState())
    {
        if (NULL != m_pCServerL1Comm)
        {
            nRet = m_pCServerL1Comm->GetL1Data(m_FMData);
            if (ERR_SUCCESS == nRet)
            {
                m_nFMCurPackNo++;

                if (0 == m_FMData.PackHead.sTelDataLength)
                {
                    m_nFinish = ERR_SUCCESS;

                    error_log("Test.log","Send SteelPosition To GUI Finish Pack!\n");
                }

                m_pRunTable->SetFMData(m_FMData);
                m_nGetL1FMState  = nRet;
                m_nGetVRFMState  = nRet;
                m_nSetVRFMState  = ERR_FAILED;
            }
        }
    }

    //����VR
    if (ERR_FAILED == m_nGetVRRollInfoState)
    {
        if (NULL != m_pCServerVRComm)
        {
            nRet = m_pCServerVRComm->GetRollInfo(m_RollInfo);

            m_nGetVRRollInfoState = ERR_FAILED;
        }
    }

    if (ERR_FAILED == m_nGetVROperState)
    {
        if (NULL != m_pCServerVRComm)
        {
            nRet = m_pCServerVRComm->GetVROperation(m_VROperation);

            m_nGetVROperState = ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}


int CHRS_Track::RMSchedClac()
{
    int nRet = -1;
    HRS_STAND_PARA  *pStandPara;

    // ��ȡ������
    m_RMAllData.PlanData     = m_RMGUIData.PlanData;
    m_RMAllData.StrategyData = m_RMGUIData.StrategyData;

    memcpy(&m_RMAllData.PlateData.SlabeData, 
        &m_RMAllData.PlanData.SlabData, 
        sizeof(HRS_SLAB_DATA));

    m_RMAllData.PlateData.dSlabeEntryTemp =
        m_RMGUIData.PlanData.dDischargeTemp;

    char *pszSteelGradeName = m_RMGUIData.szSign;

    CGlobalInstance *pInst = HRS_GetGlobalInstance();

    HRS_DEFORM_RESIST_FACTOR  *pFactor;

    pFactor = NULL;
    if (pInst != NULL )
    {
        CHRSServerCfg *pServerCfg;

        pServerCfg = (CHRSServerCfg *)pInst->QueryNotCheck(
                                 HRS_MOD_NAME_HRS_ServerCfg);
        if (pServerCfg != NULL)
        {
            pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);
            if (pFactor != NULL)
            {
                m_RMAllData.DeformFactor = *pFactor;
            }
        }
    }

    if (pFactor == NULL)
    {
        //���ο�������
        m_RMAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;       // ��������
        m_RMAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_RMAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_RMAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_RMAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        m_RMAllData.DeformFactor.dReserve1 = 1;
        m_RMAllData.DeformFactor.dReserve2 = 1;
    }

    if (NULL == m_pRMSched)
    {
        m_pRMSched = (HRS_RM_SCHED *)NG_malloc(sizeof(HRS_RM_SCHED));
    }

    pStandPara = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_RM1]);
    pStandPara->dMaxWorkingRollerRadius 
        = m_RMGUIData.adWorkingRollerRadius[0];

    pStandPara = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_RM2]);
    pStandPara->dMaxWorkingRollerRadius 
        = m_RMGUIData.adWorkingRollerRadius[1];

    memset(m_pRMSched, 0 , sizeof(HRS_RM_SCHED));

    nRet = HRS_RML2Calc_CalcAllData(&m_RMAllData, &m_RMAllOutData);
	//HRS_RML2Calc_CalcAllData ������HRS_Calc��Ŀ�е�HRS_RMCalc.cpp�ļ���
	//���ã�����������������Ҫ�õ������ݣ��ԣ�
	//��������m_RMAllData,����ṹ������е�m_RMAllData.StrategyData.rm_adjust_R1[0].dSpeedAdjustֵ�ļ��㣬��Ϊ���ڲ㺯���û��õ����ֵ�������ٶȣ�����Ҫ֪��ֵ�ǽ�������������һ�����Ƶ�ֵ��
	//��������ĺ����ǣ���GUI�����ȡ�Ĵ���������1����0���εĲ������ݵ��ٶ�������

    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        //return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_BuildSched(&m_RMAllData, &m_RMAllOutData, m_pRMSched);
	//HRS_RML2Calc_BuildSched������HRS_Calc��Ŀ�е�HRS_RMCalc.cpp�ļ���
	//���ã������л��ܼ�����ת���ɹ�����ݣ��ԣ�

    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        m_nGetRMDataState = ERR_FAILED;

        //return ERR_FAILED;
    }
    else  //�����������������һ�����������̵����ݣ�һ��ת��������̵����ݶ��ɹ��Ļ�����ô��������ͳɹ��ˡ�
    {
        printf("��������ɹ���\n");
    }

    return nRet;
}


int CHRS_Track::FMSchedClac()
{
    int nRet = -1;
    HRS_STAND_PARA  *pStandPara;


    m_FMAllData.PlanData       = m_FMGUIData.PlanData;
    m_FMAllData.FMStrategyData = m_FMGUIData.StrategyData;

    //���ο�������
    memcpy(m_FMAllData.DeformFactor.szSteelGrade, 
        m_FMAllData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);

    char *pszSteelGradeName = m_FMGUIData.szSign;

    CGlobalInstance *pInst = HRS_GetGlobalInstance();

    HRS_DEFORM_RESIST_FACTOR  *pFactor;

    pFactor = NULL;
    if (pInst != NULL )
    {
        CHRSServerCfg *pServerCfg;

        pServerCfg = (CHRSServerCfg *)pInst->QueryNotCheck(
            HRS_MOD_NAME_HRS_ServerCfg);
        if (pServerCfg != NULL)
        {
            pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);
            if (pFactor != NULL)
            {
                m_FMAllData.DeformFactor = *pFactor;
            }
        }
    }

    if (pFactor == NULL)
    {
        //���ο�������
        m_FMAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;       // ��������
        m_FMAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_FMAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_FMAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_FMAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;

        m_FMAllData.DeformFactor.dReserve1 = 1;
        m_FMAllData.DeformFactor.dReserve2 = 1;
    }


    for ( int i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        pStandPara 
            = &(m_RMAllData.AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i]);

        pStandPara->dMaxWorkingRollerRadius 
            = m_FMGUIData.adWorkingRollerRadius[i];
    }

#if HRS_WUST_CLAC
    //��������
    nRet = HRS_FMCalc_WUSTCalc(&m_FMAllData, &m_FMAllOutData);
#else
    //��������
    nRet = HRS_FML2Calc_CalcAllData(&m_FMAllData, &m_FMAllOutData);
#endif

    if (nRet == ERR_FAILED)
    {
        printf("��������ʧ�ܣ�\n");

        m_nGetFMDataState = ERR_FAILED;
        //return ERR_FAILED;
    }

    nRet = HRS_FML2Calc_BuildSched(&m_FMAllData, &m_FMAllOutData, &m_FMSched);
    if (nRet == ERR_FAILED)
    {
        m_nGetFMDataState = ERR_FAILED;

        printf("��������ʧ�ܣ�\n");

        //return ERR_FAILED;
    }
    else
    {
        printf("��������ɹ���\n");
    }

    return nRet;
}



int CHRS_Track::CalcData()
{
    int nRet = -1;

    //��������
    if (ERR_SUCCESS == m_nGetRMDataState && ERR_FAILED == m_nClacRMState)
    {
        int nRet = RMSchedClac();//����RMSchedClac����������������

        m_nClacRMState = nRet;

#if 0
        if (HRS_DATA_TYPE_ONLY_RM_PACK == m_RMGUIData.DataHead.nDataType)
        {
            m_nGetRMDataState = ERR_FAILED;
        }
#else
        m_nGetRMDataState = ERR_FAILED;
#endif

        //m_pPlanData = &m_RMGUIData.PlanData;
    }

    //��������
    if (ERR_SUCCESS == m_nGetFMDataState 
        && ERR_FAILED == m_nClacFMState)
    {
        int nRet = FMSchedClac();

        m_nClacFMState = nRet;
        m_nSetL1FMState = ERR_FAILED;

        //m_pPlanData = &m_RMGUIData.PlanData;

#if 0
        if (HRS_DATA_TYPE_ONLY_FM_PACK == m_FMGUIData.DataHead.nDataType)
        {
            m_nGetFMDataState = ERR_FAILED;
        }
#else
        m_nGetFMDataState = ERR_FAILED;
#endif
    }

    return ERR_SUCCESS;
}


int CHRS_Track::GetServiceCommState()
{
    if (m_nCommTime < 30)
    {
        m_nCommTime++;
        return ERR_FAILED;
    }
    else
    {
        m_nCommTime = 0;
    }

    if (NULL != m_pCServerVRComm )
    {
        int nRecvState = m_pCServerVRComm->GetCommState(HRS_VR_RECVTUNNEL_MAX, 
                                                        HRS_VR_SENDTUNNEL_MAX, 
                                                        HRS_SINGLE_SEND_COMM_TYPE);

        int nSendState = m_ServiceCommState.nServiceVRState = 
                        m_pCServerVRComm->GetCommState(0,
                                                       HRS_VR_RECVTUNNEL_MAX,
                                                       HRS_SINGLE_RECV_COMM_TYPE);

        m_ServiceCommState.nServiceVRState = nRecvState && nSendState;
    }

    if (NULL != m_pCServerL1Comm )
    {
        m_ServiceCommState.nServiceL1State = 
                           m_pCServerL1Comm->GetCommState(0, 
                                                          HRS_L1_TUNNEL_MAX,
                                                          HRS_KEEP_COMM_TYPE);
    }

    return ERR_SUCCESS;
}
 