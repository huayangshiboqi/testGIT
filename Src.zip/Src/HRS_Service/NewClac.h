#include "Temperature.h"

#include "HRS_CalcData.h"
#include "HRS_CommonCalc.h"

#include "HRS_RMCalc.h"


int WUST_FMCalc_CalcAllData(HRS_FM_ALL_DATA *pAllData,
                            HRS_FM_ALL_OUT_DATA *pAllOutData);