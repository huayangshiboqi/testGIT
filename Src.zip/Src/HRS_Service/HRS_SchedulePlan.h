
/* 
 *	FILE
 *      C:\svn_Company\HotContinuousRoll\Src\HRS_Service
 *
 *	DESCRIPTION
 *      �����дģ������XXXXXX		
 *
 *	HISTORY
 *		2016-10-10 11:14 create by zhouweiming.
 *
 */
#ifndef __HRS_SchedulePlan_H__
#define __HRS_SchedulePlan_H__


#include "CGameObj.h"
#include "CGlobalInstance.h"


class CHRSSchedulePlan :public CGameObj {
private:
    HASHTABLE   *m_pPlanDataTable;       // �ڵ�����ΪHRS_PLAN_DATA
public:
    CHRSSchedulePlan();
    virtual ~CHRSSchedulePlan();
public:   // ģ��̳л���Ĺ�����׼�ӿ�
    virtual int Init();

    virtual int Close();

    virtual int Run(UINT uDeltaTime);  

public:   // ��ģ���˽�нӿ�
    int GetPlanData(int nSequentialNo, HRS_PLAN_DATA  *pPlanData);
    int SetPlanData(HRS_PLAN_DATA *pPlanData);

    int RemovePlanData(int nSequentialNo);
};


#ifdef __cplusplus
extern "C" {
#endif



void * CHRSSchedulePlan_Create(CGlobalInstance *pInstance,
                        void *pArg1,
                        void *pArg2,
                        int nArg);
int CHRSSchedulePlan_Init(CGlobalInstance *pInstance, void *pModule);

int CHRSSchedulePlan_Run(CGlobalInstance *pInstance,
                    void *pModule,
                    UINT uDeltaTime);

void CHRSSchedulePlan_Destroy(void *pModule);


#ifdef __cplusplus
}
#endif




#endif // __HRS_SchedulePlan_H__