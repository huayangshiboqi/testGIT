
/* 
 *	FILE
 *      C:\svn_Company\HotContinuousRoll\Src\HRS_Service
 *
 *	DESCRIPTION
 *      �����дģ������XXXXXX		
 *
 *	HISTORY
 *		2016-10-11 11:28 create by zhouweiming.
 *
 */
#ifndef __HRS_AllModule_H__
#define __HRS_AllModule_H__


#ifdef __cplusplus
extern "C" {
#endif

extern  NG_MODULE  *g_ppAllHRSModule[];
extern  char *g_ppszHRSRunModule[];
extern  char *g_ppszHRSCloseModule[];


#ifdef __cplusplus
}
#endif



#endif // __HRS_AllModule_H__