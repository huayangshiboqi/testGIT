
#include "NG.h"
#include "HRS_CalcData.h"
#include "HRS_SchedulePlan.h"




CHRSSchedulePlan::CHRSSchedulePlan()
{

}


CHRSSchedulePlan::~CHRSSchedulePlan()
{

}


int CHRSSchedulePlan::Init()
{
    return ERR_SUCCESS;
}


int CHRSSchedulePlan::Close()
{
    return ERR_SUCCESS;
}


int CHRSSchedulePlan::Run(UINT uDeltaTime)
{
    return ERR_SUCCESS;
}


void *CHRSSchedulePlan_Create(CGlobalInstance *pInstance,
                           void *pArg1,
                           void *pArg2,
                           int nArg)
{
    CHRSSchedulePlan  *pMgr;

    pMgr = new CHRSSchedulePlan;

    printf("CHRSSchedulePlan Module created.\n");

    return pMgr;
}


int CHRSSchedulePlan_Init(CGlobalInstance *pInstance, void *pModule)
{
    CHRSSchedulePlan  *pMgr;
    int nRet;

    pMgr = (CHRSSchedulePlan *)pModule;

    nRet = pMgr->Init();

    printf("CHRSSchedulePlan Module Init.\n");

    return nRet;
}


int CHRSSchedulePlan_Run(CGlobalInstance *pInstance,
                      void *pModule,
                      UINT uDeltaTime)
{
    CHRSSchedulePlan  *pMgr;
    int nRet;

    pMgr = (CHRSSchedulePlan *)pModule;

    nRet = pMgr->Run(uDeltaTime);

    printf("CHRSSchedulePlan Module Run.\n");

    return nRet;
}


void CHRSSchedulePlan_Destroy(void *pModule)
{
    CHRSSchedulePlan  *pMgr;

    pMgr = (CHRSSchedulePlan *)pModule;

    if (pMgr != NULL)
    {
        printf("CHRSSchedulePlan Module Destroy.\n");

        delete pMgr;
    }

    return;
}
