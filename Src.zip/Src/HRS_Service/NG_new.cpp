
#include <stdlib.h>
#include "NG_new.h"
#include "NG_malloc.h"

#if 1

void * operator new(size_t size)
{
    return NG_malloc((unsigned int)size);
}

void * operator new[](size_t size)
{
    return NG_malloc((unsigned int)size);
}

void operator delete(void *p)
{
    NG_free(p);
}

void operator delete[](void *p)
{
    NG_free(p);
}

#endif
