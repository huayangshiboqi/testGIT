
#ifndef _NG_NEW_H__
#define _NG_NEW_H__

#include "NG_malloc.h"

#ifdef __cplusplus
//extern "C" {
#endif
#include <xstring>
using namespace std;



template <class T> class dmalloc_allocator 
{
public:
    typedef T  value_type;
    typedef value_type *   pointer;
    typedef const value_type * const_pointer;
    typedef value_type &       reference;
    typedef const value_type&  const_reference;
    typedef std::size_t        size_type;
    typedef std::ptrdiff_t     difference_type;


    template <class U> struct rebind {typedef dmalloc_allocator<U> other;};
    dmalloc_allocator() {}
    dmalloc_allocator(const dmalloc_allocator&) {}

    template <class U> dmalloc_allocator(const dmalloc_allocator<U> &) {}

    ~dmalloc_allocator() {}

    pointer address(reference x) const 
    {
        return &x;
    }
    const_pointer address(const_reference x ) const 
    { 
        return x;
    }

    pointer allocate(size_type _Count) 
    {
        void *p = NG_malloc(_Count * sizeof(T));
        if (!p)
        {
            throw std::bad_alloc();
        }

        return static_cast<pointer>(p);
    }

    pointer allocate(size_type _Count, const void _FARQ *)
    {	// allocate array of _Count elements, ignore hint
        return (allocate(_Count));
    }


    void deallocate(pointer p, size_type) {
        NG_free(p);
    }

    size_type max_size() const {
        return static_cast<size_type>(-1) / sizeof(T);
    }

    void construct(pointer p, const value_type &x)
    {
        new(p)  value_type(x);
    }

    void destroy(pointer p)
    {
        p->~value_type();
    }

private:
    void operator=(const dmalloc_allocator&);

};


template <class T> inline bool operator == (const dmalloc_allocator<T> &, 
                                            const dmalloc_allocator<T> &)
{
    return true;
}


template <class T> inline bool operator != (const dmalloc_allocator<T> &, 
                                            const dmalloc_allocator<T> &)
{
    return false;
}

// ����Ҫʹ��string�ĵط����������¶���
//typedef basic_string<char, char_traits<char>, dmalloc_allocator<char> > string;


//#define new NG_malloc
//#define delete NG_free

#if 1

void * operator new(size_t size);

void * operator new[](size_t size);

void operator delete(void *p);

void operator delete[](void *p);

#endif

#ifdef __cplusplus
//}
#endif

#endif /* _NG_NEW_H__ */