
#ifndef __HRS_RmWidthLevelTable_H__
#define __HRS_RmWidthLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_RmWidthLevelTable_Init(char *pszOutErr);
void HRS_RmWidthLevelTable_Destroy();
int HRS_RmWidthLevelTable_Query(double dRmWidth, int * nLevel, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_RmWidthLevelTable_H__