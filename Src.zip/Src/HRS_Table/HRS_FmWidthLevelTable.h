
#ifndef __HRS_FmWidthLevelTable_H__
#define __HRS_FmWidthLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_FmWidthLevelTable_Init(char *pszOutErr);
void HRS_FmWidthLevelTable_Destroy();
int HRS_FmWidthLevelTable_Query(double dFmWidth, int * nLevel, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmWidthLevelTable_H__