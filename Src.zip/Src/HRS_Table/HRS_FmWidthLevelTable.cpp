
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_LevelTableBase.h"
#include "HRS_FmWidthLevelTable.h"

extern HRS_TABLE_SCHEMA  HRSTableSchema_Level[];

HRS_TABLE_LEVEL *gpTableFmWidthLevel;

HRS_TABLE_INFO gHRSTableInfo_FmWidthLevel =
{
    "FmWidthLevel",                                 // ����
    3,                                             // ����
    HRSTableSchema_Level,                      // ����ģ�����
    CFG_FM_WIDTH_LEVEL,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_LEVEL,                          // ��������
    0,                                              // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_LEVEL),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmWidthLevel)
};



int HRS_FmWidthLevelTable_Init(char *pszOutErr)
{
    return HRS_LevelTable_Init(&gHRSTableInfo_FmWidthLevel, pszOutErr);
}

void HRS_FmWidthLevelTable_Destroy()
{
    HRS_LevelTable_Destroy(&gHRSTableInfo_FmWidthLevel);
}


int HRS_FmWidthLevelTable_Query(double dFmWidth, int * pnLevel, char *pszOutErr)
{
    int nRet;

    nRet = HRS_LevelTable_Query(&gHRSTableInfo_FmWidthLevel, dFmWidth, pnLevel,
                                pszOutErr);
    if (nRet == ERR_FAILED)
    {
        char szMsg[256];

        sprintf(szMsg, 
            "FmWidth  : %f\r\n"    
            "nLevel   : %d\r\n",  
            dFmWidth, 
            *pnLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}
