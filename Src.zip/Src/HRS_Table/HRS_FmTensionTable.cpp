
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmTensionTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmTension[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TENSION, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TENSION, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TENSION, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TENSION, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TENSION, nFinalTempLevel), sizeof(int)},

    {"SpecTension12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension12), sizeof(double)},
    {"SpecTension23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension23), sizeof(double)},
    {"SpecTension34", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension34), sizeof(double)},
    {"SpecTension45", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension45), sizeof(double)},
    {"SpecTension56", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension56), sizeof(double)},
    {"SpecTension67", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TENSION, dSpecTension67), sizeof(double)},
    { NULL }
};

HRS_TABLE_FM_TENSION *gpTableFmTension;

HRS_TABLE_INFO gHRSTableInfo_FmTension =
{
    "FmTension",                                 // ����
    11,                                             // ����
    HRSTableSchema_FmTension,                      // ����ģ�����
    CFG_FM_TENSION_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_TENSION, dSpecTension12),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_TENSION),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmTension)
};

int HRS_FmTensionTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmTension, pszOutErr);
}

void HRS_FmTensionTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmTension);
}

int HRS_FmTensionTab_Search(HRS_TABLE_FM_TENSION *pTable, char *pszOutErr)
{
    return HRS_SimpleTable_Search(&gHRSTableInfo_FmTension, 
        (void *)pTable, pszOutErr);
}
