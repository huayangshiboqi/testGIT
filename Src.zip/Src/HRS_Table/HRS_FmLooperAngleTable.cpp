
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmLooperAngleTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmLooperAngle[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERANGLE, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERANGLE, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERANGLE, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERANGLE, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERANGLE, nFinalTempLevel), sizeof(int)},

    {"AngleLooper12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper12), sizeof(double)},
    {"AngleLooper23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper23), sizeof(double)},
    {"AngleLooper34", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper34), sizeof(double)},
    {"AngleLooper45", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper45), sizeof(double)},
    {"AngleLooper56", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper56), sizeof(double)},
    {"AngleLooper67", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERANGLE, dAngleLooper67), sizeof(double)},
    { NULL }
};

HRS_TABLE_FM_LOOPERANGLE *gpTableFmLooperAngle;

HRS_TABLE_INFO gHRSTableInfo_FmLooperAngle =
{
    "FmLooperAngle",                                 // ����
    11,                                             // ����
    HRSTableSchema_FmLooperAngle,                      // ����ģ�����
    "FmLooperAngleTable.cfg",                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_LOOPERANGLE, dSpecLooperAngle12),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_LOOPERANGLE),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmLooperAngle)
};

int HRS_FmLooperAngleTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmLooperAngle, pszOutErr);
}

void HRS_FmLooperAngleTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmLooperAngle);
}

int HRS_FmLooperAngleTab_Search(HRS_TABLE_FM_LOOPERANGLE *pTable, char *pszOutErr)
{
    return HRS_SimpleTable_Search(&gHRSTableInfo_FmLooperAngle, 
        (void *)pTable, pszOutErr);
}
