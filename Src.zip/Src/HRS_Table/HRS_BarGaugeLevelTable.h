
#ifndef __HRS_BarGaugeLevelTable_H__
#define __HRS_BarGaugeLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_BarGaugeLevelTable_Init(char *pszOutErr);
void HRS_BarGaugeLevelTable_Destroy();
int HRS_BarGaugeLevelTable_Query(double dFmGauge, int * nLevel, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_BarGaugeLevelTable_H__