
#ifndef __HRS_RmSpeedTable_H__
#define __HRS_RmSpeedTable_H__

#ifdef __cplusplus
extern "C" {
#endif



typedef struct HRS_TABLE_RM_SPEED_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int	nSlabGaugeLevel;                // ������ȵȼ�
    int	nSlabWidthLevel;                // �������ȵȼ�
    int	nBarGaugeLevel;                 // �м�����ȵȼ�
    int	nRMWidthLevel;                  // �������ȼ���
//    int	nFinalTempLevel;                // �����¶ȼ���
    int nPassMode;

    double dEntrySpeedR11;
    double dRollingSpeedR11;
    double dExitSpeedR11;

    double dEntrySpeedR12;
    double dRollingSpeedR12;
    double dExitSpeedR12;

    double dEntrySpeedR13;
    double dRollingSpeedR13;
    double dExitSpeedR13;

    double dEntrySpeedR21;
    double dRollingSpeedR21;
    double dExitSpeedR21;

    double dEntrySpeedR22;
    double dRollingSpeedR22;
    double dExitSpeedR22;

    double dEntrySpeedR23;
    double dRollingSpeedR23;
    double dExitSpeedR23;

    double dEntrySpeedR24;
    double dRollingSpeedR24;
    double dExitSpeedR24;

    double dEntrySpeedR25;
    double dRollingSpeedR25;
    double dExitSpeedR25;

    double dEntrySpeedR26;
    double dRollingSpeedR26;
    double dExitSpeedR26;

    double dEntrySpeedR27;
    double dRollingSpeedR27;
    double dExitSpeedR27;

} HRS_TABLE_RM_SPEED;

int HRS_RmSpeedTable_Init(char *pszOutErr);
void HRS_RmSpeedTable_Destroy();
int HRS_RmSpeedTab_Search(HRS_TABLE_RM_SPEED *pTable, char *pszOutErr);

int HRS_RmSpeedTab_SearchMulti(HRS_TABLE_RM_SPEED *pTable, 
                               int nDataNum,
                               char *pszOutErr);


#ifdef __cplusplus
}
#endif


#endif // __HRS_FmSpeedTable_H__