
#ifndef __HRS_FmGaugeLevelTable_H__
#define __HRS_FmGaugeLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_FmGaugeLevelTable_Init(char *pszOutErr);
void HRS_FmGaugeLevelTable_Destroy();
int HRS_FmGaugeLevelTable_Query(double dFmGauge, int * nLevel, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmGaugeLevelTable_H__