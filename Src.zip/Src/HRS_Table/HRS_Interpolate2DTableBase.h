
#ifndef __HRS_Interpolate2DTableBase_H__
#define __HRS_Interpolate2DTableBase_H__

#ifdef __cplusplus
extern "C" {
#endif



typedef struct HRS_TABLE_INTERPOLATE_2D_st
{
    double dDim1;;
    double dDim2;
    double dValue;

} HRS_TABLE_INTERPOLATE_2D;


int HRS_Interpolate2DTable_Init(HRS_TABLE_INFO *pTableInfo, char *pszOutErr);
void HRS_Interpolate2DTable_Destroy(HRS_TABLE_INFO *pTableInfo);
int HRS_Interpolate2DTable_Query(HRS_TABLE_INFO *pTableInfo, HRS_TABLE_INTERPOLATE_2D *pSearchTable);



#ifdef __cplusplus
}
#endif


#endif // __HRS_Interpolate2DTableBase_H__