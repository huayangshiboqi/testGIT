
#ifndef __HRS_AllTABLE_H__
#define __HRS_AllTABLE_H__

#include "HRS_FmDraftRatioTable.h"
#include "HRS_FmSpeedTable.h"
#include "HRS_SlabGaugeLevelTable.h"
#include "HRS_SlabWidthLevelTable.h"
#include "HRS_BarGaugeLevelTable.h"
#include "HRS_FmGaugeLevelTable.h"
#include "HRS_FmWidthLevelTable.h"
#include "HRS_FmDeliveryTempLevelTable.h"
#include "HRS_RmWidthLevelTable.h"
#include "HRS_FmTempTable.h"
#include "HRS_RmDraftRatioTable.h"
#include "HRS_RmSpeedTable.h"
#include "HRS_RmTempTable.h"
#include "HRS_FmModulusTable.h"
#include "HRS_RmModulusTable.h"
#include "HRS_FmTensionTable.h"
#include "HRS_FmLooperDisTable.h"
#include "HRS_FmLooperAngleTable.h"


#ifdef __cplusplus
extern "C" {
#endif


int HRS_AllTable_Init(char *pszOutErr);

void HRS_AllTable_Destroy();


#ifdef __cplusplus
}
#endif


#endif // __HRS_AllTABLE_H__