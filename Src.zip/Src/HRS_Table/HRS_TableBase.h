
#ifndef __HRS_TableBase_H__
#define __HRS_TableBase_H__

#ifdef __cplusplus
extern "C" {
#endif


#define CFG_BAR_GAUGE_LEVEL           "BarGaugeLevel.csv"
#define CFG_FM_DELIVERY_TEMP_LEVEL    "FmDeliveryTempLevel.csv"
#define CFG_FM_DRAFT_RATIO_TABLE      "FmDratfRatioTable.csv"
#define CFG_FM_GAUGE_LEVEL            "FmGaugeLevel.csv"
#define CFG_FM_LOOPER_DIS_TABLE       "FmLooperDisTable.csv"
#define CFG_FM_SPEED_TABLE            "FmSpeedTable.csv"
#define CFG_FM_TEMP_TABLE             "FmTempTable.csv"
#define CFG_FM_TENSION_TABLE          "FmTensionTable.csv"
#define CFG_FM_WIDTH_LEVEL            "FmWidthLevel.csv"
#define CFG_RM_DRAFT_RATIO_TABLE      "RmDratfRatioTable.csv"
#define CFG_RM_SPEED_TABLE            "RmSpeedTable.csv"
#define CFG_RM_TEMP_TABLE             "RmTempTable.csv"
#define CFG_RM_WIDTH_LEVEL            "RmWidthLevel.csv"
#define CFG_SLAB_GAUGE_LEVEL          "SlabGaugeLevel.csv"
#define CFG_SLAB_WIDTH_LEVEL          "SlabWidthLevel.csv"


#define HRS_TAbLE_MAX_ITEMNAME_LEN      64
#define HRS_TAbLE_MAX_TABLENAME_LEN     64
#define MAX_PATH_len                    256

typedef enum HRS_TABLE_VARTYPE_em
{
    HRS_TABLE_VARTYPE_CHAR,
    HRS_TABLE_VARTYPE_INT,
    HRS_TABLE_VARTYPE_DOUBLE,

    HRS_TABLE_VARTYPE_MAX
}HRS_TABLE_VARTYPE;

typedef enum HRS_TABLE_TYPE_em
{
    HRS_TABLE_TYPE_SIMPLE,
    HRS_TABLE_TYPE_INTERPOLATE,
    HRS_TABLE_TYPE_LEVEL,

    HRS_TABLE_TYPE_MAX
}HRS_TABLE_TYPE;

typedef struct HRS_TABLE_SCHEMA_st
{
    char                strItemName[HRS_TAbLE_MAX_ITEMNAME_LEN];
    HRS_TABLE_VARTYPE   VarType;
    int                 OffSet;
    int                 nVarLen;
} HRS_TABLE_SCHEMA;

typedef struct HRS_TABLE_INFO_st
{
    char                strTableName[HRS_TAbLE_MAX_TABLENAME_LEN];
    int                 nColNum;
    HRS_TABLE_SCHEMA *  pTableSchema;
    char                pszFilePath[MAX_PATH_len];
    int                 nMaxItemLen;
    HRS_TABLE_TYPE      TableType;
    int                 nKeyLen;
    int                 nStructLen;
    int                 nRowNum;
    void **             ppTable;
} HRS_TABLE_INFO;



int HRS_Table_ReadTableFromFile(char *pszFilePath, 
                                int nColNum, 
                                int nItemLen, 
                                void **ppTable,
                                int *nLineCount);






int HRS_ReadTableToStruct(HRS_TABLE_INFO *pTableInfo, char *pszOutErr);

void HRS_TableStruct_Destroy(HRS_TABLE_INFO *pTableInfo);

int HRS_SimpleTable_Search(HRS_TABLE_INFO *pTableInfo, void*pKeyTable,
                           char *pszOutErr);

int HRS_SimpleTable_Search_Multi(HRS_TABLE_INFO *pTableInfo, 
                                 void*pKeyTable, 
                                 int nDataNum,
                                 char *pszOutErr);

#ifdef __cplusplus
}
#endif


#endif // __HRS_TableBase_H__
