#include "NG.h"

#include "HRS_TableBase.h"

#include "HRS_AllTable.h"

extern HRS_TABLE_INFO gHRSTableInfo_DraftRatio;
extern HRS_TABLE_FM_DRAFTRATIO *gpTableFmDraftRatio;

extern HRS_TABLE_INFO gHRSTableInfo_Speed;
extern HRS_TABLE_FM_SPEED *gpTableFmSpeed;


int HRS_AllTable_Init(char *pszOutErr)
{
    static bool bInitFlag = false;
    if (bInitFlag == true)
    {
        return ERR_SUCCESS;
    }

    int nRet;

    nRet = HRS_FmDraftRatioTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        strcpy(pszOutErr, "");
        return ERR_FAILED;
    }

    nRet = HRS_FmSpeedTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_SlabGaugeLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_SlabWidthLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_BarGaugeLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmGaugeLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmWidthLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmDeliveryTempLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RmWidthLevelTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmTempTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RmDraftRatioTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RmSpeedTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RmTempTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

#if 0
    nRet = HRS_FmModulusTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RmModulusTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }
#endif

    nRet = HRS_FmTensionTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

#if 0
    nRet = HRS_FmLooperAngleTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }
#endif

    nRet = HRS_FmLooperDisTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    bInitFlag = true;
    return ERR_SUCCESS;
}

void HRS_AllTable_Destroy()
{
    HRS_FmDraftRatioTable_Destroy();
    HRS_FmSpeedTable_Destroy();
    HRS_SlabGaugeLevelTable_Destroy();
    HRS_SlabWidthLevelTable_Destroy();
    HRS_FmGaugeLevelTable_Destroy();
    HRS_BarGaugeLevelTable_Destroy();
    HRS_FmWidthLevelTable_Destroy();
    HRS_FmDeliveryTempLevelTable_Destroy();
    HRS_RmWidthLevelTable_Destroy();
    HRS_FmTempTable_Destroy();
    HRS_RmDraftRatioTable_Destroy();
    HRS_RmSpeedTable_Destroy();
    HRS_RmTempTable_Destroy();
    HRS_FmModulusTable_Destroy();
    HRS_RmModulusTable_Destroy();
    HRS_FmTensionTable_Destroy();
    HRS_FmLooperAngleTable_Destroy();
    HRS_FmLooperDisTable_Destroy();
}
