#ifndef __HRS_FmSpeedTable_H__
#define __HRS_FmSpeedTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_FM_SPEED_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double dThreadSpeed;;
    double dTempAccelator;              // �¶ȼ��ٶ�
    double dPowerAccelator;             // ���ʼ��ٶ�
    double dDECC;
    double dMaxSpeed;
    double dRunoutSpeed;

} HRS_TABLE_FM_SPEED;

int HRS_FmSpeedTable_Init(char *pszOutErr);
void HRS_FmSpeedTable_Destroy();
int HRS_FmSpeedTab_Search(HRS_TABLE_FM_SPEED *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmSpeedTable_H__