
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_RmDraftRatioTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_RmDraftRatio[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nSteelGradeCode), sizeof(int)},
    {"SlabGaugeLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nSlabGaugeLevel), sizeof(int)},
    {"SlabWidthLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nSlabWidthLevel), sizeof(int)},
    {"BarGaugeLevel",    HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nBarGaugeLevel), sizeof(int)},
    {"RMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nRMWidthLevel),  sizeof(int)},
//    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nFinalTempLevel), sizeof(int)},
    {"PassMode",         HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_DRAFTRATIO, nPassMode), sizeof(int)},

    {"LoadValueR11", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR11), sizeof(double)},
    {"LoadValueR12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR12), sizeof(double)},
    {"LoadValueR13", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR13), sizeof(double)},

    {"LoadValueR21", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR21), sizeof(double)},
    {"LoadValueR22", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR22), sizeof(double)},
    {"LoadValueR23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR23), sizeof(double)},
    {"LoadValueR24", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR24), sizeof(double)},
    {"LoadValueR25", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR25), sizeof(double)},
    {"LoadValueR26", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR26), sizeof(double)},
    {"LoadValueR27", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR27), sizeof(double)},
    { NULL }
};

HRS_TABLE_RM_DRAFTRATIO *gpTableRmDraftRatio;

HRS_TABLE_INFO gHRSTableInfo_RmDraftRatio =
{
    "RMDraftRatio",                                 // ����
    16, //18,                                             // ����
    HRSTableSchema_RmDraftRatio,                      // ����ģ�����
    CFG_RM_DRAFT_RATIO_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR11),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_RM_DRAFTRATIO),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableRmDraftRatio)
};

int HRS_RmDraftRatioTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_RmDraftRatio, pszOutErr);
}

void HRS_RmDraftRatioTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_RmDraftRatio);
}

int HRS_RmDraftRatioTab_SearchMulti(HRS_TABLE_RM_DRAFTRATIO *pTable, 
                                    int nDataNum,
                                    char *pszOutErr)
{
    int nRet;
    //return HRS_SimpleTable_Search(&gHRSTableInfo_RmDraftRatio, (void *)pTable);

    nRet = HRS_SimpleTable_Search_Multi(&gHRSTableInfo_RmDraftRatio, 
                                        pTable,
                                        nDataNum,
                                        pszOutErr);
    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode:%d\r\n"
            "SlabGaugeLevel:%d \r\n"
            "SlabWidthLevel: %d\r\n"
            "BarGaugeLevel: %d\r\n"
            "RMWidthLevel : %d\r\n",
            pTable->nSteelGradeCode, 
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel, 
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}


int HRS_RmDraftRatioTab_Search(HRS_TABLE_RM_DRAFTRATIO *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_RmDraftRatio, 
        (void *)pTable, pszOutErr);

    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode:%d\r\n"
            "SlabGaugeLevel:%d \r\n"
            "SlabWidthLevel:%d\r\n"
            "BarGaugeLevel: %d\r\n"
            "RMWidthLevel : %d\r\n",
            pTable->nSteelGradeCode, 
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel, 
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}
