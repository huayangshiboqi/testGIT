
#ifndef __HRS_RmDraftRatioTable_H__
#define __HRS_RmDraftRatioTable_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "..\Include\HRS_CalcData.h"
#include "HRS_RmDraftRatioTable.h"


typedef struct HRS_TABLE_RM_DRAFTRATIO_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int	nSlabGaugeLevel;                // ������ȵȼ�
    int	nSlabWidthLevel;                // �������ȵȼ�
    int	nBarGaugeLevel;                 // �м�����ȵȼ�
    int	nRMWidthLevel;                  // �������ȼ���
    HRS_PASS_MODE_EM nPassMode;         // ���η��䷽ʽ
//    int	nFinalTempLevel;            // �����¶ȼ���

    double dLoadValueR11;
    double dLoadValueR12;
    double dLoadValueR13;
    double dLoadValueR21;
    double dLoadValueR22;
    double dLoadValueR23;
    double dLoadValueR24;
    double dLoadValueR25;
    double dLoadValueR26;
    double dLoadValueR27;

} HRS_TABLE_RM_DRAFTRATIO;

int HRS_RmDraftRatioTable_Init(char *pszOutErr);
void HRS_RmDraftRatioTable_Destroy();

int HRS_RmDraftRatioTab_SearchMulti(HRS_TABLE_RM_DRAFTRATIO *pTable, 
                                    int nDataNum,
                                    char *pszOutErr);

int HRS_RmDraftRatioTab_Search(HRS_TABLE_RM_DRAFTRATIO *pTable, char *pszOutErr);


#ifdef __cplusplus
}
#endif


#endif // __HRS_FmDraftRatioTable_H__