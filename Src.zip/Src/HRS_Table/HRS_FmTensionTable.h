
#ifndef __HRS_FmTensionTable_H__
#define __HRS_FmTensionTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_FM_TENSION_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double dSpecTension12;
    double dSpecTension23;
    double dSpecTension34;
    double dSpecTension45;
    double dSpecTension56;
    double dSpecTension67;

} HRS_TABLE_FM_TENSION;

int HRS_FmTensionTable_Init(char *pszOutErr);
void HRS_FmTensionTable_Destroy();
int HRS_FmTensionTab_Search(HRS_TABLE_FM_TENSION *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmTensionTable_H__