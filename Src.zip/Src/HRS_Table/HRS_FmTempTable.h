
#ifndef __HRS_FmTempTable_H__
#define __HRS_FmTempTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_FM_TEMP_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double dChuLuTemp;                  // ��¯�¶�

    double dEntryTemp1;
    double dExitTemp1;
    double dEntryTemp2;
    double dExitTemp2;
    double dEntryTemp3;
    double dExitTemp3;
    double dEntryTemp4;
    double dExitTemp4;
    double dEntryTemp5;
    double dExitTemp5;
    double dEntryTemp6;
    double dExitTemp6;
    double dEntryTemp7;
    double dExitTemp7;

} HRS_TABLE_FM_TEMP;

int HRS_FmTempTable_Init(char *pszOutErr);
void HRS_FmTempTable_Destroy();
int HRS_FmTempTab_Search(HRS_TABLE_FM_TEMP *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmTempTable_H__