
#ifndef __HRS_SlabGaugeLevelTable_H__
#define __HRS_SlabGaugeLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif




int HRS_SlabGaugeLevelTable_Init(char *pszOutErr);
void HRS_SlabGaugeLevelTable_Destroy();
int HRS_SlabGaugeLevelTable_Query(double dSlabGauge, int * nLevel,
                                  char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_SlabGaugeLevelTable_H__