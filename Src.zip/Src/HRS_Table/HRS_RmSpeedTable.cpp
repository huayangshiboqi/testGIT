
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_RmSpeedTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_RmSpeed[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nSteelGradeCode), sizeof(int)},
    {"SlabGaugeLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nSlabGaugeLevel), sizeof(int)},
    {"SlabWidthLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nSlabWidthLevel), sizeof(int)},
    {"BarGaugeLevel",    HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nBarGaugeLevel), sizeof(int)},
    {"RMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nRMWidthLevel), sizeof(int)},
//    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nFinalTempLevel), sizeof(int)},
    {"PassMode",         HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_SPEED, nPassMode), sizeof(int)},

    {"EntrySpeedR11",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR11), sizeof(double)},
    {"RollingSpeedR11", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR11), sizeof(double)},
    {"ExitSpeedR11",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR11), sizeof(double)},

    {"EntrySpeedR12",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR12), sizeof(double)},
    {"RollingSpeedR12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR12), sizeof(double)},
    {"ExitSpeedR12",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR12), sizeof(double)},

    {"EntrySpeedR13",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR13), sizeof(double)},
    {"RollingSpeedR13", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR13), sizeof(double)},
    {"ExitSpeedR13",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR13), sizeof(double)},

    {"EntrySpeedR21",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR21), sizeof(double)},
    {"RollingSpeedR21", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR21), sizeof(double)},
    {"ExitSpeedR21",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR21), sizeof(double)},

    {"EntrySpeedR22",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR22), sizeof(double)},
    {"RollingSpeedR22", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR22), sizeof(double)},
    {"ExitSpeedR22",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR22), sizeof(double)},

    {"EntrySpeedR23",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR23), sizeof(double)},
    {"RollingSpeedR23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR23), sizeof(double)},
    {"ExitSpeedR23",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR23), sizeof(double)},

    {"EntrySpeedR24",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR24), sizeof(double)},
    {"RollingSpeedR24", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR24), sizeof(double)},
    {"ExitSpeedR24",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR24), sizeof(double)},

    {"EntrySpeedR25",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR25), sizeof(double)},
    {"RollingSpeedR25", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR25), sizeof(double)},
    {"ExitSpeedR25",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR25), sizeof(double)},

    {"EntrySpeedR26",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR26), sizeof(double)},
    {"RollingSpeedR26", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR26), sizeof(double)},
    {"ExitSpeedR26",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR26), sizeof(double)},

    {"EntrySpeedR27",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR27), sizeof(double)},
    {"RollingSpeedR27", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dRollingSpeedR27), sizeof(double)},
    {"ExitSpeedR27",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_SPEED, dExitSpeedR27), sizeof(double)},


    { NULL }
};

HRS_TABLE_RM_SPEED *gpTableRmSpeed;

HRS_TABLE_INFO gHRSTableInfo_RmSpeed =
{ 
    "RMSpeed",                                      // ����
    36,                                             // ����
    HRSTableSchema_RmSpeed,                         // ����ģ�����
    CFG_RM_SPEED_TABLE,                             // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20,//offsetof(HRS_TABLE_RM_SPEED, dEntrySpeedR11),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_RM_SPEED),                     // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableRmSpeed)
};//gHRSTableInfo_RmSpeed���ڴ��ļ��ж����һ��ȫ�ֱ�������������ֵĺ����л������������г�ʼ���͸�ֵ

int HRS_RmSpeedTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_RmSpeed, pszOutErr);
}

void HRS_RmSpeedTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_RmSpeed);
}

int HRS_RmSpeedTab_Search(HRS_TABLE_RM_SPEED *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_RmSpeed, 
        (void *)pTable, pszOutErr);

    if (nRet == ERR_FAILED)
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode: %d\r\n"   
            "SlabGaugeLevel: %d\r\n"
            "SlabWidthLevel: %d\r\n"
            "BarGaugeLevel : %d\r\n"  
            "RMWidthLevel  : %d\r\n",      
            pTable->nSteelGradeCode,
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel,
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}


int HRS_RmSpeedTab_SearchMulti(HRS_TABLE_RM_SPEED *pTable, 
                               int nDataNum,
                               char *pszOutErr)
{
    int nRet;
    //return HRS_SimpleTable_Search(&gHRSTableInfo_RmDraftRatio, (void *)pTable);

    nRet = HRS_SimpleTable_Search_Multi(&gHRSTableInfo_RmSpeed, 
                                        pTable,
                                        nDataNum,
                                        pszOutErr);
           //��������������У�ͨ��gHRSTableInfo_RmSpeed �� pTable ����aRmSpeedTab�����и��£�����gHRSTableInfo_RmSpeed�ڸ��ļ��е������������ж����ĳ�ʼ���ͼ��㸳ֵ
	       //������պ����ĵ�һ�ֲ²⣬���gHRSTableInfo_RmSpeed��Ӧ��������ÿһ������������Ĵ�ѭ����ѭ�����ı�

    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode: %d\r\n"   
            "SlabGaugeLevel: %d\r\n"
            "SlabWidthLevel: %d\r\n"
            "BarGaugeLevel : %d\r\n"  
            "RMWidthLevel  : %d\r\n",      
            pTable->nSteelGradeCode,
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel,
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}


