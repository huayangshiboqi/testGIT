
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmDraftRatioTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmDraftRatio[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_DRAFTRATIO, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_DRAFTRATIO, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_DRAFTRATIO, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_DRAFTRATIO, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_DRAFTRATIO, nFinalTempLevel), sizeof(int)},

    {"LoadValue1", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue1), sizeof(double)},
    {"LoadValue2", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue2), sizeof(double)},
    {"LoadValue3", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue3), sizeof(double)},
    {"LoadValue4", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue4), sizeof(double)},
    {"LoadValue5", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue5), sizeof(double)},
    {"LoadValue6", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue6), sizeof(double)},
    {"LoadValue7", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue7), sizeof(double)},
    { NULL }
};

HRS_TABLE_FM_DRAFTRATIO *gpTableFmDraftRatio;

HRS_TABLE_INFO gHRSTableInfo_FmDraftRatio =
{
    "FMDraftRatio",                                 // ����
    12,                                             // ����
    HRSTableSchema_FmDraftRatio,                      // ����ģ�����
    CFG_FM_DRAFT_RATIO_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_DRAFTRATIO, fLoadValue1),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_DRAFTRATIO),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmDraftRatio)
};

int HRS_FmDraftRatioTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmDraftRatio, pszOutErr);
}

void HRS_FmDraftRatioTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmDraftRatio);
}

int HRS_FmDraftRatioTab_Search(HRS_TABLE_FM_DRAFTRATIO *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_FmDraftRatio, 
        (void *)pTable, pszOutErr);

    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode  :%d\r\n" 
            "QualityCode     :%d \r\n"
            "TargetGaugeLevel: %d\r\n"
            "FMWidthLevel    : %d\r\n"
            "FinalTempLevel  : %d\r\n",
            pTable->nSteelGradeCode, 
            pTable->nQualityCode,
            pTable->nTargetGaugeLevel, 
            pTable->nFMWidthLevel,
            pTable->nFinalTempLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}
