
#ifndef __HRS_SlabWidthLevelTable_H__
#define __HRS_SlabWidthLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_SlabWidthLevelTable_Init(char *pszOutErr);
void HRS_SlabWidthLevelTable_Destroy();
int HRS_SlabWidthLevelTable_Query(double dSlabWidth, int * nLevel, 
                                  char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_SlabWidthLevelTable_H__