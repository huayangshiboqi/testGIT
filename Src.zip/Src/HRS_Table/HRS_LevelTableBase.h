
#ifndef __HRS_LevelTableBase_H__
#define __HRS_LevelTableBase_H__

#ifdef __cplusplus
extern "C" {
#endif





#define  HRS_SCOPESYMBOL_MAX_LEN    16

typedef struct HRS_TABLE_LEVEL_st
{
    int  nLevel;
    char strScopeSymbol[HRS_SCOPESYMBOL_MAX_LEN];
    double dBoundaryValue;

} HRS_TABLE_LEVEL;


int HRS_LevelTable_Init(HRS_TABLE_INFO *pTableInfo, char *pszOutErr);
void HRS_LevelTable_Destroy(HRS_TABLE_INFO *pTableInfo);
int HRS_LevelTable_Query(HRS_TABLE_INFO *pTableInfo, 
                         double dSearchValue, int * nLevel,
                         char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_LevelTableBase_H__