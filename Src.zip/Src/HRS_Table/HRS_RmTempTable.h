
#ifndef __HRS_RmTempTable_H__
#define __HRS_RmTempTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_RM_TEMP_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int	nSlabGaugeLevel;                // ������ȵȼ�
    int	nSlabWidthLevel;                // �������ȵȼ�
    int	nBarGaugeLevel;                 // Ŀ���ȵȼ�
    int	nRMWidthLevel;                  // �������ȼ���
//    int	nFinalTempLevel;                // �����¶ȼ���
    int nPassMode;

    double dChuLuTemp;          // ��¯�¶�
    double dEntryTempR11;
    double dExitTempR11;

    double dEntryTempR12;
    double dExitTempR12;

    double dEntryTempR13;
    double dExitTempR13;

    double dEntryTempR21;
    double dExitTempR21;

    double dEntryTempR22;
    double dExitTempR22;

    double dEntryTempR23;
    double dExitTempR23;

    double dEntryTempR24;
    double dExitTempR24;

    double dEntryTempR25;
    double dExitTempR25;

    double dEntryTempR26;
    double dExitTempR26;

    double dEntryTempR27;
    double dExitTempR27;

} HRS_TABLE_RM_TEMP;

int HRS_RmTempTable_Init(char *pszOutErr);
void HRS_RmTempTable_Destroy();
int HRS_RmTempTab_Search(HRS_TABLE_RM_TEMP *pTable, char *pszOutErr);
int HRS_RmTempTab_SearchMulti(HRS_TABLE_RM_TEMP *pTable, 
                              int nDataNum, 
                              char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmTempTable_H__