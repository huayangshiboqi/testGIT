
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_LevelTableBase.h"

HRS_TABLE_SCHEMA  HRSTableSchema_Level[] =
{
    {"Level",           HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_LEVEL, nLevel), sizeof(int)},
    {"ScopeSymbol",     HRS_TABLE_VARTYPE_CHAR, offsetof(HRS_TABLE_LEVEL, strScopeSymbol), HRS_SCOPESYMBOL_MAX_LEN},
    {"BoundaryValue",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_LEVEL, dBoundaryValue), sizeof(double)},
    { NULL }
};


int HRS_LevelTable_Init(HRS_TABLE_INFO *pTableInfo, char *pszOutErr)
{
    int nRet;
    int nLineCount;
    HRS_TABLE_LEVEL *ppTable;

    if (pTableInfo == NULL)
    {
        return ERR_FAILED;
    }

    nRet = HRS_ReadTableToStruct(pTableInfo, pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    ppTable = (HRS_TABLE_LEVEL *)(*(pTableInfo->ppTable));
    if (ppTable == NULL)
    {
        return ERR_FAILED;
    }

    nLineCount = pTableInfo->nRowNum;

    for (int i = 0; i < nLineCount; i++)
    {
        if (ppTable[i].nLevel != i + 1)
        {
            return ERR_FAILED;
        }
    }

    for (int i = 0; i < nLineCount - 2; i++)
    {
        if (ppTable[i].dBoundaryValue 
             > ppTable[i + 1].dBoundaryValue)
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}


void HRS_LevelTable_Destroy(HRS_TABLE_INFO *pTableInfo)
{

    HRS_TableStruct_Destroy(pTableInfo);
}


int HRS_LevelTable_Query(HRS_TABLE_INFO *pTableInfo, double dSearchValue,
                         int * nLevel, char *pszOutErr)
{
    int nLevelCount;
    double dBoundaryValue;
    HRS_TABLE_LEVEL *ppTable;

    if (pTableInfo == NULL || nLevel == NULL)
    {
        return ERR_FAILED;
    }

    if (dSearchValue < 0)
    {
        return ERR_FAILED;
    }

    ppTable = (HRS_TABLE_LEVEL *)(*(pTableInfo->ppTable));
    if (ppTable == NULL)
    {
        return ERR_FAILED;
    }

    nLevelCount = pTableInfo->nRowNum;
    if (nLevelCount == 0)
    {
        sprintf(pszOutErr, "\r\nHRS_LevelTable_Query(): File: %s Failed.\r\n", 
            pTableInfo->pszFilePath);
        return ERR_FAILED;
    }

    for (int i = 0; i < nLevelCount - 1;i++)
    {
        dBoundaryValue = ppTable[i].dBoundaryValue;
        if (dSearchValue <= dBoundaryValue)
        {
            *nLevel = i +1;
            return ERR_SUCCESS;
        }
    }

    *nLevel = nLevelCount;
    return ERR_SUCCESS;
}
