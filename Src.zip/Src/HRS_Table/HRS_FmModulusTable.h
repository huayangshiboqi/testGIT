
#ifndef __HRS_FmModulusTable_H__
#define __HRS_FmModulusTable_H__

#ifdef __cplusplus
extern "C" {
#endif

#define HRS_MAX_FM_STAND_NUM 7

int HRS_FmModulusTable_Init(char *pszOutErr);
void HRS_FmModulusTable_Destroy();
int HRS_FmModulusTable_Query(int nStandNo, double dWidth, double dRollForce, double *dModulus);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmModulusTable_H__