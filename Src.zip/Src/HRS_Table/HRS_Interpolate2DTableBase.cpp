
#include "NG.h"
#include "stddef.h"
#include <math.h>

#include "HRS_TableBase.h"
#include "HRS_Interpolate2DTableBase.h"

HRS_TABLE_SCHEMA  HRSTableSchema_Interpolate2D[] =
{
    {"Dim1",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_INTERPOLATE_2D, dDim1), sizeof(double)},
    {"Dim2",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_INTERPOLATE_2D, dDim2), sizeof(double)},
    {"Value",  HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_INTERPOLATE_2D, dValue), sizeof(double)},
    { NULL }
};


int HRS_Interpolate2DTable_Init(HRS_TABLE_INFO *pTableInfo, char *pszOutErr)
{
    int nRet;
    int nLineCount;
    HRS_TABLE_INTERPOLATE_2D *ppTable;

    if (pTableInfo == NULL)
    {
        return ERR_FAILED;
    }

    nRet = HRS_ReadTableToStruct(pTableInfo, pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    ppTable = (HRS_TABLE_INTERPOLATE_2D *)(*(pTableInfo->ppTable));
    if (ppTable == NULL)
    {
        return ERR_FAILED;
    }

    nLineCount = pTableInfo->nRowNum;

    for (int i = 0; i < nLineCount; i++)
    {
        if (ppTable[i].dDim1 < 0 
            || ppTable[i].dDim2 < 0 
            || ppTable[i].dValue < 0)
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}

void HRS_Interpolate2DTable_Destroy(HRS_TABLE_INFO *pTableInfo)
{

    HRS_TableStruct_Destroy(pTableInfo);
}

int HRS_Interpolate2DTable_Query(HRS_TABLE_INFO *pTableInfo, HRS_TABLE_INTERPOLATE_2D *pSearchTable)
{
    int nDataLineCount;
    HRS_TABLE_INTERPOLATE_2D *ppTable;

    HRS_TABLE_INTERPOLATE_2D *pTabDim11 = NULL;
    HRS_TABLE_INTERPOLATE_2D *pTabDim12 = NULL;
    HRS_TABLE_INTERPOLATE_2D *pTabDim21 = NULL;
    HRS_TABLE_INTERPOLATE_2D *pTabDim22 = NULL;
    double dValue1;
    double dValue2;
    double dDim1S;
    double dDim2S;


    if (pTableInfo == NULL || pSearchTable == NULL)
    {
        return ERR_FAILED;
    }

    ppTable = (HRS_TABLE_INTERPOLATE_2D *)(*(pTableInfo->ppTable));
    if (ppTable == NULL)
    {
        return ERR_FAILED;
    }

    nDataLineCount = pTableInfo->nRowNum;
    if (nDataLineCount <= 0)
    {
        return ERR_FAILED;
    }

    dDim1S = pSearchTable->dDim1;
    dDim2S = pSearchTable->dDim2;
    for (int i = 0; i < nDataLineCount; i++)
    {
        if (pTabDim11 == NULL)
        {
            pTabDim11 = &ppTable[i];
            continue;
        }

        if (fabs(dDim1S - ppTable[i].dDim1) < fabs(dDim1S - pTabDim11->dDim1))
        {
            pTabDim21 = pTabDim11;
            pTabDim22 = pTabDim12;
            pTabDim11 = &ppTable[i];
            pTabDim12 = NULL;
            continue;
        }

        if (fabs(dDim1S - ppTable[i].dDim1) == fabs(dDim1S - pTabDim11->dDim1))
        {
            if (fabs(dDim2S - ppTable[i].dDim2) < fabs(dDim2S - pTabDim11->dDim2))
            {
                pTabDim12 = pTabDim11;
                pTabDim11 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) == fabs(dDim2S - pTabDim11->dDim2))
            {
                return ERR_FAILED;
            }

            if (pTabDim12 == NULL)
            {
                pTabDim12 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) < fabs(dDim2S - pTabDim12->dDim2))
            {
                pTabDim12 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) == fabs(dDim2S - pTabDim12->dDim2))
            {
                return ERR_FAILED;
            }

            continue;
        }

        if (pTabDim21 == NULL)
        {
            pTabDim21 = &ppTable[i];
            continue;
        }

        if (fabs(dDim1S - ppTable[i].dDim1) < fabs(dDim1S - pTabDim21->dDim1))
        {
            pTabDim21 = &ppTable[i];
            pTabDim22 = NULL;
            continue;
        }

        if (fabs(dDim1S - ppTable[i].dDim1) == fabs(dDim1S - pTabDim21->dDim1))
        {
            if (fabs(dDim2S - ppTable[i].dDim2) < fabs(dDim2S - pTabDim21->dDim2))
            {
                pTabDim22 = pTabDim21;
                pTabDim21 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) == fabs(dDim2S - pTabDim21->dDim2))
            {
                return ERR_FAILED;
            }

            if (pTabDim22 == NULL)
            {
                pTabDim22 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) < fabs(dDim2S - pTabDim22->dDim2))
            {
                pTabDim22 = &ppTable[i];
                continue;
            }

            if (fabs(dDim2S - ppTable[i].dDim2) == fabs(dDim2S - pTabDim22->dDim2))
            {
                return ERR_FAILED;
            }

            continue;
        }
    }

    if (pTabDim11 == NULL)
    {
        return ERR_FAILED;
    }

    if (pTabDim12 == NULL)
    {
        dValue1 = pTabDim11->dValue;
    }
    else
    {
        dValue1 = pTabDim11->dValue + (pTabDim12->dValue - pTabDim11->dValue) 
                  * (dDim2S - pTabDim11->dDim2) 
                  / (pTabDim12->dDim2 - pTabDim11->dDim2);
    }

    if (pTabDim21 == NULL)
    {
        pSearchTable->dValue = dValue1;
        return ERR_SUCCESS;
    }

    if (pTabDim22 == NULL)
    {
        dValue2 = pTabDim21->dValue;
    }
    else
    {
        dValue2 = pTabDim21->dValue + (pTabDim22->dValue - pTabDim21->dValue) 
                  * (dDim2S - pTabDim21->dDim2) 
                  / (pTabDim22->dDim2 - pTabDim21->dDim2);
    }

    pSearchTable->dValue = dValue1 + (dValue2 - dValue1)
                           * (dDim1S - pTabDim11->dDim1)
                           / (pTabDim21->dDim1 - pTabDim11->dDim1);


    return ERR_SUCCESS;
}
