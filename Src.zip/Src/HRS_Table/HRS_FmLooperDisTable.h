
#ifndef __HRS_FmLooperDisTable_H__
#define __HRS_FmLooperDisTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_FM_LOOPERDIS_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double dLooperDis12;
    double dLooperDis23;
    double dLooperDis34;
    double dLooperDis45;
    double dLooperDis56;
    double dLooperDis67;

} HRS_TABLE_FM_LOOPERDIS;

int HRS_FmLooperDisTable_Init(char *pszOutErr);
void HRS_FmLooperDisTable_Destroy();
int HRS_FmLooperDisTab_Search(HRS_TABLE_FM_LOOPERDIS *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmLooperDisTable_H__