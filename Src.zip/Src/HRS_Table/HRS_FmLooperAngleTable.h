
#ifndef __HRS_FmLooperAngleTable_H__
#define __HRS_FmLooperAngleTable_H__

#ifdef __cplusplus
extern "C" {
#endif




typedef struct HRS_TABLE_FM_LOOPERANGLE_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double dAngleLooper12;
    double dAngleLooper23;
    double dAngleLooper34;
    double dAngleLooper45;
    double dAngleLooper56;
    double dAngleLooper67;

} HRS_TABLE_FM_LOOPERANGLE;

int HRS_FmLooperAngleTable_Init(char *pszOutErr);
void HRS_FmLooperAngleTable_Destroy();
int HRS_FmLooperAngleTab_Search(HRS_TABLE_FM_LOOPERANGLE *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmLooperAngleTable_H__