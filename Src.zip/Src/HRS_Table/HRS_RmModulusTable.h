
#ifndef __HRS_RmModulusTable_H__
#define __HRS_RmModulusTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_RmModulusTable_Init(char *pszOutErr);
void HRS_RmModulusTable_Destroy();
int HRS_RmModulusTable_Query(int nStandNo, double dWidth, double dRollForce, double *dModulus);



#ifdef __cplusplus
}
#endif


#endif // __HRS_RmModulusTable_H__