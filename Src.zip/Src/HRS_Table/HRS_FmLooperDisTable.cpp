
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmLooperDisTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmLooperDis[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERDIS, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERDIS, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERDIS, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERDIS, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_LOOPERDIS, nFinalTempLevel), sizeof(int)},

    {"LooperDis12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis12), sizeof(double)},
    {"LooperDis23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis23), sizeof(double)},
    {"LooperDis34", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis34), sizeof(double)},
    {"LooperDis45", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis45), sizeof(double)},
    {"LooperDis56", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis56), sizeof(double)},
    {"LooperDis67", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis67), sizeof(double)},
    { NULL }
};

HRS_TABLE_FM_LOOPERDIS *gpTableFmLooperDis;

HRS_TABLE_INFO gHRSTableInfo_FmLooperDis =
{
    "FmLooperDis",                                 // ����
    11,                                             // ����
    HRSTableSchema_FmLooperDis,                      // ����ģ�����
    CFG_FM_LOOPER_DIS_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_LOOPERDIS, dLooperDis12),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_LOOPERDIS),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmLooperDis)
};

int HRS_FmLooperDisTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmLooperDis, pszOutErr);
}

void HRS_FmLooperDisTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmLooperDis);
}

int HRS_FmLooperDisTab_Search(HRS_TABLE_FM_LOOPERDIS *pTable, char *pszOutErr)
{
    return HRS_SimpleTable_Search(&gHRSTableInfo_FmLooperDis, 
        (void *)pTable, pszOutErr);
}
