#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmTempTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmTemp[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TEMP, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TEMP, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TEMP, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TEMP, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_TEMP, nFinalTempLevel), sizeof(int)},

    {"ChuLuTemp", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dChuLuTemp), sizeof(double)},
    {"EntryTemp1", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp1), sizeof(double)},
    {"ExitTemp1", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp1), sizeof(double)},
    {"EntryTemp2", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp2), sizeof(double)},
    {"ExitTemp2", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp2), sizeof(double)},
    {"EntryTemp3", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp3), sizeof(double)},
    {"ExitTemp3", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp3), sizeof(double)},
    {"EntryTemp4", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp4), sizeof(double)},
    {"ExitTemp4", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp4), sizeof(double)},
    {"EntryTemp5", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp5), sizeof(double)},
    {"ExitTemp5", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp5), sizeof(double)},
    {"EntryTemp6", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp6), sizeof(double)},
    {"ExitTemp6", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp6), sizeof(double)},
    {"EntryTemp7", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dEntryTemp7), sizeof(double)},
    {"ExitTemp7", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_TEMP, dExitTemp7), sizeof(double)},

    { NULL }
};

HRS_TABLE_FM_TEMP *gpTableFmTemp;

HRS_TABLE_INFO gHRSTableInfo_FmTemp =
{
    "FMTemp",                                 // ����
    20,                                             // ����
    HRSTableSchema_FmTemp,                      // ����ģ�����
    CFG_FM_TEMP_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_TEMP, dEntryTemp1),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_TEMP),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmTemp)
};


int HRS_FmTempTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmTemp, pszOutErr);
}


void HRS_FmTempTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmTemp);
}


int HRS_FmTempTab_Search(HRS_TABLE_FM_TEMP *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_FmTemp, 
        (void *)pTable, pszOutErr);
    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode  : %d\r\n"    
            "QualityCode     : %d\r\n"  
            "TargetGaugeLevel: %d\r\n"  
            "FMWidthLevel    : %d\r\n"      
            "FinalTempLevel  : %d",
            pTable->nSteelGradeCode,
            pTable->nQualityCode,
            pTable->nTargetGaugeLevel,
            pTable->nFMWidthLevel,
            pTable->nFinalTempLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}

