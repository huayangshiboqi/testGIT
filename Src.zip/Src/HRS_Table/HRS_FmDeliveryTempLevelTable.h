
#ifndef __HRS_FmDeliveryTempLevelTable_H__
#define __HRS_FmDeliveryTempLevelTable_H__

#ifdef __cplusplus
extern "C" {
#endif


int HRS_FmDeliveryTempLevelTable_Init(char *pszOutErr);
void HRS_FmDeliveryTempLevelTable_Destroy();
int HRS_FmDeliveryTempLevelTable_Query(double dFmDeliveryTemp, 
                                       int * nLevel,
                                       char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmDeliveryTempLevelTable_H__