
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_RmTempTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_RmTemp[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nSteelGradeCode), sizeof(int)},
    {"SlabGaugeLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nSlabGaugeLevel), sizeof(int)},
    {"SlabWidthLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nSlabWidthLevel), sizeof(int)},
    {"BarGaugeLevel",    HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nBarGaugeLevel), sizeof(int)},
    {"RMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nRMWidthLevel), sizeof(int)},
//    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nFinalTempLevel), sizeof(int)},
    {"PassMode",         HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_RM_TEMP, nPassMode), sizeof(int)},

    {"ChuLuTemp",    HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dChuLuTemp), sizeof(double)},

    {"EntryTempR11", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR11), sizeof(double)},
    {"ExitTempR11",  HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR11), sizeof(double)},

    {"EntryTempR12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR12), sizeof(double)},
    {"ExitTempR12", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR12), sizeof(double)},

    {"EntryTempR13", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR13), sizeof(double)},
    {"ExitTempR13", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR13), sizeof(double)},

    {"EntryTempR21", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR21), sizeof(double)},
    {"ExitTempR21", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR21), sizeof(double)},

    {"EntryTempR22", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR22), sizeof(double)},
    {"ExitTempR22", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR22), sizeof(double)},

    {"EntryTempR23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR23), sizeof(double)},
    {"ExitTempR23", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR23), sizeof(double)},

    {"EntryTempR24", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR24), sizeof(double)},
    {"ExitTempR24", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR24), sizeof(double)},

    {"EntryTempR25", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR25), sizeof(double)},
    {"ExitTempR25", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR25), sizeof(double)},

    {"EntryTempR26", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR26), sizeof(double)},
    {"ExitTempR26", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR26), sizeof(double)},

    {"EntryTempR27", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dEntryTempR27), sizeof(double)},
    {"ExitTempR27", HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_RM_TEMP, dExitTempR27), sizeof(double)},

    { NULL }
};

HRS_TABLE_RM_TEMP *gpTableRmTemp;

HRS_TABLE_INFO gHRSTableInfo_RmTemp =
{
    "RMTemp",                                 // ����
    27, //18,                                             // ����
    HRSTableSchema_RmTemp,                      // ����ģ�����
    CFG_RM_TEMP_TABLE,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_RM_DRAFTRATIO, dLoadValueR11),    // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_RM_TEMP),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableRmTemp)
};

int HRS_RmTempTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_RmTemp, pszOutErr);
}

void HRS_RmTempTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_RmTemp);
}

int HRS_RmTempTab_Search(HRS_TABLE_RM_TEMP *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_RmTemp, 
        (void *)pTable, pszOutErr);
    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode  : %d\r\n"    
            "SlabeGaugeLevel : %d\r\n"  
            "SlabeWidthLevel : %d\r\n"  
            "BarGaugeLevel   : %d\r\n"  
            "RMWidthLevel    : %d\r\n",      
            pTable->nSteelGradeCode,
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel,
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}


int HRS_RmTempTab_SearchMulti(HRS_TABLE_RM_TEMP *pTable, 
                              int nDataNum, 
                              char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search_Multi(&gHRSTableInfo_RmTemp, 
                                        (void *)pTable, nDataNum, pszOutErr);
    if ( nRet == ERR_FAILED )
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode  : %d\r\n"    
            "SlabeGaugeLevel : %d\r\n"  
            "SlabeWidthLevel : %d\r\n"  
            "BarGaugeLevel   : %d\r\n"  
            "RMWidthLevel    : %d\r\n",      
            pTable->nSteelGradeCode,
            pTable->nSlabGaugeLevel,
            pTable->nSlabWidthLevel,
            pTable->nBarGaugeLevel,
            pTable->nRMWidthLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}