
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_FmSpeedTable.h"

static HRS_TABLE_SCHEMA  HRSTableSchema_FmSpeed[] =
{
    {"SteelGradeCode",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_SPEED, nSteelGradeCode), sizeof(int)},
    {"QualityCode",      HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_SPEED, nQualityCode), sizeof(int)},
    {"TargetGaugeLevel", HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_SPEED, nTargetGaugeLevel), sizeof(int)},
    {"FMWidthLevel",     HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_SPEED, nFMWidthLevel), sizeof(int)},
    {"FinalTempLevel",   HRS_TABLE_VARTYPE_INT, offsetof(HRS_TABLE_FM_SPEED, nFinalTempLevel), sizeof(int)},

    {"ThreadSpeed",     HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dThreadSpeed), sizeof(double)},
    {"TempAccelator",   HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dTempAccelator), sizeof(double)},
    {"PowerAccelator",  HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dPowerAccelator), sizeof(double)},
    {"DECC",            HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dDECC), sizeof(double)},
    {"MaxSpeed",        HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dMaxSpeed), sizeof(double)},
    {"RunoutSpeed",     HRS_TABLE_VARTYPE_DOUBLE, offsetof(HRS_TABLE_FM_SPEED, dRunoutSpeed), sizeof(double)},
    { NULL }
};

HRS_TABLE_FM_SPEED *gpTableFmSpeed;

HRS_TABLE_INFO gHRSTableInfo_FmSpeed =
{
    "FMSpeed",                                      // ����
    11,                                             // ����
    HRSTableSchema_FmSpeed,                           // ����ģ�����
    CFG_FM_SPEED_TABLE,                             // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_SIMPLE,                          // ��������
    20, //offsetof(HRS_TABLE_FM_SPEED, dThreadSpeed),     // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_FM_SPEED),                     // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableFmSpeed)
};

int HRS_FmSpeedTable_Init(char *pszOutErr)
{
    return HRS_ReadTableToStruct(&gHRSTableInfo_FmSpeed, pszOutErr);
}

void HRS_FmSpeedTable_Destroy()
{
    HRS_TableStruct_Destroy(&gHRSTableInfo_FmSpeed);
}

int HRS_FmSpeedTab_Search(HRS_TABLE_FM_SPEED *pTable, char *pszOutErr)
{
    int nRet;

    nRet = HRS_SimpleTable_Search(&gHRSTableInfo_FmSpeed, 
        (void *)pTable, pszOutErr);
    if (nRet == ERR_FAILED)
    {
        char szMsg[256];

        sprintf(szMsg, 
            "SteelGradeCode  : %d\r\n"    
            "QualityCode     : %d\r\n"       
            "TargetGaugeLevel: %d\r\n"  
            "FMWidthLevel    : %d\r\n"      
            "FinalTempLevel  : %d",
            pTable->nSteelGradeCode,
            pTable->nQualityCode,
            pTable->nTargetGaugeLevel,
            pTable->nFMWidthLevel,
            pTable->nFinalTempLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}
