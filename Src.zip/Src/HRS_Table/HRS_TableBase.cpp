
#include "NG.h"
#include "NG_string.h "
#include "StrParse.h "
#include "DArray.h "

#include "HRS_TableBase.h"
#include "HRS_RmDraftRatioTable.h"

#define ONE_ITEM_WIDTH     12


static int ParseTableFile(char * pszFileBuf, 
                          int nFileLen, 
                          int nColNum, 
                          int nItemLen,
                          void **ppTable,
                          int *nTableLineCount);

static int ParseTableFile2(char * pszFileBuf, 
                           int nFileLen, 
                           int nColNum, 
                           int nItemLen,
                           void **ppTable,
                           int *nTableLineCount,
                           char *pszFirstLine);

int HRS_Table_WriteDataToFile(char *pszFilePath, 
                              int nColNum, 
                              int nItemLen, 
                              void **ppTable,
                              int nLineCount,
                              char *pszFirstLine);

int HRS_Table_ReadTableFromFile(char *pszFilePath, 
                                int nColNum, 
                                int nItemLen, 
                                void **ppTable,
                                int *pnLineCount)
{
    FILE *      fp;
    int         nFileLen;
    char *      pszFileBuf;
    int         nCount;
    int         nRet;
    char        szFirstLine[2048];

    if (pszFilePath == NULL || ppTable == NULL || pnLineCount == NULL)
    {
        return ERR_FAILED;
    }

    fp = fopen( pszFilePath, "rb" );
    if ( !fp )
    {
        return ERR_FAILED;
    }

    fseek(fp, 0, SEEK_END);

    nFileLen = ftell(fp);

    if ( nFileLen <= 0 )
    {
        return ERR_FAILED;
    }

    pszFileBuf = (char *)NG_malloc(nFileLen + 10);

    if ( pszFileBuf == NULL )
    {
        fclose(fp);
        return ERR_FAILED;
    }

    memset(pszFileBuf, 0, nFileLen + 10);

    fseek(fp, 0, SEEK_SET);
    nCount = (int)fread(pszFileBuf, 1, nFileLen, fp);
    if ( nCount <= 0 )
    { 
        fclose(fp);
        NG_free(pszFileBuf);
        return ERR_FAILED;
    }

    fclose(fp);

    pszFileBuf[nFileLen+9] = '\0';

    nRet = ParseTableFile2(pszFileBuf, 
                         nFileLen+10, 
                         nColNum, 
                         nItemLen, 
                         ppTable, 
                         pnLineCount,
                         szFirstLine);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    NG_free(pszFileBuf);

#if 0
    // ����csv��ʽ�Ĵ��룬�������ļ����±���Ϊcsv��ʽ
    char szPath[512];

    strcpy(szPath, pszFilePath);

    char *psz = strrchr(szPath, '.');
    if (psz != NULL)
    {
        if (stricmp(psz + 1, "cfg") == 0)
        {
            strcpy(psz + 1, "csv");
        }
        else if (stricmp(psz + 1, "csv") == 0)
        {
            strcpy(psz + 1, "csv2");
        }
    }

    strcat(szFirstLine, "\r\n");

    HRS_Table_WriteDataToFile(szPath, 
        nColNum, nItemLen, ppTable, 
        *pnLineCount, szFirstLine);
#endif


    return ERR_SUCCESS;
}


int HRS_Table_WriteDataToFile(char *pszFilePath, 
                              int nColNum, 
                              int nItemLen, 
                              void **ppTable,
                              int nLineCount,
                              char *pszFirstLine)
{
    int i;
    int k;
    int nPos;
    char szLine[8192];
    char szItem[128];
    char szOut[256];
    void *pTable;

    FILE *fp;

    fp = fopen(pszFilePath, "wb");
    if (fp == NULL)
    {
        return ERR_FAILED;
    }

    fwrite(pszFirstLine, strlen(pszFirstLine), 1, fp);

    pTable = *ppTable;

    for (i = 0; i < nLineCount; i++)
    {
        // ����һ������
        szLine[0] = '\0';
        for (k = 0; k < nColNum; k++)
        {
            nPos = i * nItemLen * nColNum + k * nItemLen;

            strcpy(szItem, (char *)pTable + nPos);

            if ( k != nColNum -1 )
            {
                StrFormat(szItem, 0, ONE_ITEM_WIDTH, NULL, szOut, sizeof(szOut)-1);
                strcat(szOut, ",  ");

                strcat(szLine, szOut);
            }
            else
            {
                strcat(szLine, szItem);
            }
        }

        strcat(szLine, "\r\n");
        fwrite(szLine, strlen(szLine), 1, fp);
    }

    fclose(fp);

    return ERR_SUCCESS;
}


static int ParseTableFile2(char * pszFileBuf, 
                          int nFileLen, 
                          int nColNum, 
                          int nItemLen,
                          void **ppTable,
                          int *nTableLineCount,
                          char *pszFirstLine)
{
    int nLineCount = 0;
    int nTableBufLen;

    //char (* pTable)[nColNum][nItemLen];
    void *pTable;
    
    pszFirstLine[0] = '\0';

    if (pszFileBuf == NULL || ppTable == NULL || nTableLineCount == NULL)
    {
        return ERR_FAILED;
    }

    for (int i = 0; i < nFileLen; i++)
    {
        if (pszFileBuf[i] == '\n')
        {
            nLineCount++;
        }
    }

    *nTableLineCount = nLineCount;

    nTableBufLen = nItemLen * nColNum * (nLineCount + 1) + 10;

    //pTable = (char (*)[nColNum][nItemLen]) NG_malloc(nTableBufLen);
    pTable =  NG_malloc(nTableBufLen);
    if (pTable == NULL)
    {
        return ERR_FAILED;
    }
    memset(pTable, 0, nTableBufLen);

    BOOL    bParseStatus    = ERR_SUCCESS;

    nLineCount = 0;

    char szLine[4096];
    char *pszLine;
    INT_STR  int_str;
    DARRAY   *pStrArray;
    
    StrInit(int_str, pszFileBuf);

    for (;;)
    {
        pszLine = StrGetLine(&int_str, szLine, sizeof(szLine)-1);
        if (pszLine == NULL)
        {
            // �����ļ�β��
            break;
        }

        StrTrimLeft(szLine);
        StrTrimRight(szLine);

        if (szLine[0] == '\0'
            || szLine[0] == '#' )
        {
            // ע�ͺͿ�������
            if ( pszFirstLine[0] == '\0' )
            {
                strcpy(pszFirstLine, szLine);
            }
            continue;
        }

        // ������ȡ����һ���ַ���
        pStrArray = ParseStrArray(szLine, ", \t");
        if (pStrArray == NULL)
        {
            // ���ݸ�ʽ����
            return ERR_FAILED;
        }

        if (pStrArray->nDataCount != nColNum)
        {
            // ���ݸ�ʽ����
            return ERR_FAILED;
        }

        // �����ݿ�����������

        int nPos;
        int nIndex = 0;
        char *pszValue;
        char *psz;

        for (;;)
        {
            if (nIndex >= nColNum)
            {
                break;
            }
            nPos = nLineCount * nItemLen * nColNum + nIndex * nItemLen;

            pszValue = (char *)DArray_GetAt(pStrArray, nIndex);
            strncpy((char *)pTable + nPos, pszValue, nItemLen);

            psz = (char *)pTable + nPos + nItemLen - 1 ;
            *psz = '\0';

            nIndex += 1;
        }

        nLineCount ++;

        DArray_Destroy(pStrArray);

    }

    *ppTable = pTable;
    *nTableLineCount = nLineCount;

    return ERR_SUCCESS;
}


static int ParseTableFile(char * pszFileBuf, 
                          int nFileLen, 
                          int nColNum, 
                          int nItemLen,
                          void **ppTable,
                          int *nTableLineCount)
{
    int nLineCount = 0;
    int nTableBufLen;

    //char (* pTable)[nColNum][nItemLen];
    void *pTable;

    if (pszFileBuf == NULL || ppTable == NULL || nTableLineCount == NULL)
    {
        return ERR_FAILED;
    }

    for (int i = 0; i < nFileLen; i++)
    {
        if (pszFileBuf[i] == '\n')
        {
            nLineCount++;
        }
    }

    *nTableLineCount = nLineCount;

    nTableBufLen = nItemLen * nColNum * (nLineCount + 1) + 10;

    //pTable = (char (*)[nColNum][nItemLen]) NG_malloc(nTableBufLen);
    pTable =  NG_malloc(nTableBufLen);
    if (pTable == NULL)
    {
        return ERR_FAILED;
    }
    memset(pTable, 0, nTableBufLen);


    char *  pszLineToken;
    char *  pszKeyToken;
    char *  pszNextBuf;
    BOOL    bParseStatus    = ERR_SUCCESS;

    nLineCount = 0;
    for ( pszLineToken = strtok(pszFileBuf, "\r\n"); 
        pszLineToken != NULL; 
        pszLineToken = strtok(pszNextBuf, "\r\n") )
    {
        int         LineTokenLen;

        pszNextBuf = pszLineToken;
        LineTokenLen = (int)strlen(pszLineToken);

        pszKeyToken = strtok(pszLineToken, " \t");
        if ( pszKeyToken == NULL )
        {
            // һ��Ϊ���������һ��
            int exitflag = 0;
            for (pszNextBuf = pszNextBuf + LineTokenLen; 
                *pszNextBuf == '\0'; 
                pszNextBuf++)
            {
                if ( pszNextBuf >= (pszFileBuf + nFileLen -1) )
                {
                    exitflag = 1;
                    break;
                }
            }
            if (exitflag)
            {
                break;
            }

            continue;
        }
        strncpy(((char *)pTable + nLineCount * nItemLen * nColNum), pszKeyToken, nItemLen);
        *((char *)pTable + nLineCount * nItemLen * nColNum + nItemLen - 1) = '\0';

        printf("%s ", pszKeyToken); // debug

        for (int i = 1; i < nColNum; i++)
        {
            pszKeyToken = strtok(NULL, " \t");
            if ( pszKeyToken == NULL )
            {
                bParseStatus = ERR_FAILED;
                goto Lable_Error_Goto;
            }

            strncpy((char *)pTable + nLineCount * nItemLen * nColNum + i * nItemLen, pszKeyToken, nItemLen);
            *((char *)pTable + nLineCount * nItemLen * nColNum + i * nItemLen + nItemLen - 1) = '\0';

            printf("%s ", pszKeyToken); // debug
        }
        
        pszKeyToken = strtok(NULL, " \t");
        if ( pszKeyToken != NULL )
        {
            bParseStatus = ERR_FAILED;
            goto Lable_Error_Goto;
        }

        printf("\n"); // debug


        nLineCount++;

        int exitflag = 0;
        for (pszNextBuf = pszNextBuf + LineTokenLen; 
            *pszNextBuf == '\0'; 
            pszNextBuf++)
        {
            if ( pszNextBuf >= (pszFileBuf + nFileLen -1) )
            {
                exitflag = 1;
                break;
            }
        }
        if (exitflag)
        {
            break;
        }

    }

    *ppTable = pTable;
    *nTableLineCount = nLineCount;

    return ERR_SUCCESS;

Lable_Error_Goto:
    NG_free(pTable);
    return ERR_FAILED;

}

int HRS_ReadTableToStruct(HRS_TABLE_INFO *pTableInfo, char *pszOutErr)
{
    void *pTable;
    int nLineCount;
    int nColNum;
    int nItemLen;
    HRS_TABLE_SCHEMA *pSchema;
    int nStructLen;
    int nRet;
    int nOffset;
    int nOffsetSource;
    int nVarMaxLen;
    void **ppTableStruct;

    if (pTableInfo == NULL)
    {
        return ERR_FAILED;
    }

    pszOutErr[0] = '\0';

    nColNum = pTableInfo->nColNum;
    nItemLen = pTableInfo->nMaxItemLen;
    pSchema = pTableInfo->pTableSchema;
    nStructLen = pTableInfo->nStructLen;
    ppTableStruct = pTableInfo->ppTable;

    nRet = HRS_Table_ReadTableFromFile( pTableInfo->pszFilePath, 
                                        nColNum, 
                                        nItemLen, 
                                        &pTable, 
                                        &nLineCount); 
    if (nRet == ERR_FAILED)
    {
        sprintf(pszOutErr, "File: %s Load Failed.", pTableInfo->pszFilePath);
        return ERR_FAILED;
    }

    *ppTableStruct = NG_malloc(nLineCount * pTableInfo->nStructLen);
    if (*ppTableStruct == NULL)
    {
        return ERR_FAILED;
    }
    memset(*ppTableStruct, 0, nLineCount * pTableInfo->nStructLen);

    for (int i = 0; i < nLineCount; i++)
    {
        for (int j = 0; j < nColNum; j++)
        {
            switch (pSchema[j].VarType)
            {
            case HRS_TABLE_VARTYPE_CHAR:
                nVarMaxLen = pSchema[j].nVarLen;
                nOffset = nStructLen * i + pSchema[j].OffSet;
                nOffsetSource = i * nItemLen * nColNum + j * nItemLen;
                strncpy((char *)(*ppTableStruct)+nOffset, 
                        (char *)pTable + nOffsetSource, 
                        nVarMaxLen);
                *((char *)(*ppTableStruct)+nOffset+nVarMaxLen-1) = '\0';
                break;

            case HRS_TABLE_VARTYPE_INT:
                nOffset = nStructLen * i + pSchema[j].OffSet;
                nOffsetSource = i * nItemLen * nColNum + j * nItemLen;
                *((int *)((char *)(*ppTableStruct)+nOffset)) 
                        = atoi((char *)pTable + nOffsetSource);
                break;

            case HRS_TABLE_VARTYPE_DOUBLE:
                nOffset = nStructLen * i + pSchema[j].OffSet;
                nOffsetSource = i * nItemLen * nColNum + j * nItemLen;
                *((double *)((char *)(*ppTableStruct)+nOffset)) 
                        = atof((char *)pTable + nOffsetSource);
                break;

            default:
                break;
            }
        }
    }

    pTableInfo->nRowNum = nLineCount;

    NG_free(pTable);
    return ERR_SUCCESS;
}

void HRS_TableStruct_Destroy(HRS_TABLE_INFO *pTableInfo)
{
    void **ppTableStruct;

    if (pTableInfo == NULL)
    {
        return;
    }

    ppTableStruct = pTableInfo->ppTable;

    if (ppTableStruct != NULL)
    {
        NG_free(*ppTableStruct);
    }

    return;
}

int HRS_SimpleTable_Search(HRS_TABLE_INFO *pTableInfo, void*pKeyTable,
                           char *pszOutErr)
{
    int nLineCount;
    int nStructLen;
    int nKeyLen;
    void *ppTableStruct;

    pszOutErr[0] = '\0';

    if (pTableInfo == NULL || pKeyTable == NULL)
    {
        return ERR_FAILED;
    }

    if (pTableInfo->TableType != HRS_TABLE_TYPE_SIMPLE)
    {
        return ERR_FAILED;
    }

    nLineCount = pTableInfo->nRowNum;
    nStructLen = pTableInfo->nStructLen;
    nKeyLen = pTableInfo->nKeyLen;
    ppTableStruct = *(pTableInfo->ppTable);

    for (int i = 0; i < nLineCount; i++)
    {
        if (!memcmp((char *)ppTableStruct + i * nStructLen, pKeyTable, nKeyLen))
        {
            memcpy(pKeyTable, (char *)ppTableStruct + i * nStructLen, nStructLen);
            return ERR_SUCCESS;
        }
    }

    sprintf(pszOutErr, "\r\nFile: %s Query Failed. \r\nTalbeName: %s", 
            pTableInfo->pszFilePath, pTableInfo->strTableName);

    return ERR_FAILED;
}


int HRS_SimpleTable_Search_Multi(HRS_TABLE_INFO *pTableInfo, 
                                 void*pKeyTable, 
                                 int nDataNum,
                                 char *pszOutErr)
{
    int nLineCount;
    int nStructLen;
    int nKeyLen;
    void *ppTableStruct;

    if (pTableInfo == NULL || pKeyTable == NULL || NULL == pKeyTable)
    {
        return ERR_FAILED;
    }

    if (pTableInfo->TableType != HRS_TABLE_TYPE_SIMPLE)
    {
        return ERR_FAILED;
    }

    nLineCount = pTableInfo->nRowNum;       //����״̬������
    nStructLen = pTableInfo->nStructLen;    //�������ݽṹ����
    nKeyLen = pTableInfo->nKeyLen;          //����ͷ���ȣ��򵥱�����Ч
    ppTableStruct = *(pTableInfo->ppTable); //pTableInfo->ppTable��ָ��ָ���ָ��

    int j = 0;

    char *pTable = (char *)pKeyTable;

    for (int i = 0; i < nLineCount; i++)
    {
        if (!memcmp((char *)ppTableStruct + i * nStructLen, pKeyTable, nKeyLen))
	       //memcmp�ǱȽ��ڴ�����buf1��buf2��ǰnKeyLen�����ݡ���buf1<buf2,����ֵС��0��buf1=buf2ʱ������ֵΪ0��buf1>buf2ʱ������ֵ����0���Ƚϱ�׼���ǰ���ASCII��ֵ���Ƚϵ�
        {
            memcpy(pTable + j * nStructLen, 
                   (char *)ppTableStruct + i * nStructLen, nStructLen);
			//memcpy���ڴ濽���������Ǵ�Դ(char *)ppTableStruct + i * nStructLen��ָ�ڴ��ַ����ʼλ�ÿ�ʼ����nStructLen���ֽڵ�Ŀ��pTable + j * nStructLen��ָ�����ʼ��ַ
            //��������pTable(ָ��pKeyTable��ָ��pTable��ָ��HRS_RML2Calc_CalcSpeed�����е�aRmSpeedTab�������ո��������ٶ�ֵ�ı���õ����¡�
			//���������ǣ���������������µģ�
			//������ͨ��ppTableStruct������и��µ�
			//��ppTableStruct��HRS_RmSpeedTab_SearchMulti�����������Ĳ�����gHRSTableInfo_RmSpeed
			//���ԣ������һ���о�gHRSTableInfo_RmSpeed���������õ���

            j++;

            // ������������ֹԽ��
            if (j > nDataNum )
            {
                break;
            }
        }
    }

    if (j > 0)
    {
        return ERR_SUCCESS;
    }

    sprintf(pszOutErr, "\r\nQuery Table: %s Failed. \r\nFile: %s", 
        pTableInfo->strTableName, pTableInfo->pszFilePath);

    return ERR_FAILED;
}


