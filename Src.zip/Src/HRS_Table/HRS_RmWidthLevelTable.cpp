
#include "NG.h"
#include "stddef.h"

#include "HRS_TableBase.h"
#include "HRS_LevelTableBase.h"
#include "HRS_RmWidthLevelTable.h"

extern HRS_TABLE_SCHEMA  HRSTableSchema_Level[];

HRS_TABLE_LEVEL *gpTableRmWidthLevel;

HRS_TABLE_INFO gHRSTableInfo_RmWidthLevel =
{
    "RmWidthLevel",                                 // ����
    3,                                             // ����
    HRSTableSchema_Level,                      // ����ģ�����
    CFG_RM_WIDTH_LEVEL,                          // �����ļ���
    64,                                             // ��Ԫ��󳤶�
    HRS_TABLE_TYPE_LEVEL,                          // ��������
    0,                                              // ����ͷ���ȣ��򵥱�����Ч
    sizeof(HRS_TABLE_LEVEL),                   // �������ݽṹ����
    0,                                              // ����״̬������
    (void **)(&gpTableRmWidthLevel)
};



int HRS_RmWidthLevelTable_Init(char *pszOutErr)
{
    return HRS_LevelTable_Init(&gHRSTableInfo_RmWidthLevel, pszOutErr);
}

void HRS_RmWidthLevelTable_Destroy()
{
    HRS_LevelTable_Destroy(&gHRSTableInfo_RmWidthLevel);
}

int HRS_RmWidthLevelTable_Query(double dRmWidth, int * pnLevel, char *pszOutErr)
{
    int nRet;

    nRet = HRS_LevelTable_Query(&gHRSTableInfo_RmWidthLevel, 
                                dRmWidth, pnLevel, pszOutErr);
    if (nRet == ERR_FAILED)
    {
        char szMsg[256];

        sprintf(szMsg, 
            "RmWidth  : %f\r\n"    
            "nLevel   : %d\r\n",  
            dRmWidth, 
            *pnLevel);

        strcat(pszOutErr, "\r\n");
        strcat(pszOutErr, szMsg);
    }

    return nRet;
}
