
#ifndef __HRS_FmDraftRatioTable_H__
#define __HRS_FmDraftRatioTable_H__

#ifdef __cplusplus
extern "C" {
#endif







typedef struct HRS_TABLE_FM_DRAFTRATIO_st
{
    int nSteelGradeCode;                // ���ַ���   SFC
    int nQualityCode;                      // ������	QUAL
    int	nTargetGaugeLevel;              // Ŀ���ȵȼ�
    int	nFMWidthLevel;                  // �������ȼ���
    int	nFinalTempLevel;                // �����¶ȼ���

    double fLoadValue1;
    double fLoadValue2;
    double fLoadValue3;
    double fLoadValue4;
    double fLoadValue5;
    double fLoadValue6;
    double fLoadValue7;

} HRS_TABLE_FM_DRAFTRATIO;

int HRS_FmDraftRatioTable_Init(char *pszOutErr);
void HRS_FmDraftRatioTable_Destroy();
int HRS_FmDraftRatioTab_Search(HRS_TABLE_FM_DRAFTRATIO *pTable, char *pszOutErr);



#ifdef __cplusplus
}
#endif


#endif // __HRS_FmDraftRatioTable_H__