
#include "NG.h"
#include "NG_Handle.h"
#include "CGlobalInstance.h"

#include "HRS_Calc.h"

#include "HRS_CalcData.h"
#include "HRS_CommonCalc.h"
#include "HRS_RMCalc.h"


extern "C" CGlobalInstance *HRS_GetGlobalInstance();

typedef struct HRS_CALC_DATA_st {
    HRS_RM_ALL_DATA    AllData;
} HRS_CALC_DATA;


void HRS_CalcData_Destroy(void *pData)
{
    HRS_CALC_DATA *pCalcData;

    pCalcData = (HRS_CALC_DATA *)pData;

    if (pCalcData != NULL)
    {
        NG_free(pCalcData);
    }

    return;
}


HANDLE HRS_Calc_Create(HRS_PLAN_DATA *pPlanData,
                       HRS_RM_STRATEGY_DATA *pStrategyData,
                       HRS_PLATE_DATA    *pPlateData,
                       HRS_ALL_STAND_PARA *pAllStandPara,
                       HRS_DEFORM_RESIST_FACTOR *pDeformFactor
                       )
{
    REAL_HANDLE    *pHandle;
    HRS_CALC_DATA  *pCalcData;
    HRS_RM_ALL_DATA *pAllData;

    HRS_STEEL_GRADE  SteelGrade;
    HRS_SLAB_DATA    *pSlabData;

    if (   pPlanData     == NULL 
        || pStrategyData == NULL
        || pPlateData    == NULL
        || pAllStandPara == NULL
        || pDeformFactor == NULL )
    {
        return NULL;
    }

    pCalcData = (HRS_CALC_DATA *)NG_malloc(sizeof(HRS_CALC_DATA));
    if (pCalcData == NULL)
    {
        return NULL;
    }

    pAllData = &(pCalcData->AllData);

    pAllData->AllStandPara = *pAllStandPara;
    pAllData->DeformFactor = *pDeformFactor;
    pAllData->PlanData     = *pPlanData;
    pAllData->PlateData    = *pPlateData;
    pAllData->StrategyData = *pStrategyData;

    SteelGrade.SlabData        = pPlanData->SlabData;
    SteelGrade.dDownCoilerTemp = pPlanData->dCoilTemp;
    SteelGrade.dFMDeliveryTemp = pPlanData->dRMDeliveryTemp;
    SteelGrade.dTargetGuage    = pPlanData->dTargetGauge;
    SteelGrade.dTargetWidth    = pPlanData->dTargetWidth;

    pSlabData = &(SteelGrade.SlabData);


    //HRS_RML2Calc_GetSteelData(&SteelGrade, &(pAllData->SteelLevel));


    pHandle = RealHandle_New();

    pHandle->nId = HANDLE_ID_RW_CALC;
    pHandle->pObject = pCalcData;
    pHandle->func    = HRS_CalcData_Destroy;

    return (HANDLE)pHandle;
}


int HRS_Calc_RM_Gauge(HANDLE hCalcData, 
                      HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge)
{
    REAL_HANDLE      *pHandle;
    HRS_CALC_DATA    *pCalcData;
    HRS_RM_ALL_PASS   AllPass;
    int               nRet;
    char              szOutErr[1024];

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareGaugePara(&(pCalcData->AllData), 
                                  &AllPass);

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, pAllDeliveryGauge,
                                  szOutErr);

    return nRet;
}


int HRS_Calc_RM_Speed(HANDLE hCalcData, HRS_RM_ALL_SPEED *pAllSpeed)
{
    REAL_HANDLE          *pHandle;
    HRS_CALC_DATA        *pCalcData;

    HRS_RM_ALL_PASS            AllPass;
    HRS_RM_ALL_DELIVERY_GAUGE  AllGauge;
    HRS_RM_ALL_ENTRY_PARA      AllEntry;
    char                  szOutErr[1024];

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareGaugePara(&(pCalcData->AllData), 
        &AllPass);
    HRS_RML2Calc_CalcGauge(&AllPass, &AllGauge,
                           szOutErr);

    HRS_RML2Calc_PrepareEntryPara(&(pCalcData->AllData), 
        &AllPass,
        &AllGauge,
        &AllEntry);

    //nRet = HRS_RML2Calc_CalcSpeed(&AllEntry, pAllSpeed);

    return ERR_SUCCESS;
}


int HRS_Calc_RM_Temp(HANDLE hCalcData, HRS_RM_ALL_TEMP *pAllTemp)
{
    REAL_HANDLE          *pHandle;
    HRS_CALC_DATA        *pCalcData;
    HRS_RM_ALL_PASS            AllPass;
    HRS_RM_ALL_DELIVERY_GAUGE  AllGauge;
    HRS_RM_ALL_ENTRY_PARA      AllEntry;
    char                       szOutErr[1024];

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareGaugePara(&(pCalcData->AllData), 
                                  &AllPass);
    HRS_RML2Calc_CalcGauge(&AllPass, &AllGauge, szOutErr);

    HRS_RML2Calc_PrepareEntryPara(&(pCalcData->AllData), 
                                  &AllPass,
                                  &AllGauge,
                                  &AllEntry);

    //int nRet = HRS_RML2Calc_CalcTemp(&AllEntry, pAllTemp);

    return ERR_SUCCESS;
}


int HRS_Calc_RM_RollingForce(HANDLE hCalcData, 
                             HRS_RM_ALL_ROLL_FORCE *pAllRollForce)//������
{
    REAL_HANDLE          *pHandle;
    HRS_CALC_DATA        *pCalcData;
    int                   nRet;

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcRollingForce(&(pCalcData->AllData), pAllRollForce);

    return nRet;
}


int HRS_Calc_RM_Gap(HANDLE hCalcData, HRS_RM_ALL_GAP *pAllGap)//����
{
    REAL_HANDLE         *pHandle;
    HRS_CALC_DATA       *pCalcData;
    int                  nRet;

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcGap(&(pCalcData->AllData), pAllGap);

    return nRet;
}


int HRS_Calc_RM_AllData(HANDLE hCalcData, HRS_RM_ALL_OUT_DATA *pAllOutData)
{
    REAL_HANDLE   *pHandle;
    HRS_CALC_DATA *pCalcData;
    int            nRet;

    if (hCalcData == NULL)
    {
        return ERR_FAILED;
    }

    pHandle = (REAL_HANDLE *)hCalcData;

    pCalcData = (HRS_CALC_DATA *)pHandle->pObject;

    if (pHandle->nId != HANDLE_ID_RW_CALC)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcAllData(&(pCalcData->AllData),
                             pAllOutData);

    return nRet;
}

