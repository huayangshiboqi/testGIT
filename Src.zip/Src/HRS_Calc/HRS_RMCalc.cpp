#include <math.h>
#include <direct.h>
#include "NG.h"
#include "NG_debug.h"
#include "NG_Path.h"
#include "CGlobalInstance.h"

#include "HRS_Global.h"
#include "HRS_CommonCalc.h"
#include "HRS_RMCalc.h"
#include "HRS_ModuleName.h"
#include "HRS_ServerCfg.h"
#include "HRS_EquipParaMgr.h"
#include "HRS_RmDraftRatioTable.h"

#include "HRS_AllTable.h"
#include "HRS_ModulusTable.h"

#if 0
�����������¶ȣ� VHCR-MOSFM-4.4.8.2.1
��������κ��ѹ��������ں�ȳ��ں�ȣ�VHCR-MOSFM-4.4.8.2.2
��������ο������� VHCR-MOSFM-4.4.8.2.3
������ڳ��ȣ� VHCR-MOSFM-4.4.8.2.4
��������¶ȣ� VHCR-MOSFM-4.4.8.2.5
����ˮƽ�������������� VHCR-MOSFM-4.4.8.2.6

// ��������¶�
/**
    ͨ����������ӳ�¯�󵽴�����ʼ����ǰ���½����������������¶ȡ�
    ���У�
    TEIN��I������I��������¶� 
    TAUS��I��1������I��1���γ����¶� 
    GAST���ȷ��䳣�� 
    TIME��I�����ӵ�I��1����ҧ�ֵ���I����ҧ�ֵ�ʱ�� 
    HEIN��I������ں��
    TSPR�������½� 
    TSPR = TVMAX - (HEIN(I) - HEINM) * TSPM
    TVMAX����С���ʱ������½� 
    HEINM��������С��� 
    TSPM���½�����б��
*/
HRS_RM_CalcTempIn(int i)  // i��ʾ���Σ���1��ʼ
{
    assert(i >= 1);

    double dValue;   // �����õ���ʱ����
    double dData;    // �����õ���ʱ����

    double dGast;       // �ȷ��䳣��
    double dTspm;    // TSPM���½�����б��
    double dHeinm;   // HEINM��������С��� 
    double dTvMax;   // TVMAX����С���ʱ������½� 
    double dTspr;    // TSPR�������½� 

    double adTempIn[16]; // ����������¶�����
    double adTaus[16];   // �������γ����¶�
    double adTime[16];   // ������ҧ��ʱ��
    double adHein[16];   // ��ں��


    dTspr = dTvMax - (adHein[i] - dHeinm) * dTspm;


    dData = adTaus[i-1];
    dValue = dData * dData * dData;

    dData = 1.0 / dValue;  // ��ҪУ��dValue��ֵ�Ƿ����Ϊ0

    dValue = dData + (dGast * adTime[i]) / adHein[i];  // ��ҪУ��adHein[i]��ֵ�Ƿ����Ϊ0

    dData = powf(dValue, 1.0/3.0);

    dValue = 1.0 / dData;   // ��ҪУ��dData��ֵ�Ƿ����Ϊ0
    
    dValue = dValue - dTspr;

    adTempIn[i] = dValue;

    return;
}

#endif

#if 0
// ׼���������� 
int HRS_RML2Calc_Prepare(int nSequentialNo, 
                         char *pszStripNo,
                         HRS_RM_ALL_DATA  *pRMAllData)
{
    HRS_STEEL_GRADE   steel_grade;
    HRS_SLAB_DATA     *pSlabeData;
    HRS_PLAN_DATA     *pPlanData;

    HRS_RML2Calc_GetSchedulePlanData(nSequentialNo, pszStripNo,
                                     &(pRMAllData->PlanData));
    HRS_RML2Calc_GetRMStrategyData(pszStripNo, &(pRMAllData->StrategyData));
    HRS_RML2Calc_GetPlateData(nSequentialNo, pszStripNo,
                              &(pRMAllData->PlateData));

    HRS_RML2Cacl_GetAllMillParaData(&(pRMAllData->AllStandPara));

    pPlanData = &(pRMAllData->PlanData);
    steel_grade.dDownCoilerTemp = pPlanData->dCoilTemp;
    steel_grade.dFMDeliveryTemp = pPlanData->dRMDeliveryTemp;
    steel_grade.dTargetGuage    = pPlanData->dTargetGauge;
    steel_grade.dTargetWidth    = pPlanData->dTargetWidth;

    pSlabeData = &(steel_grade.SlabData);

    *pSlabeData = pPlanData->SlabData;

    HRS_RML2Calc_GetSteelData(&steel_grade, &(pRMAllData->SteelLevel));

    CGlobalInstance *pInst = HRS_GetGlobalInstance();

    CHRSServerCfg *pServerCfg = (CHRSServerCfg *)pInst->QueryNotCheck(
                                                  HRS_MOD_NAME_HRS_ServerCfg);
    HRS_DEFORM_RESIST_FACTOR *pFactor = pServerCfg->FindDeformFactor(
                                                  pSlabeData->szSteelGradeName);
    pRMAllData->DeformFactor = *pFactor;

    return ERR_SUCCESS;
}

// ��ȡ���Ƽƻ����� 
int HRS_RML2Calc_GetSchedulePlanData(int nSequentialNo, 
                                     char *pszStripNo, 
                                     HRS_PLAN_DATA *pPlanData)
{

    return ERR_SUCCESS;
}


// ��ȡ���Ʋ������� 
int HRS_RML2Calc_GetRMStrategyData(char *pszStripNo, 
                                   HRS_RM_STRATEGY_DATA *pStrategyData)
{

    return ERR_SUCCESS;
}


// ��ȡ��������     
int HRS_RML2Calc_GetPlateData(int nSequentialNo, 
                              char *pszStripNo, 
                              HRS_PLATE_DATA *pPlateData)
{
    return ERR_SUCCESS;
}


// ��ȡ�豸����     
int HRS_RML2Calc_GetEquipParaData(int nMillNo, 
                                  HRS_STAND_PARA *pEquipPara)
{
    HRS_STAND_PARA *pPara;

    CGlobalInstance *pInst = HRS_GetGlobalInstance();

    CHRSEquipParaMgr *pMgr = (CHRSEquipParaMgr *)pInst->QueryNotCheck(
                                              HRS_MOD_NAME_HRS_EquipParaMgr);

    pPara = pMgr->GetStandPara(nMillNo);
    if (pPara == NULL)
    {
        return ERR_FAILED;
    }

    *pEquipPara = *pPara;

    return ERR_SUCCESS;
}


int HRS_RML2Cacl_GetAllMillParaData(HRS_ALL_STAND_PARA *pAllMillPara)
{
    int i;
    if (pAllMillPara == NULL)
    {
        return ERR_FAILED;
    }

    for (i = 0; i < HRS_MAX_STAND_NUM; i++)
    {
        HRS_RML2Calc_GetEquipParaData(i, &(pAllMillPara->aEquipPara[i]));
    }

    return ERR_SUCCESS;
}

#endif

// ���ݰ������ݼ�����ֵȼ�����ȼ����ȵȼ� 
int HRS_RML2Calc_GetSteelData(HRS_RM_ALL_DATA *pAllData) 
                              
{
    HRS_STEEL_LEVEL *SteelLevel;
    double dSlabGauge;
    double dSlabWidth;
    double dBarGauge;
    double dRmWidth;
    double dFmDeliveryTemp;
    HRS_PLAN_DATA        *pPlanData;
    int nRet;
    char *pszOutErr;

    pszOutErr = pAllData->szOutErr;

    pPlanData     = &(pAllData->PlanData);

    pszOutErr[0] = '\0';

    //��ʼ�����ģ��
    nRet = HRS_AllTable_Init(pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;

    SteelLevel->nSteelGradeCode = pPlanData->SlabData.nSteelGradeCode;


    dSlabGauge = pPlanData->SlabData.dSlabGauge;
    nRet = HRS_SlabGaugeLevelTable_Query(dSlabGauge,
        &SteelLevel->nSlabGaugeLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dSlabWidth = pPlanData->SlabData.dSlabWidth;
    nRet = HRS_SlabWidthLevelTable_Query(dSlabWidth,
        &SteelLevel->nSlabWidthLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dBarGauge = pPlanData->dTransferBarGauge;  // ���м�����Ȳ��ȵȼ�

    nRet = HRS_BarGaugeLevelTable_Query(dBarGauge,
        &SteelLevel->nTargetGaugeLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dRmWidth = pPlanData->dTargetWidth;
    nRet = HRS_RmWidthLevelTable_Query(dRmWidth,
        &SteelLevel->nRMWidthLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���м������ȵȼ�����������ȵȼ� ...
    SteelLevel->nSlabWidthLevel = SteelLevel->nRMWidthLevel;

    dFmDeliveryTemp = pPlanData->dFMDeliveryTemp;
    nRet = HRS_FmDeliveryTempLevelTable_Query(dFmDeliveryTemp,
        &SteelLevel->nFinalTempLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_RmDraftPara
    �ӳ�ʼ�����������ɵ���������Ϣ 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������

    @param HRS_RM_ALL_PASS * pAllPass - [out]����������Ϣ 
    @param void *pRmDraftTab          - [out]ѹ�������� 
    @param int nTableDataNum          - [out]ѹ����������Ŀ 

    @return void - ��
*/
void HRS_RML2Calc_RmDraftPara(HRS_RM_ALL_DATA *pAllData,
                              HRS_RM_ALL_PASS *pAllPass,
                              void *pDraftTab,
                              int nTableDataNum)
{
    HRS_RM_STRATEGY_DATA *pStrategyData;
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    HRS_PASS             *pRMPass;
    int                   i;

    HRS_PASS_MODE_EM      nPassMode;

    if (pAllData == NULL || pAllPass == NULL || NULL == pDraftTab)
    {
        return;
    }

    HRS_TABLE_RM_DRAFTRATIO *pRmDraftTab = (HRS_TABLE_RM_DRAFTRATIO *)pDraftTab;

    pPlanData     = &(pAllData->PlanData);
    pStrategyData = &(pAllData->StrategyData);
    SteelLevel = &pAllData->SteelLevel;

    //////////////////////////////////////////////////////////////////////////
    // �ȸ�����1�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm1stPass);
    
    //
    // ��ѯѹ���ʱ�����ȡ������ѹ��������
    //
    for (int i = 0; i < nTableDataNum; i++)
    {
        pRmDraftTab[i].nSteelGradeCode = SteelLevel->nSteelGradeCode;;
        pRmDraftTab[i].nSlabGaugeLevel = SteelLevel->nSlabGaugeLevel;
        pRmDraftTab[i].nSlabWidthLevel = SteelLevel->nSlabWidthLevel;
        pRmDraftTab[i].nBarGaugeLevel = SteelLevel->nTargetGaugeLevel;
        pRmDraftTab[i].nRMWidthLevel = SteelLevel->nRMWidthLevel;
//        pRmDraftTab[i].nFinalTempLevel = SteelLevel->nFinalTempLevel;

    }

    HRS_RmDraftRatioTab_SearchMulti(pRmDraftTab, nTableDataNum, 
                                    pAllData->szOutErr);

    nPassMode = pAllData->StrategyData.nPassMode;

    // ���ҵ���ģʽ
    int nFind;
    nFind = -1;
    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )
    {
        if ( pRmDraftTab[i].nPassMode == nPassMode)
        {
            // �ҵ��˶�Ӧ�ĵ��η���ģʽ��ѹ���ʷ����
            nFind = i;
            break;
        }
    }

    if ( nFind < 0 )
    {
        nFind = 0;
    }

    nPassMode = (HRS_PASS_MODE_EM)pRmDraftTab[nFind].nPassMode;
    pAllData->StrategyData.nPassMode = nPassMode;

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab[nFind].dLoadValueR11;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab[nFind].dLoadValueR12;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab[nFind].dLoadValueR13;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM1;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode / 10;


    //////////////////////////////////////////////////////////////////////////
    // �ٸ�����2�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm2ndPass);

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab[nFind].dLoadValueR21;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab[nFind].dLoadValueR22;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab[nFind].dLoadValueR23;
    pRMPass->adPassDraftRatio[3] = pRmDraftTab[nFind].dLoadValueR24;
    pRMPass->adPassDraftRatio[4] = pRmDraftTab[nFind].dLoadValueR25;
    pRMPass->adPassDraftRatio[5] = pRmDraftTab[nFind].dLoadValueR26;
    pRMPass->adPassDraftRatio[6] = pRmDraftTab[nFind].dLoadValueR27;


    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM2;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode % 10;


    // ������ƫ��
    pAllPass->dMaxDeviation = HRS_MAX_CALC_DEVIATION;
    
    return; 
}


/** Method:    HRS_RML2Calc_RmDraftPara
    �ӳ�ʼ�����������ɵ���������Ϣ 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������

    @param HRS_RM_ALL_PASS * pAllPass - [out]����������Ϣ 
    @param void *pRmDraftTab          - [out]ѹ�������� 
    @param int nTableDataNum          - [out]ѹ����������Ŀ 

    @return void - ��
*/
void HRS_RML2Calc_RmDraftParaGUI(HRS_RM_ALL_DATA *pAllData,
                              HRS_RM_ALL_PASS *pAllPass,
                              void *pDraftTab,
                              int nTableDataNum,
                              int nPassMode)
{
    HRS_RM_STRATEGY_DATA *pStrategyData;
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    HRS_PASS             *pRMPass;
    int                   i;

    if (pAllData == NULL || pAllPass == NULL || NULL == pDraftTab)
    {
        return;
    }

    HRS_TABLE_RM_DRAFTRATIO *pRmDraftTab = (HRS_TABLE_RM_DRAFTRATIO *)pDraftTab;

    pPlanData     = &(pAllData->PlanData);
    pStrategyData = &(pAllData->StrategyData);
    SteelLevel = &pAllData->SteelLevel;

    //////////////////////////////////////////////////////////////////////////
    // �ȸ�����1�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm1stPass);
    
    //
    // ��ѯѹ���ʱ�����ȡ������ѹ��������
    //
    for (i = 0; i < nTableDataNum; i++)
    {
        pRmDraftTab[i].nSteelGradeCode = SteelLevel->nSteelGradeCode;;
        pRmDraftTab[i].nSlabGaugeLevel = SteelLevel->nSlabGaugeLevel;
        pRmDraftTab[i].nSlabWidthLevel = SteelLevel->nSlabWidthLevel;
        pRmDraftTab[i].nBarGaugeLevel = SteelLevel->nTargetGaugeLevel;
        pRmDraftTab[i].nRMWidthLevel = SteelLevel->nRMWidthLevel;
//        pRmDraftTab[i].nFinalTempLevel = SteelLevel->nFinalTempLevel;

    }

    //HRS_RmDraftRatioTab_SearchMulti(pRmDraftTab, nTableDataNum, 
    //                                pAllData->szOutErr);

    // ���ҵ���ģʽ
    int nFind;
    nFind = -1;
    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )
    {
        if ( pRmDraftTab[i].nPassMode == nPassMode)
        {
            // �ҵ��˶�Ӧ�ĵ��η���ģʽ��ѹ���ʷ����
            nFind = i;
            break;
        }
    }
    
    if ( nFind < 0 )
    {
        nFind = 0;
    }

    pAllData->StrategyData.nPassMode = (HRS_PASS_MODE_EM)nPassMode;

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab[nFind].dLoadValueR11;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab[nFind].dLoadValueR12;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab[nFind].dLoadValueR13;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM1;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode / 10;


    //////////////////////////////////////////////////////////////////////////
    // �ٸ�����2�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm2ndPass);

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab[nFind].dLoadValueR21;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab[nFind].dLoadValueR22;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab[nFind].dLoadValueR23;
    pRMPass->adPassDraftRatio[3] = pRmDraftTab[nFind].dLoadValueR24;
    pRMPass->adPassDraftRatio[4] = pRmDraftTab[nFind].dLoadValueR25;
    pRMPass->adPassDraftRatio[5] = pRmDraftTab[nFind].dLoadValueR26;
    pRMPass->adPassDraftRatio[6] = pRmDraftTab[nFind].dLoadValueR27;


    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM2;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode % 10;

    // ������ƫ��
    pAllPass->dMaxDeviation = HRS_MAX_CALC_DEVIATION;
    
    return; 
}


/** Method:    HRS_RML2Calc_PrepareGaugePara
    �ӳ�ʼ�����������ɵ���������Ϣ 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_PASS * pAllPass - [out]����������Ϣ 
    
    @return void - ��
*/
void HRS_RML2Calc_PrepareGaugePara(HRS_RM_ALL_DATA *pAllData,
                                   HRS_RM_ALL_PASS *pAllPass)
{
    HRS_RM_STRATEGY_DATA *pStrategyData;
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    HRS_PASS             *pRMPass;

    HRS_PASS_MODE_EM      nPassMode;


    if (pAllData == NULL || pAllPass == NULL)
    {
        return;
    }

    pPlanData     = &(pAllData->PlanData);
    pStrategyData = &(pAllData->StrategyData);
    SteelLevel = &pAllData->SteelLevel;

    nPassMode = pAllData->StrategyData.nPassMode;

    //////////////////////////////////////////////////////////////////////////
    // �ȸ�����1�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm1stPass);
    
    //
    // ��ѯѹ���ʱ�����ȡ������ѹ��������
    //
    HRS_TABLE_RM_DRAFTRATIO pRmDraftTab;
    pRmDraftTab.nSteelGradeCode = SteelLevel->nSteelGradeCode;;
    pRmDraftTab.nSlabGaugeLevel = SteelLevel->nSlabGaugeLevel;
    pRmDraftTab.nSlabWidthLevel = SteelLevel->nSlabWidthLevel;
    pRmDraftTab.nBarGaugeLevel  = SteelLevel->nTargetGaugeLevel;
    pRmDraftTab.nRMWidthLevel   = SteelLevel->nRMWidthLevel;
//    pRmDraftTab.nFinalTempLevel = SteelLevel->nFinalTempLevel;
    pRmDraftTab.nPassMode = nPassMode;

    HRS_RmDraftRatioTab_Search(&pRmDraftTab, pAllData->szOutErr);

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab.dLoadValueR11;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab.dLoadValueR12;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab.dLoadValueR13;

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStrategyData->rm_adjust_R1[0].dDraftRatio;
    pRMPass->adPassDraftRatio[1] = pStrategyData->rm_adjust_R1[1].dDraftRatio;
    pRMPass->adPassDraftRatio[2] = pStrategyData->rm_adjust_R1[2].dDraftRatio;

    pRMPass->adDeliveryGauge[0]  = pStrategyData->rm_adjust_R1[0].dDeliveryGauge;
    pRMPass->adDeliveryGauge[1]  = pStrategyData->rm_adjust_R1[1].dDeliveryGauge;
    pRMPass->adDeliveryGauge[2]  = pStrategyData->rm_adjust_R1[2].dDeliveryGauge;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM1;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode / 10;


    //////////////////////////////////////////////////////////////////////////
    // �ٸ�����2�ĳ�Ա��ֵ
    // 
    pRMPass       = &(pAllPass->Rm2ndPass);

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pRmDraftTab.dLoadValueR21;
    pRMPass->adPassDraftRatio[1] = pRmDraftTab.dLoadValueR22;
    pRMPass->adPassDraftRatio[2] = pRmDraftTab.dLoadValueR23;
    pRMPass->adPassDraftRatio[3] = pRmDraftTab.dLoadValueR24;
    pRMPass->adPassDraftRatio[4] = pRmDraftTab.dLoadValueR25;
    pRMPass->adPassDraftRatio[5] = pRmDraftTab.dLoadValueR26;
    pRMPass->adPassDraftRatio[6] = pRmDraftTab.dLoadValueR27;



    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStrategyData->rm_adjust_R2[0].dDraftRatio;
    pRMPass->adPassDraftRatio[1] = pStrategyData->rm_adjust_R2[1].dDraftRatio;
    pRMPass->adPassDraftRatio[2] = pStrategyData->rm_adjust_R2[2].dDraftRatio;
    pRMPass->adPassDraftRatio[3] = pStrategyData->rm_adjust_R2[3].dDraftRatio;
    pRMPass->adPassDraftRatio[4] = pStrategyData->rm_adjust_R2[4].dDraftRatio;
    pRMPass->adPassDraftRatio[5] = pStrategyData->rm_adjust_R2[5].dDraftRatio;
    pRMPass->adPassDraftRatio[6] = pStrategyData->rm_adjust_R2[6].dDraftRatio;
    pRMPass->adDeliveryGauge[0]  = pStrategyData->rm_adjust_R2[0].dDeliveryGauge;
    pRMPass->adDeliveryGauge[1]  = pStrategyData->rm_adjust_R2[1].dDeliveryGauge;
    pRMPass->adDeliveryGauge[2]  = pStrategyData->rm_adjust_R2[2].dDeliveryGauge;
    pRMPass->adDeliveryGauge[3]  = pStrategyData->rm_adjust_R2[3].dDeliveryGauge;
    pRMPass->adDeliveryGauge[4]  = pStrategyData->rm_adjust_R2[4].dDeliveryGauge;
    pRMPass->adDeliveryGauge[5]  = pStrategyData->rm_adjust_R2[5].dDeliveryGauge;
    pRMPass->adDeliveryGauge[6]  = pStrategyData->rm_adjust_R2[6].dDeliveryGauge;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pPlanData->SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pStrategyData->dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM2;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode % 10;

    // ������ƫ��
    pAllPass->dMaxDeviation = HRS_MAX_CALC_DEVIATION;
    
    return; 
}


/** Method:    HRS_RML2Calc_CalcGauge
    ��������γ��ں�� 

    @param HRS_RM_ALL_PASS * pRMAllPass - ���е���������Ϣ
    @param HRS_RM_ALL_DELIVERY_GAUGE * pAllDeliveryGauge - [out]���е��εĳ��ں��
    @param char * pszOutErr - [out]���������Ϣ
    
    @return int - ��
*/
int HRS_RML2Calc_CalcGauge(HRS_RM_ALL_PASS *pRMAllPass, 
                           HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                           char *pszOutErr)
{
    int nRet;
    int i;
    int nRm1stPassNum;
    int nRm2ndPassNum;
    int nTotalPassNum;

    double dEntryGague;
    double dDeliveryGauge;
    
    double adDraftRatio[HRS_MAX_RM_PASS_NUM];
    double adDeliveryGauge[HRS_MAX_RM_PASS_NUM];
    double adEntryGauge[HRS_MAX_RM_PASS_NUM];
    double adActDraftRatio[HRS_MAX_RM_PASS_NUM];
   

    if (pRMAllPass == NULL || pAllDeliveryGauge == NULL)
    {
        return ERR_FAILED;
    }

    memset(pAllDeliveryGauge , 0, sizeof(HRS_RM_ALL_DELIVERY_GAUGE));

    nRm1stPassNum  = pRMAllPass->Rm1stPass.nTotalPassNum;
    nRm2ndPassNum  = pRMAllPass->Rm2ndPass.nTotalPassNum;
    nTotalPassNum  = nRm1stPassNum;
    nTotalPassNum += nRm2ndPassNum;

    dEntryGague    = pRMAllPass->Rm1stPass.dSlabGauge;
    dDeliveryGauge = pRMAllPass->Rm1stPass.dTransferBarThick;

    //
    // ���õ���ѹ�������飬Ϊ������ü�����ں�Ⱥ���׼������
    //
    for (i = 0; i < nRm1stPassNum; i++)
    {
        adDraftRatio[i] = pRMAllPass->Rm1stPass.adPassDraftRatio[i];
//        adDeliveryGauge[i] = pRMAllPass->Rm1stPass.adDeliveryGauge[i];
    }

    for (i = nRm1stPassNum; i < nTotalPassNum; i++)
    {
        adDraftRatio[i] = pRMAllPass->Rm2ndPass.adPassDraftRatio[i - nRm1stPassNum];
//        adDeliveryGauge[i] = pRMAllPass->Rm2ndPass.adDeliveryGauge[i - nRm1stPassNum];
    }


    //
    // ������ں��
    //
    nRet = HRS_Calc_DeliveryGauge(nTotalPassNum,
                           dEntryGague, 
                           dDeliveryGauge, 
                           adDraftRatio, 
                           pRMAllPass->dMaxDeviation, 
                           adDeliveryGauge ,
                           adEntryGauge, 
                           adActDraftRatio,
                           pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // �����������õ����������
    //
    pAllDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum = nRm1stPassNum;
    for (i = 0; i < nRm1stPassNum; i++)
    {
        pAllDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge[i] 
                                                       = adDeliveryGauge[i];
    }

    pAllDeliveryGauge->Rm2ndDeliveryGauge.nTotalPassNum = nRm2ndPassNum;
    for (i = nRm1stPassNum; i < nTotalPassNum; i++)
    {
        pAllDeliveryGauge->Rm2ndDeliveryGauge.adDeliveryGauge[i - nRm1stPassNum] 
                                                       = adDeliveryGauge[i];
    }

#if 0
    pAllDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum = nRm1stPassNum;
    for (i = 0; i < nRm1stPassNum; i++)
    {
        pAllDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge[i] 
            = pRMAllPass->Rm1stPass.adDeliveryGauge[i];
    }

    pAllDeliveryGauge->Rm2ndDeliveryGauge.nTotalPassNum = nRm2ndPassNum;
    for (i = 0; i < nRm2ndPassNum; i++)
    {
        pAllDeliveryGauge->Rm2ndDeliveryGauge.adDeliveryGauge[i] 
            = pRMAllPass->Rm2ndPass.adDeliveryGauge[i];
    }
#endif
    return ERR_SUCCESS;
}


                           
/** Method:    HRS_RML2Calc_CalcGauge_forGUI
    ��������γ��ں�� 

    @param HRS_RM_ALL_PASS * pRMAllPass - ���е���������Ϣ
    @param HRS_RM_ALL_DELIVERY_GAUGE * pAllDeliveryGauge - [out]���е��εĳ��ں��
    
    @return int - ��
*/
int HRS_RML2Calc_CalcGauge_forGUI(HRS_RM_ALL_PASS *pRMAllPass, 
                           HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                           char *pszOutErr)
{
    int nRet;
    int i;
    int nRm1stPassNum;
    int nRm2ndPassNum;
    int nTotalPassNum;

    double dEntryGague;
    double dDeliveryGauge;
    
    double adDraftRatio[HRS_MAX_RM_PASS_NUM];
    double adDeliveryGauge[HRS_MAX_RM_PASS_NUM];
    double adEntryGauge[HRS_MAX_RM_PASS_NUM];
    double adActDraftRatio[HRS_MAX_RM_PASS_NUM];
   

    if (pRMAllPass == NULL || pAllDeliveryGauge == NULL)
    {
        return ERR_FAILED;
    }

    memset(pAllDeliveryGauge , 0, sizeof(HRS_RM_ALL_DELIVERY_GAUGE));

    nRm1stPassNum  = pRMAllPass->Rm1stPass.nTotalPassNum;
    nRm2ndPassNum  = pRMAllPass->Rm2ndPass.nTotalPassNum;
    nTotalPassNum  = nRm1stPassNum;
    nTotalPassNum += nRm2ndPassNum;

    dEntryGague    = pRMAllPass->Rm1stPass.dSlabGauge;
    dDeliveryGauge = pRMAllPass->Rm1stPass.dTransferBarThick;

    //
    // ���õ���ѹ�������飬Ϊ������ü�����ں�Ⱥ���׼������
    //
    for (i = 0; i < nRm1stPassNum; i++)
    {
        adDraftRatio[i] = pRMAllPass->Rm1stPass.adPassDraftRatio[i];
//        adDeliveryGauge[i] = pRMAllPass->Rm1stPass.adDeliveryGauge[i];
    }

    for (i = nRm1stPassNum; i < nTotalPassNum; i++)
    {
        adDraftRatio[i] = pRMAllPass->Rm2ndPass.adPassDraftRatio[i - nRm1stPassNum];
//        adDeliveryGauge[i] = pRMAllPass->Rm2ndPass.adDeliveryGauge[i - nRm1stPassNum];
    }


    //
    // ������ں��
    //
    nRet = HRS_Calc_DeliveryGauge(nTotalPassNum,
                           dEntryGague, 
                           dDeliveryGauge, 
                           adDraftRatio, 
                           pRMAllPass->dMaxDeviation, 
                           adDeliveryGauge ,
                           adEntryGauge, 
                           adActDraftRatio,
                           pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // �����������õ����������
    //
    pAllDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum = nRm1stPassNum;
    for (i = 0; i < nRm1stPassNum; i++)
    {
        pAllDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge[i] 
                                                       = adDeliveryGauge[i];
    }

    pAllDeliveryGauge->Rm2ndDeliveryGauge.nTotalPassNum = nRm2ndPassNum;
    for (i = nRm1stPassNum; i < nTotalPassNum; i++)
    {
        pAllDeliveryGauge->Rm2ndDeliveryGauge.adDeliveryGauge[i - nRm1stPassNum] 
                                                       = adDeliveryGauge[i];
    }

#if 0
    pAllDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum = nRm1stPassNum;
    for (i = 0; i < nRm1stPassNum; i++)
    {
        pAllDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge[i] 
            = pRMAllPass->Rm1stPass.adDeliveryGauge[i];
    }

    pAllDeliveryGauge->Rm2ndDeliveryGauge.nTotalPassNum = nRm2ndPassNum;
    for (i = 0; i < nRm2ndPassNum; i++)
    {
        pAllDeliveryGauge->Rm2ndDeliveryGauge.adDeliveryGauge[i] 
            = pRMAllPass->Rm2ndPass.adDeliveryGauge[i];
    }
#endif
    return ERR_SUCCESS;
}

/** Method:    HRS_RML2Calc_PrepareEntryPara
    ���ٶȺ��¶ȼ��㺯��׼��������� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_PASS * pAllPass - ������Ϣ���ݣ��ɺ�Ȳ���׼������׼����
    @param HRS_RM_ALL_DELIVERY_GAUGE * pAllDeliveryGauge - ���ں��
    @param HRS_RM_ALL_ENTRY_PARA * pAllEntry - [out] �ַż����¶Ⱥ��ٶ��õĲ���
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_PrepareEntryPara(HRS_RM_ALL_DATA *pAllData,
                                  HRS_RM_ALL_PASS *pAllPass,
                                  HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                                  HRS_RM_ALL_ENTRY_PARA *pAllEntry)
{
    double              dEntryTemp;  // ������1������¶�
    double              dEntryTemp2; // ������2������¶�
    HRS_ENTRY_PARA     *pPara;       // ��ʱ����
    double              dGauge;      // �����ʱ����


    if (   pAllData          == NULL 
        || pAllPass          == NULL 
        || pAllDeliveryGauge == NULL
        || pAllEntry         == NULL )
    {
        return ERR_FAILED;
    }

    pPara = &(pAllEntry->Rm1stPara);

    // ��������κ�ȼ���Ϳ��ȼ���
    dGauge = pAllDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge[0];

#if 0
    steel_grade.
    HRS_RML2Calc_GetSteelData(pSteelGrade, )
    
    pPara->anEntryGaugeLevel[] = ;
    pPara->anEntryWidthLevel[] = ;
#endif

    dEntryTemp = pAllData->StrategyData.dExtTemp;
    
    // �����½�ģ�ͼ����������¶�
    dEntryTemp          = dEntryTemp;

    pPara->dRMEntryTemp = dEntryTemp;
    pPara->nStandNo     = HRS_STAND_NO_RM1;

    strcpy(pPara->szSteelGradeName, 
        pAllData->PlanData.SlabData.szSteelGradeName);
    pPara->nSteelGradeCode     = pAllData->PlanData.SlabData.nSteelGradeCode;
    pPara->nTotalPassNum       = pAllPass->Rm1stPass.nTotalPassNum;


    // 
    // ��������2��
    // 
    pPara = &(pAllEntry->Rm2ndPara);

    // ��������κ�ȼ���Ϳ��ȼ���
    dGauge = pAllDeliveryGauge->Rm2ndDeliveryGauge.adDeliveryGauge[0];

#if 0
    steel_grade.
        HRS_RML2Calc_GetSteelData(pSteelGrade, )

        pPara->anEntryGaugeLevel[] = ;
    pPara->anEntryWidthLevel[] = ;
#endif
  
    dEntryTemp = pAllData->StrategyData.dExtTemp;

    // �����½�ģ�ͼ������2������¶�
    dEntryTemp2         = dEntryTemp;   // ��ʵ�ʼ������1����������Ҫ��������

    pPara->dRMEntryTemp = dEntryTemp2;
    pPara->nStandNo     = HRS_STAND_NO_RM2;

    strcpy(pPara->szSteelGradeName, 
        pAllData->PlanData.SlabData.szSteelGradeName);
    pPara->nSteelGradeCode   = pAllData->PlanData.SlabData.nSteelGradeCode;
    pPara->nTotalPassNum     = pAllPass->Rm2ndPass.nTotalPassNum;

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_CalcSpeed
    ��������������ٶ�   

    @param HRS_RM_ALL_ENTRY_PARA * pEntryPara - �������
                                         ��HRS_RML2Calc_PrepareEntryPara()׼��
    @param HRS_RM_ALL_SPEED * pAllSpeed - [out] ��Ÿ����ε��ٶ�
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
//������������������Ǹ������ܸ����θ�һ���ٶȵĹ��ܣ���ô����ͬһ������ͬһ�������У�����ٶȸ�ֵ��һ���ģ�����Ҳ��������ѭ����ѭ�����ı䣿
//��һ�ֲ²⣺�����ͬһ������ͬһ�����Σ��ٶȸ�ֵ����ѭ�������ı���ı�Ļ�����ô����˵��ͨ����Ϊ�������𽥸���һ�����ٻ��߼��ٵĹ���ֵ�����������ٵ���󣬻���ٵ�0
//�ڶ��ֲ²⣺�������һ�ֲ²��Ǵ���ģ�ͬһ������ͬһ���Σ����������ٶȣ�ҧ���ٶȣ��׸��ٶȾ���ͬ�Ļ�����ô����ʲô�ڿ�����Щ��ʼ�ٶȵı仯�����ٶȵĸ�ֵ��ʲô�ط����ж��������ģ�
//�����ԣ���һ�ֲ²��վ��ס�ţ������ȼ����һ�ֲ²��ǶԵģ�Ȼ��ʼ��֧�ֲ²������
//�ڵ�һ�ֲ²��£�������Ĵ����п��Կ�����������������ٶȣ�ҧ���ٶȣ��׸��ٶ�����ѭ�������仯���б仯����Ҫ�ľ��Ƕ���������ٶȱ��б������ݸı���У�����������ݵ��ٶ���������������Ǵ�GUI���洫�����Ķ��ٶȽ����һ����������
//�ڵ�һ�ֲ²��£�������Ҫ֪������������ٶȱ��Ƿ�ֻ����������ݵĵ�������һ�Σ�����ÿ�ζ����£����µĵط������
//��ʵ֤�����������ֲ²ⶼ����ȷ�������������ǹ�����ݣ��������ݲ�������ѭ���ı���ı䣬
int HRS_RML2Calc_CalcSpeed(HRS_RM_ALL_DATA *pAllData, 
                           HRS_RM_ALL_ENTRY_PARA *pEntryPara, 
                           HRS_RM_ALL_SPEED *pAllSpeed)
{
    HRS_STEEL_LEVEL *SteelLevel;
    HRS_SPEED  *pSpeed;
    int nRet;

    if ( pEntryPara == NULL || pAllSpeed == NULL || pAllData == NULL )
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;

    HRS_TABLE_RM_SPEED aRmSpeedTab[HRS_RM_DRAFT_NUM_MAX];  //�����ٶȱ����ͣ��ԣ�
    HRS_TABLE_RM_SPEED *pRmSpeedTab;


    memset(aRmSpeedTab, 0, sizeof(aRmSpeedTab));

    pRmSpeedTab = &(aRmSpeedTab[0]);                       //��������������ģ���ַ��һ��ָ��
                                                           //������һ����������еĳ��ȡ����ȵȱ������и���ֵ
    pRmSpeedTab->nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pRmSpeedTab->nSlabGaugeLevel = SteelLevel->nSlabGaugeLevel;
    pRmSpeedTab->nSlabWidthLevel = SteelLevel->nSlabWidthLevel;
    pRmSpeedTab->nBarGaugeLevel  = SteelLevel->nTargetGaugeLevel;
    pRmSpeedTab->nRMWidthLevel   = SteelLevel->nRMWidthLevel;
//    pRmSpeedTab.nFinalTempLevel = SteelLevel->nFinalTempLevel;
    pRmSpeedTab->nPassMode = pAllData->StrategyData.nPassMode;;


    nRet = HRS_RmSpeedTab_SearchMulti(aRmSpeedTab, 
                                      HRS_RM_DRAFT_NUM_MAX, 
                                      pAllData->szOutErr);
           //��������Ǹ�ʲô�õ��أ�������������ĸ����ܸ������ٶȸ�ֵ��ʲô��ϵ�أ����ԣ�
	       //��������Ĳ���aRmSpeedTab���ڸú����еõ����µģ�����������Ǵ����ٶȱ�������������������ٶȸ�ֵʱ���õ�
	       //������յ�һ�ֲ²⣬��ô���aRmSpeedTab�ͻ�����������ÿһ�δ��ѭ�����ı䣬��Ϊ��ͨ�����������Ĵ����ĸ����ٶȡ�
	       //��aRmSpeedTab���ɸú���������������������ģ����忴�����ڲ�

    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;   //���nRet��ERR_FAILED,��ʾ��������ٶȱ�aRmSpeedTab�ĸ��������в���ĳ�ִ��󣬾Ͳ��ܼ���������һ����ֱ�ӽ����������ԣ�
    }

    int nPassMode = pAllData->StrategyData.nPassMode;

    int i;

    int nFind = -1;
    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )//�����ѭ���У�ת�£�
    {
        if ( aRmSpeedTab[i].nPassMode == nPassMode )//���ζԱ��еı�־λ���м�⣬��ȷ���Ƿ�ɹ��õ��������ݣ��ԣ�
        {
            // �ҵ��˶�Ӧ������
            nFind = i;
            break;
        }
    }

    if ( nFind < 0 )
    {
        nFind = 0;
    }

    pRmSpeedTab = &(aRmSpeedTab[nFind]);

    pAllSpeed->Rm1stPassSpeed.nTotalPassNum = 
                        pAllData->StrategyData.nPassMode / 10;   //���PassNum�����趨�ĵ�����Ϣ��������һ�������������Σ���Σ��ߴεȵȣ��ԣ�
	                                                             //��������Ľ���������
	                                                             //��Ϊ������Ѿ�֪���˵�����Ϣ������������ܸ������ٶȸ�ֵʱ��Ϊʲô��������һ����ֵ������1��3���Σ�����2��6���Σ�
    pAllSpeed->Rm2ndPassSpeed.nTotalPassNum = 
                        pAllData->StrategyData.nPassMode % 10;

    //����1���ٶȸ�ֵ
    pSpeed = &(pAllSpeed->Rm1stPassSpeed);
	
	// �����ȡ����1�ĸ����������ٶ�
    pSpeed->adSpeed[0] = pRmSpeedTab->dRollingSpeedR11;
    pSpeed->adSpeed[0] += pAllData->StrategyData.rm_adjust_R1[0].dSpeedAdjust;//����֪��������������Ƕ���������������ʵ��ֵ��ʵ�ʱ仯��������һ�����ڸ���ֵ����������һ����һ���䶯�����ƣ�һֱ��С����һֱ���
																			  //���ԣ�����Ҫ֪�������ֵ��һֱ�ڱ�󣬻���һֱ�ڱ�С��������������������Ҫ֪�������ֵ��������������ģ�
																			  //���ֵ�ĺ����ǣ������У�1����0���Σ����������е��ٶ���������Ӧ���Ǵ�GUI�����������һ����

    pSpeed->adSpeed[1] = pRmSpeedTab->dRollingSpeedR12;
    pSpeed->adSpeed[1] += pAllData->StrategyData.rm_adjust_R1[1].dSpeedAdjust;

    pSpeed->adSpeed[2] = pRmSpeedTab->dRollingSpeedR13;
    pSpeed->adSpeed[2] += pAllData->StrategyData.rm_adjust_R1[2].dSpeedAdjust;



    // ҧ���ٶ�
    pSpeed->adThreadInSpeed[0] = pRmSpeedTab->dEntrySpeedR11;
    pSpeed->adThreadInSpeed[1] = pRmSpeedTab->dEntrySpeedR12;
    pSpeed->adThreadInSpeed[2] = pRmSpeedTab->dEntrySpeedR13;

    // �׸��ٶ�
    pSpeed->adThreadOutSpeed[0] = pRmSpeedTab->dExitSpeedR11;
    pSpeed->adThreadOutSpeed[1] = pRmSpeedTab->dExitSpeedR12;
    pSpeed->adThreadOutSpeed[2] = pRmSpeedTab->dExitSpeedR13;

    //
    // ����2���ٶȸ�ֵ
    //
    pSpeed = &(pAllSpeed->Rm2ndPassSpeed);   //���Rm2ndPassSpeedҲ��һ���ṹ�������������ṹ����������������ٶȣ�ҧ���ٶȺ��׸��ٶȣ��ԣ�
                                             //�����÷����ǰ�pAllSpeed->Rm2ndPassSpeed����ṹ������������pSpeed��������Դﵽ����д��Ŀ�ģ��ԣ�error
											 //�����÷����ǰ�pAllSpeed->Rm2ndPassSpeed����ṹ�������ַ����һ��ָ�룬��ָ����������в������Դﵽ�򻯵�Ŀ�ģ��ԣ�

	//ͬһ�����ܣ�ͬһ�����£������ٶȣ�ҧ���ٶȣ��׸��ٶ���ʲô��ϵ�����𣿣��ԣ�

    // �����ٶ�   ͬһ���ܣ��£���ͬ���Σ��������ٶȵļ���
    pSpeed->adSpeed[0] = pRmSpeedTab->dRollingSpeedR21;
    pSpeed->adSpeed[0] += pAllData->StrategyData.rm_adjust_R2[0].dSpeedAdjust;//�����ٶȵ�����

    pSpeed->adSpeed[1] = pRmSpeedTab->dRollingSpeedR22;
    pSpeed->adSpeed[1] += pAllData->StrategyData.rm_adjust_R2[1].dSpeedAdjust;

    pSpeed->adSpeed[2] = pRmSpeedTab->dRollingSpeedR23;
    pSpeed->adSpeed[2] += pAllData->StrategyData.rm_adjust_R2[2].dSpeedAdjust;

    pSpeed->adSpeed[3] = pRmSpeedTab->dRollingSpeedR24;
    pSpeed->adSpeed[3] += pAllData->StrategyData.rm_adjust_R2[3].dSpeedAdjust;

    pSpeed->adSpeed[4] = pRmSpeedTab->dRollingSpeedR25;
    pSpeed->adSpeed[4] += pAllData->StrategyData.rm_adjust_R2[4].dSpeedAdjust;

    pSpeed->adSpeed[5] = pRmSpeedTab->dRollingSpeedR26;
    pSpeed->adSpeed[5] += pAllData->StrategyData.rm_adjust_R2[5].dSpeedAdjust;

    pSpeed->adSpeed[6] = pRmSpeedTab->dRollingSpeedR27;
    pSpeed->adSpeed[6] += pAllData->StrategyData.rm_adjust_R2[6].dSpeedAdjust;

    // ҧ���ٶ�
    pSpeed->adThreadInSpeed[0] = pRmSpeedTab->dEntrySpeedR21;
    pSpeed->adThreadInSpeed[1] = pRmSpeedTab->dEntrySpeedR22;
    pSpeed->adThreadInSpeed[2] = pRmSpeedTab->dEntrySpeedR23;
    pSpeed->adThreadInSpeed[3] = pRmSpeedTab->dEntrySpeedR24;
    pSpeed->adThreadInSpeed[4] = pRmSpeedTab->dEntrySpeedR25;
    pSpeed->adThreadInSpeed[5] = pRmSpeedTab->dEntrySpeedR26;
    pSpeed->adThreadInSpeed[6] = pRmSpeedTab->dEntrySpeedR27;

    // �׸��ٶ�
    pSpeed->adThreadOutSpeed[0] = pRmSpeedTab->dExitSpeedR21;
    pSpeed->adThreadOutSpeed[1] = pRmSpeedTab->dExitSpeedR22;
    pSpeed->adThreadOutSpeed[2] = pRmSpeedTab->dExitSpeedR23;
    pSpeed->adThreadOutSpeed[3] = pRmSpeedTab->dExitSpeedR24;
    pSpeed->adThreadOutSpeed[4] = pRmSpeedTab->dExitSpeedR25;
    pSpeed->adThreadOutSpeed[5] = pRmSpeedTab->dExitSpeedR26;
    pSpeed->adThreadOutSpeed[6] = pRmSpeedTab->dExitSpeedR27;


    return ERR_SUCCESS;
}



/** Method:    HRS_RML2Calc_CalcTemp
    ��ѯ�����γ�����¶� 

    @param HRS_RM_ALL_ENTRY_PARA * pEntryPara - �������
    @param HRS_RM_ALL_TEMP * pRMAllTemp - [out] ��Ÿ���������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcTemp(HRS_RM_ALL_DATA *pAllData, 
                          HRS_RM_ALL_ENTRY_PARA *pEntryPara,
                          HRS_RM_ALL_TEMP *pRMAllTemp)
{
#if 0
    HRS_STEEL_QUERY_INFO SteelQueryInfo;
    HRS_TEMP_PAIR        RMTempPair;
    int                  i;
    int                  nGaugeLevel;
    int                  nWidthLevel;
    int                  nTotalPassCount;

    if (pEntryPara == NULL || pRMAllTemp == NULL )
    {
        return ERR_FAILED;
    }

    //
    // �����������1�ĸ������¶�
    //
    nTotalPassCount = pEntryPara->Rm1stPara.nTotalPassNum;
    for ( i = 0; i < nTotalPassCount; i++ )
    {
        nGaugeLevel = pEntryPara->Rm1stPara.anEntryGaugeLevel[i];
        nWidthLevel = pEntryPara->Rm1stPara.anEntryWidthLevel[i];

        SteelQueryInfo.nStandNo        = HRS_STAND_NO_RM1;
        SteelQueryInfo.nGaugeLevel     = nGaugeLevel;
        SteelQueryInfo.nSteelGradeCode = pEntryPara->Rm1stPara.nSteelGradeCode;
        SteelQueryInfo.nTotalPassNum   = nTotalPassCount;
        SteelQueryInfo.nWidthLevel     = nWidthLevel;

        HRS_RM_QueryTempTable(&SteelQueryInfo, &RMTempPair);


        pRMAllTemp->Rm1stTemp.adTempPair[i] = RMTempPair;
    }
    
    pRMAllTemp->Rm1stTemp.nTotalPassNum = nTotalPassCount;


    //
    // �����������2�ĸ������¶�
    //
    nTotalPassCount = pEntryPara->Rm2ndPara.nTotalPassNum;
    for ( i = 0; i < nTotalPassCount; i++ )
    {
        nGaugeLevel = pEntryPara->Rm2ndPara.anEntryGaugeLevel[i];
        nWidthLevel = pEntryPara->Rm2ndPara.anEntryWidthLevel[i];

        SteelQueryInfo.nStandNo        = HRS_STAND_NO_RM2;
        SteelQueryInfo.nGaugeLevel     = nGaugeLevel;
        SteelQueryInfo.nSteelGradeCode = pEntryPara->Rm1stPara.nSteelGradeCode;
        SteelQueryInfo.nTotalPassNum   = nTotalPassCount;
        SteelQueryInfo.nWidthLevel     = nWidthLevel;

        HRS_RM_QueryTempTable(&SteelQueryInfo, &RMTempPair);


        pRMAllTemp->Rm2ndTemp.adTempPair[i] = RMTempPair;
    }

    pRMAllTemp->Rm2ndTemp.nTotalPassNum = nTotalPassCount;

#endif

    HRS_STEEL_LEVEL *SteelLevel;
    HRS_TEMP  *pTemp;
    int nRet;

    if ( pEntryPara == NULL || pRMAllTemp == NULL || pAllData == NULL )
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;

    HRS_TABLE_RM_TEMP *pRmTempTab;
    HRS_TABLE_RM_TEMP aRmTempTab[HRS_RM_DRAFT_NUM_MAX];

    memset(aRmTempTab, 0, sizeof(aRmTempTab));

    pRmTempTab = &(aRmTempTab[0]);

    pRmTempTab->nSteelGradeCode = SteelLevel->nSteelGradeCode;;
    pRmTempTab->nSlabGaugeLevel = SteelLevel->nSlabGaugeLevel;
    pRmTempTab->nSlabWidthLevel = SteelLevel->nSlabWidthLevel;
    pRmTempTab->nBarGaugeLevel  = SteelLevel->nTargetGaugeLevel;
    pRmTempTab->nRMWidthLevel   = SteelLevel->nRMWidthLevel;
//    pRmTempTab->nFinalTempLevel = SteelLevel->nFinalTempLevel;
    pRmTempTab->nPassMode       = pAllData->StrategyData.nPassMode;;

    nRet = HRS_RmTempTab_SearchMulti(aRmTempTab, 
                                     HRS_RM_DRAFT_NUM_MAX,
                                     pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    int nPassMode = pAllData->StrategyData.nPassMode;

    int i;
    int nFind = -1;
    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )
    {
        if ( aRmTempTab[i].nPassMode == nPassMode )
        {
            // �ҵ��˶�Ӧ������
            nFind = i;
            break;
        }
    }

    if ( nFind < 0 )
    {
        nFind = 0;
    }

    pRmTempTab = &(aRmTempTab[nFind]);


    pRMAllTemp->Rm1stTemp.nTotalPassNum = 
                    pAllData->StrategyData.nPassMode / 10;
    pRMAllTemp->Rm2ndTemp.nTotalPassNum = 
                    pAllData->StrategyData.nPassMode % 10;

    // �����ȡ�����ε��¶�
    pTemp = &(pRMAllTemp->Rm1stTemp);

    double dTemp;
    double dDischargeTemp;

    dDischargeTemp = pAllData->StrategyData.dExtTemp;

    if (dDischargeTemp < NG_POSITIVE_ZERO )
    {
        sprintf(pAllData->szOutErr,
            "HRS_RML2Calc_CalcTemp(): ��¯�¶�= %f ����С��0", 
            dDischargeTemp);
        return ERR_FAILED;
    }

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
                     pRmTempTab->dChuLuTemp, 
                     pRmTempTab->dEntryTempR11);
    pTemp->adTempPair[0].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR11);
    pTemp->adTempPair[0].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR12);
    pTemp->adTempPair[1].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR12);
    pTemp->adTempPair[1].dDeliveryTemp = dTemp;
    
    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR13);
    pTemp->adTempPair[2].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR13);
    pTemp->adTempPair[2].dDeliveryTemp = dTemp;

    pTemp = &(pRMAllTemp->Rm2ndTemp);

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR21);
    pTemp->adTempPair[0].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR21);
    pTemp->adTempPair[0].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR22);
    pTemp->adTempPair[1].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR22);
    pTemp->adTempPair[1].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR23);
    pTemp->adTempPair[2].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR23);
    pTemp->adTempPair[2].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR24);
    pTemp->adTempPair[3].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR24);
    pTemp->adTempPair[3].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR25);
    pTemp->adTempPair[4].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR25);
    pTemp->adTempPair[4].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR26);
    pTemp->adTempPair[5].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR26);
    pTemp->adTempPair[5].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dEntryTempR27);
    pTemp->adTempPair[6].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        pRmTempTab->dChuLuTemp, 
        pRmTempTab->dExitTempR27);
    pTemp->adTempPair[6].dDeliveryTemp = dTemp;

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_AllRollingForce
    �������д������ܵ������� 

    @param HRS_RM_ALL_DATA * pAllData - ���еĳ�ʼ��������
    @param HRS_RM_ALL_DELIVERY_GAUGE * pDeliveryGauge - ���ں�ȣ�
                                                        �ɺ�ȼ��㺯���������
    @param HRS_RM_ALL_TEMP * pAllTemp - ��ںͳ����¶ȣ����¶ȼ��㺯���������
    @param HRS_RM_ALL_SPEED * pAllSpeed - �ٶȣ����ٶȼ��㺯���������
    @param HRS_RM_ALL_ROLL_FORCE * pAllForce - [out] ������е��ε�������
                                                     ���м����������ο�����
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_AllRollingForce(HRS_RM_ALL_DATA *pAllData,
                                 HRS_RM_ALL_DELIVERY_GAUGE *pDeliveryGauge,
                                 HRS_RM_ALL_TEMP  *pAllTemp,
                                 HRS_RM_ALL_SPEED *pAllSpeed,
                                 HRS_RM_ALL_ROLL_FORCE  *pAllRollForce)
{
    HRS_ONE_PASS_ROLL_FORCE     *pRollForce;
    HRS_DELIVERY_GAUGE          *pGauge;
    HRS_SLAB_DATA               *pSlabData;
    int                         nTotalPassNum;
    int i;

    if (   pAllData       == NULL 
        || pDeliveryGauge == NULL 
        || pAllTemp       == NULL 
        || pAllSpeed      == NULL 
        || pAllRollForce  == NULL)
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    //
    // ׼�������β���
    // 
    pGauge = &(pDeliveryGauge->Rm1stDeliveryGauge);
    nTotalPassNum = pGauge->nTotalPassNum;
    pAllRollForce->Rm1stForce.nTotalPassNum = nTotalPassNum;
    for ( i= 0; i < nTotalPassNum; i++)
    {
        pRollForce = &(pAllRollForce->Rm1stForce.aPassForce[i]);

        pRollForce->dDeliveryGauge  = pGauge->adDeliveryGauge[i];
        if ( i == 0 )
        {
            pRollForce->dEntryGauge = pSlabData->dSlabGauge;
        }
        else
        {
            pRollForce->dEntryGauge = pGauge->adDeliveryGauge[i-1];
        }

        // pRollForce->dWidth          = pSlabData->dSlabWidth;

        pRollForce->dWidth  = pAllData->StrategyData.rm_adjust_R1[i].dWidth;
    }


    pGauge = &(pDeliveryGauge->Rm2ndDeliveryGauge);
    nTotalPassNum = pGauge->nTotalPassNum;
    pAllRollForce->Rm2ndForce.nTotalPassNum = nTotalPassNum;
    for ( i= 0; i < nTotalPassNum; i++)
    {
        pRollForce = &(pAllRollForce->Rm2ndForce.aPassForce[i]);

        pRollForce->dDeliveryGauge         = pGauge->adDeliveryGauge[i];
        if ( i == 0 )
        {
            if ( pDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum <= 0 )
            {
                pRollForce->dEntryGauge        = 
                    pSlabData->dSlabGauge;  
            }
            else
            {
                pRollForce->dEntryGauge        = 
                    pDeliveryGauge->Rm1stDeliveryGauge.adDeliveryGauge
                    [pDeliveryGauge->Rm1stDeliveryGauge.nTotalPassNum - 1];  
            }
        }
        else
        {
            pRollForce->dEntryGauge        = pGauge->adDeliveryGauge[i-1];
        }
//        pRollForce->dWidth                 = pSlabData->dSlabWidth;
        pRollForce->dWidth  = pAllData->StrategyData.rm_adjust_R2[i].dWidth;
    }

    HRS_STAND_PARA *pEquipPara;

    //
    // �����������1�ĸ�����������
    //
    pEquipPara = &(pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_RM1]);
    pGauge = &(pDeliveryGauge->Rm1stDeliveryGauge);

    int nRet = HRS_Calc_Stand_RollingForce(pEquipPara->dMaxWorkingRollerRadius,
                                    pEquipPara->dCalcAdjust,
                                    pAllRollForce->Rm1stForce.nTotalPassNum,
                                    pGauge,
                                    &(pAllData->DeformFactor),
                                    &(pAllTemp->Rm1stTemp),
                                    &(pAllSpeed->Rm1stPassSpeed), 
                                    &(pAllRollForce->Rm1stForce),
                                    pAllData->szOutErr);
    if (ERR_FAILED == nRet)
    {
        return ERR_FAILED;
    }

    //
    // �����������2������������
    //
    pEquipPara = &(pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_RM2]);
    pGauge = &(pDeliveryGauge->Rm2ndDeliveryGauge);

    nRet = HRS_Calc_Stand_RollingForce(pEquipPara->dMaxWorkingRollerRadius,
                                pEquipPara->dCalcAdjust,
                                pAllRollForce->Rm2ndForce.nTotalPassNum,
                                pGauge,
                                &(pAllData->DeformFactor),
                                &(pAllTemp->Rm2ndTemp),
                                &(pAllSpeed->Rm2ndPassSpeed), 
                                &(pAllRollForce->Rm2ndForce),
                                pAllData->szOutErr);
    if (ERR_FAILED == nRet)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_CalcRollingForce
    ���������������  

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ�������
    @param HRS_RM_ALL_ROLL_FORCE * pAllRollForce - [out] ������������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcRollingForce(HRS_RM_ALL_DATA *pAllData,
                                  HRS_RM_ALL_ROLL_FORCE  *pAllRollForce)
{
    HRS_SLAB_DATA               *pSlabData;
    HRS_RM_ALL_PASS              AllPass;            // �������õĲ���
    HRS_RM_ALL_DELIVERY_GAUGE    AllDeliveryGauge;   // ���л��ܸ����γ��ں��
    HRS_RM_ALL_ENTRY_PARA        AllEntry;           // �����¶Ⱥ��ٶ�ʹ�õĲ���
    HRS_RM_ALL_SPEED             AllSpeed;           // ���л��ܸ����ε��ٶ�
    HRS_RM_ALL_TEMP              AllTemp;            // ���л��ܸ����ε��¶�
    int                          nRet;

    if (   pAllData      == NULL 
        || pAllRollForce == NULL)
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    HRS_RML2Calc_PrepareGaugePara(pAllData, &AllPass);

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, &AllDeliveryGauge,
                                  pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareEntryPara(pAllData, 
                                  &AllPass, 
                                  &AllDeliveryGauge, 
                                  &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, &AllSpeed);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }
    
    nRet = HRS_RML2Calc_CalcTemp(pAllData, &AllEntry, &AllTemp);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // �������л��ܵ�������
    // 
    nRet = HRS_RML2Calc_AllRollingForce(pAllData,
                                        &AllDeliveryGauge,
                                        &AllTemp,
                                        &AllSpeed, 
                                        pAllRollForce);

    return nRet;
}


/** Method:    HRS_RML2Calc_PrepareGapPara
    Ϊ�������׼��������� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ�������
    @param HRS_RM_ALL_DELIVERY_GAUGE * pAllGauge - �ɼ�����ں�Ⱥ����������
    @param HRS_RM_ALL_ROLL_FORCE * pAllRollForce - �ɼ��������������������
    @param HRS_RM_ALL_GAP_PARA * pAllGapPara - [out] �������
    
    @return void - ��
*/
void HRS_RML2Calc_PrepareGapPara(HRS_RM_ALL_DATA           *pAllData, 
                                 HRS_RM_ALL_DELIVERY_GAUGE *pAllGauge,
                                 HRS_RM_ALL_ROLL_FORCE     *pAllRollForce,
                                 HRS_RM_ALL_GAP_PARA       *pAllGapPara)
{   
    HRS_DELIVERY_GAUGE    *pGauge;
    HRS_STAND_ROLL_FORCE  *pStandForce;

    HRS_GAP_PARA          *pGapPara;
    HRS_GAP_PASS_PARA     *pGapPassPara;

    double dModulus;
    double dWidth;
    double dRollForce;

    int    i;
    int    nRet;

    if (   pAllData      == NULL 
        || pAllGauge     == NULL 
        || pAllRollForce == NULL 
        || pAllGapPara   == NULL)
    {
        return;
    }

    pGauge      = &(pAllGauge->Rm1stDeliveryGauge);
    pStandForce = &(pAllRollForce->Rm1stForce);
    pGapPara    = &(pAllGapPara->Rm1stGapPara);

    pGapPara->nTotalPassNum = pStandForce->nTotalPassNum;

    for (i = 0; i < pStandForce->nTotalPassNum; i++)
    {
        pGapPassPara = &(pGapPara->GapPassPara[i]);

        pGapPassPara->dDeliveryGauge    = pGauge->adDeliveryGauge[i];
        pGapPassPara->dRollForce        = pStandForce->aPassForce[i].dRollForce;

        //��ѯ�նȱ�
        dWidth = pAllData->PlanData.SlabData.dSlabWidth;
        
        pGapPassPara->dZeroForce 
            = pAllData->AllStandPara.aEquipPara[i+HRS_STAND_NO_RM1].dZeroForce;

#if 0
        dRollForce = pAllRollForce->Rm1stForce.aPassForce[i].dRollForce * 10;
        HRS_FmModulusTable_Query(i+1, dWidth, dRollForce, &dModulus);

        pGapPassPara->dModulus          = dModulus / 10;  // ���...
#else
        dRollForce = pAllRollForce->Rm1stForce.aPassForce[i].dRollForce;

        nRet = HRS_CalcModulus((HRS_STAND_NO_EM)(i+HRS_STAND_NO_RM1), 
                                dRollForce, dWidth, 
                                &dModulus);
        if (nRet == ERR_FAILED)
        {
            printf("CalcModulus Failed. nStandNo = %d\r\n", i+HRS_STAND_NO_RM1);
            return;
        }

        pGapPassPara->dModulus = dModulus;
#endif
        pGapPassPara->dOilFilmComp      = 0.0;  // ��Ĥ����ֵ�� ��ʱ��Ϊ0
        pGapPassPara->dRollWearComp     = 0.0;  // ĥ�𲹳�ֵ�� ��ʱ��Ϊ0
        pGapPassPara->dThermalCrownComp = 0.0;  // �����Ͳ���ֵ,��ʱ��Ϊ0
    }

    pGauge      = &(pAllGauge->Rm2ndDeliveryGauge);
    pStandForce = &(pAllRollForce->Rm2ndForce);
    pGapPara    = &(pAllGapPara->Rm2ndGapPara);

    pGapPara->nTotalPassNum = pStandForce->nTotalPassNum;

    for (i = 0; i < pStandForce->nTotalPassNum; i++)
    {
        pGapPassPara = &(pGapPara->GapPassPara[i]);

        pGapPassPara->dDeliveryGauge    = pGauge->adDeliveryGauge[i];
        pGapPassPara->dRollForce        = pStandForce->aPassForce[i].dRollForce;

        pGapPassPara->dZeroForce 
            = pAllData->AllStandPara.aEquipPara[i+HRS_STAND_NO_RM2].dZeroForce;

        //��ѯ�նȱ�
        dWidth = pAllData->PlanData.SlabData.dSlabWidth;
#if 0
        dRollForce = pAllRollForce->Rm2ndForce.aPassForce[i].dRollForce * 10;
        HRS_FmModulusTable_Query(i+1, dWidth, dRollForce, &dModulus);

        pGapPassPara->dModulus          = dModulus / 10;  // ���...
#else
        dRollForce = pAllRollForce->Rm2ndForce.aPassForce[i].dRollForce;

        nRet = HRS_CalcModulus((HRS_STAND_NO_EM)(i+HRS_STAND_NO_FM1), 
                                dRollForce, dWidth,
                                &dModulus);
        if (nRet == ERR_FAILED)
        {
            printf("CalcModulus Failed. nStandNo = %d\r\n", i+HRS_STAND_NO_FM1);
            return;
        }

        pGapPassPara->dModulus = dModulus;
#endif
        pGapPassPara->dOilFilmComp      = 0.0;  // ��Ĥ����ֵ�� ��ʱ��Ϊ0
        pGapPassPara->dRollWearComp     = 0.0;  // ĥ�𲹳�ֵ�� ��ʱ��Ϊ0
        pGapPassPara->dThermalCrownComp = 0.0;  // �����Ͳ���ֵ,��ʱ��Ϊ0
    }

    return;
}



/** Method:    HRS_RML2Calc_CalcStandGap
    ���㵥�����ܸ����εĹ��� 

    @param HRS_GAP_PARA * pGapPara - ����������
    @param HRS_GAP * pStandGap - [out] ��Ÿ����εĹ�������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcStandGap(HRS_GAP_PARA *pGapPara, HRS_GAP  *pStandGap)
{
    int    i;
    int    nRet;
    double dGap;

    if (pGapPara == NULL || pStandGap == NULL)
    {
        return ERR_FAILED;
    }
    
    int nTotalPassNum = pGapPara->nTotalPassNum;

    for ( i = 0; i < nTotalPassNum; i++ )
    {
        nRet = HRS_Calc_OnePass_Gap(&(pGapPara->GapPassPara[i]), &dGap);
        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        pStandGap->adGap[i] = dGap;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_CalcAllGap
    ��������ι��� 

    @param HRS_RM_ALL_GAP_PARA * pAllGapPara - ���������������
    @param HRS_RM_ALL_GAP * pAllGap - [out] ��ż�����ĸ����ι���
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcAllGap(HRS_RM_ALL_GAP_PARA *pAllGapPara,
                         HRS_RM_ALL_GAP *pAllGap)
{
    int nRet;

    if (pAllGapPara == NULL || pAllGap == NULL)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcStandGap(&(pAllGapPara->Rm1stGapPara),
                                     &(pAllGap->Rm1stGap));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcStandGap(&(pAllGapPara->Rm2ndGapPara),
                                     &(pAllGap->Rm2ndGap));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_RML2Calc_CalcGap
    ����������л��ܵĸ����εĹ��� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_GAP * pAllGap - [out] ��Ÿ����εĹ�������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcGap(HRS_RM_ALL_DATA *pAllData,
                         HRS_RM_ALL_GAP  *pAllGap)
{
    HRS_SLAB_DATA               *pSlabData;
    int                          nRet;

    HRS_RM_ALL_PASS              AllPass;            // �������õĲ���
    HRS_RM_ALL_DELIVERY_GAUGE    AllDeliveryGauge;   // ���л��ܸ����γ��ں��
    HRS_RM_ALL_ENTRY_PARA        AllEntry;           // �����¶Ⱥ��ٶ�ʹ�õĲ���
    HRS_RM_ALL_SPEED             AllSpeed;           // ���л��ܸ����ε��ٶ�
    HRS_RM_ALL_TEMP              AllTemp;            // ���л��ܸ����ε��¶�
    HRS_RM_ALL_ROLL_FORCE        AllRollForce;
    HRS_RM_ALL_GAP_PARA          AllGapPara;


    if (pAllData == NULL || pAllGap == NULL)
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    HRS_RML2Calc_PrepareGaugePara(pAllData, &AllPass);

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, &AllDeliveryGauge,
        pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareEntryPara(pAllData, 
        &AllPass, 
        &AllDeliveryGauge, 
        &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, &AllSpeed);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcTemp(pAllData, &AllEntry, &AllTemp);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // �������л��ܵ�������
    // 
    nRet = HRS_RML2Calc_AllRollingForce(pAllData,
        &AllDeliveryGauge,
        &AllTemp,
        &AllSpeed, 
        &AllRollForce);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareGapPara(pAllData, 
                                &AllDeliveryGauge, 
                                &AllRollForce, 
                                &AllGapPara);

    nRet = HRS_RML2Calc_CalcAllGap(&AllGapPara, pAllGap);

    return nRet;    
}



/** Method:    HRS_Calc_Stand_Torque
    ��������Ť�� 

    @param HRS_STAND_ROLL_FORCE * pStandForce - �������ܸ����ε�������
    @param HRS_CALC_STAND_RESULT * pStandTorqueResult - [out] ��ű����ܸ����ε�Ť��
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Calc_Stand_Torque(HRS_STAND_ROLL_FORCE  *pStandForce,
                          HRS_CALC_STAND_RESULT *pStandTorqueResult)
{
    int i;
    int nRet;

    int nTotalPassNum;

    double dEntryGauge;
    double dDeliveryGauge;
    double dFlattenRadius;
    double dRollForce;

    double dTorque;        // [out] Ť��

    if (pStandForce == NULL || pStandTorqueResult == NULL)
    {
        return ERR_FAILED;
    }

    nTotalPassNum = pStandForce->nTotalPassNum;

    pStandTorqueResult->nTotalPassNum = nTotalPassNum;

    for (i = 0; i < nTotalPassNum; i++)
    {
        dEntryGauge    = pStandForce->aPassForce[i].dEntryGauge;
        dDeliveryGauge = pStandForce->aPassForce[i].dDeliveryGauge;
        dFlattenRadius = pStandForce->aPassForce[i].dFlatRadius;
        dRollForce     = pStandForce->aPassForce[i].dRollForce;

        // ���㵥�����ε�Ť��
        nRet = HRS_Calc_RollingTorqueFrance(dEntryGauge,
                                            dDeliveryGauge,
                                            dFlattenRadius,
                                            dRollForce,
                                            &dTorque);
        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        pStandTorqueResult->adValue[i] = dTorque;
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_RM_Calc_AllTorque
    ����������л��ܵĸ�����Ť�� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_ROLL_FORCE * pAllForce - �����ε�������
    @param HRS_RM_CALC_RESULT * pAllTorqueResult - [out] ��Ÿ����ε�Ť��
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RM_Calc_AllTorque(HRS_RM_ALL_DATA             *pAllData,
                          HRS_RM_ALL_ROLL_FORCE       *pAllForce,
                          HRS_RM_CALC_RESULT          *pAllTorqueResult)
{
    int nRet;

    if (pAllData == NULL || pAllForce == NULL || pAllTorqueResult == NULL)
    {
        return ERR_FAILED;
    }

    //
    // ���������1�ĸ�����Ť��
    //
    nRet = HRS_Calc_Stand_Torque(&(pAllForce->Rm1stForce),
                                 &(pAllTorqueResult->Rm1stResult));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // ���������2�ĸ�����Ť��
    //
    nRet = HRS_Calc_Stand_Torque(&(pAllForce->Rm2ndForce),
                                 &(pAllTorqueResult->Rm2ndResult));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_Calc_Stand_Power
    ���㵥�����ܵĸ����ι��� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ�������
    @param HRS_SPEED * pSpeed - �������ٶ�
    @param HRS_STAND_ROLL_FORCE * pStandForce - ������������
    @param HRS_CALC_STAND_RESULT * pTorqueStandReslut - ������Ť��
    @param HRS_CALC_STAND_RESULT * pPowerResult - [out] �����ι���
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_Calc_Stand_Power(HRS_RM_ALL_DATA        *pAllData,
                         HRS_SPEED              *pSpeed,
                         HRS_STAND_ROLL_FORCE   *pStandForce,
                         HRS_CALC_STAND_RESULT  *pTorqueStandReslut,
                         HRS_CALC_STAND_RESULT  *pPowerResult)
{
    int i;
    int nRet;

    int nTotalPassNum;
    double dTorque;        

    double dRollingPower;  // [out] 

    if (   pAllData           == NULL 
        || pSpeed             == NULL 
        || pStandForce        == NULL 
        || pTorqueStandReslut == NULL 
        || pPowerResult       == NULL )
    {
        return ERR_FAILED;
    }

    nTotalPassNum = pTorqueStandReslut->nTotalPassNum;

    pPowerResult->nTotalPassNum = nTotalPassNum;

    for (i = 0; i < nTotalPassNum; i++)
    {
        dTorque = pTorqueStandReslut->adValue[i];

        nRet = HRS_Calc_RollingPower(dTorque, 
                                     pSpeed->adThreadInSpeed[i], 
                                     pStandForce->aPassForce[i].dFlatRadius,
                                     &dRollingPower);
        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        pPowerResult->adValue[i] = dRollingPower;
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_RM_Calc_AllPower
    ����������л��ܵĸ����ι��� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_SPEED * pAllSpeed - �������ٶ�
    @param HRS_RM_ALL_ROLL_FORCE * pAllForce - ������������
    @param HRS_RM_CALC_RESULT * pTorqueResult - ������Ť��
    @param HRS_RM_CALC_RESULT * pAllPowerResult - [out] �����ι���
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RM_Calc_AllPower(HRS_RM_ALL_DATA       *pAllData,
                         HRS_RM_ALL_SPEED      *pAllSpeed,
                         HRS_RM_ALL_ROLL_FORCE *pAllForce,
                         HRS_RM_CALC_RESULT    *pTorqueResult,
                         HRS_RM_CALC_RESULT    *pAllPowerResult)
{
    int nRet;

    if (   pAllData        == NULL
        || pAllSpeed       == NULL
        || pAllForce       == NULL 
        || pTorqueResult   == NULL 
        || pAllPowerResult == NULL )
    {
        return ERR_FAILED;
    }

    //
    // ���������1�ĸ�����Ť��
    //
    nRet = HRS_Calc_Stand_Power(pAllData,
                                &(pAllSpeed->Rm1stPassSpeed),
                                &(pAllForce->Rm1stForce),
                                &(pTorqueResult->Rm1stResult),
                                &(pAllPowerResult->Rm1stResult));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // ���������2�ĸ�����Ť��
    //
    nRet = HRS_Calc_Stand_Power(pAllData,
                                &(pAllSpeed->Rm2ndPassSpeed),
                                &(pAllForce->Rm2ndForce),
                                &(pTorqueResult->Rm2ndResult),
                                &(pAllPowerResult->Rm2ndResult));
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


/** Method:    HRS_RML2Calc_CalcAllData
    ����������������Ҫ�õ������� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_OUT_DATA * pAllOutData - [out] ��Ŵ������м����������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_CalcAllData(HRS_RM_ALL_DATA *pAllData,
                             HRS_RM_ALL_OUT_DATA *pAllOutData)
{
    HRS_SLAB_DATA               *pSlabData;
    
    HRS_RM_ALL_PASS              AllPass;            // �������õĲ���
    HRS_RM_ALL_DELIVERY_GAUGE    AllDeliveryGauge;   // ���л��ܸ����γ��ں��
    
    HRS_RM_ALL_ENTRY_PARA        AllEntry;           // �����¶Ⱥ��ٶ�ʹ�õĲ���   
    HRS_RM_ALL_SPEED             AllSpeed;           // ���л��ܸ����ε��ٶ�
    HRS_RM_ALL_TEMP              AllTemp;            // ���л��ܸ����ε��¶�
    
    HRS_RM_ALL_ROLL_FORCE        AllRollForce;

    HRS_RM_ALL_GAP_PARA          AllGapPara;
    HRS_RM_ALL_GAP               AllGap;

    HRS_RM_CALC_RESULT           AllTorqueResult;
    HRS_RM_CALC_RESULT           AllPowerResult;

    HRS_RM_STAND_OUT_DATA        *pStandOutData;
    int                          i;
    int                          nRet;

    if ( pAllData == NULL || pAllOutData == NULL )
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    nRet = HRS_RML2Calc_GetSteelData(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareGaugePara(pAllData, &AllPass);

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, &AllDeliveryGauge,
                                  pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    int nRm1stPassNum = AllPass.Rm1stPass.nTotalPassNum;
    AllDeliveryGauge.Rm1stDeliveryGauge.nTotalPassNum = nRm1stPassNum;
    for (i = 0; i < nRm1stPassNum; i++)
    {
        AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[i] 
        = AllPass.Rm1stPass.adDeliveryGauge[i];
    }

    int nRm2ndPassNum = AllPass.Rm2ndPass.nTotalPassNum;
    AllDeliveryGauge.Rm2ndDeliveryGauge.nTotalPassNum = nRm2ndPassNum;
    for (i = 0; i < nRm2ndPassNum; i++)
    {
        AllDeliveryGauge.Rm2ndDeliveryGauge.adDeliveryGauge[i] 
        = AllPass.Rm2ndPass.adDeliveryGauge[i];
    }


    HRS_RML2Calc_PrepareEntryPara(pAllData, 
        &AllPass, 
        &AllDeliveryGauge, 
        &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, &AllSpeed);
	//����ٶȵļ��㣨��)�������д�����
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_RML2Calc_CalcTemp(pAllData, &AllEntry, &AllTemp);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //
    // �������л��ܵ�������
    // 
    nRet = HRS_RML2Calc_AllRollingForce(pAllData,
        &AllDeliveryGauge,
        &AllTemp,
        &AllSpeed, 
        &AllRollForce);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // �������
    HRS_RML2Calc_PrepareGapPara(pAllData, 
                                &AllDeliveryGauge, 
                                &AllRollForce, 
                                &AllGapPara);

    nRet = HRS_RML2Calc_CalcAllGap(&AllGapPara, &AllGap);

    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_RML2Calc_CalcAllGap() error.");
        return ERR_FAILED;
    }


    // ������������
    nRet = HRS_RM_Calc_AllTorque(pAllData, 
                                 &AllRollForce, 
                                 &AllTorqueResult);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_RM_Calc_AllTorque() error.");
        return ERR_FAILED;
    }


    // ���㹦��
    nRet = HRS_RM_Calc_AllPower(pAllData,
                                &AllSpeed,
                                &AllRollForce,
                                &AllTorqueResult,
                                &AllPowerResult);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_RM_Calc_AllPower() error.");
        return ERR_FAILED;
    }

    //
    // �����������1�����м���������
    //
    HRS_DELIVERY_GAUGE  *pGauge;
    HRS_ONE_PASS_ROLL_FORCE  *pOnePassRollForce;
    pStandOutData = &(pAllOutData->Rm1stOutData);
    
    pGauge = &(AllDeliveryGauge.Rm1stDeliveryGauge);

    pStandOutData->SlabeData = pAllData->PlanData.SlabData;

    pStandOutData->nTotalPassNum = pGauge->nTotalPassNum;
    pStandOutData->nStandNo = HRS_STAND_NO_RM1;
    for ( i = 0; i < pGauge->nTotalPassNum; i++)
    {
        pOnePassRollForce = &(AllRollForce.Rm1stForce.aPassForce[i]);

        pStandOutData->adDeliveryGauge[i] = pGauge->adDeliveryGauge[i];
        pStandOutData->adSpeed[i]         = AllSpeed.Rm1stPassSpeed.adSpeed[i];
        pStandOutData->adInSpeed[i]       = AllSpeed.Rm1stPassSpeed.adThreadInSpeed[i];
        pStandOutData->adOutSpeed[i]      = AllSpeed.Rm1stPassSpeed.adThreadOutSpeed[i];

        pStandOutData->adTempPair[i]      = AllTemp.Rm1stTemp.adTempPair[i];
        pStandOutData->adGap[i]           = AllGap.Rm1stGap.adGap[i];
        pStandOutData->adRollingForce[i]  = AllRollForce.Rm1stForce.aPassForce[i].dRollForce;
        pStandOutData->adTorque[i]        = AllTorqueResult.Rm1stResult.adValue[i];
        pStandOutData->adPower[i]         = AllPowerResult.Rm1stResult.adValue[i];


        if (i == 0)
        {
            pStandOutData->adDraft[i]     = pSlabData->dSlabGauge 
                - pStandOutData->adDeliveryGauge[i];
        }
        else
        {
            pStandOutData->adDraft[i]     = pStandOutData->adDeliveryGauge[i-1] 
            - pStandOutData->adDeliveryGauge[i];
        }

        pStandOutData->adWidth[i] 
                   = pAllData->StrategyData.rm_adjust_R1[i].dWidth;

        pStandOutData->adLength[i]        = (pSlabData->dSlabGauge 
                       / pStandOutData->adDeliveryGauge[i])
                       * pSlabData->dSlabLen;

        pStandOutData->adLength[i]        
                       *= pSlabData->dSlabWidth / pStandOutData->adWidth[i];

        pStandOutData->adQp[i]           = pOnePassRollForce->dQp;
        pStandOutData->adDeformResist[i] = pOnePassRollForce->dDeformResist;

        pStandOutData->adWorkingRollerRadius[i] 
                    = pOnePassRollForce->dWorkingRollerRadius;
        pStandOutData->adFlatRadius[i]   = pOnePassRollForce->dFlatRadius;

        pStandOutData->adCorr[i]         = pOnePassRollForce->dCorr;
       
        pStandOutData->adGaugeRollForceFactor[i] 
                    = pOnePassRollForce->dGaugeRollForceFactor;
        pStandOutData->adTempRollForceFactor[i] 
                    = pOnePassRollForce->dTempRollForceFactor;

    }

    //
    // �����������2�����м���������
    //
    pStandOutData = &(pAllOutData->Rm2ndOutData);

    pGauge = &(AllDeliveryGauge.Rm2ndDeliveryGauge);


    pStandOutData->SlabeData = pAllData->PlanData.SlabData;

    pStandOutData->nTotalPassNum = pGauge->nTotalPassNum;
    pStandOutData->nStandNo = HRS_STAND_NO_RM2;

    for ( i = 0; i < pGauge->nTotalPassNum; i++)
    {
        pOnePassRollForce = &(AllRollForce.Rm2ndForce.aPassForce[i]);

        pStandOutData->adDeliveryGauge[i] = pGauge->adDeliveryGauge[i];
        pStandOutData->adSpeed[i]         = AllSpeed.Rm2ndPassSpeed.adSpeed[i];
        pStandOutData->adInSpeed[i]       = AllSpeed.Rm2ndPassSpeed.adThreadInSpeed[i];
        pStandOutData->adOutSpeed[i]      = AllSpeed.Rm2ndPassSpeed.adThreadOutSpeed[i];

        pStandOutData->adTempPair[i]      = AllTemp.Rm2ndTemp.adTempPair[i];
        pStandOutData->adGap[i]           = AllGap.Rm2ndGap.adGap[i];
        pStandOutData->adRollingForce[i]  = AllRollForce.Rm2ndForce.aPassForce[i].dRollForce;
        pStandOutData->adTorque[i]        = AllTorqueResult.Rm2ndResult.adValue[i];
        pStandOutData->adPower[i]         = AllPowerResult.Rm2ndResult.adValue[i];

        pStandOutData->adLength[i]        = (pSlabData->dSlabGauge 
                                             / pStandOutData->adDeliveryGauge[i])
                                             * pSlabData->dSlabLen;

        if (i == 0)
        {
            int nPassNum = AllDeliveryGauge.Rm1stDeliveryGauge.nTotalPassNum;
            if (nPassNum > 0)
            {
                pStandOutData->adDraft[i] = 
                  AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[nPassNum - 1] 
                 - pStandOutData->adDeliveryGauge[i];

            }
            else
            {
                pStandOutData->adDraft[i] = 
                  pSlabData->dSlabGauge - pStandOutData->adDeliveryGauge[i];
            }
        }
        else
        {
            pStandOutData->adDraft[i]     = pStandOutData->adDeliveryGauge[i-1] 
                                            - pStandOutData->adDeliveryGauge[i];
        }
        
        pStandOutData->adWidth[i] 
               = pAllData->StrategyData.rm_adjust_R2[i].dWidth;

       pStandOutData->adLength[i]         = (pSlabData->dSlabGauge 
               / pStandOutData->adDeliveryGauge[i])
               * pSlabData->dSlabLen;

        pStandOutData->adLength[i]        
               *= pSlabData->dSlabWidth / pStandOutData->adWidth[i];

        pStandOutData->adQp[i]           = pOnePassRollForce->dQp;
        pStandOutData->adDeformResist[i] = pOnePassRollForce->dDeformResist;
        
        pStandOutData->adWorkingRollerRadius[i] 
                      = pOnePassRollForce->dWorkingRollerRadius;
        pStandOutData->adFlatRadius[i] = pOnePassRollForce->dFlatRadius;

        pStandOutData->adCorr[i] = pOnePassRollForce->dCorr;

        pStandOutData->adGaugeRollForceFactor[i] 
                      = pOnePassRollForce->dGaugeRollForceFactor;
        pStandOutData->adTempRollForceFactor[i] 
                      = pOnePassRollForce->dTempRollForceFactor;
    }


    // ���������1�ĳ��۴���
    pStandOutData = &(pAllOutData->Rm1stOutData);

    int nDescCode = pAllData->PlanData.nRMDescCode;
    int nSprayCode;
    for ( i = 0; i < pStandOutData->nTotalPassNum; i++)
    {
        nSprayCode = pAllData->StrategyData.rm_adjust_R1[i].nSprayState;

        if (nSprayCode == HRS_SPRAY_AUTO)
        {
            pStandOutData->anDescCode[i] = HRS_GetRMPassDescCode(nDescCode, 
                                                              HRS_STAND_NO_RM1, 
                                                              i);
        }
        else if (nSprayCode == HRS_SPRAY_ON)
        {
            pStandOutData->anDescCode[i] = 1;    // ǿ�д򿪳��۲���
        }
        else if(nSprayCode == HRS_SPRAY_OFF)
        {
            pStandOutData->anDescCode[i] = 0;    // ǿ�йرճ��۲���
        }
        else
        {
            // 
        }

    }

    // ���������2�ĳ��۴���
    pStandOutData = &(pAllOutData->Rm2ndOutData);

    for ( i = 0; i < pStandOutData->nTotalPassNum; i++)
    {
        nSprayCode = pAllData->StrategyData.rm_adjust_R2[i].nSprayState;

        if (nSprayCode == HRS_SPRAY_AUTO)
        {
            pStandOutData->anDescCode[i] = HRS_GetRMPassDescCode(nDescCode, 
                                                            HRS_STAND_NO_RM2, 
                                                            i);
        }
        else if (nSprayCode == HRS_SPRAY_ON)
        {
            pStandOutData->anDescCode[i] = 1;    // ǿ�д򿪳��۲���
        }
        else if(nSprayCode == HRS_SPRAY_OFF)
        {
            pStandOutData->anDescCode[i] = 0;    // ǿ�йرճ��۲���
        }
        else
        {
            // 
        }
    }

    char *pszMsg = HRS_RML2Calc_BuildOutStr(pAllOutData);

    char szPath[512];
    NG_Path_GetRunPath(szPath, sizeof(szPath));

    strcat(szPath, "\\RMLog\\");

    _mkdir(szPath);

    strcat(szPath, HRS_RML2_CALC_LOG_FILE);

    LogPrint(szPath, "--------------------------%s-------------", 
             "RML2Calc");

    error_log(szPath, pszMsg);

    NG_free(pszMsg);

    return ERR_SUCCESS;
}



/** Method:    HRS_RML2Calc_BuildOnePassSched
    ���������ܼ�����ת���ɹ�����ݣ��������һ�㹩L1��GUI����ʹ�� 

    @param HRS_RM_STAND_OUT_DATA * pStandOutData - �������ܼ����������
    @param double dDeliveryWidth - ���ڿ���
    @param int nPassNo - ���κ�
    @param HRS_RM_SCHEDCALC_ONEPASS * pOnePass - [out] ��ż���������
    
    @return void - ��
*/
static void HRS_RML2Calc_BuildOnePassSched(HRS_RM_STAND_OUT_DATA *pStandOutData,
                                           double dDeliveryWidth,
                                           int nPassNo,
                                           HRS_RM_SCHEDCALC_ONEPASS *pOnePass)
{
    int i = nPassNo;

    if (pStandOutData == NULL || pOnePass == NULL)
    {
        return;
    }

    if (   dDeliveryWidth <  NG_POSITIVE_ZERO 
        || nPassNo        >= HRS_MAX_RM_PASS_NUM)
    {
        return;
    }

    pOnePass->fDeliveryGauge          = (float)(pStandOutData->adDeliveryGauge[i]);
    pOnePass->fDeliveryLength         = (float)(pStandOutData->adLength[i]);
    pOnePass->fDeliveryWidth          = (float)dDeliveryWidth;
    pOnePass->fMillerDraft            = (float)(pStandOutData->adDraft[i]);
    pOnePass->fMillerGap              = (float)(pStandOutData->adGap[i]);
    pOnePass->fRollingPower           = (float)(pStandOutData->adPower[i]);
    pOnePass->fRollingSpeed           = (float)(pStandOutData->adSpeed[i]);
    pOnePass->nDescCode               = (float)(pStandOutData->anDescCode[i]);
    pOnePass->fMillerForce            = (float)(pStandOutData->adRollingForce[i]);
    pOnePass->nMillerTorque           = (float)(pStandOutData->adTorque[i]);

    pOnePass->fEntryTemp              = (float)(pStandOutData->adTempPair[i].dEntryTemp);
    pOnePass->fDeliveryTemp           = (float)(pStandOutData->adTempPair[i].dDeliveryTemp);

    pOnePass->fEffective              = 0;

    pOnePass->fEdgerRollDeliveryWidth = 0;
    pOnePass->fEdgerRollDraft         = 0;
    pOnePass->fEdgerRollForce         = 0;
    pOnePass->fEdgerRollTorque        = 0;
    pOnePass->nEdgerRollGap           = 0;

    memset(pOnePass->szPassNo, 0, sizeof(pOnePass->szPassNo));

    return;
}

// ���ɷ��͸�GUI����Ĺ������

/** Method:    HRS_RML2Calc_BuildSched
    �����л��ܼ�����ת���ɹ�����ݣ��������һ�㹩L1��GUI����ʹ�� 

    @param HRS_RM_ALL_DATA * pAllData - ��ʼ��������
    @param HRS_RM_ALL_OUT_DATA * pAllOutData - ���л��ܵļ���������
    @param HRS_RM_SCHED * pRMSched - [out] ���ת����Ĺ������
    
    @return int - ERR_SUCCESS, ERR_FAILED
*/
int HRS_RML2Calc_BuildSched(HRS_RM_ALL_DATA *pAllData,
                            HRS_RM_ALL_OUT_DATA *pAllOutData,
                            HRS_RM_SCHED *pRMSched)
{
    int i;
    HRS_RM_STAND_OUT_DATA    *pStandOutData;
    HRS_RM_SCHEDCALC_ONEPASS *pOnePass;

    double dDeliveryWidth = pAllData->PlanData.SlabData.dSlabWidth;

    if (pAllData == NULL || pAllOutData == NULL || pRMSched == NULL)
    {
        return ERR_FAILED;
    }

    pRMSched->emPassMode = pAllData->StrategyData.nPassMode;

    StrSafeCopy(pRMSched->BasicDataPass.szStripNo, 
                pAllData->PlanData.SlabData.szStripNo,
                HRS_STRIP_NO_LEN);
    //
    // ��������1�Ĺ������
    //
    pStandOutData = &(pAllOutData->Rm1stOutData);

    pRMSched->nR1stPassNum = pStandOutData->nTotalPassNum;

    for ( i = 0; i < pStandOutData->nTotalPassNum; i++ )
    {
        pOnePass = &(pRMSched->SchedCalcPassR1[i]);


        dDeliveryWidth = pStandOutData->adWidth[i];
        HRS_RML2Calc_BuildOnePassSched(pStandOutData, 
                                       dDeliveryWidth, 
                                       i, 
                                       pOnePass);
    }

    //
    // ��������2�Ĺ������
    //
    pStandOutData = &(pAllOutData->Rm2ndOutData);

    pRMSched->nR2ndPassNum = pStandOutData->nTotalPassNum;

    for ( i = 0; i < pStandOutData->nTotalPassNum; i++ )
    {
        pOnePass = &(pRMSched->SchedCalcPassR2[i]);

        dDeliveryWidth = pStandOutData->adWidth[i];

        HRS_RML2Calc_BuildOnePassSched(pStandOutData, 
            dDeliveryWidth, 
            i, 
            pOnePass);
    }

    pRMSched->szOutErr[0] = '\0';

    if ( pAllData->szOutErr[0] != '\0')
    {
        strcpy(pRMSched->szOutErr, pAllData->szOutErr);
    }

    return ERR_SUCCESS;
}


void HRS_RML2Calc_BuildLine_Double(double *pdData,
                                   int nDataCount,
                                   char *pszPrefix,
                                   char *pszBuf)
{
    int  i;
    char szItem[512];

    pszBuf[0] = '\0';
    strcat(pszBuf, pszPrefix);
    for ( i = 0; i < nDataCount; i++ )
    {
        sprintf(szItem, "%.6f \t\t", pdData[i]);

        strcat(pszBuf, szItem);
    }
    strcat(pszBuf, "\r\n");

    return;
}


void HRS_RML2Calc_BuildLine_Int(int *pnData,
                                int nDataCount,
                                char *pszPrefix,
                                char *pszBuf)
{
    int  i;
    char szItem[256];

    pszBuf[0] = '\0';

    strcat(pszBuf, pszPrefix);
    for ( i = 0; i < nDataCount; i++ )
    {
        sprintf(szItem, "[%d]:%d", i, pnData[i]);

        strcat(pszBuf, szItem);
        strcat(pszBuf, ", ");
    }
    strcat(pszBuf, "\r\n");

    return;
}




int HRS_RML2Calc_BuildStandOutStr(HRS_RM_STAND_OUT_DATA *pStandOut, 
                                  char *pszOut, int nOutLen)
{
    int  i;
    char szMsg[1024];
    char szItem[256];
    HRS_SLAB_DATA  *pSlabData;

    pSlabData = &(pStandOut->SlabeData);

    int nIndex;

    nIndex = 1;

    if ( pStandOut->nStandNo == HRS_STAND_NO_RM1 )
    {
        nIndex = 1;
    }
    else
    {
        nIndex = 2;
    }

    sprintf(szMsg, 
        "StandNo         : R%d\r\n"
        "szGrade         : %s\r\n"
        "szSteelGradeName: %s\r\n"
        "szStripNo       : %s\r\n"
        "nSteelGradeNode : %d\r\n"
        "dSlabWidth      : %f\r\n"
        "dSlabGauge      : %f\r\n"
        "dSlabLen        : %f\r\n",
        nIndex,
        pSlabData->szGrade,
        pSlabData->szSteelGradeName,
        pSlabData->szStripNo,
        pSlabData->nSteelGradeCode,
        pSlabData->dSlabWidth,
        pSlabData->dSlabGauge,
        pSlabData->dSlabLen);

    strcpy(pszOut, szMsg);

    sprintf(szMsg, "TotalPassNum    : %d\r\n", pStandOut->nTotalPassNum);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Int(pStandOut->anDescCode, 
                               pStandOut->nTotalPassNum,
                               "anDescCode       : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adDeliveryGauge, 
                               pStandOut->nTotalPassNum,
                               "adDeliveryGauge  : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adGap, 
                               pStandOut->nTotalPassNum,
                               "adGap            : ", 
                               szMsg);
    strcat(pszOut, szMsg);
    HRS_RML2Calc_BuildLine_Double(pStandOut->adDraft, 
                               pStandOut->nTotalPassNum,
                               "adDraft          : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adSpeed, 
                               pStandOut->nTotalPassNum,
                               "adSpeed          : ", 
                               szMsg);
    strcat(pszOut, szMsg);
    HRS_RML2Calc_BuildLine_Double(pStandOut->adInSpeed, 
                               pStandOut->nTotalPassNum,
                               "adInSpeed        : ", 
                               szMsg);
    strcat(pszOut, szMsg);
    HRS_RML2Calc_BuildLine_Double(pStandOut->adOutSpeed, 
                               pStandOut->nTotalPassNum,
                               "adOutSpeed       : ", 
                               szMsg);
    strcat(pszOut, szMsg);


    strcpy(szMsg, "EntryTemp        : ");
    for ( i = 0; i < pStandOut->nTotalPassNum; i++ )
    {
        sprintf(szItem, "%f \t\t", pStandOut->adTempPair[i].dEntryTemp);
        strcat(szMsg, szItem);
    }
    strcat(szMsg, "\r\n");
    strcat(pszOut, szMsg);

    strcpy(szMsg, "DeliveryTemp     : ");
    for ( i = 0; i < pStandOut->nTotalPassNum; i++ )
    {
        sprintf(szItem, "%f \t\t", pStandOut->adTempPair[i].dDeliveryTemp);
        strcat(szMsg, szItem);
    }
    strcat(szMsg, "\r\n");
    strcat(pszOut, szMsg);


    HRS_RML2Calc_BuildLine_Double(pStandOut->adRollingForce, 
                               pStandOut->nTotalPassNum,
                               "adRollingForce   : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adTorque, 
                               pStandOut->nTotalPassNum,
                               "adTorque         : ", 
                               szMsg);
    strcat(pszOut, szMsg);
    HRS_RML2Calc_BuildLine_Double(pStandOut->adPower, 
                               pStandOut->nTotalPassNum,
                               "adPower          : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adLength, 
                               pStandOut->nTotalPassNum,
                               "adLength         : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adWidth, 
                               pStandOut->nTotalPassNum,
                               "adWidth          : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adQp, 
                               pStandOut->nTotalPassNum,
                               "adQp             : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adDeformResist, 
                               pStandOut->nTotalPassNum,
                               "adDeformResist   : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adCorr, 
                               pStandOut->nTotalPassNum,
                               "adCorr           : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adFlatRadius, 
                               pStandOut->nTotalPassNum,
                               "adFlatRadius             : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adWorkingRollerRadius, 
                               pStandOut->nTotalPassNum,
                               "adWorkingRollerRadius    : ", 
                               szMsg);
    strcat(pszOut, szMsg);

#if 0
    HRS_RML2Calc_BuildLine_Double(pStandOut->adGaugeRollForceFactor, 
                               pStandOut->nTotalPassNum,
                               "adGaugeRollForceFactor   : ", 
                               szMsg);
    strcat(pszOut, szMsg);

    HRS_RML2Calc_BuildLine_Double(pStandOut->adTempRollForceFactor, 
                               pStandOut->nTotalPassNum,
                               "adTempRollForceFactor   : ", 
                               szMsg);
    strcat(pszOut, szMsg);
#endif

    return ERR_SUCCESS;
}


char *HRS_RML2Calc_BuildOutStr(HRS_RM_ALL_OUT_DATA *pAllOutData)
{
    char *pszMsg;
    char *pszOut;

    int nActLen;
    int nTotalLen = 32768;

    pszMsg = (char *)NG_malloc(nTotalLen);
    if ( pszMsg == NULL )
    {
        return NULL;
    }

    HRS_RML2Calc_BuildStandOutStr(&(pAllOutData->Rm1stOutData), 
        pszMsg, nTotalLen);

    nActLen = (int)strlen(pszMsg);

    pszOut = pszMsg + nActLen;

    strcat(pszOut, "\r\n");

    pszOut += 2;

    HRS_RML2Calc_BuildStandOutStr(&(pAllOutData->Rm2ndOutData), 
        pszOut, nTotalLen - nActLen - 2);

    strcat(pszMsg, "\r\n\r\n");

    return pszMsg;
}


// ��ѯѹ���նȱ��Ϳ��ȸն�ϵ���� 
int HRS_RML2Calc_QueryModulusTable(int nMillNo, 
                                   double dRollForce, 
                                   double dEntryWidth,
                                   double *pdModulus)
{
    return ERR_SUCCESS;
}


// ��ѯ��ȿ����½��� 
int HRS_RM_QueryTempTable(HRS_STEEL_QUERY_INFO *pSteelQueryInfo,
                                HRS_TEMP_PAIR *pRMTempPair)
{
    return ERR_SUCCESS;
}


// ��ѯѹ���ʷ����   
int HRS_RM_QueryDraftRatioTable(HRS_STEEL_QUERY_INFO *pSteelQueryInfo,
                                      HRS_RM_DRAFT_RATIO *pDraftRatio)
{
    return ERR_SUCCESS;
}


// ���㲹��ϵ�� 
int HRS_RM_CalcCompen()
{
    return ERR_SUCCESS;
}

