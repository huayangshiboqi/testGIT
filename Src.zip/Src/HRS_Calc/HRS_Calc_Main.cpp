// HRS_Calc_Main.cpp : �������̨Ӧ�ó������ڵ㡣
//
#define _WIN32_WINNT    0x0401

#include "RW.h"
#include "WinPrint.h"
#include <stdio.h>
#include "MP_Comm.h"
#include "NG_threads.h"
#include "NG_SimpleTypes.h"
#include "MP_RemoteCall.h"
#include "MP_FuncCfg.h"
//#include "RWPMCalc_MPCalcFunctionDef.h"
#include "NG_Path.h"

#include "HRS_RMCalc.h"
#include "HRS_FMCalc.h"
#include "MP_HRS_Calc.h"

#define HRSCalc_SERVICE_NAME    "HRSCalcService"

// ���㺯����ŵ�ö��ֵ
typedef enum HRS_CalcFuncName_en
{
    HRS_CALC_FUNC_INVALID = -1,

    HRS_CALC_FUNC_RML2_CALC_GAP = 0,       // ����������㺯��
    HRS_CALC_FUNC_RML2_CALC_ROLLING_FORCE, // �������������㺯��
    HRS_CALC_FUNC_RML2_CALC_TEMP,          // �����¶ȼ��㺯��
    HRS_CALC_FUNC_RML2_CALC_SPEED,         // �����ٶȼ��㺯��
    HRS_CALC_FUNC_RML2_CALC_THICK,         // �������ں�ȼ��㺯��

    HRS_CALC_FUNC_FML2_CALC_GAP,           // ����������㺯��
    HRS_CALC_FUNC_FML2_CALC_ROLLING_FORCE, // �������������㺯��
    HRS_CALC_FUNC_FML2_CALC_TEMP,          // �����¶ȼ��㺯��
    HRS_CALC_FUNC_FML2_CALC_SPEED,         // �����ٶȼ��㺯��
    HRS_CALC_FUNC_FML2_CALC_THICK,         // �������ں�ȼ��㺯��

    HRS_CALC_FUNC_MAX                      // ���㺯������
} HRS_CALC_FUNC_EM;


SERVICE_STATUS          HRSCalcServiceStatus; 
SERVICE_STATUS_HANDLE   HRSCalcServiceStatusHandle; 

VOID WINAPI  HRSCalcServiceStart (DWORD argc, LPTSTR *argv); 
VOID WINAPI  HRSCalcServiceCtrlHandler (DWORD opcode); 
DWORD HRSCalcServiceInitialization (DWORD argc, LPTSTR *argv, 
                                   DWORD *specificError); 
VOID HRSCalcSvcDebugOut(LPSTR String, DWORD Status) ;

static void HRSCalc_CreateThread();

static void * HRSCalc_ThreadFunc(void *pArg);
static void HRSCalc_StopService();

void Usage(void)
{
    printf("HRSCalcService                   #������������Ҫ��Service��ʽ����\n");
    printf("HRSCalcService -d nWaitTimeMs    #����������ͨ�������б��ڵ���\n\n");

    return;
}

VOID  main( ) 
{ 
    SERVICE_TABLE_ENTRY   DispatchTable[] = 
    { 
        {  TEXT(HRSCalc_SERVICE_NAME), HRSCalcServiceStart }, 
        { NULL,              NULL            } 
    }; 


    char *pszCmdLine = NULL;

    char **ppszArgv = NULL;
    int    nArgCount = 0;
    pszCmdLine = (char *)GetCommandLine(); 
	//�������������ʱ���������Ĳ�����ͨ��GetCommandLine���ա�Windows API
	//HRS_Calc��һ����̬�⣬�Ǳ����ص����������У�����һ������ʹ�õġ�
	//GetCommandLineһ���Ǳ�ĳ��򣬵��ÿ�ִ���ļ�����.exe��.dll��.sys�ȡ�
	//Ҳ����˵�������̬����Ŀ���ɵ�.lib�����ص��ý�������е�һ��.exe�У���������.exe������

    ppszArgv = NG_GetCmdLineArray(pszCmdLine, &nArgCount);

    WinPrint("argv = %s\n", pszCmdLine);

    if ( ppszArgv == NULL )
    {
        return;
    }

    if ( nArgCount == 3 )
    {
        if ( ppszArgv[1][0] == '-' 
            && (ppszArgv[1][1] == 'd' || ppszArgv[1][1] == 'D') )
        {
            int nWaitTimeMs = atoi(ppszArgv[2]);

            HRSCalc_ThreadFunc(NULL);

            NGClock_Delay(nWaitTimeMs);

            NG_FreeArray((void **)ppszArgv);

            HRSCalc_StopService();

            return;
        }
    }
    else if ( nArgCount > 1 )
    {
        Usage();
        NG_FreeArray((void **)ppszArgv);

        NG_malloc_close();

        return;
    }

    NG_FreeArray((void **)ppszArgv);


    if (!StartServiceCtrlDispatcher( DispatchTable)) 
    { 
        HRSCalcSvcDebugOut(" [HDRServer_SERVICE_NAME] StartServiceCtrlDispatcher error = \
                          %d\n", GetLastError()); 
    }

    return;
} 


VOID HRSCalcSvcDebugOut(LPSTR String, DWORD Status) 
{ 
    CHAR  Buffer[1024]; 
    if (strlen(String) < 1000) 
    { 
        sprintf(Buffer, String, Status); 
        WinPrint(Buffer); 
    } 
} 


void WINAPI 
HRSCalcServiceStart (DWORD argc, LPTSTR *argv) 
{ 
    DWORD status; 
    DWORD specificError; 

    HRSCalcServiceStatus.dwServiceType        = SERVICE_WIN32; 
    HRSCalcServiceStatus.dwCurrentState       = SERVICE_START_PENDING; 
    HRSCalcServiceStatus.dwControlsAccepted   = SERVICE_ACCEPT_STOP | 
        SERVICE_ACCEPT_PAUSE_CONTINUE; 
    HRSCalcServiceStatus.dwWin32ExitCode      = 0; 
    HRSCalcServiceStatus.dwServiceSpecificExitCode = 0; 
    HRSCalcServiceStatus.dwCheckPoint         = 0; 
    HRSCalcServiceStatus.dwWaitHint           = 0; 

    HRSCalcServiceStatusHandle = RegisterServiceCtrlHandler( 
        TEXT(HRSCalc_SERVICE_NAME), 
        HRSCalcServiceCtrlHandler); 

    if (HRSCalcServiceStatusHandle == (SERVICE_STATUS_HANDLE)0) 
    { 
        HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] RegisterServiceCtrlHandler \
                          failed %d\n", GetLastError()); 
        return; 
    } 

    // Initialization code goes here. 
    status = HRSCalcServiceInitialization(argc,argv, &specificError); 

    // Handle error condition 
    if (status != NO_ERROR) 
    { 
        HRSCalcServiceStatus.dwCurrentState       = SERVICE_STOPPED; 
        HRSCalcServiceStatus.dwCheckPoint         = 0; 
        HRSCalcServiceStatus.dwWaitHint           = 0; 
        HRSCalcServiceStatus.dwWin32ExitCode      = status; 
        HRSCalcServiceStatus.dwServiceSpecificExitCode = specificError; 

        SetServiceStatus (HRSCalcServiceStatusHandle, &HRSCalcServiceStatus); 
        return; 
    } 

    // Initialization complete - report running status. 
    HRSCalcServiceStatus.dwCurrentState       = SERVICE_RUNNING; 
    HRSCalcServiceStatus.dwCheckPoint         = 0; 
    HRSCalcServiceStatus.dwWaitHint           = 0; 

    if (!SetServiceStatus (HRSCalcServiceStatusHandle, &HRSCalcServiceStatus)) 
    { 
        status = GetLastError(); 
        HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] SetServiceStatus error\
                          %ld\n",status); 
    } 


    // This is where the service does its work. 
    // CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)HRSCalc_thread,  NULL, 0, &dwThreadId);
    HRSCalc_CreateThread();

    HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] Returning the Main Thread \n",0); 

    return; 
} 


// Stub initialization function. 
DWORD HRSCalcServiceInitialization(DWORD   argc, LPTSTR  *argv, 
                                  DWORD *specificError) 
{ 
    argv; 
    argc; 
    specificError; 
    return(0); 
} 


VOID WINAPI HRSCalcServiceCtrlHandler (DWORD Opcode) 
{ 
    DWORD status; 

    switch(Opcode) 
    { 
    case SERVICE_CONTROL_PAUSE: 
        // Do whatever it takes to pause here. 
        HRSCalcServiceStatus.dwCurrentState = SERVICE_PAUSED; 
        break; 

    case SERVICE_CONTROL_CONTINUE: 
        // Do whatever it takes to continue here. 
        HRSCalcServiceStatus.dwCurrentState = SERVICE_RUNNING; 
        break; 

    case SERVICE_CONTROL_STOP: 
        // Do whatever it takes to stop here. 
        HRSCalcServiceStatus.dwWin32ExitCode = 0; 
        HRSCalcServiceStatus.dwCurrentState  = SERVICE_STOPPED; 
        HRSCalcServiceStatus.dwCheckPoint    = 0; 
        HRSCalcServiceStatus.dwWaitHint      = 0;

        // ֹͣ���񣬻�����Դ
        HRSCalc_StopService();

        if (!SetServiceStatus (HRSCalcServiceStatusHandle, 
            &HRSCalcServiceStatus))
        { 
            status = GetLastError(); 
            HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] SetServiceStatus error \
                              %ld\n",status); 
        } 

        HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] Leaving HRSCalcService \n",0); 
        return; 

    case SERVICE_CONTROL_INTERROGATE: 
        // Fall through to send current status. 
        break; 

    default: 
        HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] Unrecognized opcode %ld\n", 
            Opcode); 
    } 

    // Send current status. 
    if (!SetServiceStatus (HRSCalcServiceStatusHandle,  &HRSCalcServiceStatus)) 
    { 
        status = GetLastError(); 
        HRSCalcSvcDebugOut(" [HRSCalc_SERVICE_NAME] SetServiceStatus error \
                          %ld\n",status); 
    } 
    return; 
} 


void HRSCalc_CreateThread(void)
{
    HANDLE hThread;

    hThread = NG_CreateThread(HRSCalc_ThreadFunc, NULL, NGTHREAD_RUNNING);

    return;
}

HANDLE   g_hRemoteCallCalcServer = NULL;


void HRSCalc_StopService()
{
    NG_CloseHandle(g_hRemoteCallCalcServer);

    g_hRemoteCallCalcServer = NULL;
}


//����ID,������������ָ���������
FUNC_NAME_PTR  g_aHRS_NamePtr[] =
{ 
    {HRS_CALC_FUNC_RML2_CALC_GAP           , "HRS_RML2Calc_CalcGap"          , MP_HRS_RML2Calc_CalcGap         }, // ����������㺯��
    {HRS_CALC_FUNC_RML2_CALC_ROLLING_FORCE , "HRS_RML2Calc_CalcRollingForce" , MP_HRS_RML2Calc_CalcRollingForce}, // �������������㺯��
    {HRS_CALC_FUNC_RML2_CALC_TEMP          , "HRS_RML2Calc_CalcTemp"         , MP_HRS_RML2Calc_CalcTemp        }, // �����¶ȼ��㺯��
    {HRS_CALC_FUNC_RML2_CALC_SPEED         , "HRS_RML2Calc_CalcSpeed"        , MP_HRS_RML2Calc_CalcSpeed       }, // �����ٶȼ��㺯��
    {HRS_CALC_FUNC_RML2_CALC_THICK         , "HRS_RML2Calc_CalcThick"        , MP_HRS_RML2Calc_CalcThick       }, // �������ں�ȼ��㺯��
    
    {HRS_CALC_FUNC_FML2_CALC_GAP           , "HRS_FML2Calc_CalcGap"          , MP_HRS_FML2Calc_CalcGap         }, // ����������㺯��
    {HRS_CALC_FUNC_FML2_CALC_ROLLING_FORCE , "HRS_FML2Calc_CalcRollingForce" , MP_HRS_FML2Calc_CalcRollingForce}, // �������������㺯��
    {HRS_CALC_FUNC_FML2_CALC_TEMP          , "HRS_FM_QueryL2Calc_CalcTemp"         , MP_HRS_FM_QueryL2Calc_CalcTemp        }, // �����¶ȼ��㺯��
    {HRS_CALC_FUNC_FML2_CALC_SPEED         , "HRS_FML2Calc_CalcSpeed"        , MP_HRS_FML2Calc_CalcSpeed       }, // �����ٶȼ��㺯��
    {HRS_CALC_FUNC_FML2_CALC_THICK         , "HRS_FML2Calc_CalcThick"        , MP_HRS_FML2Calc_CalcThick       }, // �������ں�ȼ��㺯��
                                                                                                               
    //�������������                                                                                           
    {-1,  NULL,     NULL  }                                                                                    
};


void * HRSCalc_ThreadFunc(void *pArg)
{
    char szPath[512];
    int nRet = NG_Path_GetRunPath(szPath, sizeof(szPath)-1);
    if ( nRet == ERR_FAILED )
    {
        return NULL;
    }
    strcat(szPath, "HRSCalc.cfg");


    g_hRemoteCallCalcServer = MP_RemoteCall_MasterOpen(szPath, g_aHRS_NamePtr);

    if ( g_hRemoteCallCalcServer == NULL )
    {
        WinPrint(" [HRSCalc_SERVICE_NAME] MasterOpen error.\n"); 
    }
    else
    {
        WinPrint(" [HRSCalc_SERVICE_NAME] MasterOpen successful\n");
    }

    NGClock_Delay(1000);

    return NULL;
}
