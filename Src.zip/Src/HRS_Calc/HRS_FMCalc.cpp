
#include <direct.h>
#include <math.h>
#include "NG.h"
#include "NG_Time.h"
#include "NG_Path.h"

#include "HRS_FMCalc.h"
#include "CGlobalInstance.h"
#include "HRS_Global.h"
#include "HRS_CommonCalc.h"
#include "HRS_RMCalc.h"
#include "HRS_ModuleName.h"
#include "HRS_ServerCfg.h"
#include "HRS_EquipParaMgr.h"

#include "HRS_AllTable.h"
#include "HRS_ModulusTable.h"


#if 0
/*
�����������¶ȣ� VHCR-MOSFM-4.4.8.2.1
��������κ��ѹ��������ں�ȳ��ں�ȣ�VHCR-MOSFM-4.4.8.2.2
��������ο������� VHCR-MOSFM-4.4.8.2.3
������ڳ��ȣ� VHCR-MOSFM-4.4.8.2.4
��������¶ȣ� VHCR-MOSFM-4.4.8.2.5
����ˮƽ�������������� VHCR-MOSFM-4.4.8.2.6
*/

// ��������¶�
/**
    ͨ����������ӳ�¯�󵽴�����ʼ����ǰ���½����������������¶ȡ�
    ���У�
    TEIN��I������I��������¶� 
    TAUS��I��1������I��1���γ����¶� 
    GAST���ȷ��䳣�� 
    TIME��I�����ӵ�I��1����ҧ�ֵ���I����ҧ�ֵ�ʱ�� 
    HEIN��I������ں��
    TSPR�������½� 
    TSPR = TVMAX - (HEIN(I) - HEINM) * TSPM
    TVMAX����С���ʱ������½� 
    HEINM��������С��� 
    TSPM���½�����б��
*/
HRS_FM_CalcTempIn(int i)  // i��ʾ���Σ���1��ʼ
{
    assert(i >= 1);

    double dValue;   // �����õ���ʱ����
    double dData;    // �����õ���ʱ����

    double dGast;       // �ȷ��䳣��
    double dTspm;    // TSPM���½�����б��
    double dHeinm;   // HEINM��������С��� 
    double dTvMax;   // TVMAX����С���ʱ������½� 
    double dTspr;    // TSPR�������½� 

    double adTempIn[16]; // ����������¶�����
    double adTaus[16];   // �������γ����¶�
    double adTime[16];   // ������ҧ��ʱ��
    double adHein[16];   // ��ں��


    dTspr = dTvMax - (adHein[i] - dHeinm) * dTspm;


    dData = adTaus[i-1];
    dValue = dData * dData * dData;

    dData = 1.0 / dValue;  // ��ҪУ��dValue��ֵ�Ƿ����Ϊ0

    dValue = dData + (dGast * adTime[i]) / adHein[i];  // ��ҪУ��adHein[i]��ֵ�Ƿ����Ϊ0

    dData = powf(dValue, 1.0/3.0);

    dValue = 1.0 / dData;   // ��ҪУ��dData��ֵ�Ƿ����Ϊ0
    
    dValue = dValue - dTspr;

    adTempIn[i] = dValue;

    return;
}
#endif

#if 1
// ׼���������� 

// ��ȡ���Ƽƻ����� 
int HRS_FML2Calc_GetSchedulePlanData()
{
    return ERR_SUCCESS;
}


// ��ȡ���Ʋ������� 
int HRS_FML2Calc_GetFMStrategyData()
{
    return ERR_SUCCESS;
}


// ��ȡ��������     
int HRS_FML2Calc_GetPlateData()
{
    return ERR_SUCCESS;
}


// ��ȡ�豸����     
int HRS_FML2Cacl_GetEquipParaData()
{
    return ERR_SUCCESS;
}

int HRS_FML2Calc_Prepare()
{

    HRS_FML2Calc_GetSchedulePlanData();
    HRS_FML2Calc_GetFMStrategyData();
    HRS_FML2Calc_GetPlateData();

    HRS_FML2Cacl_GetEquipParaData();
    HRS_FML2Calc_GetSteelData();

    return ERR_SUCCESS;
}

#endif

// ���ݰ������ݼ�����ֵȼ�����ȼ����ȵȼ� 
int HRS_FML2Calc_GetSteelData()
{
    return ERR_SUCCESS;
}





// ��ѯѹ���նȱ��Ϳ��ȸն�ϵ���� 
int HRS_FML2Calc_QueryModulusTable()
{
    return ERR_SUCCESS;
}


// ��ѯ��ȿ����½��� 
int HRS_FML2Calc_QueryTempTable()
{
    return ERR_SUCCESS;
}


// ��ѯѹ���ʷ����   
int HRS_FML2Calc_QueryDraftRatioTable()
{
    return ERR_SUCCESS;
}


// ���㲹��ϵ�� 
int HRS_FML2Calc_CalcCompen()
{
    return ERR_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////

// ������ѯ�����ȼ���Ϣ
int  HRS_FM_QuerySlabLevel(HRS_FM_ALL_DATA *pAllData)
{
    HRS_STEEL_LEVEL *SteelLevel;
    double dSlabGauge;
    double dSlabWidth;
    double dFmGauge;
    double dFmWidth;
    double dFmDeliveryTemp;
    double dRmWidth;
    HRS_PLAN_DATA        *pPlanData;
    HRS_FM_STRATEGY_DATA *pFMStrategyData;
    int nRet;
    char *pszOutErr = pAllData->szOutErr;

    pszOutErr[0] = '\0';

    pFMStrategyData = &(pAllData->FMStrategyData);
    pPlanData     = &(pAllData->PlanData);

    ////��ʼ�����ģ��
    //nRet = HRS_AllTable_Init();
    //if (nRet == ERR_FAILED)
    //{
    //    return ERR_FAILED;
    //}

    SteelLevel = &pAllData->SteelLevel;

    SteelLevel->nSteelGradeCode = pPlanData->SlabData.nSteelGradeCode;


    dSlabGauge = pPlanData->SlabData.dSlabGauge;
    nRet = HRS_SlabGaugeLevelTable_Query(dSlabGauge,
        &SteelLevel->nSlabGaugeLevel, pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dSlabWidth = pPlanData->SlabData.dSlabWidth;
    nRet = HRS_SlabWidthLevelTable_Query(dSlabWidth,
        &SteelLevel->nSlabWidthLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dFmGauge = pPlanData->dTargetGauge;
    nRet = HRS_FmGaugeLevelTable_Query(dFmGauge,
        &SteelLevel->nTargetGaugeLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dFmWidth = pPlanData->dTargetWidth;
    nRet = HRS_FmWidthLevelTable_Query(dFmWidth,
        &SteelLevel->nFMWidthLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    dFmDeliveryTemp = pPlanData->dFMDeliveryTemp;
    nRet = HRS_FmDeliveryTempLevelTable_Query(dFmDeliveryTemp,
        &SteelLevel->nFinalTempLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //�������ȵȼ������Դ���������
    dRmWidth = pFMStrategyData->FMStraData.dTransferBarWidth;
    nRet = HRS_RmWidthLevelTable_Query(dRmWidth,
        &SteelLevel->nRMWidthLevel,
        pszOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;

}


////////////////////////////////////////////////////////////////////////////////


// ��ѯ����ѹ���ʷ����׼������
int HRS_FM_QueryDraftRatioTable_PrepPara(HRS_FM_ALL_DATA *pAllData,
                                         HRS_FM_DRAFTRATIO_QUERY_INFO 
                                         *pDraftRatioQueryInfo)
{
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    if (pAllData == NULL || pDraftRatioQueryInfo == NULL)
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;
    pPlanData     = &(pAllData->PlanData);

    pDraftRatioQueryInfo->nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pDraftRatioQueryInfo->nQualityCode = pAllData->PlanData.nQualityCode;
    pDraftRatioQueryInfo->nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pDraftRatioQueryInfo->nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pDraftRatioQueryInfo->nFinalTempLevel = SteelLevel->nFinalTempLevel;

    strncpy(pDraftRatioQueryInfo->szSteelGradeName, 
            pPlanData->SlabData.szSteelGradeName, 
            HRS_MAX_GRADE_LEN);


    return ERR_SUCCESS;
}

// ��ѯ����ѹ���ʷ����   
int HRS_FM_QueryDraftRatioTable(HRS_FM_DRAFTRATIO_QUERY_INFO 
                                *pDraftRatioQueryInfo,
                                HRS_FM_DRAFT_RATIO *pDraftRatio,
                                char *pszOutErr)
{
                                                                                //��������
    int nRet;
    HRS_TABLE_FM_DRAFTRATIO FmDraftRatioTabInfo;

    FmDraftRatioTabInfo.nSteelGradeCode = pDraftRatioQueryInfo->nSteelGradeCode;
    FmDraftRatioTabInfo.nQualityCode    = pDraftRatioQueryInfo->nQualityCode;
    FmDraftRatioTabInfo.nTargetGaugeLevel = pDraftRatioQueryInfo->nTargetGaugeLevel;
    FmDraftRatioTabInfo.nFMWidthLevel = pDraftRatioQueryInfo->nFMWidthLevel;
    FmDraftRatioTabInfo.nFinalTempLevel = pDraftRatioQueryInfo->nFinalTempLevel;

    nRet = HRS_FmDraftRatioTab_Search(&FmDraftRatioTabInfo, pszOutErr);
    if ( nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    pDraftRatio->adDraftRatio[0] = FmDraftRatioTabInfo.fLoadValue1;
    pDraftRatio->adDraftRatio[1] = FmDraftRatioTabInfo.fLoadValue2;
    pDraftRatio->adDraftRatio[2] = FmDraftRatioTabInfo.fLoadValue3;
    pDraftRatio->adDraftRatio[3] = FmDraftRatioTabInfo.fLoadValue4;
    pDraftRatio->adDraftRatio[4] = FmDraftRatioTabInfo.fLoadValue5;
    pDraftRatio->adDraftRatio[5] = FmDraftRatioTabInfo.fLoadValue6;
    pDraftRatio->adDraftRatio[6] = FmDraftRatioTabInfo.fLoadValue7;


    return ERR_SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////

// ���������ں�ȼ��㺯��׼���������
int HRS_FML2Calc_PrepareGaugePara(HRS_FM_ALL_DATA *pAllData, 
                                   HRS_FM_DELIVERY_GAUGE_PARA *pGaugePara)
{
    HRS_PLAN_DATA        *pPlanData;
    HRS_FM_DRAFTRATIO_QUERY_INFO pDraftRatioQueryInfo;
    HRS_FM_DRAFT_RATIO pDraftRatio;
    HRS_FM_STRATEGY_DATA *pFMStrategyData;
    int nRet;
    
    pFMStrategyData = &(pAllData->FMStrategyData);
    pPlanData     = &(pAllData->PlanData);

    nRet = HRS_FM_QueryDraftRatioTable_PrepPara(pAllData, &pDraftRatioQueryInfo);
    if (nRet == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    nRet = HRS_FM_QueryDraftRatioTable(&pDraftRatioQueryInfo, 
                                       &pDraftRatio,
                                       pAllData->szOutErr);
    if (nRet == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    pGaugePara->dTargetGauge = pPlanData->dTargetGauge;
    pGaugePara->dTargetGauge += pAllData->FMStrategyData.FMStraData.dFMThickAdjust;
    
    if (pFMStrategyData->FMStraData.dTransferBarThick <= 0)
    {
        pGaugePara->dTransferBarThick = pPlanData->dTransferBarGauge;
    }
    else
    {
        pGaugePara->dTransferBarThick = pFMStrategyData->FMStraData.dTransferBarThick;
    }

    // ѹ���ʸĳ��ý����е�ѹ���ʽ��м��㣬��ʹ�ò��������

    double dDraftRatio;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        dDraftRatio = pAllData->FMStrategyData.FMLoadData.adLoadValue[i];
        dDraftRatio += pAllData->FMStrategyData.FMLoadData.adLoadCorr[i];

        //pGaugePara->adPassDraftRatio[i] = pDraftRatio.adDraftRatio[i];
        pGaugePara->adPassDraftRatio[i] = dDraftRatio;
    }

    //���Ŀ���ȼ���ƫ��
    pGaugePara->dMaxDeviation = HRS_MAX_CALC_DEVIATION;   

    return ERR_SUCCESS;
}

// ���㾫�������ܳ��ں�� 
int HRS_FML2Calc_CalcGauge(HRS_FM_DELIVERY_GAUGE_PARA *pGaugePara, 
                           HRS_FM_DELIVERY_GAUGE *pAllDeliveryGauge,
                           char *pszOutErr)
{
    int nRet;

    nRet = HRS_Calc_DeliveryGauge( HRS_MAX_FM_STAND_NUM, 
                                   pGaugePara->dTransferBarThick,
                                   pGaugePara->dTargetGauge,
                                   pGaugePara->adPassDraftRatio,
                                   pGaugePara->dMaxDeviation,
                                   pAllDeliveryGauge->adDeliveryGauge,
                                   pAllDeliveryGauge->adEntryGauge,
                                   pAllDeliveryGauge->adActDraftRatio,
                                   pszOutErr);

    return nRet;
}

////////////////////////////////////////////////////////////////////////////////

// �������ٶȼ��㺯��׼���������
int HRS_FML2Calc_PrepareSpeedPara(HRS_FM_ALL_DATA *pAllData,
                                  HRS_FM_DELIVERY_GAUGE *pAllDeliveryGauge,
                                  HRS_FM_SPEED_PARA *pSpeedPara)
{
    HRS_FM_STRATEGY_DATA *pFMStrategyData;

    pFMStrategyData = &(pAllData->FMStrategyData);

    pSpeedPara->dThreadSpeed = pFMStrategyData->FMStraData.dThreadSpeed;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pSpeedPara->adDeliveryGauge[i] = pAllDeliveryGauge->adDeliveryGauge[i];
    }

    return ERR_SUCCESS;
}

// ���㾫�������������ٶ� 
int HRS_FML2Calc_CalcSpeed(HRS_FM_SPEED_PARA *pSpeedPara, 
                           HRS_FM_SPEED *pAllSpeed)
{
    if (pSpeedPara->dThreadSpeed < 0)
    {
        return ERR_FAILED;
    }

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        if (pSpeedPara->adDeliveryGauge[i] < 0)
        {
            return ERR_FAILED;
        }
    }

    pAllSpeed->adSpeed[HRS_MAX_FM_STAND_NUM-1] = pSpeedPara->dThreadSpeed;
    for (int i = HRS_MAX_FM_STAND_NUM-2; i >=0; i--)
    {
        pAllSpeed->adSpeed[i] = (pAllSpeed->adSpeed[i+1] * 
                                 pSpeedPara->adDeliveryGauge[i+1]) /
                                 pSpeedPara->adDeliveryGauge[i];
    }

    return ERR_SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////

// ��������¶ȼ��㺯��׼���������
int HRS_FML2Calc_PrepareTempPara(HRS_FM_ALL_DATA *pAllData,
                                 HRS_FM_TEMP_PARA *pTempPara)
{
    HRS_PLAN_DATA        *pPlanData;
    HRS_FM_STRATEGY_DATA *pFMStrategyData;
    HRS_STEEL_LEVEL *SteelLevel;

    if (pAllData == NULL || pTempPara == NULL)
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;
    pPlanData     = &(pAllData->PlanData);
    pFMStrategyData = &(pAllData->FMStrategyData);

    strncpy(pTempPara->szSteelGradeName, 
            pPlanData->SlabData.szSteelGradeName, 
            HRS_MAX_GRADE_LEN);

    pTempPara->dFMEntryTemp = pFMStrategyData->FMStraData.dFMEntryTemp;
    pTempPara->dFMDeliveryTemp = pPlanData->dFMDeliveryTemp;

    pTempPara->nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pTempPara->nQualityCode = pAllData->PlanData.nQualityCode;
    pTempPara->nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pTempPara->nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pTempPara->nFinalTempLevel = SteelLevel->nFinalTempLevel;

    return ERR_SUCCESS;
}


// ��ѯ���������ܳ�����¶� 
int HRS_FM_QueryL2Calc_CalcTemp(HRS_FM_TEMP_PARA *pTempPara, 
                          HRS_FM_TEMP *pAllTemp, 
                          char *pszOutErr)
{
                                                                                //��������

    int nRet;
    HRS_TABLE_FM_TEMP FmTempTabInfo;

    FmTempTabInfo.nSteelGradeCode = pTempPara->nSteelGradeCode;
    FmTempTabInfo.nQualityCode = pTempPara->nQualityCode;
    FmTempTabInfo.nTargetGaugeLevel = pTempPara->nTargetGaugeLevel;
    FmTempTabInfo.nFMWidthLevel = pTempPara->nFMWidthLevel;
    FmTempTabInfo.nFinalTempLevel = pTempPara->nFinalTempLevel;

    nRet = HRS_FmTempTab_Search(&FmTempTabInfo, pszOutErr);
    if ( nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }


    double dDischargeTemp = pTempPara->dFMEntryTemp;

    if (dDischargeTemp < NG_POSITIVE_ZERO )
    {
        return ERR_FAILED;
    }

    double dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp1);
    pAllTemp->adTempPair[0].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp1);
    pAllTemp->adTempPair[0].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp2);
    pAllTemp->adTempPair[1].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp2);
    pAllTemp->adTempPair[1].dDeliveryTemp = dTemp;


    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp3);
    pAllTemp->adTempPair[2].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp3);
    pAllTemp->adTempPair[2].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp4);
    pAllTemp->adTempPair[3].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp4);
    pAllTemp->adTempPair[3].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp5);
    pAllTemp->adTempPair[4].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp5);
    pAllTemp->adTempPair[4].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp6);
    pAllTemp->adTempPair[5].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp6);
    pAllTemp->adTempPair[5].dDeliveryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dEntryTemp7);
    pAllTemp->adTempPair[6].dEntryTemp = dTemp;

    dTemp = HRS_CalcActTemp(dDischargeTemp, 
        FmTempTabInfo.dChuLuTemp, 
        FmTempTabInfo.dExitTemp7);
    pAllTemp->adTempPair[6].dDeliveryTemp = dTemp;

    return ERR_SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////

//
// �������о������ܵ�������
//
int HRS_FML2Calc_AllRollingForce(HRS_FM_ALL_DATA *pAllData,
                                 HRS_FM_DELIVERY_GAUGE *pAllDeliveryGauge,
                                 HRS_FM_TEMP *pAllTemp,
                                 HRS_FM_SPEED *pAllSpeed,
                                 HRS_FM_ALL_ROLLFORCE *pAllRollForce)
{
    HRS_PLAN_DATA  *pPlanData;
    HRS_STAND_PARA *pEquipPara;
    HRS_SLAB_DATA  *pSlabData;
    HRS_FM_STRATEGY_DATA *pFMStrategyData;
    HRS_ONE_PASS_ROLL_FORCE  OnePassRollForce;
    int nRet;

    pFMStrategyData = &(pAllData->FMStrategyData);
    pPlanData     = &(pAllData->PlanData);

    pSlabData = &(pAllData->PlanData.SlabData);

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pAllRollForce->aStandRollForce[i].dDeliveryGauge 
            = pAllDeliveryGauge->adDeliveryGauge[i];
        pAllRollForce->aStandRollForce[i].dWidth = 
            pFMStrategyData->FMStraData.dTransferBarWidth;

        if ( i == 0 )
        {
            pAllRollForce->aStandRollForce[i].dEntryGauge 
                            = pFMStrategyData->FMStraData.dTransferBarThick;
        } 
        else
        {
            pAllRollForce->aStandRollForce[i].dEntryGauge 
                = pAllDeliveryGauge->adDeliveryGauge[i-1];
        }

        pAllRollForce->aStandRollForce[i].dCorr = 0.65; //... 
    }

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pEquipPara = &(pAllData->AllStandPara.aEquipPara[i+HRS_STAND_NO_FM1]);

        if (pAllData->FMStrategyData.FMLoadData.adLoadValue[i] 
            > NG_POSITIVE_ZERO )
        {
            nRet = HRS_Calc_OnePass_RollingForce(pEquipPara->dMaxWorkingRollerRadius,
                pEquipPara->dCalcAdjust,
                pAllTemp->adTempPair[i].dEntryTemp,
                pAllSpeed->adSpeed[i],
                &(pAllData->DeformFactor),
                &(pAllRollForce->aStandRollForce[i]),
                pAllData->szOutErr);

            if (nRet == ERR_FAILED )
            {
                return ERR_FAILED;
            }

            OnePassRollForce = pAllRollForce->aStandRollForce[i];

            double dOldEntryGauge = OnePassRollForce.dEntryGauge;

            OnePassRollForce.dEntryGauge *= 1.05;    // �Ŷ�5%���м���

            // �ټ���һ�����������Ƚ�������������ֵ��ͨ����ֵ�ó�����Ŷ�ϵ��
            nRet = HRS_Calc_OnePass_RollingForce(pEquipPara->dMaxWorkingRollerRadius,
                pEquipPara->dCalcAdjust,
                pAllTemp->adTempPair[i].dEntryTemp,
                pAllSpeed->adSpeed[i],
                &(pAllData->DeformFactor),
                &(OnePassRollForce),
                pAllData->szOutErr);

            if ( nRet == ERR_FAILED )
            {
                return ERR_FAILED;
            }

            double dDeltaRollForce = OnePassRollForce.dRollForce 
                - pAllRollForce->aStandRollForce[i].dRollForce;

            double dRatio = dDeltaRollForce;
            dRatio /= (pAllRollForce->aStandRollForce[i].dEntryGauge * 0.05);

            pAllRollForce->aStandRollForce[i].dGaugeRollForceFactor = dRatio;

            //
            // �ټ���һ���¶ȶ���������Ӱ��ϵ��
            //
            OnePassRollForce.dEntryGauge = dOldEntryGauge;

            double dEntryTemp = pAllTemp->adTempPair[i].dEntryTemp;
            dEntryTemp *= 1.05;

            nRet = HRS_Calc_OnePass_RollingForce(pEquipPara->dMaxWorkingRollerRadius,
                pEquipPara->dCalcAdjust,
                dEntryTemp,
                pAllSpeed->adSpeed[i],
                &(pAllData->DeformFactor),
                &(OnePassRollForce),
                pAllData->szOutErr);

            dDeltaRollForce = OnePassRollForce.dRollForce 
                - pAllRollForce->aStandRollForce[i].dRollForce;

            dRatio = dDeltaRollForce;
            dRatio /= ( pAllTemp->adTempPair[i].dEntryTemp * 0.05);

            pAllRollForce->aStandRollForce[i].dTempRollForceFactor = dRatio;
        }
        else
        {
            pAllRollForce->aStandRollForce[i].dWorkingRollerRadius = 
                pEquipPara->dMaxWorkingRollerRadius;
            pAllRollForce->aStandRollForce[i].dFlatRadius
                = pAllRollForce->aStandRollForce[i].dWorkingRollerRadius;

            pAllRollForce->aStandRollForce[i].dQp                   = 0.0;
            pAllRollForce->aStandRollForce[i].dDeformResist         = 0.0;
            pAllRollForce->aStandRollForce[i].dRollForce            = 0.0;
            pAllRollForce->aStandRollForce[i].dGaugeRollForceFactor = 0.0;
            pAllRollForce->aStandRollForce[i].dTempRollForceFactor  = 0.0;

        }
    }

    return ERR_SUCCESS;
} 

////////////////////////////////////////////////////////////////////////////////

// ��������㺯��׼���������
int HRS_FML2Calc_PrepareGapPara(HRS_FM_ALL_DATA           *pAllData, 
                                 HRS_FM_DELIVERY_GAUGE     *pAllDeliveryGauge,
                                 HRS_FM_ALL_ROLLFORCE          *pAllRollForce,
                                 HRS_FM_GAP_PARA           *pAllGapPara)
{
    double dModulus;
    double dWidth;
    double dRollForce;
    int    nRet;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pAllGapPara->GapStandPara[i].dDeliveryGauge 
                        = pAllDeliveryGauge->adDeliveryGauge[i];
        pAllGapPara->GapStandPara[i].dRollForce 
                        = pAllRollForce->aStandRollForce[i].dRollForce;

        //��ѯ�նȱ�
        dWidth = pAllData->FMStrategyData.FMStraData.dTransferBarWidth;
#if 0
        dRollForce = pAllRollForce->aStandRollForce[i].dRollForce * 10;
        HRS_FmModulusTable_Query(i+1, dWidth, dRollForce, &dModulus);
#endif
        dRollForce = pAllRollForce->aStandRollForce[i].dRollForce;

        nRet = HRS_CalcModulus((HRS_STAND_NO_EM)(i+HRS_STAND_NO_FM1), 
                                dRollForce, dWidth,
                                &dModulus);
        if (nRet == ERR_FAILED)
        {
            printf("CalcModulus Failed. nStandNo = %d\r\n", i+HRS_STAND_NO_FM1);
            return ERR_FAILED;
        }

        pAllGapPara->GapStandPara[i].dModulus = dModulus;

        pAllGapPara->GapStandPara[i].dZeroForce 
             = pAllData->AllStandPara.aEquipPara[i+HRS_STAND_NO_FM1].dZeroForce;

//        pAllGapPara->GapStandPara[i].dModulus          = dModulus / 10;     
        pAllGapPara->GapStandPara[i].dOilFilmComp      = 0.0;  // ��Ĥ����ֵ�� ��ʱ��Ϊ0
        pAllGapPara->GapStandPara[i].dRollWearComp     = 0.0;  // ĥ�𲹳�ֵ�� ��ʱ��Ϊ0
        pAllGapPara->GapStandPara[i].dThermalCrownComp = 0.0;  // �����Ͳ���ֵ,��ʱ��Ϊ0
    }

    return ERR_SUCCESS;
}

// ���㾫�������ܹ��� 
int HRS_FML2Calc_CalcAllGap(HRS_FM_GAP_PARA *pAllGapPara,
                            HRS_FM_GAP *pAllGap)
{
    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        HRS_Calc_OnePass_Gap(&pAllGapPara->GapStandPara[i], 
                             &pAllGap->adGap[i]);
    }

    return ERR_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////

//
// �������о������ܵ�Ť��
//
int HRS_FML2Calc_AllTorque(HRS_FM_ALL_DATA *pAllData,
                           HRS_FM_ALL_ROLLFORCE  *pAllRollForce,
                           HRS_FM_TORQUE  *pAllTorque)
{
    double dEntryGauge;
    double dDeliveryGauge;
    double dFlattenRadius;
    double dRollForce;
    double dTorque; 
    int    nRet;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        dEntryGauge = pAllRollForce->aStandRollForce[i].dEntryGauge;
        dDeliveryGauge = pAllRollForce->aStandRollForce[i].dDeliveryGauge;
        dFlattenRadius = pAllRollForce->aStandRollForce[i].dFlatRadius;
        dRollForce = pAllRollForce->aStandRollForce[i].dRollForce;

        nRet = HRS_Calc_RollingTorqueFrance(dEntryGauge,
                                            dDeliveryGauge,
                                            dFlattenRadius,
                                            dRollForce,
                                            &dTorque);

        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        pAllTorque->adStandTorque[i] = dTorque;
    }

    return ERR_SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////

//
// �������о������ܵĹ���
//
int HRS_FML2Calc_AllPower( HRS_FM_ALL_DATA *pAllData,
                          HRS_FM_SPEED *pAllSpeed,
                          HRS_FM_ALL_ROLLFORCE *pAllRollForce,
                          HRS_FM_TORQUE  *pAllTorque,
                          HRS_FM_POWER *pAllPower)
{
    double dTorque;
    double dSpeed;
    double dFlatRadius;
    double dRollingPower;
    int nRet;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        dTorque = pAllTorque->adStandTorque[i];
        dSpeed = pAllSpeed->adSpeed[i];
        dFlatRadius = pAllRollForce->aStandRollForce[i].dFlatRadius;

        nRet = HRS_Calc_RollingPower(dTorque, 
                                     dSpeed, 
                                     dFlatRadius,
                                     &dRollingPower);

        if (nRet == ERR_FAILED)
        {
            return ERR_FAILED;
        }

        pAllPower->adStandPower[i] = dRollingPower;
    }

    return ERR_SUCCESS;

}


////////////////////////////////////////////////////////////////////////////////

// ���㾫��������ǰ��ϵ�� 
int HRS_FML2Calc_CalcAllForwardSlip(HRS_FM_ALL_DATA *pAllData,
                                    HRS_FM_DELIVERY_GAUGE *pAllDeliveryGauge,
                                    HRS_FM_TEMP *pAllTemp,
                                    HRS_FM_FORWARDSLIP *pAllForwardSlip)
{
    double dDraft;
    HRS_STAND_PARA *pEquipPara;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pEquipPara = &(pAllData->AllStandPara.aEquipPara[i+HRS_STAND_NO_FM1]);
        dDraft = pAllDeliveryGauge->adEntryGauge[i] - pAllDeliveryGauge->adDeliveryGauge[i];

        HRS_Calc_ForwardSlip(dDraft,
                             pEquipPara->dMaxWorkingRollerRadius,
                             pAllTemp->adTempPair[i].dEntryTemp,
                             pAllDeliveryGauge->adEntryGauge[i],
                             &pAllForwardSlip->adForwardSlip[i]);
    }

    return ERR_SUCCESS;
}

////////////////////////////////////////////////////////////////////////////////

// ���㾫������һ�����
int HRS_FML2Calc_CommSched(HRS_FM_ALL_DATA *pAllData,
                           HRS_FM_DELIVERY_GAUGE *pAllDeliveryGauge,
                           HRS_FM_TEMP *pAllTemp,
                           HRS_FM_CALC_COMM *pAllFmCommSched)
{
    int nRet;
    HRS_TABLE_FM_TENSION pFmTension;
    HRS_TABLE_FM_LOOPERDIS pFmLooperDis;
    HRS_STEEL_LEVEL *SteelLevel;

    SteelLevel = &pAllData->SteelLevel;

    // ����
    pFmTension.nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pFmTension.nQualityCode     = pAllData->PlanData.nQualityCode;
    pFmTension.nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pFmTension.nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pFmTension.nFinalTempLevel = SteelLevel->nFinalTempLevel;

    nRet = HRS_FmTensionTab_Search(&pFmTension, pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    pAllFmCommSched->adTension[0] = pFmTension.dSpecTension12;
    pAllFmCommSched->adTension[1] = pFmTension.dSpecTension23;
    pAllFmCommSched->adTension[2] = pFmTension.dSpecTension34;
    pAllFmCommSched->adTension[3] = pFmTension.dSpecTension45;
    pAllFmCommSched->adTension[4] = pFmTension.dSpecTension56;
    pAllFmCommSched->adTension[5] = pFmTension.dSpecTension67;
    pAllFmCommSched->adTension[6] = 0;

#if 0
    // ���׽Ƕ�
    pFMLooperAngle.nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pFMLooperAngle.nQualityCode     = pAllData->PlanData.nQualityCode;
    pFMLooperAngle.nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pFMLooperAngle.nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pFMLooperAngle.nFinalTempLevel = SteelLevel->nFinalTempLevel;

    nRet = HRS_FmLooperAngleTab_Search(&pFMLooperAngle, pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    pAllFmCommSched->adLooperAngle[0] = pFMLooperAngle.dAngleLooper12;
    pAllFmCommSched->adLooperAngle[1] = pFMLooperAngle.dAngleLooper23;
    pAllFmCommSched->adLooperAngle[2] = pFMLooperAngle.dAngleLooper34;
    pAllFmCommSched->adLooperAngle[3] = pFMLooperAngle.dAngleLooper45;
    pAllFmCommSched->adLooperAngle[4] = pFMLooperAngle.dAngleLooper56;
    pAllFmCommSched->adLooperAngle[5] = pFMLooperAngle.dAngleLooper67;
    pAllFmCommSched->adLooperAngle[6] = 0;
#endif

    // ����
    pFmLooperDis.nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pFmLooperDis.nQualityCode     = pAllData->PlanData.nQualityCode;
    pFmLooperDis.nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pFmLooperDis.nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pFmLooperDis.nFinalTempLevel = SteelLevel->nFinalTempLevel;

    nRet = HRS_FmLooperDisTab_Search(&pFmLooperDis, pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    pAllFmCommSched->adLooperDis[0] = pFmLooperDis.dLooperDis12;
    pAllFmCommSched->adLooperDis[1] = pFmLooperDis.dLooperDis23;
    pAllFmCommSched->adLooperDis[2] = pFmLooperDis.dLooperDis34;
    pAllFmCommSched->adLooperDis[3] = pFmLooperDis.dLooperDis45;
    pAllFmCommSched->adLooperDis[4] = pFmLooperDis.dLooperDis56;
    pAllFmCommSched->adLooperDis[5] = pFmLooperDis.dLooperDis67;
    pAllFmCommSched->adLooperDis[6] = 0;


    return ERR_SUCCESS;
}


//FM��̼��㣨�ſأ�
////////////////////////////////////////////////////////////////////////////////
//
// �������е�����
//
int HRS_FML2Calc_CalcAllData(HRS_FM_ALL_DATA *pAllData,
                             HRS_FM_ALL_OUT_DATA *pAllOutData)
{
    HRS_FM_DRAFTRATIO_QUERY_INFO    pDraftRatioQueryInfo;
    HRS_FM_DRAFT_RATIO              pDraftRatio;

    HRS_FM_DELIVERY_GAUGE_PARA      pGaugePara;
    HRS_FM_DELIVERY_GAUGE           pAllDeliveryGauge;

    HRS_FM_SPEED_PARA               pSpeedPara;
    HRS_FM_SPEED                    pAllSpeed;

    HRS_FM_TEMP_PARA                pTempPara;
    HRS_FM_TEMP                     pAllTemp;

    HRS_FM_ALL_ROLLFORCE            pAllRollForce;

    HRS_FM_GAP_PARA                 pAllGapPara;
    HRS_FM_GAP                      pAllGap;

    HRS_FM_TORQUE                   pAllTorque;

    HRS_FM_POWER                    pAllPower;

    HRS_FM_FORWARDSLIP              pAllForwardSlip;

    HRS_FM_CALC_COMM                pAllFmCommSched;

    int                             nRet;

    // ������ѯ�����ȼ���Ϣ
    nRet = HRS_FM_QuerySlabLevel(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����׼������
    nRet = HRS_FM_QueryDraftRatioTable_PrepPara(pAllData, &pDraftRatioQueryInfo);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����
    nRet = HRS_FM_QueryDraftRatioTable(&pDraftRatioQueryInfo, 
        &pDraftRatio,
        pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���������ں�ȼ��㺯��׼���������
    nRet = HRS_FML2Calc_PrepareGaugePara(pAllData, &pGaugePara);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���㾫�������ܳ��ں��
    nRet = HRS_FML2Calc_CalcGauge(&pGaugePara, &pAllDeliveryGauge,
        pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���������ٶȼ��㺯��׼���������
    nRet = HRS_FML2Calc_PrepareSpeedPara(pAllData, 
        &pAllDeliveryGauge, 
        &pSpeedPara);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���㾫�������������ٶ�
    nRet = HRS_FML2Calc_CalcSpeed(&pSpeedPara, &pAllSpeed);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_FML2Calc_CalcSpeed() error.");
        return ERR_FAILED;
    }

    // ��������¶ȼ��㺯��׼���������
    nRet = HRS_FML2Calc_PrepareTempPara(pAllData, &pTempPara);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���㾫�������ܳ�����¶� 
    nRet = HRS_FM_QueryL2Calc_CalcTemp(&pTempPara, 
        &pAllTemp, 
        pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // �������о������ܵ�������
    nRet = HRS_FML2Calc_AllRollingForce(pAllData, 
        &pAllDeliveryGauge, 
        &pAllTemp, 
        &pAllSpeed,  
        &pAllRollForce);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��������㺯��׼���������
    nRet = HRS_FML2Calc_PrepareGapPara(pAllData, 
        &pAllDeliveryGauge, 
        &pAllRollForce, 
        &pAllGapPara);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���㾫�������ܹ��� 
    nRet = HRS_FML2Calc_CalcAllGap(&pAllGapPara, &pAllGap);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_FML2Calc_CalcAllGap() error.");
        return ERR_FAILED;
    }

    // �������о������ܵ�Ť��
    nRet = HRS_FML2Calc_AllTorque(pAllData,  
        &pAllRollForce, 
        &pAllTorque);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_FML2Calc_AllTorque() error.");
        return ERR_FAILED;
    }

    // �������о������ܵĹ��� 
    nRet = HRS_FML2Calc_AllPower(pAllData, 
        &pAllSpeed, 
        &pAllRollForce,
        &pAllTorque, 
        &pAllPower);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_FML2Calc_AllPower() error.");
        return ERR_FAILED;
    }

    // ���㾫��������ǰ��ϵ�� 
    nRet = HRS_FML2Calc_CalcAllForwardSlip(pAllData, 
        &pAllDeliveryGauge, 
        &pAllTemp,
        &pAllForwardSlip);
    if (nRet == ERR_FAILED)
    {
        strcpy(pAllData->szOutErr, "HRS_FML2Calc_CalcAllForwardSlip() error.");
        return ERR_FAILED;
    }

    // ���㾫������һ����� 
    nRet = HRS_FML2Calc_CommSched(pAllData, 
        &pAllDeliveryGauge, 
        &pAllTemp,
        &pAllFmCommSched);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pAllOutData->aFMOutData[i].dDeliveryGauge   = pAllDeliveryGauge.adDeliveryGauge[i];
        pAllOutData->aFMOutData[i].dSpeed           = pAllSpeed.adSpeed[i];
        pAllOutData->aFMOutData[i].dTempPair        = pAllTemp.adTempPair[i];
        pAllOutData->aFMOutData[i].dRollingForce    = pAllRollForce.aStandRollForce[i].dRollForce;
        pAllOutData->aFMOutData[i].dGap             = pAllGap.adGap[i];
        pAllOutData->aFMOutData[i].dTorque          = pAllTorque.adStandTorque[i];
        pAllOutData->aFMOutData[i].dPower           = pAllPower.adStandPower[i];

        pAllOutData->aFMOutData[i].dEntryGauge      = pAllDeliveryGauge.adEntryGauge[i];
        pAllOutData->aFMOutData[i].dDraftRatio      = pAllDeliveryGauge.adActDraftRatio[i];
        pAllOutData->aFMOutData[i].dDeformResist    = pAllRollForce.aStandRollForce[i].dDeformResist;
        pAllOutData->aFMOutData[i].dGaugeRollForceFactor = pAllRollForce.aStandRollForce[i].dGaugeRollForceFactor;

        pAllOutData->aFMOutData[i].dTempForceFactor = pAllRollForce.aStandRollForce[i].dTempRollForceFactor;

        pAllOutData->aFMOutData[i].dForwardSlip     = pAllForwardSlip.adForwardSlip[i];

        pAllOutData->aFMOutData[i].dFlatRadius      = pAllRollForce.aStandRollForce[i].dFlatRadius;
        pAllOutData->aFMOutData[i].dQp              = pAllRollForce.aStandRollForce[i].dQp;

        pAllOutData->aFMOutData[i].dTension         = pAllFmCommSched.adTension[i];
        pAllOutData->aFMOutData[i].dLooperAngle    
            = pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i].dLooperTargetAngle; //pAllFmCommSched.adLooperAngle[i];
        pAllOutData->aFMOutData[i].dLooperTargetAngle    
            = pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i].dLooperTargetAngle; //pAllFmCommSched.adLooperAngle[i];
        pAllOutData->aFMOutData[i].dLooperWaitAngle    
            = pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i].dLooperWaitAngle; //pAllFmCommSched.adLooperAngle[i];
        pAllOutData->aFMOutData[i].dLooperDis       = pAllFmCommSched.adLooperDis[i];

        pAllOutData->aFMOutData[i].dModulus         = pAllGapPara.GapStandPara[i].dModulus;

        pAllOutData->aFMOutData[i].dWorkingRollerRadius = pAllRollForce.aStandRollForce[i].dWorkingRollerRadius;
        pAllOutData->aFMOutData[i].dZeroForce           = pAllGapPara.GapStandPara[i].dZeroForce;

        pAllOutData->aFMOutData[i].dFlow                = 0.0;
        pAllOutData->aFMOutData[i].dBend                = 0.0;
        pAllOutData->aFMOutData[i].dShift               = 0.0;

        //        pAllOutData->aFMOutData[i].dLooperWaitAngle     = 0.0;
        //        pAllOutData->aFMOutData[i].dLooperTargetAngle   = 0.0;
    }

    pAllOutData->SlabeData = pAllData->PlanData.SlabData;


    char *pszLogMsg = HRS_FML2Calc_BuildOutStr(pAllOutData);

    char szPath[512];
    NG_Path_GetRunPath(szPath, sizeof(szPath));

    strcat(szPath, "\\FMLog\\");

    _mkdir(szPath);

    strcat(szPath, HRS_FML2_CALC_LOG_FILE);

    error_log(szPath, pszLogMsg);

    NG_free(pszLogMsg);

    return ERR_SUCCESS;
}


int HRS_FML2Calc_BuildSched(HRS_FM_ALL_DATA *pAllData,
                            HRS_FM_ALL_OUT_DATA *pAllOutData,
                            HRS_FM_SCHED *pFMSched)
{
    HRS_FM_PRECALC_DATA *pFmStandSched;
    HRS_FM_STRATEGY_DATA *pFMStrategyData;

    strcpy(pFMSched->szPlateNo, pAllData->PlanData.SlabData.szStripNo);
    strcpy(pFMSched->szSteelGrade, pAllData->PlanData.SlabData.szGrade);

    pFMStrategyData = &(pAllData->FMStrategyData);

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pFmStandSched = &pFMSched->PreCalcDataF[i];

        pFmStandSched->fEntryGauge      = pAllOutData->aFMOutData[i].dEntryGauge;
        pFmStandSched->fDeliveryGauge   = pAllOutData->aFMOutData[i].dDeliveryGauge;
        pFmStandSched->fEntryWidth      = pFMStrategyData->FMStraData.dTransferBarWidth;
        pFmStandSched->fDeliveryWidth   = pFMStrategyData->FMStraData.dTransferBarWidth;
        pFmStandSched->fDraftRatio      = pAllOutData->aFMOutData[i].dDraftRatio;
        pFmStandSched->fRollingForce    = pAllOutData->aFMOutData[i].dRollingForce;
        pFmStandSched->fGap             = pAllOutData->aFMOutData[i].dGap;
        pFmStandSched->fTorque          = pAllOutData->aFMOutData[i].dTorque;
        pFmStandSched->fPower           = pAllOutData->aFMOutData[i].dPower;
        pFmStandSched->fDeformResist    = pAllOutData->aFMOutData[i].dDeformResist;
        pFmStandSched->fFlatRadius      = pAllOutData->aFMOutData[i].dFlatRadius;
        pFmStandSched->fQp              = pAllOutData->aFMOutData[i].dQp;
        pFmStandSched->fSpeed           = pAllOutData->aFMOutData[i].dSpeed;
        pFmStandSched->fFlow            = 0;
        pFmStandSched->fEnterTemp       = pAllOutData->aFMOutData[i].dTempPair.dEntryTemp;
        pFmStandSched->fDeliveryTemp    = pAllOutData->aFMOutData[i].dTempPair.dDeliveryTemp;
        pFmStandSched->fBend            = 0;
        pFmStandSched->fShift           = 0;
        pFmStandSched->fForwardSlip     = pAllOutData->aFMOutData[i].dForwardSlip;

        pFmStandSched->fTension         = pAllOutData->aFMOutData[i].dTension;
        pFmStandSched->fLooperAngle     = pAllOutData->aFMOutData[i].dLooperAngle;
        pFmStandSched->fLooperDis       = pAllOutData->aFMOutData[i].dLooperDis;

        pFmStandSched->fGaugeRollForceFactor = pAllOutData->aFMOutData[i].dGaugeRollForceFactor;
        pFmStandSched->fTempRollForceFactor  = pAllOutData->aFMOutData[i].dTempForceFactor;

        pFmStandSched->fLooperWaitAngle    = 
            pAllOutData->aFMOutData[i].dLooperWaitAngle;   //10.0;  // ���׳�ʼ�ȴ��Ƕ�
        pFmStandSched->fLooperTargetAngle  = 
            pAllOutData->aFMOutData[i].dLooperTargetAngle; // 60.0;  // 60��
        pFmStandSched->fLowerLooperRestLen = 8.0;   // 8�׳�

        pFmStandSched->fSetupLooperLen     = 
            pAllData->AllStandPara.aEquipPara[HRS_STAND_NO_FM1+i].dSetupLooperLen;    //0.01;  // ȱʡ10ms ��Ҫ���...

        pFmStandSched->fModulus = pAllOutData->aFMOutData[i].dModulus;

        pFmStandSched->fWorkingRollerRadius = pAllOutData->aFMOutData[i].dWorkingRollerRadius;

        pFmStandSched->fZeroForce = pAllOutData->aFMOutData[i].dZeroForce;
    }

    pFMSched->szOutErr[0] = '\0';

    if ( pAllData->szOutErr[0] != '\0')
    {
        strcpy(pFMSched->szOutErr, pAllData->szOutErr);
    }


    return ERR_SUCCESS;
}


int HRS_FML2Calc_BuildStandOutStr(HRS_FM_STAND_OUT_DATA *pStandOut, 
                                  char *pszOut, int nOutLen)
{
    char szMsg[1024];

    pszOut[0] = '\0';

    sprintf(szMsg, "dDeliveryGauge    : %f\r\n", pStandOut->dDeliveryGauge);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dSpeed            : %f\r\n", pStandOut->dSpeed);
    strcat(pszOut, szMsg);

    sprintf(szMsg, "dEntryTemp        : %f\r\n", pStandOut->dTempPair.dEntryTemp);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dDeliveryTemp     : %f\r\n", pStandOut->dTempPair.dDeliveryTemp);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dRollingForce     : %f\r\n", pStandOut->dRollingForce);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dGap              : %f\r\n", pStandOut->dGap);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dTorque           : %f\r\n", pStandOut->dTorque);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dPower            : %f\r\n", pStandOut->dPower);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dTension          : %f\r\n", pStandOut->dTension);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dLooperAngle      : %f\r\n", pStandOut->dLooperAngle);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dLooperDis        : %f\r\n", pStandOut->dLooperDis);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dEntryGauge       : %f\r\n", pStandOut->dEntryGauge);
    strcat(pszOut, szMsg);

    sprintf(szMsg, "dDraftRatio       : %f\r\n", pStandOut->dDraftRatio);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dDeformResist     : %f\r\n", pStandOut->dDeformResist);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dFlow             : %f\r\n", pStandOut->dFlow);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dBend             : %f\r\n", pStandOut->dBend);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dShift            : %f\r\n", pStandOut->dShift);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dForwardSlip      : %f\r\n", pStandOut->dForwardSlip);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dLooperWaitAngle  : %f\r\n", pStandOut->dLooperWaitAngle);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dLooperTargetAngle: %f\r\n", pStandOut->dLooperTargetAngle);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dFlatRadius       : %f\r\n", pStandOut->dFlatRadius);
    strcat(pszOut, szMsg);

    sprintf(szMsg, "dQp                  : %f\r\n", pStandOut->dQp);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dGaugeRollForceFactor: %f\r\n", pStandOut->dGaugeRollForceFactor);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dTempForceFactor     : %f\r\n", pStandOut->dTempForceFactor);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dModulus             : %f\r\n", pStandOut->dModulus);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dWorkingRollerRadius : %f\r\n", pStandOut->dWorkingRollerRadius);
    strcat(pszOut, szMsg);
    sprintf(szMsg, "dZeroForce           : %f\r\n", pStandOut->dZeroForce);
    strcat(pszOut, szMsg);

    return ERR_SUCCESS;
}


char *HRS_FML2Calc_BuildOutStr(HRS_FM_ALL_OUT_DATA *pAllOutData)
{
    char *pszMsg;
    char szMsg[2048];
    char szOut[4096];
    int  i;

    int  nTotalLen = 65536;

    pszMsg = (char *)NG_malloc(nTotalLen);
    if ( pszMsg == NULL )
    {
        return NULL;
    }

    pszMsg[0] = '\0';

    HRS_SLAB_DATA  *pSlabData;

    pSlabData = &(pAllOutData->SlabeData);

    NG_TIME  ng_time;
    NGTime_GetLocalTimeMs(&ng_time);

    NGTime_ToSecondStr(&ng_time, NULL, szOut, sizeof(szOut)-1);

    double dBarGauge;

    dBarGauge = pAllOutData->aFMOutData[0].dEntryGauge;

    sprintf(szMsg,
        "------------------------- %s -----------------FML2Calc--------------------------\r\n"
        "szGrade            : %s\r\n"
        "szSteelGradeName   : %s\r\n"
        "szStripNo          : %s\r\n"
        "nSteelGradeNode    : %d\r\n"
        "dSlabWidth         : %f\r\n"
        "dSlabGauge         : %f\r\n"
        "dTransferBarGauge  : %f\r\n"
        "dSlabLen           : %f\r\n\r\n",
        szOut,
        pSlabData->szGrade,
        pSlabData->szSteelGradeName,
        pSlabData->szStripNo,
        pSlabData->nSteelGradeCode,
        pSlabData->dSlabWidth,
        pSlabData->dSlabGauge,
        dBarGauge,
        pSlabData->dSlabLen);

    strcpy(pszMsg, szMsg);


    for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        sprintf(szMsg, "!!! FM Stand: %d \r\n", i+1);
        strcat(pszMsg, szMsg);

        HRS_FML2Calc_BuildStandOutStr(&(pAllOutData->aFMOutData[i]), 
            szOut, sizeof(szOut)-1);

        strcat(szOut, "\r\n");

        strcat(pszMsg, szOut);
    }

    strcat(pszMsg, "\r\n\r\n");

    return pszMsg;
}

