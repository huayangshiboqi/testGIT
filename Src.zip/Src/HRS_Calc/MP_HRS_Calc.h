/* 
 *	FILE
 *      c:\svn_Company\HotContinuousRoll\Src\HRS_Calc
 *
 *	DESCRIPTION
 *      ������ģ��ϵͳԶ�̼�����ù����ṩģ��		
 *
 *	HISTORY
 *		2016-10-11 17:48 create by zhouweiming.
 *
 */
#ifndef __MP_HRS_Calc_H__
#define __MP_HRS_Calc_H__


#ifdef __cplusplus
extern "C" {
#endif


/** Method: MP_CalcRollerWear

    @param HANDLE hRemoteHandle - Զ�̵��þ����ΪNULLʱΪ���ص��ã�
    @param void * pData -       - ����ĥ���������
    @param int nLen             - pData��Ӧ�����ݳ���

    @return: int -                 ����ֵ
*/
int MP_HRS_RML2Calc_CalcGap(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_RML2Calc_CalcRollingForce(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_RML2Calc_CalcSpeed(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_RML2Calc_CalcTemp(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_RML2Calc_CalcThick(HANDLE hRemoteHandle,void *pData,int nLen);

int MP_HRS_FML2Calc_CalcGap(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_FML2Calc_CalcRollingForce(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_FML2Calc_CalcSpeed(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_FM_QueryL2Calc_CalcTemp(HANDLE hRemoteHandle,void *pData,int nLen);
int MP_HRS_FML2Calc_CalcThick(HANDLE hRemoteHandle,void *pData,int nLen);


#ifdef __cplusplus
}
#endif



#endif // __MP_HRS_Calc_H__
