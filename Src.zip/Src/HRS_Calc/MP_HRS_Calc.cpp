
#include "NG.h"
#include "HRS_RMCalc.h"
#include "HRS_FMCalc.h"
#include "MP_HRS_Calc.h"
#include "MP_RemoteCall.h"

int MP_HRS_RML2Calc_CalcGap(HANDLE hRemoteHandle,void *pData,int nLen)
{
    char data[128] = "This is server";

    MP_RemoteCall_SetRetData(hRemoteHandle, data, 128);

    return ERR_SUCCESS;
}


int MP_HRS_RML2Calc_CalcRollingForce(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_RML2Calc_CalcSpeed(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_RML2Calc_CalcTemp(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_RML2Calc_CalcThick(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_FML2Calc_CalcGap(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_FML2Calc_CalcRollingForce(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_FML2Calc_CalcSpeed(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_FM_QueryL2Calc_CalcTemp(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}


int MP_HRS_FML2Calc_CalcThick(HANDLE hRemoteHandle,void *pData,int nLen)
{
    return ERR_SUCCESS;
}

