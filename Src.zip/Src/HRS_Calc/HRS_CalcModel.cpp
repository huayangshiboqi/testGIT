
#include "NG.h"
#include "NG_String.h"
#include "StrParse.h"
#include "CfgAPI.h"
#include "HRS_CalcModel.h"

void HRS_CalcFuncNode_Destroy(HRS_CALC_FUNC_NODE *pNode);

HRS_CALC_FUNC_NODE * HRS_CalcFuncNode_Create()
{
    HRS_CALC_FUNC_NODE *pNode;

    pNode = (HRS_CALC_FUNC_NODE *)NG_malloc(sizeof(HRS_CALC_FUNC_NODE));
    if (pNode == NULL)
    {
        return NULL;
    }

    pNode->pszFuncName = NULL;
    pNode->calc_func   = NULL;
    pNode->nFuncId     = -1;
    pNode->nParaLen    = 0;

    return pNode;
}


void HRS_CalcFuncNode_Destroy(HRS_CALC_FUNC_NODE *pNode)
{
    if (pNode != NULL)
    {
        if (pNode->pszFuncName != NULL)
        {
            NG_free(pNode->pszFuncName);
        }

        NG_free(pNode);
    }

    return;
}

#if 0
�����ļ���ʽ��

    [AllFuncs]
    # FuncId = FuncName, nParaLen
       0 = Calc1, 16
       1 = Calc2, 32
       ...

#endif

#define  HRS_CALC_SECTION_ALL_FUNCS   "AllFuncs"


/** Method:    HRS_CalcModel_ParseKey
    ���������ļ���ʽ 
    �������ΪHRS_CALC_FUNC_NODE

    @param APPKEY * pAppKey - Ҫ���͵�APPKEY
    
    @return HRS_CALC_FUNC_NODE * - �ɹ�����HRS_CALC_FUNC_NODEָ�룬ʧ�ܷ���NULL
*/
HRS_CALC_FUNC_NODE *HRS_CalcModel_ParseKey(APPKEY *pAppKey)
{
    HRS_CALC_FUNC_NODE *pNode;
    int nFuncId;
    char *pszFuncName;
    int nParaLen;

    DARRAY *pArray;

    if ( pAppKey == NULL )
    {
        return NULL;
    }

    nFuncId = atoi(pAppKey->key_name);

    pArray = ParseStrArray(pAppKey->key_value, ", \t");
    if (pArray == NULL)
    {
        return NULL;
    }
    if (pArray->nDataCount != 2)
    {
        return NULL;
    }


    pszFuncName = (char *)DArray_GetAt(pArray, 0);
    char *pszPara = (char *)DArray_GetAt(pArray, 1);

    nParaLen = atoi(pszPara);

    pNode = HRS_CalcFuncNode_Create();

    pNode->calc_func = NULL;
    pNode->nFuncId = nFuncId;
    pNode->nParaLen = nParaLen;
    pNode->pszFuncName = StrCopy(pszFuncName);

    DArray_Destroy(pArray);

    return pNode;
}



/** Method:    HRS_CalcModel_ReadDataToModel
    �������ļ����е���Ϣ��������ģ���� 

    @param APPSECTION * pSection - �����ļ��еĶ�
    @param HRS_CALC_MODEL * pModel - ����ģ��ָ��
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
static int HRS_CalcModel_ReadDataToModel(APPSECTION *pSection, HRS_CALC_MODEL *pModel)
{
    HRS_CALC_FUNC_NODE *pNode;
    HRS_CALC_FUNC_NODE *pFindNode;
    APPKEY             *pAppKey;

    if (pSection == NULL || pModel == NULL)
    {
        return ERR_FAILED;
    }

    AppSection_SearchStart(pSection);

    for (;;)
    {
        pAppKey = AppSection_SearchNext(pSection);
        if (pAppKey == NULL)
        {
            break;
        }
        
        pNode = HRS_CalcModel_ParseKey(pAppKey);
        if (pNode == NULL)
        {
            return ERR_FAILED;
        }
        
        pFindNode = (HRS_CALC_FUNC_NODE *)DArray_GetAt(pModel->pCalcFuncNodeArray, 
                                                       pNode->nFuncId);
        if (pFindNode == NULL)
        {
            return ERR_FAILED;
        }

        DArray_InsertAt(pModel->pCalcFuncNodeArray, pNode, pNode->nFuncId);
    }

    return ERR_SUCCESS;
}



/** Method:    HRS_CalcModel_Create
    ��������ģ�ͽṹ�� 

    
    @return HRS_CALC_MODEL * - �ɹ����ؼ���ģ�ͽṹ��ָ�룬ʧ�ܷ���NULL
*/
HRS_CALC_MODEL *HRS_CalcModel_Create()
{
    HRS_CALC_MODEL  *pModel;

    pModel = (HRS_CALC_MODEL *)NG_malloc(sizeof(HRS_CALC_MODEL));
    if (pModel == NULL)
    {
        return NULL;
    }

    memset(pModel, 0, sizeof(HRS_CALC_MODEL));

    pModel->pCalcFuncNodeArray = DArray_Create(256, 
        (DESTROYFUNC)HRS_CalcFuncNode_Destroy, NULL, NULL);
    if (pModel->pCalcFuncNodeArray == NULL)
    {
        NG_free(pModel);

        return NULL;
    }
    pModel->pszCfgFile = NULL;

    return pModel;
}


/** Method:    HRS_CalcModel_Load
    �������ļ���װ��һ������ģ��ģ�� 
    �����ļ�����Ҫ�������ģ������У��Ĳ���������Ϣ�����⻹�к���������Ϣ

    @param char * pszCfgFile - �����ļ�
    
    @return HRS_CALC_MODEL * - �ɹ�����ģ��ָ�룬 ʧ�ܷ���NULL
*/
HRS_CALC_MODEL *HRS_CalcModel_Load(char *pszCfgFile)
{
    HRS_CALC_MODEL  *pModel;

    APPCONF    *pAppConf;
    APPSECTION *pSection;

    pModel = NULL;

    pAppConf = AppConf_LoadFromFile(pszCfgFile);
    if (pAppConf == NULL)
    {
        return NULL;
    }

    pSection = AppConf_FindSection(pAppConf, HRS_CALC_SECTION_ALL_FUNCS);
    if (pSection == NULL)
    {
        goto Label_HRS_CalcModel_Create;
    }

    pModel = HRS_CalcModel_Create();
    if (pModel == NULL)
    {
        goto Label_HRS_CalcModel_Create;
    }


    int nRet = HRS_CalcModel_ReadDataToModel(pSection, pModel);

    if (nRet == ERR_FAILED)
    {
        goto Label_HRS_CalcModel_Create;
    }

    pModel->pszCfgFile = StrCopy(pszCfgFile);

    return pModel;

Label_HRS_CalcModel_Create:
    if (pAppConf != NULL)
    {
        AppConf_Destroy(pAppConf);
    }

    if (pModel != NULL)
    {
        HRS_CalcModel_Destroy(pModel);
    }

    return NULL;
}


int HRS_CalcModel_SaveToFile(HRS_CALC_MODEL *pModel, char *pszCfgFile)
{
    APPCONF    *pAppConf;
    APPSECTION *pSection;
    APPKEY     *pAppKey;

    HRS_CALC_FUNC_NODE *pNode;

    if (pModel == NULL || pszCfgFile == NULL || pszCfgFile[0] == '\0')
    {
        return ERR_FAILED;
    }

    pAppConf = AppConf_New();

    pSection = AppSection_New();

    pSection->section_name = StrCopy(HRS_CALC_SECTION_ALL_FUNCS);

    AppConf_AddSection(pAppConf, pSection);


    DArray_EnumBegin(pModel->pCalcFuncNodeArray);

    for (;;)
    {
        pNode = (HRS_CALC_FUNC_NODE *)DArray_EnumNext(pModel->pCalcFuncNodeArray);
        if (pNode == NULL)
        {
            break;
        }

        pAppKey = AppKey_New();

        char szId[32];
        memset(szId, 0, sizeof(szId));
        itoa(pNode->nFuncId, szId, 10);
        pAppKey->key_name = StrCopy(szId);

        char szTemp[512];
        sprintf(szTemp, "%s, %d", pNode->pszFuncName, pNode->nParaLen);
        pAppKey->key_value = StrCopy(szTemp);

        AppSection_AddAppKey(pSection, pAppKey);
    }

    int nRet = AppConf_ShadowInFile(pAppConf, pszCfgFile);

    return nRet;
}


/** Method:    HRS_CalcModel_Destroy
    �ͷż���ģ��ָ�� 

    @param HRS_CALC_MODEL * pCalcModel - ����ģ��ָ��
    
    @return void - ��
*/
void HRS_CalcModel_Destroy(HRS_CALC_MODEL *pCalcModel)
{
    if (pCalcModel == NULL)
    {
        return;
    }

    DArray_Destroy(pCalcModel->pCalcFuncNodeArray);

    NG_free(pCalcModel->pszCfgFile);

    NG_free(pCalcModel);

    return;
}


/** Method:    HRS_CalcModel_RegFuncPair
    �����ģ����ע��һ�����㺯�� 

    @param HRS_CALC_MODEL * pModel - ����ģ��ָ��
    @param int nFuncId - ����ID (��0��ʼ���α��)
    @param HRS_CALC_FUNC calc_func - ���㺯��ָ��
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_CalcModel_RegFuncPair(HRS_CALC_MODEL *pModel, 
                              int nFuncId, 
                              HRS_CALC_FUNC calc_func)
{
    HRS_CALC_FUNC_NODE *pNode;

    if (pModel == NULL || nFuncId < 0 || calc_func == NULL)
    {
        return ERR_FAILED;
    }

    pNode = (HRS_CALC_FUNC_NODE *)DArray_GetAt(pModel->pCalcFuncNodeArray, 
                                               nFuncId);
    if (pNode == NULL)
    {
        return ERR_FAILED;
    }

    pNode->calc_func = calc_func;

    return ERR_SUCCESS;
}


/** Method:    HRS_CalcModel_RegCalcFunc
    ע����㺯����Ϣ 

    @param HRS_CALC_MODEL * pModel - ����ģ��ָ��
    @param char * pszFuncName - ��������
    @param int nFuncId - ����ID(��0��ʼ���α��)
    @param int nParaLen - ��������
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_CalcModel_RegCalcFunc(HRS_CALC_MODEL *pModel, 
                              char *pszFuncName, int nFuncId, 
                              int nParaLen)
{
    HRS_CALC_FUNC_NODE *pNode;

    if (pModel == NULL || pszFuncName == NULL || pszFuncName[0] == '\0')
    {
        return ERR_FAILED;
    }

    pNode = (HRS_CALC_FUNC_NODE *)DArray_GetAt(pModel->pCalcFuncNodeArray, nFuncId);
    if (pNode != NULL)
    {
        return ERR_FAILED;
    }

    pNode = HRS_CalcFuncNode_Create();

    pNode->nFuncId = nFuncId;
    pNode->nParaLen = nParaLen;
    pNode->pszFuncName = StrCopy(pszFuncName);
    pNode->calc_func = NULL;

    DArray_InsertAt(pModel->pCalcFuncNodeArray, pNode, nFuncId);

    return ERR_SUCCESS;
}


/** Method:    HRS_CalcModel_DelCalcFunc
    �Ӽ���ģ����ɾ��һ�����㺯�� 

    @param HRS_CALC_MODEL * pModel - ����ģ��ָ��
    @param int nFuncId - ����ID(��0��ʼ���α��)
    
    @return int - ERR_FAILED, ERR_SUCCESS
*/
int HRS_CalcModel_DelCalcFunc(HRS_CALC_MODEL *pModel, int nFuncId)
{
    HRS_CALC_FUNC_NODE *pNode;
    if (pModel == NULL)
    {
        return ERR_FAILED;
    }

    if (nFuncId > pModel->pCalcFuncNodeArray->nCurBound 
        || nFuncId < 0 )
    {
        return ERR_FAILED;
    }

    pNode = (HRS_CALC_FUNC_NODE *)DArray_GetAt(pModel->pCalcFuncNodeArray, 
                                               nFuncId);
    if (pNode == NULL)
    {
        return ERR_FAILED;
    }

    DArray_RemoveAt(pModel->pCalcFuncNodeArray, nFuncId);

    return ERR_SUCCESS;
}


/** Method:    HRS_CalcModel_GetCalcFuncNode
    �Ӽ���ģ���л�ȡ���㺯���ڵ� 

    @param HRS_CALC_MODEL * pModel - ����ģ��ָ��
    @param int nFuncId - ����ID(��0��ʼ���α��)
    
    @return HRS_CALC_FUNC_NODE * - �ɹ����ؼ��㺯���ڵ�ָ�룬ʧ�ܷ���NULL
*/
HRS_CALC_FUNC_NODE * HRS_CalcModel_GetCalcFuncNode(HRS_CALC_MODEL *pModel, 
                                                   int nFuncId)
{
    HRS_CALC_FUNC_NODE *pNode;
    if (pModel == NULL)
    {
        return NULL;
    }

    if (nFuncId > pModel->pCalcFuncNodeArray->nCurBound 
        || nFuncId < 0 )
    {
        return NULL;
    }

    pNode = (HRS_CALC_FUNC_NODE *)DArray_GetAt(pModel->pCalcFuncNodeArray, 
                                               nFuncId);

    return pNode;
}
