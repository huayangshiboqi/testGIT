// ViewRollSchem.cpp : ʵ���ļ�
//

#include "stdafx.h"

#include "WinCommon.h "
#include "NG_errno.h" 
#include "NG_malloc.h"

#include "HRSGui.h"
#include "ViewRollSchem.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "GridCtrlFunc.h"

// CViewRollSchem

IMPLEMENT_DYNCREATE(CViewRollSchem, CFormView)

CViewRollSchem::CViewRollSchem()
    : CFormView(CViewRollSchem::IDD)
    , m_strSearchNo(_T(""))
{
    //m_pRollSchedMgr = new CPceDataMgr;
    m_nInitPDIGrid  = ERR_FAILED;
    m_pRollSchedMgr = NULL;
}

CViewRollSchem::~CViewRollSchem()
{
    /*
    *  �ͷŻ�ˢ
    */
    m_CBrushDlgBG.DeleteObject();
    m_CBrushEditBG.DeleteObject();


    if (m_pRollSchedMgr != NULL)
    {
        //delete m_pRollSchedMgr;
    }
}

void CViewRollSchem::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_GridControl(pDX, IDC_GRIDCTRL_ROLLSCHEM, m_GridRollSchem);
    DDX_Text(pDX, IDC_EDIT_SC_STRIPNO_SEARCH, m_strSearchNo);
}

BEGIN_MESSAGE_MAP(CViewRollSchem, CFormView)
    ON_WM_CTLCOLOR()
    ON_WM_SIZE()

    ON_BN_CLICKED(IDC_BUT_SC_ADD, &CViewRollSchem::OnBnClickedButScAdd)
    ON_BN_CLICKED(IDC_BUT_SC_DEL, &CViewRollSchem::OnBnClickedButScDel)
    ON_BN_CLICKED(IDC_BUT_SC_IMPORT, &CViewRollSchem::OnBnClickedButScImport)
    ON_BN_CLICKED(IDC_BUT_SC_SAVE, &CViewRollSchem::OnBnClickedButScExport)

    ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRIDCTRL_ROLLSCHEM, OnGridEndLableEdit)
    ON_NOTIFY(NM_CLICK, IDC_GRIDCTRL_ROLLSCHEM, OnGridClick)
    ON_BN_CLICKED(IDC_BUT_SC_MOVEUP, &CViewRollSchem::OnBnClickedButScMoveup)
    ON_BN_CLICKED(IDC_BUT_SC_MOVEDOWN, &CViewRollSchem::OnBnClickedButScMovedown)
    ON_BN_CLICKED(IDC_BUT_SC_SEARCH, &CViewRollSchem::OnBnClickedButScSearch)
    ON_BN_CLICKED(IDC_BUT_SAVE_TOMEM, &CViewRollSchem::OnBnClickedButSaveFile)
END_MESSAGE_MAP()


// CViewRollSchem ���

#ifdef _DEBUG
void CViewRollSchem::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewRollSchem::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewRollSchem ��Ϣ��������

void CViewRollSchem::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    /*
    *  ��ʼ�����滭ˢ
    */
    //m_CBrushDlgBG.CreateSolidBrush(IF_BG_COR);
    //m_CBrushEditBG.CreateSolidBrush(EDIT_BG_COR);

    GridCtrlInit();

    return;
}


void CViewRollSchem::GridCtrlInit()
{
    
    int                 iCol; 
    int                 iColNumber;  
    

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRollSchem.SetListMode(TRUE);
        m_GridRollSchem.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRollSchem.SetModified(FALSE);

        m_GridRollSchem.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRollSchem.SetFixedRowCount(1);
        m_GridRollSchem.SetFixedColumnCount(1); 
        m_GridRollSchem.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    int anPDIWidth[HRS_ROLL_SCHED_ITEM_NUM] = {
        50, 105, 70, 75, 60, 
        70, 70, 45, 70, 45, 
        70, 70, 70, 70, 75, 
        60, 60, 60, 60, 55, 
        55, 40, 40, 40, 70
    };

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        ////����ǵȴ�����(�Ƶס�����)
        //Item.crBkClr = PINK_COR;
        //Item.crFgClr = BLACK_COR;

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridRollSchem.SetItem(&Item);

        m_GridRollSchem.SetColumnWidth(iCol, anPDIWidth[iCol]);

    }

//    m_GridRollSchem.AutoSize();

    return;
}


void CViewRollSchem::OnBnClickedButScAdd()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    char strHeading[5]={0};
    int  RowCount;

    RowCount = m_GridRollSchem.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRollSchem.InsertRow(strHeading);

    m_pRollSchedMgr->AddRollSchedItem();


    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

    m_GridRollSchem.SetSelectedRange(RowCount, 1, RowCount, 
                                     HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridRollSchem.ScrollToRow(RowCount);

    theApp.m_nPDIRow = RowCount;

    return;
}

#if 0
/** Method: Win_GetSaveFileName
    ��ʾ���ļ��Ի�������ȡ�򿪵��ļ��� 

    @param char * pszFileNameBuf - [out] ��ȡѡ��Ĵ��ļ����ƣ�����·������
    @param int nBufLen - pszFileNameBuf�Ļ���������
    @param char * pszTitle - ���ļ��Ի���ı���
    @param char * pszInitDir - Ҫ���ļ��ĳ�ʼ·������ʼ·���Ǵ򿪶Ի����ȱʡ·��
    @param char * pszFilterComment1 - �ļ�����1��ע���ı� ��: "All Files(*.*)", "Text Files(*.txt)"��
    @param char * pszFilter1 - �ļ�����1�Ĺ�����  �磺"*.*", "*.txt"��
    @param char * pszFilterComment2 - �ļ�����2��ע���ı�
    @param char * pszFilter2 - �ļ�����2�Ĺ�����
    @param HWND hWndParent - �����ھ��

    @return:  int - ERR_FAILED, ERR_SUCCESS
*/
int Win_GetOpenFileName(char *pszFileNameBuf, int nBufLen, 
                        char *pszTitle, char *pszInitDir,
                        char *pszFilterComment1, char *pszFilter1,
                        char *pszFilterComment2, char *pszFilter2,
                        HWND hWndParent)
{
    OPENFILENAME  Ofn;
    char *pszFilter;
    char szFileTitle[MAX_PATH];
   

    int nLen;
    int nLen2;

    pszFileNameBuf[0] = '\0';

    nLen = 0;
    if ( pszFilterComment1 != NULL )
    {
        nLen += (int)strlen(pszFilterComment1);

        if (pszFilter1 != NULL )
        {
            nLen += (int)strlen(pszFilter1);
        }
        else
        {
            return ERR_FAILED;
        }
    }

    if ( pszFilterComment2 != NULL )
    {
        nLen += (int)strlen(pszFilterComment2);

        if (pszFilter2 != NULL )
        {
            nLen += (int)strlen(pszFilter2);
        }
        else
        {
            return ERR_FAILED;
        }
    }

    nLen += 32;  // ���һЩ����ռ䣬��ȷ����������ȫ�����

    pszFilter = (char *)NG_malloc(nLen);
    if ( pszFilter == NULL )
    {
        return ERR_FAILED;
    }

    nLen = 0;
    if (pszFilterComment1 != NULL )
    {
        strcpy(pszFilter, pszFilterComment1);

        nLen = (int)strlen(pszFilterComment1);

        *(pszFilter + nLen) = '\0';

        nLen += 1;

        nLen2 = (int)strlen(pszFilter1);
        memcpy(pszFilter + nLen, pszFilter1, nLen2);

        nLen += nLen2;

        *(pszFilter + nLen) = '\0';

        nLen += 1;
    }

    if ( pszFilterComment2 != NULL )
    {
        nLen2 = (int)strlen(pszFilterComment2);

        memcpy(pszFilter + nLen, pszFilterComment2, nLen2);

        nLen += nLen2;

        *(pszFilter + nLen) = '\0';

        nLen += 1;

        nLen2 = (int)strlen(pszFilter2);

        memcpy(pszFilter + nLen, pszFilter2, nLen2);

        nLen += nLen2;

        *(pszFilter + nLen) = '\0';

        nLen += 1;
    }

    *(pszFilter + nLen) = '\0';


    strcpy(szFileTitle, "File Title");

    memset(&Ofn, 0, sizeof(Ofn));
    Ofn.lStructSize = sizeof(OPENFILENAME); 
    Ofn.hwndOwner = hWndParent; 
    Ofn.lpstrFilter = pszFilter; 
    Ofn.lpstrFile= pszFileNameBuf; 
    Ofn.nMaxFile = nBufLen; 
    Ofn.lpstrFileTitle = szFileTitle; 
    Ofn.nMaxFileTitle = sizeof(szFileTitle); 
    Ofn.lpstrInitialDir = (LPSTR)pszInitDir; 
    Ofn.Flags = OFN_SHOWHELP | OFN_OVERWRITEPROMPT; 
    Ofn.lpstrTitle = pszTitle; 

    // Display the Filename common dialog box. The 
    // filename specified by the user is passed 
    // to the CreateEnhMetaFile function and used to 
    // store the metafile on disk. 
    BOOL bRet =  GetOpenFileName(&Ofn);

    if ( !bRet )
    {
        NG_free(pszFilter);
        return ERR_FAILED;
    }

    NG_free(pszFilter);

    int nFixFlag;
    if ( Ofn.nFilterIndex == 1 )
    {
        nFixFlag = 1;

        char *psz = strchr(pszFileNameBuf, '.');
        if ( psz != NULL )
        {
            if ( stricmp(psz, pszFilter1+1 ) == 0 
                || stricmp(pszFilter1, "*.*") == 0 )
            {
                // ���ô���
                nFixFlag = 0;
            }
        }

        if ( nFixFlag )
        {
            strcat(pszFileNameBuf, pszFilter1 + 1);
        }
    }
    else if ( Ofn.nFilterIndex == 2 )
    {
        nFixFlag = 1;

        char *psz = strchr(pszFileNameBuf, '.');
        if ( psz != NULL )
        {
            if ( stricmp(psz, pszFilter2+1 ) == 0 
                || stricmp(pszFilter2, "*.*") == 0 )
            {
                // ���ô���
                nFixFlag = 0;
            }
        }

        if ( nFixFlag )
        {
            strcat(pszFileNameBuf, pszFilter2 + 1);
        }
    }

    return ERR_SUCCESS;
}
#endif

void CViewRollSchem::OnBnClickedButScDel()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    CCellID CurCell;
    int nRow;
    int nCol;

    CurCell = m_GridRollSchem.GetFocusCell();
    nRow = CurCell.row;
    nCol = CurCell.col;
    //
    int nReturn =  AfxMessageBox("ȷ��ɾ�����ݣ�",
        MB_OKCANCEL | MB_ICONQUESTION);

    if(MB_ICONQUESTION == nReturn)
    {
        return;
    }

    m_pRollSchedMgr->DeleteRollSchedItem(nRow);

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(nRow, nCol);
    m_GridRollSchem.SetSelectedRange(nRow,1,nRow,HRS_ROLL_SCHED_ITEM_NUM-1);

    theApp.m_nPDIRow = nRow;
}


void CViewRollSchem::RefeshRollSchemTab()
{
    MTLIST *pRollSchedList  = NULL;
    int     nRollSchedCount = 0;
    CString    strStipNo;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    if (NULL == pRollSchedList)
    {
        return;
    }

    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);
    if (nRollSchedCount > 0 && nRollSchedCount <= GRID_ROW_MAX)
    {
        GetDlgItem(IDC_BUT_SC_DEL)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_SAVE)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_MOVEUP)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_MOVEDOWN)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_SEARCH)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SAVE_TOMEM)->EnableWindow(TRUE);
    }
    else if(nRollSchedCount <= 0)
    {
        m_GridRollSchem.DeleteNonFixedRows();

        AfxMessageBox("������ĿΪ0��");
        return;
    }
    else
    {
        AfxMessageBox("������Ŀ���ޣ�");
    }
    
    int nScrollPos = m_GridRollSchem.GetScrollPos(SB_VERT);

    m_GridRollSchem.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA *pPceData;

        RowCount = m_GridRollSchem.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *)DoubleList_GetAt(pRollSchedList->pList,i);
        if (NULL == pPceData)
        {
            break;;
        }

        if (i == theApp.m_nPDIRow - 1)
        {
            m_strSearchNo = pPceData->stRollSched.strSTRIP_NO;
        }

        m_GridRollSchem.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                             | DT_VCENTER
                             | DT_SINGLELINE
                             | DT_END_ELLIPSIS;

            SetTextBGCor(m_GridRollSchem, pPceData, i + 1, j);

            switch (j)
            {
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.4f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridRollSchem.SetItem(&Item);
        }
    }

    m_GridRollSchem.Refresh();
//    m_GridRollSchem.AutoSizeColumns();

    m_GridRollSchem.SetScrollPos(SB_VERT, nScrollPos);
    return;
}


void CViewRollSchem::OnBnClickedButScImport()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������


    MTLIST *pRollSchedList  = NULL;
    int     nRollSchedCount = 0;

    char    strFilePath[MAX_PATH];
    int     nRet;

    nRet = Win_GetOpenFileName( strFilePath, 
                                MAX_PATH, 
                                "ѡ�����Ƽƻ��ļ�·��", 
                                "./", 
                                "All Files(*.*)", "*.*", 
                                "Text Files(*.txt)", "*.txt", 
                                this->m_hWnd);

    if ( nRet != ERR_SUCCESS)
    {
//        AfxMessageBox("ȡ����ѡȡ�ļ���·��ѡ�����!");
        return;
    }

    nRet = m_pRollSchedMgr->ReadSchedFromFile(strFilePath);
    if ( nRet != ERR_SUCCESS)
    {
        AfxMessageBox("�������ļ���ʽ����! ���鿴HRS_PDI.log��־�ļ�");
        return;
    }

    int nLoadNum = m_pRollSchedMgr->GetLoadFiledSteelNum();
    int nSuccessNum = m_pRollSchedMgr->GetLoadSuccessSteelNum();
    int nRepeatNum = m_pRollSchedMgr->GetRepeatStripNoNum();

    char szMsg[256];

    sprintf(szMsg, "Load Failed Num: %d\r\n"
        "Repeat Strip No Num: %d\r\n"
        "Load Success Num: %d\r\n", 
        nLoadNum - nSuccessNum, nRepeatNum, nSuccessNum);

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    if (NULL == pRollSchedList)
    {
        return;
    }

    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    if (nRollSchedCount >= GRID_ROW_MAX)
    {
        GetDlgItem(IDC_BUT_SC_DEL)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_SAVE)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_MOVEUP)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_MOVEDOWN)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SC_SEARCH)->EnableWindow(TRUE);
        GetDlgItem(IDC_BUT_SAVE_TOMEM)->EnableWindow(TRUE);

        AfxMessageBox("��ʾ��������Ŀ���ܳ���1024�飬���������ݵĸְ�δ�ܵ��룬\
                      Ŀǰ����ɹ���������Ŀ����һ��Ϊ1024��");
    }

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

    m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    AfxMessageBox(szMsg);

    return;
} 


void CViewRollSchem::SavePDIFile()
{
    char    strFilePath[MAX_PATH];
    int     nRet;

    nRet = Win_GetSaveFileName( strFilePath, 
        MAX_PATH, 
        "ѡ�����Ƽƻ��ļ�·��", 
        "./", 
        "Text Files(*.txt)", "*.txt", 
        "All Files(*.*)", "*.*", 
        this->m_hWnd);

    if ( nRet != ERR_SUCCESS )
    {
        //AfxMessageBox("·��ѡ�����!");
        return;
    }
    //else if ( nRet == OP_CANCEL )
    //{
    //    return;
    //}

    nRet = m_pRollSchedMgr->WriteSchedToFile(strFilePath);
    if ( nRet == NULL )
    {
        MessageBox("�����ļ��ɹ�!");
        return;
    }
    else
    {
        AfxMessageBox("�����ļ�ʧ��!");
    }

    return;
}


void CViewRollSchem::OnBnClickedButScExport()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    SavePDIFile();
    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

    m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);
}

void CViewRollSchem::OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    if (NULL == pNotifyStruct || NULL == pResult)
    {
        return;
    }

    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    // �޸�����У��򲻱����������
    if (nCol < 1)
    {
        RefeshRollSchemTab();
        return;
    }
#if 0
    int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                            "�뿪", 
                            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

    if ( nRet != IDYES )
    {
        RefeshRollSchemTab();
        return;
    }
#endif

    HRS_ROLL_SCHED *pRollSched;

    pRollSched = GetRollSchedFromGrid(nRow);

    m_pRollSchedMgr->ChangeRollSchedItem(pRollSched, nRow-1);

    //SavePDIFile();

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

    m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);
    m_GridRollSchem.ScrollToRow(theApp.m_nPDIRow);
}

HRS_ROLL_SCHED * CViewRollSchem::GetRollSchedFromGrid(int nRow)
{
    HRS_ROLL_SCHED * pRollSched;
    CString StrItem;
    int RowCount;
    int nLen;
    char szMsg[256];

    RowCount = m_GridRollSchem.GetRowCount();
    if ( nRow < 1 || nRow >= RowCount)
    {
        return NULL;
    }

    pRollSched = (HRS_ROLL_SCHED *) NG_malloc(sizeof(HRS_ROLL_SCHED));

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_SEQ);
    pRollSched->nSEQ = atoi(StrItem);

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_STRIP_NO);

    nLen = StrItem.GetLength();

    char *pszStripNo = StrItem.GetBuffer();

    StrTrimLeft(pszStripNo);
    StrTrimRight(pszStripNo);

    if (nLen < HRS_STRIP_NO_LEN_MIN 
        || nLen > HRS_STRIP_NO_LEN_MAX
        || pszStripNo == NULL 
        || pszStripNo[0] == '\0' )
    {
        sprintf(szMsg, "StripNo Length is out of range, Min Len = %d, Max Len = %d", 
            HRS_STRIP_NO_LEN_MIN,
            HRS_STRIP_NO_LEN_MAX);
        AfxMessageBox(szMsg);
        return NULL;
    }
    sprintf_s( pRollSched->strSTRIP_NO , HRS_STRIP_NO_LEN, "%s", StrItem.GetBuffer());
    StrItem.ReleaseBuffer();
    pRollSched->strSTRIP_NO[HRS_STRIP_NO_LEN-1] = '\0';


    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_COMSEQ);
    pRollSched->nCOMSEQ = atoi(StrItem);



    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_GRADE);
    nLen = StrItem.GetLength();
    char *pszGrade = StrItem.GetBuffer();

    StrTrimLeft(pszGrade);
    StrTrimRight(pszGrade);
    if ( nLen >= HRS_GRADE_LEN 
        || pszGrade == NULL 
        || pszGrade[0] == '\0' )
    {
        sprintf(szMsg, "Grade Length is out of range, valid Len = 1~%d", HRS_GRADE_LEN-1);
        AfxMessageBox(szMsg);
        return NULL;
    }
    sprintf_s( pRollSched->strGRADE , HRS_GRADE_LEN, "%s", StrItem.GetBuffer());
    StrItem.ReleaseBuffer();
    pRollSched->strGRADE[HRS_GRADE_LEN-1] = '\0';

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_SIGN);
    nLen = StrItem.GetLength();
    char *pszSign = StrItem.GetBuffer();

    StrTrimLeft(pszSign);
    StrTrimRight(pszSign);

    if ( nLen >= HRS_SIGN_LEN 
        || pszSign == NULL 
        || pszSign[0] == '\0' )
    {
        sprintf(szMsg, "Sign Length is out of range, valid Len = 1~%d", HRS_SIGN_LEN-1);
        AfxMessageBox(szMsg);
        return NULL;
    }
    sprintf_s( pRollSched->strSIGN , HRS_SIGN_LEN, "%s", StrItem.GetBuffer());
    StrItem.ReleaseBuffer();
    pRollSched->strSIGN[HRS_SIGN_LEN-1] = '\0';

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_C_H);
    pRollSched->fC_H = atof(StrItem);
    if (pRollSched->fC_H > 20 
        || pRollSched->fC_H < 1.0)
    {
        sprintf(szMsg, "C_H is out of range, Valid Range = %f ~ %f",
            1.0, 20.0);
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_C_W);
    pRollSched->fC_W = atof(StrItem);
    if (pRollSched->fC_W > 1650 
        || pRollSched->fC_W < 800)
    {
        sprintf(szMsg, "C_W is out of range, Valid Range = %f ~ %f",
            800.0, 1650.0);
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_FSB);
    pRollSched->nFSB = atoi(StrItem);
    if (pRollSched->nFSB < 0)
    {
        sprintf(szMsg, "FSB is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_R_H);
    pRollSched->fR_H = atof(StrItem);
    if (pRollSched->fR_H > 65 
        || pRollSched->fR_H < 30)
    {
        sprintf(szMsg, "R_H is out of range, Valid Range: %f ~ %f",
            30.0, 65.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }


    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_RSB);
    pRollSched->nRSB = atoi(StrItem);
    if (pRollSched->nRSB < 0)
    {
        sprintf(szMsg, "RSB is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_S_H);
    pRollSched->fS_H = atof(StrItem);
    if (pRollSched->fS_H > 250 
        || pRollSched->fS_H < 150)
    {
        sprintf(szMsg, "S_H is out of range, Valid Range: %f ~ %f",
            150.0, 250.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_S_W);
    pRollSched->fS_W = atof(StrItem);
    if (pRollSched->fS_W > 1650 
        || pRollSched->fS_W < 800)
    {
        sprintf(szMsg, "S_W is out of range, Valid Range: %f ~ %f",
            800.0, 1650.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_S_L);
    pRollSched->fS_L = atof(StrItem);
    if (pRollSched->fS_L > 15000 
        || pRollSched->fS_L < 3000)
    {
        sprintf(szMsg, "S_W is out of range, Valid Range: %f ~ %f",
            3000.0, 15000.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_WT);
    pRollSched->fWT = atof(StrItem);
    if (pRollSched->fWT > 1000.0 
        || pRollSched->fWT < 5.0)
    {
        sprintf(szMsg, "WT is out of range, Valid Range: %f ~ %f",
            5.0, 1000.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_WE);
    pRollSched->fWE = atof(StrItem);
    if (pRollSched->fWE > 35 * 1000 
        || pRollSched->fWE < 2 *1000)
    {
        sprintf(szMsg, "WE is out of range, Valid Range: %f ~ %f",
            2 *1000.0, 35 * 1000.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_FDT);
    pRollSched->fFDT = atof(StrItem);
    if (pRollSched->fFDT > 1000 
        || pRollSched->fFDT < 600)
    {
        sprintf(szMsg, "FDT is out of range, Valid Range: %f ~ %f",
            600.0, 1000.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_EXT);
    pRollSched->fEXT = atof(StrItem);
    if (pRollSched->fEXT > 1350 
        || pRollSched->fEXT < 1000)
    {
        sprintf(szMsg, "EXT is out of range, Valid Range: %f ~ %f",
            1000.0, 1350.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_RDT);
    pRollSched->fRDT = atof(StrItem);
    if (pRollSched->fRDT > 1300 
        || pRollSched->fRDT < 800)
    {
        sprintf(szMsg, "RDT is out of range, Valid Range: %f ~ %f",
            800.0, 1300.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_CTC);
    pRollSched->fCTC = atof(StrItem);
    if (pRollSched->fCTC > 800 
        || pRollSched->fCTC < 400)
    {
        sprintf(szMsg, "CTC is out of range, Valid Range: %f ~ %f",
            400.0, 800.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_QUAL);
    pRollSched->nQUAL = atoi(StrItem);
    if (pRollSched->nQUAL < 0)
    {
        sprintf(szMsg, "QUAL is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_SFC);
    pRollSched->nSFC = atoi(StrItem);
    if (pRollSched->nSFC < 0)
    {
        sprintf(szMsg, "SFC is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_STA);
    pRollSched->nSTA = atoi(StrItem);
    if (pRollSched->nSTA < 0)
    {
        sprintf(szMsg, "STA is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_HTT);
    pRollSched->nHTT = atoi(StrItem);
    if (pRollSched->nHTT < 0)
    {
        sprintf(szMsg, "HTT is out of range, Valid value is > %d",
            0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_CP);
    pRollSched->nCP = atoi(StrItem);

    StrItem = m_GridRollSchem.GetItemText(nRow, HRS_ROLLSCHED_CROWN);
    pRollSched->fCROWN = atof(StrItem);
    if (pRollSched->fCROWN > 15 
        || pRollSched->fCROWN < -10)
    {
        sprintf(szMsg, "CROWN is out of range, Valid Range: %f ~ %f",
            -10.0, 15.0 );
        AfxMessageBox(szMsg);
        return NULL;
    }

    return pRollSched;
}


void CViewRollSchem::OnBnClickedButScMoveup()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    CCellID CurCell;
    int nRow;
    int nCol;


    CurCell = m_GridRollSchem.GetFocusCell();
    nRow = CurCell.row;
    nCol = CurCell.col;

    if (nRow == 1)
    {
        MessageBox("�����Ѿ��ǵ�һ�����ݣ��޷����ƣ�");
        return;
    }

    m_pRollSchedMgr->MoveUpRollSchedItem(nRow);

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(nRow-1, nCol);
    m_GridRollSchem.SetSelectedRange(nRow-1,1,nRow-1,HRS_ROLL_SCHED_ITEM_NUM-1);

    theApp.m_nPDIRow = nRow - 1;
}


void CViewRollSchem::OnBnClickedButScMovedown()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������


    CCellID CurCell;
    int nRow;
    int nCol;

    CurCell = m_GridRollSchem.GetFocusCell();
    nRow = CurCell.row;
    nCol = CurCell.col;

    int nRowTotalCount = 0;
    nRowTotalCount = m_GridRollSchem.GetRowCount() - 1;
    if (nRowTotalCount  == nRow)
    {
        MessageBox("�����Ѿ������һ�����ݣ��޷����ƣ�");
        return;
    }

    m_pRollSchedMgr->MoveDownRollSchedItem(nRow);

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(nRow+1, nCol);
    m_GridRollSchem.SetSelectedRange(nRow+1,1,nRow+1,HRS_ROLL_SCHED_ITEM_NUM-1);

    theApp.m_nPDIRow = nRow + 1;
}



void CViewRollSchem::OnBnClickedButScSearch()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    int nSeq;

    nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strSearchNo);
    if (nSeq < 0)
    {

        MessageBox("���ݲ���ʧ�ܣ�û�д˸ְ�ŵĸְ���ڣ�");

        return;
    }

    m_GridRollSchem.SetFocusCell(nSeq, 2);
    m_GridRollSchem.SetSelectedRange(nSeq,1,nSeq,HRS_ROLL_SCHED_ITEM_NUM-1);

    theApp.m_nPDIRow = nSeq;
}


void CViewRollSchem::OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridRollSchem.GetFixedRowCount() )
    {
        return;
    }

    itemStr = m_GridRollSchem.GetItemText(nRow, 1);

    m_strSearchNo = itemStr;

    theApp.m_nPDIRow = nRow;

    UpdateData(FALSE);
}



void CViewRollSchem::OnBnClickedButSaveFile()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    int nRet = m_pRollSchedMgr->WriteSchedToFile(ROLLSCHEM_TEST_PDIFILE);
    if ( nRet == NULL )
    {
        MessageBox("�����ļ��ɹ�!");
        return;
    }
    else
    {
        AfxMessageBox("�����ļ�ʧ��!");
    }

    //if ( m_pRollSchedMgr->PceDataMgrCmp(*m_pRollSchedMgrOrig) )
    //{
    //    delete *m_pRollSchedMgrOrig;

    //    *m_pRollSchedMgrOrig = m_pRollSchedMgr->PceDataMgrCopy();

    //    MessageBox("���ݱ���ɹ���");

    //}
    //else 
    //{
    //    MessageBox("û�����ݸ���");
    //}
}


bool CViewRollSchem::ExitConfirm(CPceDataMgr **m_pRollSchedMgrOrig)
{
    if ( m_pRollSchedMgr->PceDataMgrCmp(*m_pRollSchedMgrOrig) )
    {
        
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                              "�뿪", 
                              MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            delete *m_pRollSchedMgrOrig;

            *m_pRollSchedMgrOrig = m_pRollSchedMgr->PceDataMgrCopy();

            MessageBox("���Ƽƻ������Ѹ��ģ���������Ӧ���������Ʋ��Ի���������������������Ʋ�������");
        }
        else if (nRet == IDCANCEL)
        {
            return false;
        }
    }
    else 
    {
        return true;
    }

    return true;

}

/*
@fn OnCtlColor
@brief
    ���ÿؼ�����ɫ
@return
    ��
@*/
HBRUSH CViewRollSchem::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
    /*
     *  ����ؼ�������ɫ��ˢ
     */
    HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

    /* 
     *  ���ݿؼ��������ÿؼ���ɫ
     */
    switch (nCtlColor)
    {
        case (CTLCOLOR_STATIC):
        {
            pDC->SetTextColor(STAC_TEXT_COR);
            pDC->SetBkColor(STAC_BG_COR);
            pDC->SetBkMode(TRANSPARENT);
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        case (CTLCOLOR_EDIT):
        {
            pDC->SetTextColor(EDIT_TEXT_COR);
            pDC->SetBkColor(EDIT_BG_COR);
            return (HBRUSH)m_CBrushEditBG.m_hObject;
        }
        case (CTLCOLOR_BTN):
        {
            pDC->SetBkColor(BUTN_BG_COR);
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        case (CTLCOLOR_DLG):
        {
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        default:
            break;
    }

    /*
     *  ���ر���ɫ
     */
    return hbr;
}



void CViewRollSchem::OnSize(UINT nType, int cx, int cy) 
{
    CFormView::OnSize(nType, cx, cy);

    CRect           rcRect;                      /* λ��                     */

    ///*
    // *  ���ݴ��ڴ�С�����������б���
    // */
    //if (m_GridRollSchem.m_hWnd)
    //{
    //    rcRect.left   = cx / 3;
    //    rcRect.right  = cx;
    //    rcRect.top    = 60;
    //    rcRect.bottom = cy / 3;

    //    m_GridRollSchem.MoveWindow(&rcRect);
    //    m_GridRollSchem.Invalidate();
    //}

    ///*
    // *  ���ݴ��ڴ�С���������ʾ����
    // */
    //if (m_gridMntSch.m_hWnd)
    //{
    //    rcRect.left   = cx / 4 - 40;
    //    rcRect.right  = cx;
    //    rcRect.top    = cy * 4 / 5-40;
    //    rcRect.bottom = cy;

    //    m_gridMntSch.MoveWindow(&rcRect);
    //    m_gridMntSch.Invalidate();
    //}

    ///*
    // *  ���ݴ��ڿ��ȵ���������Ϣ�ı�����
    // */
    //if (m_eidtMsg.m_hWnd)
    //{
    //    rcRect.left   = VMNT_MSG_RECT_L;
    //    rcRect.right  = VMNT_MSG_RECT_R_DEV * cx;
    //    rcRect.top    = VMNT_MSG_RECT_T;
    //    rcRect.bottom = VMNT_MSG_RECT_B;

    //    m_eidtMsg.MoveWindow(&rcRect);
    //}

    return;
}


int CViewRollSchem::LoadPDIData()
{
    if (NULL == m_pRollSchedMgr)
    {
        return ERR_FAILED;
    }

    char szTemp[256];
    memset(szTemp, 0, sizeof(szTemp));
    int nRet = ERR_SUCCESS;

    if ( 0 == m_pRollSchedMgr->GetLoadSuccessSteelNum())
    {
        nRet = ERR_FAILED;
    }
    //int nRet = m_pRollSchedMgr->ReadSchedFromFile("TestSched.txt");
    if ( ERR_FAILED == nRet )
    {
        GetDlgItem(IDC_BUT_SC_DEL)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_SAVE)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_MOVEUP)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_MOVEDOWN)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_SEARCH)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SAVE_TOMEM)->EnableWindow(FALSE);


        sprintf(szTemp,
                "�ļ���%s�������ڣ������ļ���ʽ����", 
                ROLLSCHEM_TEST_PDIFILE);

        AfxMessageBox(szTemp);
        return ERR_FAILED;
    }

    int nLoadNum;
    int nSuccessNum;

    memset(szTemp, 0, sizeof(szTemp));

    nLoadNum = m_pRollSchedMgr->GetLoadFiledSteelNum();
    nSuccessNum = m_pRollSchedMgr->GetLoadSuccessSteelNum();
    int nRepeatNum = m_pRollSchedMgr->GetRepeatStripNoNum();

    sprintf(szTemp,
        "����ʧ�ܵĸְ�����   :%d \r\n"
        "�ظ�StripNo�ĸְ�����: %d\r\n"
        "���سɹ��ĸְ�����   : %d\r\n", 
        nLoadNum - nSuccessNum, 
        nRepeatNum,
        nSuccessNum);

    if (0 == m_pRollSchedMgr->GetLoadSuccessSteelNum())
    {
        GetDlgItem(IDC_BUT_SC_DEL)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_SAVE)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_MOVEUP)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_MOVEDOWN)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SC_SEARCH)->EnableWindow(FALSE);
        GetDlgItem(IDC_BUT_SAVE_TOMEM)->EnableWindow(FALSE);

        AfxMessageBox(szTemp);

        return ERR_SUCCESS;
    }

    AfxMessageBox(szTemp);

    RefeshRollSchemTab();

    m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

    m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);
    return ERR_SUCCESS;
}
