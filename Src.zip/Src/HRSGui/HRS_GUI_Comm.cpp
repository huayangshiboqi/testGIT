#include "stdafx.h"

#include "NG.h"
#include "NG_CheckSum.h"

#include "MP.h"
#include "MP_Comm.h"

#include "HRS_GUI_Comm.h"

CHRSGUIComm::CHRSGUIComm()
{
    m_pCommInfo = NULL;

}


CHRSGUIComm::~CHRSGUIComm()
{
    if (NULL != m_pCommInfo)
    {
        HRS_Comm_Client_Destory(m_pCommInfo);

        m_pCommInfo = NULL;
    }

}

int CHRSGUIComm::SendRMData(HRS_RM_DATA_FROM_GUI *pRMData)
{
    if (NULL == m_pCommInfo || NULL == pRMData)
    {
        return ERR_FAILED;
    }

    pRMData->DataHead.nTunnelNo  = HRS_GUI_RM_STRA_PACK;

    pRMData->DataHead.nPackLen   = sizeof(HRS_RM_DATA_FROM_GUI);

    pRMData->DataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pRMData->DataHead, 
        sizeof(HRS_DATA_HEAD) - sizeof(int));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pRMData, sizeof(HRS_RM_DATA_FROM_GUI));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_RM_STRA_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSGUIComm.log", "GUI���ʹ������������Server��\r\n");

    return ERR_SUCCESS;
}

int CHRSGUIComm::SetVRRMData(HRS_RM_DATA_FROM_GUI *pRMData)
{
    if (NULL == pRMData)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pRMData->DataHead.nDataType  = HRS_DATA_TYPE_RM_FM_PACK; //HRS_DATA_TYPE_ONLY_RM_PACK;//

    int nRet = SendRMData(pRMData);

    return nRet;
}


int CHRSGUIComm::SendFMData(HRS_FM_DATA_FROM_GUI *pFMData)
{
    if (NULL == m_pCommInfo || NULL == pFMData)
    {
        return ERR_FAILED;
    }

    pFMData->DataHead.nTunnelNo  = HRS_GUI_FM_STRA_PACK;
    pFMData->DataHead.nPackLen   = sizeof(HRS_FM_DATA_FROM_GUI);

    pFMData->DataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pFMData->DataHead, 
        sizeof(HRS_DATA_HEAD) - sizeof(int));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pFMData, sizeof(HRS_FM_DATA_FROM_GUI));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_FM_STRA_PACK;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSGUIComm.log", "GUI���;������������Server��\r\n");

    return ERR_SUCCESS;
}

int CHRSGUIComm::SendL1RMSchedData(HRS_L1_RM_SCHED *pRMData)
{
    if (NULL == m_pCommInfo || NULL == pRMData)
    {
        return ERR_FAILED;
    }

    pRMData->stRoughRollSched.DataHead.nTunnelNo  = HRS_GUI_L1_RM_SCHED;
    pRMData->stRoughRollSched.DataHead.nPackLen   = sizeof(HRS_L1_FM_SCHED);

    pRMData->stRoughRollSched.DataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pRMData->stRoughRollSched.DataHead, 
        sizeof(HRS_DATA_HEAD) - sizeof(int));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pRMData, sizeof(HRS_L1_RM_SCHED));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_L1_RM_SCHED;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSGUIComm.log", "GUI���������Ʋ�����Server��\r\n");

    return ERR_SUCCESS;
}

int CHRSGUIComm::SendL1FMSchedData(HRS_L1_FM_SCHED *pFMData)
{
    if (NULL == m_pCommInfo || NULL == pFMData)
    {
        return ERR_FAILED;
    }

    pFMData->stDataHead.nTunnelNo  = HRS_GUI_L1_FM_SCHED;
    pFMData->stDataHead.nPackLen   = sizeof(HRS_L1_FM_SCHED);

    pFMData->stDataHead.usCheckSum = 
        GetByteCheckSum((const char *)&pFMData->stDataHead, 
        sizeof(HRS_DATA_HEAD) - sizeof(int));

    HRS_COMM_PACK_INFO *pCommPack = 
        HRS_Comm_PackInfo_Create(pFMData, sizeof(HRS_L1_FM_SCHED));
    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    pCommPack->nTunnelNo = HRS_GUI_L1_FM_SCHED;

    MsgQueue_SendNoBlock(m_pCommInfo->pSendMsgQue, pCommPack);

    error_log("HRSGUIComm.log", "GUI������������������Server��\r\n");

    return ERR_SUCCESS;
}

int CHRSGUIComm::SetVRFMData(HRS_FM_DATA_FROM_GUI *pFMData)
{
    if (NULL == pFMData)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pFMData->DataHead.nDataType  = HRS_DATA_TYPE_L1_FM_PACK;//HRS_DATA_TYPE_ONLY_FM_PACK;

    int nRet = SendFMData(pFMData);

    return nRet;
}

//int CHRSGUIComm::SetL1SimuRMData(HRS_RM_DATA_FROM_GUI *pRMData)
//{
//    if (NULL == pRMData)
//    {
//        return ERR_FAILED;
//    }
//
//    if (NULL == m_pCommInfo)
//    {
//        return ERR_FAILED;
//    }
//
//    pRMData->DataHead.nDataType  = HRS_DATA_TYPE_L1_SIMULATE; 
//
//    int nRet = SendRMData(pRMData);
//
//    return nRet;
//}

int CHRSGUIComm::SetL1SimuRMData(HRS_L1_RM_SCHED *pRMData) //����L1��������
{
    if (NULL == pRMData)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pRMData->stRoughRollSched.DataHead.nDataType  = HRS_DATA_TYPE_RM_SIMULATE;

    int nRet = SendL1RMSchedData(pRMData);

    return nRet;
}


int CHRSGUIComm::SetL1SimuFMData( HRS_L1_FM_SCHED *pFinishRollSched)
{
    if (NULL == pFinishRollSched)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pFinishRollSched->stDataHead.nDataType  = HRS_DATA_TYPE_L1_SIMULATE;

    int nRet = SendL1FMSchedData(pFinishRollSched);

    return nRet;
}


int CHRSGUIComm::SetRMData(HRS_RM_DATA_FROM_GUI *pRMData)
{
    if (NULL == pRMData)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pRMData->DataHead.nDataType  = HRS_DATA_TYPE_ONLY_RM_PACK; //HRS_DATA_TYPE_RM_FM_PACK; //HRS_DATA_TYPE_ONLY_RM_PACK;//

    int nRet = SendRMData(pRMData);

    return nRet;
}


int CHRSGUIComm::SetFMData(HRS_FM_DATA_FROM_GUI *pFMData)
{
    if (NULL == pFMData)
    {
        return ERR_FAILED;
    }

    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    pFMData->DataHead.nDataType  = HRS_DATA_TYPE_ONLY_FM_PACK;//HRS_DATA_TYPE_L1_FM_PACK;//HRS_DATA_TYPE_ONLY_FM_PACK;

    int nRet = SendFMData(pFMData);

    return nRet;
}


int CHRSGUIComm::GetRMSched(HRS_RM_SCHED &RMSched)
{
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    HRS_RM_SCHED *pRMSched = &RMSched;

    HRS_COMM_PACK_INFO *pCommPack = (HRS_COMM_PACK_INFO *)
        MsgQueue_RecvNoBlock(m_pCommInfo->pRecvMsgQue[HRS_GUI_RM_ROLL_PACK]);

    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_RM_SCHED))
    {
        memcpy(pRMSched, pCommPack->pPackData, sizeof(HRS_RM_SCHED));
    }
    else
    {
        memcpy(pRMSched, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSGUIComm.log", "GUI��ȡ������̣�\r\n");

    return ERR_SUCCESS;
}


int CHRSGUIComm::GetFMSched(HRS_FM_SCHED &FMSched)
{
    HRS_FM_SCHED *pFMSched = &FMSched;
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    HRS_COMM_PACK_INFO *pCommPack = (HRS_COMM_PACK_INFO *)
        MsgQueue_RecvNoBlock(m_pCommInfo->pRecvMsgQue[HRS_GUI_FM_ROLL_PACK]);

    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_FM_SCHED))
    {
        memcpy(pFMSched, pCommPack->pPackData, sizeof(HRS_FM_SCHED));
    }
    else
    {
        memcpy(pFMSched, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSGUIComm.log", "GUI��ȡ������̣�\r\n");

    return ERR_SUCCESS;
}


int CHRSGUIComm::GetSteelInfo(HRS_STEEL_INFO &SteelInfo)
{
    HRS_STEEL_INFO *pSteelInfo = &SteelInfo;
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    memset(&SteelInfo, 0, sizeof(HRS_STEEL_INFO));

    HRS_COMM_PACK_INFO *pCommPack = (HRS_COMM_PACK_INFO *)
        MsgQueue_RecvNoBlock(m_pCommInfo->pRecvMsgQue[HRS_GUI_STEEL_INFO_PACK]);

    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_STEEL_INFO))
    {
        memcpy(pSteelInfo, pCommPack->pPackData, sizeof(HRS_STEEL_INFO));
    }
    else
    {
        memcpy(pSteelInfo, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    //error_log("HRSGUIComm.log", "GetSteelInfo��\n");

    return ERR_SUCCESS;
}


int CHRSGUIComm::GetL1AveData(HRS_L1_SIMULATE_ALL_AVEDATA &AveData)
{
    HRS_L1_SIMULATE_ALL_AVEDATA *pAveData = &AveData;
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    memset(&AveData, 0, sizeof(HRS_L1_SIMULATE_ALL_AVEDATA));

    HRS_COMM_PACK_INFO *pCommPack = (HRS_COMM_PACK_INFO *)
        MsgQueue_RecvNoBlock(m_pCommInfo->pRecvMsgQue[HRS_GUI_L1_AVE_PACK]);

    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_L1_SIMULATE_ALL_AVEDATA))
    {
        memcpy(pAveData, pCommPack->pPackData, sizeof(HRS_L1_SIMULATE_ALL_AVEDATA));
    }
    else
    {
        memcpy(pAveData, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    error_log("HRSGUIComm.log", "GUI��ȡ���������������\r\n");

    return ERR_SUCCESS;
}


int CHRSGUIComm::GetServiceCommInfo(HRS_Service_CommError &ServiceCommState)
{
    HRS_Service_CommError *pServiceCommState = &ServiceCommState;
    if (NULL == m_pCommInfo)
    {
        return ERR_FAILED;
    }

    memset(pServiceCommState, 0, sizeof(HRS_Service_CommError));

    HRS_COMM_PACK_INFO *pCommPack = (HRS_COMM_PACK_INFO *)
        MsgQueue_RecvNoBlock(m_pCommInfo->pRecvMsgQue[HRS_GUI_COMM_INFO]);

    if (NULL == pCommPack)
    {
        return ERR_FAILED;
    }

    if (pCommPack->nPackLen > sizeof(HRS_Service_CommError))
    {
        memcpy(pServiceCommState, pCommPack->pPackData, sizeof(HRS_Service_CommError));
    }
    else
    {
        memcpy(pServiceCommState, pCommPack->pPackData, pCommPack->nPackLen);
    }

    HRS_Comm_PackInfo_Destory(pCommPack);

    pCommPack = NULL;

    //error_log("HRSGUIComm.log", "GetServiceCommInfo��\n");

    return ERR_SUCCESS;
}

int CHRSGUIComm::GetCommState()
{
    int anState[8];
    int i;

    m_nCommState = ERR_SUCCESS;

    if ( m_pCommInfo != NULL && m_pCommInfo->hComm != NULL )
    {
        for ( i = 0; i < 1; i++ )
        {
            anState[i] = MP_Comm_GetStatus(m_pCommInfo->hComm, i);
        }
    }
    else
    {
        for ( i = 0; i < 1; i++ )
        {
            anState[i] = RW_TCP_KEEP_STATUS_DOUBLE_INIT;
        }
    }

    for ( i = 0; i < 1; i++ )
    {
        if (0 != anState[i])
        {
            m_nCommState = ERR_FAILED;
            break;
        }
    }

    return m_nCommState;
}

void CHRSGUIComm::GetStateMsg(char *pszMsg)
{
    int anState[8];
    int i;

    char szState[128];

    if ( m_pCommInfo != NULL && m_pCommInfo->hComm != NULL )
    {
        for ( i = 0; i < 8; i++ )
        {
            anState[i] = MP_Comm_GetStatus(m_pCommInfo->hComm, i);
        }
    }
    else
    {
        for ( i = 0; i < 8; i++ )
        {
            anState[i] = RW_TCP_KEEP_STATUS_DOUBLE_INIT;
        }
    }

    
    int nOneStatus;
    char szStatus[128];

    pszMsg[0] = '\0';

    nOneStatus = MP_Comm_GetSendStatus(anState[0]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "RMCalcSend: %s\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetRecvStatus(anState[2]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "RMCalcRecv: %s\r\n\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetSendStatus(anState[1]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "FMCalcSend: %s\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetRecvStatus(anState[3]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "FMCalcRecv: %s\r\n\r\n", szStatus);
    strcat(pszMsg, szState);


    nOneStatus = MP_Comm_GetSendStatus(anState[4]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "RMSchedSend: %s\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetSendStatus(anState[5]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "FMSchedSend: %s\r\n\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetRecvStatus(anState[6]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "SimuRecv:    %s\r\n", szStatus);
    strcat(pszMsg, szState);

    nOneStatus = MP_Comm_GetRecvStatus(anState[7]);
    MP_Comm_GetStatusMsg(nOneStatus, szStatus, sizeof(szStatus));
    sprintf(szState, "GhostRecv:   %s\r\n", szStatus);
    strcat(pszMsg, szState);

    return;
}


void CHRSGUIComm::MTaskSetExitFlag()
{
    if(NULL == m_pCommInfo || NULL == m_pCommInfo->pMTask)
    {
        return ;
    }

    MTask_SetExitFlag(m_pCommInfo->pMTask, MTASK_EXIT);

    return;
}


int CHRSGUIComm::GUICommCreate()
{
    //����ͨ�Ž���
    if (NULL != m_pCommInfo)
    {
        HRS_Comm_Client_Destory(m_pCommInfo);
    }

    m_pCommInfo = HRS_Comm_Client_Create(HRS_CLIENT_COMM_CFG);

    if (NULL == m_pCommInfo)
    {
        m_nCommState = ERR_FAILED;

        return ERR_FAILED;
    }

    m_pCommInfo->nCommNo = HRS_SERVER_GUI_COMM_NO;

    m_nCommState = ERR_SUCCESS;

    m_pCommInfo->nCommModel = ERR_FAILED;

    return ERR_SUCCESS;
}
