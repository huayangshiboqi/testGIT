// ChildFrm.cpp : CChildFrame ���ʵ��
//
#include "stdafx.h"
#include "HRSGui.h"

#include "ChildFrm.h"

#include "ViewNavig.h"
#include "ViewRollSchem.h"
#include "ViewRoughRollStra.h"
//#include "ViewRoughRollSched.h"
#include "ViewFinishRollStra.h"
//#include "ViewFinishRollSched.h"
#include "ViewRollerData.h"
#include "ViewGhostRoll.h"

#include "InterfaceStruct.h"
#include "ViewTitle.h"
#include "ViewRight.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define HRS_TIMER_ELLAPSE           10



// CChildFrame
IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)

    ON_WM_MDIACTIVATE()
    ON_MESSAGE(NM_VIEW_CHANGE, _OnViewChange)
    ON_WM_TIMER()
END_MESSAGE_MAP()


// CChildFrame ����/����
CChildFrame::CChildFrame()
{
    // TODO: �ڴ����ӳ�Ա��ʼ������
   m_pRollSchedMgr = NULL;//new CPceDataMgr;
   m_pCViewData = NULL;

   m_bState = false;

   m_nXPos = 0;

   m_nRollEnd = ERR_FAILED;
   m_nRolling = ERR_FAILED;

   m_SteelInfo.fStrip1HeadPosition = -1;

 }


CChildFrame::~CChildFrame()
{

    if (m_pRollSchedMgr != NULL)
    {
        delete m_pRollSchedMgr;
    }
}


BOOL CChildFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/, CCreateContext* pContext)
{
    if (!m_wndSplitter.CreateStatic(this, 1, 2))
    {
        return FALSE;
    }

    CRect rcClient;
    CRect rcRightClient;

    /*
     *  ��ȡ��ܴ��ڿͻ�����CRect����
     */
    GetClientRect(&rcClient);
    ScreenToClient(rcClient);

    /*
     *  �������洰���е���ͼ
     */
    if (!m_wndSplitter.CreateView(0,
                                  0,
                                  RUNTIME_CLASS(CViewNavig),
                                  CSize(140,
                                  rcClient.Height()),
                                  pContext))
    {
        return FALSE;
    }

   /* if (!m_wndSplitter.CreateView(0,
                                  1,
                                  RUNTIME_CLASS(CViewRight),
                                  CSize(rcClient.Width() - 140,
                                  rcClient.Height()),
                                  pContext))
    {
        return FALSE;
    }*/

    //m_pRightView = ((CViewRight*)(m_wndSplitter.GetPane(0,1)));


    UINT uID = m_wndSplitter.IdFromRowCol(0,1);

    int nWith = rcClient.Width() - 140;
    int nLenth = rcClient.Height();

    OnCreateRight(pContext, uID, nWith, nLenth);

    ///*
    // *  �������洰���е���ͼ
    // */
    //if (!m_wndRightSplitter.CreateView(0,
    //                                   0,
    //                                   RUNTIME_CLASS(CViewTitle),
    //                                   CSize(rcClient.Width() - 140,
    //                                   140),
    //                                   pContext))
    //{
    //    return FALSE;
    //}

    //if (!m_wndRightSplitter.CreateView(0,
    //                                   1,
    //                                   RUNTIME_CLASS(CViewRollSchem),
    //                                   CSize(rcClient.Width() - 140,
    //                                   rcClient.Height() - 140),
    //                                   pContext))
    //{
    //    return FALSE;
    //}

#if 1
     //m_wndSplitter.HideSplitter();

    ((CViewRollSchem*)( m_wndRightSplitter.GetPane(1,0)))
        ->SetRollSchedMgr(&m_pRollSchedMgr);
    m_nRightViewType = IDD_VIEW_ROLLSCHEM;

    if (NULL == m_pRollSchedMgr)
    {
        m_pRollSchedMgr = new CPceDataMgr;

        m_pRollSchedMgr->LoadRollerDataMgr(ROLLER_DATA_FILE);

        m_pRollSchedMgr->ReadSchedFromFile(ROLLSCHEM_TEST_PDIFILE);
    }

    m_wndSplitter.RecalcLayout();

    m_wndRightSplitter.RecalcLayout();
#endif

    m_nRightViewType = IDD_VIEW_ROLLSCHEM;

    m_bState = true;

    //m_wndSplitter.RecalcLayout();

    SetTimer(HRS_TIMER_EVENT_ID, HRS_TIMER_ELLAPSE, NULL);

    return TRUE;
}


BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: �ڴ˴�ͨ���޸� CREATESTRUCT cs ���޸Ĵ��������ʽ
    if( !CMDIChildWnd::PreCreateWindow(cs) )
        return FALSE;

    cs.style = WS_CHILD | WS_VISIBLE | WS_OVERLAPPED | WS_CAPTION
        /*| WS_SYSMENU*/ | FWS_ADDTOTITLE | WS_CHILD/*WS_THICKFRAME*/
        /*| WS_MINIMIZEBOX | WS_MAXIMIZEBOX*/ | WS_MAXIMIZE;

    return TRUE;
}


BOOL CChildFrame::OnCreateRight(CCreateContext* pContext, UINT uID, int nWith, int nLenth)
{
    if (!m_wndRightSplitter.CreateStatic(&m_wndSplitter, 2, 1,WS_CHILD | WS_VISIBLE , uID))
    {
        return FALSE;
    }

    //CRect rcRightClient;

    ///*
    // *  ��ȡ��ܴ��ڿͻ�����CRect����
    // */
    //GetClientRect(&rcRightClient);
    //ScreenToClient(rcRightClient);

    m_nTitleHeight = 165;
    m_nTitleWidth  = nWith - 80;

    /*
     *  �������洰���е���ͼ
     */
    if (!m_wndRightSplitter.CreateView(0,
                                       0,
                                       RUNTIME_CLASS(CViewTitle),
                                       CSize(nWith,
                                       185),
                                       pContext))
    {
        return FALSE;
    }

    if (!m_wndRightSplitter.CreateView(1,
                                       0,
                                       RUNTIME_CLASS(CViewRollSchem),
                                       CSize(nWith,
                                       nLenth - 185),
                                       pContext))
    {
        return FALSE;
    }

    return TRUE;
}


// CChildFrame ���

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
    CMDIChildWnd::AssertValid();
}


void CChildFrame::Dump(CDumpContext& dc) const
{
    CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG


// CChildFrame ��Ϣ��������


/*****************************************************************************/
/*                     CChildFrame::OnMDIActivate ʵ��                       */
/*****************************************************************************/
/*
@fn OnMDIActivate
@brief
    ��Ӧϵͳ����
@return
    ��
@*/
void CChildFrame::OnMDIActivate(BOOL bActivate, CWnd*, CWnd*)
{
    /*
     *  ���治��ʾ�˵�
     */
    AfxGetMainWnd()->SetMenu(NULL);
    return;
}


/*****************************************************************************/
/*                   CChildFrame::PreTranslateMessage ʵ��                   */
/*****************************************************************************/
/*
@fn PreTranslateMessage
@brief
    ��ϢԤ����
@arg [in ] pMsg
    MSG* ��Ϣ����
@return
    ��־����״̬
@*/
BOOL CChildFrame::PreTranslateMessage(MSG* pMsg)
{

    /*
     *  �Դ��ڷָ�����Ϣ���д���
     */
    if (pMsg->hwnd == m_wndSplitter.m_hWnd)
    {
        /*
         *  ��������ƶ��Ͱ�ť������Ϣ���ָ�ڲ����϶�
         */
        if (   (pMsg->message == WM_LBUTTONDOWN)
            || (pMsg->message == WM_MOUSEMOVE))
        {
            return TRUE;
        }
    }

    return CMDIChildWnd::PreTranslateMessage(pMsg);
}


/*****************************************************************************/
/*                     CChildFrame::_OnViewChange ʵ��                       */
/*****************************************************************************/
/*
@fn _OnViewChange
@brief
    ��ͼ�л���Ϣ����
@return
    LRESULT
@*/
LRESULT CChildFrame::_OnViewChange(WPARAM wParam,LPARAM lParam)
{

    if (ERR_FAILED == m_nRolling && ERR_FAILED == theApp.m_nAverageing)
    {
        _SwitchRightView((int)wParam);
    }

    return 0;
}


bool CChildFrame::RefshView(int iViewId)
{
    if (IDC_BUT_NAVIG_EXIT == iViewId)
    {
        int         iReturn;  

        iReturn =  AfxMessageBox("ȷ���˳�ϵͳ��",
            MB_OKCANCEL | MB_ICONQUESTION);

        if(IDOK == iReturn)
        {
            this->GetTopLevelFrame()->PostMessage(WM_CLOSE);
        }

        return true;
    }

    bool    bOK(true);                  //  ��ǲ����ɹ�

    switch (iViewId)
    {
        case (IDD_VIEW_ROLLSCHEM):
        {
            m_wndRightSplitter.CreateView(1,
                                     0,
                                     RUNTIME_CLASS(CViewRollSchem),
                                     CSize(0, 0),
                                     NULL);

            m_pCViewData =  m_wndRightSplitter.GetPane(1,0);
            ((CViewRollSchem*)( m_wndRightSplitter.GetPane(1,0)))
                ->SetRollSchedMgr(&m_pRollSchedMgr);
            m_nRightViewType = IDD_VIEW_ROLLSCHEM;

            ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                ->_SetButtonState(IDD_VIEW_ROLLSCHEM);

            break;
        }
        case (IDD_VIEW_ROUGHROLLSCHEM):
        {
            m_wndRightSplitter.CreateView(1,
                                     0,
                                     RUNTIME_CLASS(CViewRoughRollStra),
                                     CSize(0, 0),
                                     NULL);

            m_pCViewData =  m_wndRightSplitter.GetPane(1,0);
            ((CViewRoughRollStra*)( m_wndRightSplitter.GetPane(1,0)))
                ->SetRollSchedMgr(m_pRollSchedMgr);
            m_nRightViewType = IDD_VIEW_ROUGHROLLSCHEM;

            ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                ->_SetButtonState(IDD_VIEW_ROUGHROLLSCHEM);

            break;
        }
       /* case (IDD_VIEW_ROUGHROLL_SCHED):
            {
                m_wndSplitter.CreateView(0,
                                        1,
                                        RUNTIME_CLASS(CViewRoughRollSched),
                                        CSize(0, 0),
                                        NULL);

                ((CViewRoughRollSched*)(m_wndSplitter.GetPane(0,1)))
                    ->SetRollSchedMgr(m_pRollSchedMgr);
                m_nRightViewType = IDD_VIEW_ROUGHROLL_SCHED;

                ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                    ->_SetButtonState(IDD_VIEW_ROUGHROLL_SCHED);

                break;
            }*/
        case (IDD_VIEW_FINISHROLL_STRA):
            {
                m_wndRightSplitter.CreateView(1,
                                        0,
                                        RUNTIME_CLASS(CViewFinishRollStra),
                                        CSize(0, 0),
                                        NULL);

                m_pCViewData =  m_wndRightSplitter.GetPane(1,0);
                ((CViewFinishRollStra*)( m_wndRightSplitter.GetPane(1,0)))
                    ->SetRollSchedMgr(m_pRollSchedMgr);
                m_nRightViewType = IDD_VIEW_FINISHROLL_STRA;

                ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                    ->_SetButtonState(IDD_VIEW_FINISHROLL_STRA);

                break;
            }
#if 0
        case (IDD_VIEW_FM_SCHED):
            {
                m_wndSplitter.CreateView(0,
                                        1,
                                        RUNTIME_CLASS(CViewFinishRollSched),
                                        CSize(0, 0),
                                        NULL);

                ((CViewFinishRollSched*)(m_wndSplitter.GetPane(0,1)))
                    ->SetRollSchedMgr(m_pRollSchedMgr);
                m_nRightViewType = IDD_VIEW_FM_SCHED;

                ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                    ->_SetButtonState(IDD_VIEW_FM_SCHED);

                break;
            }
#endif

        case (IDD_VIEW_GHOSTROLL):
            {
                m_wndRightSplitter.CreateView(1,
                                        0,
                                        RUNTIME_CLASS(CViewGhostRoll),
                                        CSize(0, 0),
                                        NULL);

                m_pCViewData =  m_wndRightSplitter.GetPane(1,0);
                ((CViewGhostRoll*)( m_wndRightSplitter.GetPane(1,0)))
                    ->SetRollSchedMgr(m_pRollSchedMgr);
                m_nRightViewType = IDD_VIEW_GHOSTROLL;

                ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                    ->_SetButtonState(IDD_VIEW_GHOSTROLL);

                break;
            }

        case (IDD_VIEW_ROLLER_DATA):
            {
                m_wndRightSplitter.CreateView(1,
                    0,
                    RUNTIME_CLASS(CViewRollerData),
                    CSize(0, 0),
                    NULL);

                m_pCViewData =  m_wndRightSplitter.GetPane(1,0);
                ((CViewRollerData*)( m_wndRightSplitter.GetPane(1,0)))
                    ->SetRollSchedMgr(m_pRollSchedMgr);
                m_nRightViewType = IDD_VIEW_ROLLER_DATA;

                ((CViewNavig*)(m_wndSplitter.GetPane(0,0)))
                    ->_SetButtonState(IDD_VIEW_ROLLER_DATA);

                break;
            }
            
        default :
        {
            bOK = false;

            break;
        }
    }

    return bOK;
}


/*****************************************************************************/
/*                    CChildFrame::_SwitchRightView ʵ��                     */
/*****************************************************************************/
/*
@fn _SwitchRightView
@brief
    ������ͼID�л�����ͼ
@arg [in ] iViewId
    int ��ͼID
@return
    bool ��־����״̬
@*/
bool CChildFrame::_SwitchRightView(int iViewId)
{
    if (IDC_BUT_NAVIG_EXIT == iViewId)
    {
        int         iReturn;  

        iReturn =  AfxMessageBox("ȷ���˳�ϵͳ��",
                             MB_OKCANCEL | MB_ICONQUESTION);

        if(IDOK == iReturn)
        {
            this->GetTopLevelFrame()->PostMessage(WM_CLOSE);
        }

        return true;
    }

    bool    bOK(true);                  //  ��ǲ����ɹ�

#if 0

    if (m_nRightViewType == IDD_VIEW_ROLLSCHEM)
    {
        if( ! ((CViewRollSchem*)(m_wndSplitter.GetPane(0,1)))
            ->ExitConfirm(&m_pRollSchedMgr) )
        {
            return bOK;
        }

    }
    else if (m_nRightViewType == IDD_VIEW_ROUGHROLLSCHEM)
    {
        if( ! ((CViewRoughRollStra*)(m_wndSplitter.GetPane(0,1)))
            ->ExitConfirm() )
        {
            return bOK;
        }
    }
    else if (m_nRightViewType == IDD_VIEW_FINISHROLL_STRA)
    {
        if( ! ((CViewFinishRollStra*)(m_wndSplitter.GetPane(0,1)))
            ->ExitConfirm() )
        {
            return bOK;
        }
    }

#endif

    /*
     *  ɾ��ԭ�е���ͼ
     */
    if (m_wndRightSplitter.GetPane(1,0))
    {
        m_wndRightSplitter.DeleteView(1,0);
    }
    else
    {
        return false;
    }

    /*
     *  ���ݵ�ǰ��ͼID�Ź����µ���ͼ
     */
    RefshView(iViewId);

    /*
     *  ���´��ڲ���
     */
    m_wndSplitter.RecalcLayout();

    m_wndRightSplitter.RecalcLayout();

    return bOK;

}


void CChildFrame::OnTimer(UINT_PTR nIDEvent)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
    CMDIChildWnd::OnTimer(nIDEvent);

    if (false == m_bState)
    {
        return;
    }

    if(NULL == m_pCViewData)
    {
        m_pCViewData =  m_wndRightSplitter.GetPane(1,0);

        //ˢ��PDI����
        if (ERR_FAILED == ((CViewRollSchem*)(m_pCViewData))->GetInitPDIGridState())
        {
            if (NULL == m_pRollSchedMgr)
            {
                m_pRollSchedMgr = new CPceDataMgr;

                m_pRollSchedMgr->LoadRollerDataMgr(ROLLER_DATA_FILE);

                m_pRollSchedMgr->ReadSchedFromFile(ROLLSCHEM_TEST_PDIFILE);
            }

            ((CViewRollSchem*)(m_pCViewData))->InitRollSchedMgr(m_pRollSchedMgr);

            ((CViewRollSchem*)(m_pCViewData))->SetetInitPDIGridState(ERR_SUCCESS);

            m_wndSplitter.RecalcLayout();

            m_wndRightSplitter.RecalcLayout();

            return;
        }

        return;
    }

    if(ERR_SUCCESS == m_nRollEnd)
    {
        ((CViewGhostRoll*)(m_pCViewData))->SetRollEnd();

        m_nRollEnd = ERR_FAILED;
    }

    //ˢ��ͼƬ�ְ�λ��
    if (ERR_SUCCESS == theApp.m_pGUIComm->GetSteelInfo(m_SteelInfo))
    {
        if ((m_SteelInfo.fStrip1HeadPosition > 422000 
            ||0 >= m_SteelInfo.fStrip1HeadPosition)
            && ERR_SUCCESS == m_nRolling)
        {
            m_nRollEnd = ERR_SUCCESS;

            m_nRolling = ERR_FAILED;

            theApp.m_nRolling = ERR_FAILED;

            //AfxMessageBox("�������Ƴ������ְ������");

            //m_pCViewTitle->SetSteelPos(50, 30);
        }
        else
        {
            nTelTotalTime = 0;

            m_pCViewTitle = (CViewTitle *)m_wndRightSplitter.GetPane(0,0);

            m_nTitleWidth = 1585;

            int nScrollPos = m_pCViewTitle->GetScrollPos(SB_HORZ);

            int nXPos = 70 + m_SteelInfo.fStrip1HeadPosition * m_nTitleWidth /420000;
            nXPos -= nScrollPos;

            int nWidth = (m_SteelInfo.fStrip1HeadPosition 
                - m_SteelInfo.fStrip1tailPosition) * m_nTitleWidth /420000;

            if(nXPos > m_nTitleWidth + 69 - nScrollPos)
            {
                m_pCViewTitle->ShowCoil();
            }
            else
            {
                m_pCViewTitle->HideCoil();
            }
            nXPos -= nWidth;

            m_pCViewTitle->SetSteelPos(nXPos, nWidth);
        }

        nTelTotalTime = 0;
    }
    else if (ERR_SUCCESS == m_nRolling)
    {
        nTelTotalTime++;

        if (nTelTotalTime > 800)
        {
            m_nRollEnd = ERR_SUCCESS;

            m_nRolling = ERR_FAILED;

            theApp.m_nRolling = ERR_FAILED;

            nTelTotalTime = 0;

            AfxMessageBox("�������Ƴ������ְ������");

            m_pCViewTitle->SetSteelPos(50, 30);
        }
    }

    //ˢ��ͨ��״̬
    HRS_Service_CommError ServiceCommState;
    if (ERR_SUCCESS == theApp.m_pGUIComm->GetServiceCommInfo(ServiceCommState))
    {
        theApp.m_nServiceVRState = ServiceCommState.nServiceVRState;
        theApp.m_nServiceL1State = ServiceCommState.nServiceL1State;
    }

    //ˢ�¾�����������
    HRS_FM_SCHED FMSched;
    if (IDD_VIEW_FINISHROLL_STRA == m_nRightViewType
        && ERR_SUCCESS == theApp.m_pGUIComm->GetFMSched(FMSched)) 
    {
        ((CViewFinishRollStra*)(m_pCViewData))->SetFMSched(FMSched);

        return;
    }

    //ˢ�´�����������
    HRS_RM_SCHED RMSched;
    if (IDD_VIEW_ROUGHROLLSCHEM == m_nRightViewType 
        && ERR_SUCCESS == theApp.m_pGUIComm->GetRMSched(RMSched))
    {
        ((CViewRoughRollStra*)(m_pCViewData))->SetRMSched(RMSched);

        return;
    }

    //ˢ��VRҳ��
    HRS_L1_SIMULATE_ALL_AVEDATA AveData;

    if (IDD_VIEW_GHOSTROLL == m_nRightViewType)
    {
        if (ERR_SUCCESS == theApp.m_pGUIComm->GetRMSched(RMSched))
        {
            ((CViewGhostRoll*)(m_pCViewData))->SetRMSched(RMSched);
        }

        if (ERR_SUCCESS == theApp.m_pGUIComm->GetFMSched(FMSched))
        {
            //AfxMessageBox("ˢ��VRҳ��");

            ((CViewGhostRoll*)(m_pCViewData))->SetFMSched(FMSched);
        }

        if (ERR_SUCCESS == theApp.m_pGUIComm->GetL1AveData(AveData))
        {
            //AfxMessageBox("ˢ��VRҳ���ֵ");

            ((CViewGhostRoll*)(m_pCViewData))->SetL1AveData(AveData);

            //m_pCViewTitle->SetSteelPos(130, 80);

            theApp.m_nAverageing = ERR_FAILED;

            m_nXPos = 0;

            theApp.m_nAveTotalTimes = 0;
        }

        if (0 < m_SteelInfo.fStrip1HeadPosition)
        {
            if (ERR_FAILED == m_nRolling)
            {
                ((CViewGhostRoll*)(m_pCViewData))->SetRolling();

                m_nRolling = ERR_SUCCESS;

                theApp.m_nRolling = ERR_SUCCESS;
            }
        }

        if (theApp.m_nAveTotalTimes > 50 )
        {
            if (ERR_SUCCESS == theApp.m_nAverageing)
            {
                theApp.m_nAverageing = ERR_FAILED;

                ((CViewGhostRoll*)(m_pCViewData))->SetL1AveDataOverTime();

                m_nXPos = 0;
            }

            theApp.m_nAveTotalTimes = 0;

        }

        return;
    }

}
