// ViewGhostRoll.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewGhostRoll.h"

#include "WinCommon.h "
#include "NG_errno.h" 
#include "NG_malloc.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "HRS_EquipParaMgr.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"
#include "GridCtrlFunc.h"

// CViewGhostRoll

IMPLEMENT_DYNCREATE(CViewGhostRoll, CFormView)

CViewGhostRoll::CViewGhostRoll()
    : CFormView(CViewGhostRoll::IDD)
    , m_strEditStripNo(_T(""))
{

    m_pRollSchedMgr = NULL;
    m_pCurPceData = NULL;

    m_nSimulatorStatus = ERR_FAILED;

    m_nRow = 1;

    m_pAveClacDialog = NULL;

}

CViewGhostRoll::~CViewGhostRoll()
{
    if (NULL != m_pAveClacDialog)
    {
        delete m_pAveClacDialog;
    }
}

void CViewGhostRoll::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    //DDX_GridControl(pDX, IDC_GRID_GR_STRIPNO, m_GridStripNo);
    DDX_GridControl(pDX, IDC_GRID_GR_RM_SCHEDCALC, m_GridGrRmSchedCalc);
    DDX_GridControl(pDX, IDC_GRID_GR_FM_PRECALC, m_GridGrFmPreCalc);
    //DDX_GridControl(pDX, IDC_GRID_GR_FM_PRECALC_BASIC, m_GridGrFmPreCalcBasic);
    DDX_GridControl(pDX, IDC_GRID_GR_PDI, m_GridGrPDI);
    DDX_Text(pDX, IDC_EDIT_STRIP_NO, m_strEditStripNo);
}

BEGIN_MESSAGE_MAP(CViewGhostRoll, CFormView)
    ON_NOTIFY(NM_CLICK, IDC_GRID_GR_PDI, OnGridStripNoClick)
    ON_EN_CHANGE(IDC_EDIT_STRIP_NO, &CViewGhostRoll::OnEnChangeEditStripNo)
    ON_BN_CLICKED(IDC_VR_ROLL, &CViewGhostRoll::OnBnClickedButCalc)
    ON_BN_CLICKED(IDC_FM_SIMULATION_CLAC, &CViewGhostRoll::OnBnClickedSimulationButCalc)


END_MESSAGE_MAP()


// CViewGhostRoll ���

#ifdef _DEBUG
void CViewGhostRoll::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewGhostRoll::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewGhostRoll ��Ϣ��������

void CViewGhostRoll::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GridCtrlInit();

}

void CViewGhostRoll::GridCtrlInit()
{
    int                 iCol; 
    int                 iColNumber;  
    

#if 0


#define M_T(x) #x
    const char* pszTitle[]  = { HRS_GR_STRIP_NO_LIST , "\0" };
    const char* pszUnit[]   = { HRS_GR_STRIP_NO_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_GR_STRIP_NO_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridStripNo.SetListMode(TRUE);
        m_GridStripNo.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridStripNo.SetModified(FALSE);

        m_GridStripNo.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridStripNo.SetFixedRowCount(1);
        m_GridStripNo.SetFixedColumnCount(1); 
        m_GridStripNo.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridStripNo.SetItem(&Item);
    }

    m_GridStripNo.AutoSize();

#endif
    
#define M_T(x) #x
    const char* pszTitle2[]  = { HRS_ROUGHROLL_SCHEDCALC_LIST , "\0" };
    const char* pszUnit2[]   = { HRS_ROUGHROLL_SCHEDCALC_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridGrRmSchedCalc.SetListMode(TRUE);
        m_GridGrRmSchedCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridGrRmSchedCalc.SetModified(FALSE);

        m_GridGrRmSchedCalc.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridGrRmSchedCalc.SetFixedRowCount(1);
        m_GridGrRmSchedCalc.SetFixedColumnCount(1); 
        m_GridGrRmSchedCalc.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle2[iCol],pszUnit2[iCol]);

        m_GridGrRmSchedCalc.SetItem(&Item);
    }

    m_GridGrRmSchedCalc.AutoSize();


        
#define M_T(x) #x
    const char* pszTitle3[]  = { HRS_FM_VR_PRECALC_DATA_LIST , "\0" };
    const char* pszUnit3[]   = { HRS_FM_VR_PRECALC_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FM_VR_PRECALC_DATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridGrFmPreCalc.SetListMode(TRUE);
        m_GridGrFmPreCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridGrFmPreCalc.SetModified(FALSE);

        m_GridGrFmPreCalc.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridGrFmPreCalc.SetFixedRowCount(1);
        //m_GridGrFmPreCalc.SetFixedColumnCount(1); 
        m_GridGrFmPreCalc.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle3[iCol],pszUnit3[iCol]);

        m_GridGrFmPreCalc.SetItem(&Item);
    }

    m_GridGrFmPreCalc.AutoSize();


    
#if 0

#define M_T(x) #x
    const char* pszTitle4[]  = { HRS_FM_PRECALC_BASICDATA_LIST , "\0" };
    const char* pszUnit4[]   = { HRS_FM_PRECALC_BASICDATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FM_PRECALC_BASICDATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridGrFmPreCalcBasic.SetListMode(TRUE);
        m_GridGrFmPreCalcBasic.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridGrFmPreCalcBasic.SetModified(FALSE);

        m_GridGrFmPreCalcBasic.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridGrFmPreCalcBasic.SetFixedRowCount(1);
        //m_GridGrFmPreCalcBasic.SetFixedColumnCount(1); 
        m_GridGrFmPreCalcBasic.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle4[iCol],pszUnit4[iCol]);

        m_GridGrFmPreCalcBasic.SetItem(&Item);
    }

    m_GridGrFmPreCalcBasic.AutoSize();


#endif
    
#define M_T(x) #x
    const char* pszTitle5[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit5[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridGrPDI.SetListMode(TRUE);
        m_GridGrPDI.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridGrPDI.SetModified(FALSE);

        m_GridGrPDI.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridGrPDI.SetFixedRowCount(1);
        m_GridGrPDI.SetFixedColumnCount(1); 
        m_GridGrPDI.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle5[iCol],pszUnit5[iCol]);

        m_GridGrPDI.SetItem(&Item);
    }

    m_GridGrPDI.AutoSize();


    return;
}


void CViewGhostRoll::InitStripNoGrid()
{
    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    //PDI��ʼ��
    m_GridGrPDI.DeleteNonFixedRows();

    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridGrPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridGrPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            SetTextBGCor(m_GridGrPDI, pPceData, i + 1, j);

            switch (j)
            { 
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.2f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break; 
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridGrPDI.SetItem(&Item);
        }

    }
    m_GridGrPDI.Refresh();

#if 0

    m_GridStripNo.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridStripNo.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridStripNo.InsertRow(strHeading);

        for(int j = 0; j < HRS_GR_STRIP_NO_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_GR_STRIP_NO_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_GR_STRIP_NO_FCE :
                Item.strText.Format(_T("%d"), 0);       //��֪����ʲô������
                break;
            case HRS_GR_STRIP_NO_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridStripNo.SetItem(&Item);
        }
    }

    m_GridStripNo.Refresh();

#endif
}


void CViewGhostRoll::RefreshRollPDIGrid()
{
    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    m_GridGrPDI.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridGrPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridGrPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            //SetTextBGCor(pPceData, Item);

            SetTextBGCor(m_GridGrPDI, pPceData, i + 1, j);

            switch (j)
            {
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.4f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.4f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridGrPDI.SetItem(&Item);
        }
    }

    m_GridGrPDI.Refresh();

    m_GridGrPDI.SetEditable(FALSE);

    //m_GridRoughRollPDI.EnableSelection(TRUE);
}


#if 1
void CViewGhostRoll::OnGridStripNoClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    if (ERR_SUCCESS == m_nSimulatorStatus)
    {
        AfxMessageBox("�������ƽ����У����ܸ����ְ壡");

        RefreshSchedCalcGrid();

        m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

        m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

        return;
    }

    m_pCurPceData->nSimulatorStatus = ERR_FAILED;

    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridGrPDI.GetFixedRowCount() )
    {
        return;
    }

    m_nRow = nRow;

    itemStr = m_GridGrPDI.GetItemText(nRow, 1);

    m_CellRange = m_GridGrPDI.GetSelectedCellRange();

    //ˢ�������
    m_strEditStripNo = itemStr;

    //PceData_Destroy(m_pCurPceData);

    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(itemStr);
    if (NULL == m_pCurPceData)
    {
        MessageBox("�˸ְ����ݶ�ȡʧ�ܣ�");

        return;
    }

    theApp.m_nPDIRow = nRow;

    //RefreshRollPDIGrid();

    InitStripNoGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    RefreshSchedCalcGrid();

    UpdateData(FALSE);

    return;
}
#endif


void CViewGhostRoll::RefreshSchedCalcGrid()
{
    CString itemStr = m_GridGrPDI.GetItemText(theApp.m_nPDIRow, 1);

    if (m_pCurPceData == NULL)
    {
        m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(itemStr);
        if (NULL == m_pCurPceData)
        {
            MessageBox("�˸ְ����ݶ�ȡʧ�ܣ�");

            return;
        }
    }

    char strHeading[5]={0};
    int  RowCount;

    int  nCountR1;
    int  nCountR2;

    nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
    nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;

    m_GridGrRmSchedCalc.DeleteNonFixedRows();

    for (int i = 0; i < nCountR1; i++)
    {
        RowCount = m_GridGrRmSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridGrRmSchedCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_RM_SCHEDCALC_PASS :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].strPass);
                break;
            case HRS_RM_SCHEDCALC_EGAP :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nEGAP);
                break;
            case HRS_RM_SCHEDCALC_ED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fED);
                break;
            case HRS_RM_SCHEDCALC_RGAP :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fRGAP);
                break;
            case HRS_RM_SCHEDCALC_RD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fRD);
                break;
            case HRS_RM_SCHEDCALC_BAR_H :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_H);
                break;
            case HRS_RM_SCHEDCALC_E_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fE_W);
                break;
            case HRS_RM_SCHEDCALC_BAR_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_W);
                break;

            case HRS_RM_SCHEDCALC_BAR_L :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_L);
                break;
            case HRS_RM_SCHEDCALC_E_RF :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fE_RF);
                break;
            case HRS_RM_SCHEDCALC_R_RF :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nR_RF);
                break;
            case HRS_RM_SCHEDCALC_SPD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fSPD);
                break;
            case HRS_RM_SCHEDCALC_R_ET :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fR_ET);
                break;
            case HRS_RM_SCHEDCALC_R_TOR :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nR_TOR);
                break;
            case HRS_RM_SCHEDCALC_Effic :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fEffic);
                break;
            case HRS_RM_SCHEDCALC_R_POW :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fR_POW);
                break;
            case HRS_RM_SCHEDCALC_DESC :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nDESC);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridGrRmSchedCalc.SetItem(&Item);

        }
    }

    for (int i = 0; i < nCountR2; i++)
    {
        RowCount = m_GridGrRmSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridGrRmSchedCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_RM_SCHEDCALC_PASS :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].strPass);
                break;
            case HRS_RM_SCHEDCALC_EGAP :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nEGAP);
                break;
            case HRS_RM_SCHEDCALC_ED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fED);
                break;
            case HRS_RM_SCHEDCALC_RGAP :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fRGAP);
                break;
            case HRS_RM_SCHEDCALC_RD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fRD);
                break;
            case HRS_RM_SCHEDCALC_BAR_H :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_H);
                break;
            case HRS_RM_SCHEDCALC_E_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fE_W);
                break;
            case HRS_RM_SCHEDCALC_BAR_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_W);
                break;

            case HRS_RM_SCHEDCALC_BAR_L :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_L);
                break;
            case HRS_RM_SCHEDCALC_E_RF :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fE_RF);
                break;
            case HRS_RM_SCHEDCALC_R_RF :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nR_RF);
                break;
            case HRS_RM_SCHEDCALC_SPD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fSPD);
                break;
            case HRS_RM_SCHEDCALC_R_ET :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fR_ET);
                break;
            case HRS_RM_SCHEDCALC_R_TOR :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nR_TOR);
                break;
            case HRS_RM_SCHEDCALC_Effic :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fEffic);
                break;
            case HRS_RM_SCHEDCALC_R_POW :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fR_POW);
                break;
            case HRS_RM_SCHEDCALC_DESC :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nDESC);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridGrRmSchedCalc.SetItem(&Item);

        }
    }

    RowCount = m_GridGrRmSchedCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridGrRmSchedCalc.InsertRow(strHeading);

    for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
            | DT_VCENTER
            | DT_SINGLELINE
            | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_RM_SCHEDCALC_PASS :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.strPass);
            break;
        case HRS_RM_SCHEDCALC_EGAP :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nEGAP);
            break;
        case HRS_RM_SCHEDCALC_ED :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fED);
            break;
        case HRS_RM_SCHEDCALC_RGAP :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fRGAP);
            break;
        case HRS_RM_SCHEDCALC_RD :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fRD);
            break;
        case HRS_RM_SCHEDCALC_BAR_H :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_H);
            break;
        case HRS_RM_SCHEDCALC_E_W :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fE_W);
            break;
        case HRS_RM_SCHEDCALC_BAR_W :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_W);
            break;

        case HRS_RM_SCHEDCALC_BAR_L :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_L);
            break;
        case HRS_RM_SCHEDCALC_E_RF :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fE_RF);
            break;
        case HRS_RM_SCHEDCALC_R_RF :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nR_RF);
            break;
        case HRS_RM_SCHEDCALC_SPD :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fSPD);
            break;
        case HRS_RM_SCHEDCALC_R_ET :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fR_ET);
            break;
        case HRS_RM_SCHEDCALC_R_TOR :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nR_TOR);
            break;
        case HRS_RM_SCHEDCALC_Effic :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fEffic);
            break;
        case HRS_RM_SCHEDCALC_R_POW :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fR_POW);
            break;
        case HRS_RM_SCHEDCALC_DESC :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nDESC);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridGrRmSchedCalc.SetItem(&Item);

    }


    m_GridGrRmSchedCalc.AutoSizeColumns();
    m_GridGrRmSchedCalc.Refresh();



    /* 
     * precalc
     */
    m_GridGrFmPreCalc.DeleteNonFixedRows();

    RowCount = m_GridGrFmPreCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridGrFmPreCalc.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_VR_PRECALC_DATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
            | DT_VCENTER
            | DT_SINGLELINE
            | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_VR_PRECALC_DATA_STAND :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.strStand);
            break; 
        case HRS_FM_VR_PRECALC_DATA_H_ENTRY :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHEntry);
            break;
        case HRS_FM_VR_PRECALC_DATA_H_EXIT :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHExit);
            break;
        case HRS_FM_VR_PRECALC_DATA_H_ACTUAL_EXIT :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stAveData.E3ActualData.dAveDeliveryGauge);
            break;
        case HRS_FM_VR_PRECALC_DATA_RED :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRED);
            break;
        case HRS_FM_VR_PRECALC_DATA_RF :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRF);
            break;
        case HRS_FM_VR_PRECALC_DATA_ACTUAL_RF :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stAveData.E3ActualData.dAveDraftRatio);
            break;
        case HRS_FM_VR_PRECALC_DATA_GAP :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fGAP);
            break;
        case HRS_FM_VR_PRECALC_DATA_ACTUAL_GAP :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stAveData.E3ActualData.dAveGap);
            break;
        case HRS_FM_VR_PRECALC_DATA_TQRQUE :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nTqrque);
            break;
        case HRS_FM_VR_PRECALC_DATA_POWER :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fPower);
            break;

        case HRS_FM_VR_PRECALC_DATA_KM :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nKM);
            break;
        case HRS_FM_VR_PRECALC_DATA_VR :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fV);
            break;
        case HRS_FM_VR_PRECALC_DATA_FLOW :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nFlow);
            break;
        case HRS_FM_VR_PRECALC_DATA_ENT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nENT);
            break;
        case HRS_FM_VR_PRECALC_DATA_EXT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nEXT);
            break;
        case HRS_FM_VR_PRECALC_DATA_BEND :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nBend);
            break;
        case HRS_FM_VR_PRECALC_DATA_VS :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nShift);
            break;
        case HRS_FM_VR_PRECALC_DATA_FS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fFS);
            break;
        case HRS_FM_VR_PRECALC_DATA_BS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fBS);
            break;
        case HRS_FM_VR_PRECALC_DATA_TENSION :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fTension);
            break;
        case HRS_FM_VR_PRECALC_DATA_ACTUAL_TENSION :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stAveData.E3ActualData.dAveTension);
            break;
        case HRS_FM_VR_PRECALC_DATA_LOOPER_DIS :
            Item.strText.Format(_T("%4.2f"),
                m_pCurPceData->stFinishRollSched.PreCalcDataE3.fLooperDis * 1000.0);
            break;
        case HRS_FM_VR_PRECALC_DATA_SPRAY_ISC :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.nSprayCode);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridGrFmPreCalc.SetItem(&Item);

    }

#if 1

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        RowCount = m_GridGrFmPreCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridGrFmPreCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_FM_VR_PRECALC_DATA_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_FM_VR_PRECALC_DATA_STAND :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].strStand);
                break; 
            case HRS_FM_VR_PRECALC_DATA_H_ENTRY :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHEntry);
                break;
            case HRS_FM_VR_PRECALC_DATA_H_EXIT :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHExit);
                break;
            case HRS_FM_VR_PRECALC_DATA_H_ACTUAL_EXIT :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stAveData.FMActualData[i].dAveDeliveryGauge);
                break;
            case HRS_FM_VR_PRECALC_DATA_RED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRED);
                break;
            case HRS_FM_VR_PRECALC_DATA_RF :
                Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRF);
                break;
            case HRS_FM_VR_PRECALC_DATA_ACTUAL_RF :
                Item.strText.Format(_T("%8.2f"),m_pCurPceData->stAveData.FMActualData[i].dAveRollingForce);
                break;
            case HRS_FM_VR_PRECALC_DATA_GAP :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fGAP);
                break;
            case HRS_FM_VR_PRECALC_DATA_ACTUAL_GAP :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stAveData.FMActualData[i].dAveGap);
                break;
            case HRS_FM_VR_PRECALC_DATA_TQRQUE :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nTqrque);
                break;
            case HRS_FM_VR_PRECALC_DATA_POWER :
                Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fPower);
                break;

            case HRS_FM_VR_PRECALC_DATA_KM :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nKM);
                break;
            case HRS_FM_VR_PRECALC_DATA_VR :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fV);
                break;
            case HRS_FM_VR_PRECALC_DATA_FLOW :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nFlow);
                break;
            case HRS_FM_VR_PRECALC_DATA_ENT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nENT);
                break;
            case HRS_FM_VR_PRECALC_DATA_EXT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nEXT);
                break;
            case HRS_FM_VR_PRECALC_DATA_BEND :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nBend);
                break;
            case HRS_FM_VR_PRECALC_DATA_VS :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nShift);
                break;
            case HRS_FM_VR_PRECALC_DATA_FS :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fFS);
                break;
            case HRS_FM_VR_PRECALC_DATA_BS :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fBS);
                break;
            case HRS_FM_VR_PRECALC_DATA_TENSION :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fTension);
                break;
            case HRS_FM_VR_PRECALC_DATA_ACTUAL_TENSION :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stAveData.FMActualData[i].dAveTension);
                break;
            case HRS_FM_VR_PRECALC_DATA_SPRAY_ISC :
//                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fLooperAngle);
                break;
            case HRS_FM_VR_PRECALC_DATA_LOOPER_DIS :
                Item.strText.Format(_T("%4.2f"),
                    m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fLooperDis * 1000.0);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridGrFmPreCalc.SetItem(&Item);

        }
    }

    m_GridGrFmPreCalc.AutoSizeColumns();
    m_GridGrFmPreCalc.Refresh();
#endif
    /* 
     * precalc basic
     */
#if 0

    m_GridGrFmPreCalcBasic.DeleteNonFixedRows();
    RowCount = m_GridGrFmPreCalcBasic.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridGrFmPreCalcBasic.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_PRECALC_BASICDATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
            | DT_VCENTER
            | DT_SINGLELINE
            | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_PRECALC_BASICDATA_STRIP_NO :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_FM_PRECALC_BASICDATA_RH2 :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRH2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RW2 :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRW2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RL2 :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRL2);
            break;
        case HRS_FM_PRECALC_BASICDATA_EXT_T :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fExtT);
            break;
        case HRS_FM_PRECALC_BASICDATA_FT0 :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fFT0);
            break;
        case HRS_FM_PRECALC_BASICDATA_LOADT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nLoadT);
            break;

        case HRS_FM_PRECALC_BASICDATA_SPRAY_C :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nSprayC);
            break;
        case HRS_FM_PRECALC_BASICDATA_V :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fV);
            break;
        case HRS_FM_PRECALC_BASICDATA_VOUT :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVOut);
            break;
        case HRS_FM_PRECALC_BASICDATA_VMAX :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVMax);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC1 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC1);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC2 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC2);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridGrFmPreCalcBasic.SetItem(&Item);

    }


    m_GridGrFmPreCalcBasic.AutoSizeColumns();
    m_GridGrFmPreCalcBasic.Refresh();


#endif
    /* 
     * PDI
     */
#if 0


    m_GridGrPDI.DeleteNonFixedRows();

    RowCount = m_GridGrPDI.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridGrPDI.InsertRow(strHeading);

    for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    =  DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        { 
        case 0 :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nSEQ);
            break;
        case HRS_ROLLSCHED_STRIP_NO :
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_ROLLSCHED_COMSEQ :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nCOMSEQ);
            break;
        case HRS_ROLLSCHED_GRADE :
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strGRADE);
            break;
        case HRS_ROLLSCHED_SIGN :
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSIGN);
            break;
        case HRS_ROLLSCHED_C_H :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stRollSched.fC_H);
            break;
        case HRS_ROLLSCHED_C_W :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fC_W);
            break;
        case HRS_ROLLSCHED_FSB :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nFSB);
            break;
        case HRS_ROLLSCHED_R_H :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fR_H);
            break;
        case HRS_ROLLSCHED_RSB :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nRSB);
            break;
        case HRS_ROLLSCHED_S_H :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fS_H);
            break;
        case HRS_ROLLSCHED_S_W :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fS_W);
            break;
        case HRS_ROLLSCHED_S_L :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fS_L);
            break;
        case HRS_ROLLSCHED_WT :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fWT);
            break;
        case HRS_ROLLSCHED_WE :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fWE);
            break;
        case HRS_ROLLSCHED_FDT :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fFDT);
            break;
        case HRS_ROLLSCHED_EXT :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fEXT);
            break;
        case HRS_ROLLSCHED_RDT :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fRDT);
            break;
        case HRS_ROLLSCHED_CTC :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fCTC);
            break;
        case HRS_ROLLSCHED_QUAL :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nQUAL);
            break;
        case HRS_ROLLSCHED_SFC :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nSFC);
            break;
        case HRS_ROLLSCHED_STA :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nSTA);
            break;
        case HRS_ROLLSCHED_HTT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nHTT);
            break;
        case HRS_ROLLSCHED_CP :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRollSched.nCP);
            break;
        case HRS_ROLLSCHED_CROWN :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stRollSched.fCROWN);
            break;
        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }

        m_GridGrPDI.SetItem(&Item);
    }

    m_GridGrPDI.Refresh();
#endif

    //ˢ�������
    m_strEditStripNo = itemStr;

    return;
}


void CViewGhostRoll::OnEnChangeEditStripNo()
{
    // TODO:  ����ÿؼ��� RICHEDIT �ؼ�������������
    // ���͸�֪ͨ��������д CFormView::OnInitDialog()
    // ���������� CRichEditCtrl().SetEventMask()��
    // ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

    // TODO:  �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

#if 1

    int nSeq;

    nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strEditStripNo);
    if (nSeq < 0)
    {
        return;
    }

    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(m_strEditStripNo);
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("�ְ岻���ڣ�");

        m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow,1,theApp.m_nPDIRow,HRS_GR_STRIP_NO_ITEM_NUM-1);

        m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

        return;
    }

    m_GridGrPDI.SetFocusCell(nSeq, 2);
    m_GridGrPDI.SetSelectedRange(nSeq,1,nSeq,HRS_GR_STRIP_NO_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    theApp.m_nPDIRow = nSeq;

    m_pCurPceData->nSimulatorStatus = ERR_FAILED;
    RefreshSchedCalcGrid();

#endif
}


void CViewGhostRoll::SetRollSchedMgr(CPceDataMgr * pRollSchedMgr) 
{
    m_pRollSchedMgr = pRollSchedMgr;

    InitStripNoGrid();

    RefreshSchedCalcGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    m_nRow = 1;


    UpdateData(FALSE);
    return;
}

void CViewGhostRoll::SetRMSched(HRS_RM_SCHED &RMSched)
{
    int nRet = -1;

    nRet = PceData_SetRmSchedCalcFromCalc(m_pCurPceData, &RMSched, NULL);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������ô�����̴���!");
        return;
    }
    m_pCurPceData->nRoughRollSchedStatus = nRet;

    RefreshSchedCalcGrid();

    return;
}

void CViewGhostRoll::SetFMSched(HRS_FM_SCHED &FMSched)
{
    int nRet = -1;

    nRet = PceData_SetFmSchedCalcFromCalc(m_pCurPceData, &FMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������þ�����̴���!");
        return;
    }
    m_pCurPceData->nFinishRollSchedStatus = nRet;

    RefreshSchedCalcGrid();

    return;
}


void CViewGhostRoll::SetRollEnd()
{
    m_pCurPceData->nRollingStatus = ERR_FAILED;

    m_pCurPceData->nRolledStatus = ERR_SUCCESS;

    RefreshRollPDIGrid();

    //RefreshSchedCalcGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    m_nSimulatorStatus = ERR_FAILED;

    GetDlgItem(IDC_FM_SIMULATION_CLAC)->EnableWindow(TRUE);
    GetDlgItem(IDC_VR_ROLL)->EnableWindow(TRUE);
    return;
}


void CViewGhostRoll::SetRolling()
{
    m_pCurPceData->nRollingStatus = ERR_SUCCESS;

    RefreshRollPDIGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    //RefreshSchedCalcGrid();

    return;
}


void CViewGhostRoll::SetL1AveDataOverTime()
{

    m_pAveClacDialog->ShowWindow(SW_HIDE);

    m_pCurPceData->nSimulatorStatus = ERR_FAILED;

    m_nSimulatorStatus = ERR_FAILED;

    GetDlgItem(IDC_VR_ROLL)->EnableWindow(TRUE);
    GetDlgItem(IDC_FM_SIMULATION_CLAC)->EnableWindow(TRUE);

    AfxMessageBox("L1����ʧ�ܣ�����ͨ�Ż��������!");

    return;
}



void CViewGhostRoll::SetL1AveData(HRS_L1_SIMULATE_ALL_AVEDATA &AveData)
{
    int nRet = -1;

    //if (NULL != m_pAveClacDialog)
    //{
    //    m_pAveClacDialog->ShowWindow(SW_HIDE);

    //    delete m_pAveClacDialog;
    //}

    m_pAveClacDialog->ShowWindow(SW_HIDE);

    nRet = PceData_SetL1AveCalcFromCalc(m_pCurPceData, AveData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������þ���L1���ݾ�ֵ����!");
        return;
    }

    m_pCurPceData->nSimulatorStatus = ERR_SUCCESS;

    RefreshSchedCalcGrid();

    RefreshRollPDIGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridGrPDI.ScrollToRow(theApp.m_nPDIRow);

    m_nSimulatorStatus = ERR_FAILED;

    GetDlgItem(IDC_VR_ROLL)->EnableWindow(TRUE);
    GetDlgItem(IDC_FM_SIMULATION_CLAC)->EnableWindow(TRUE);
    return;
}


int CViewGhostRoll::GetRMCfgData()
{
    HRS_RM_ALL_PASS AllPass;
    HRS_RM_ALL_SPEED AllSpeed;
    HRS_RM_ALL_DELIVERY_GAUGE AllDeliveryGauge;

    //��ȡ����
    if (ERR_FAILED == GetRMGuiData())
    {
        MessageBox("�������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }

    if (m_RmAllCalcData.StrategyData.dTransferBarThick <= 0)
    {
        m_RmAllCalcData.StrategyData.dTransferBarThick = 
            m_RmAllCalcData.PlanData.dTransferBarGauge;

    }


    if (ERR_FAILED == HRS_RMCalc_Speed(&m_RmAllCalcData, 
        &AllPass,
        &AllDeliveryGauge,
        &AllSpeed))
    {
        MessageBox("�������ݻ�ȡʧ��!");
        return ERR_FAILED;
    }

    //���ݸ�ֵ
    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        /*m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit = 
            AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[i];*/

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed = 
            AllSpeed.Rm1stPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraft = 
            AllPass.Rm1stPass.adPassDraftRatio[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth = 
            m_pCurPceData->stRollSched.fC_W;

    }

    for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        /*m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Exit = 
            AllDeliveryGauge.Rm2ndDeliveryGauge.adDeliveryGauge[i];*/

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fSpeed = 
            AllSpeed.Rm2ndPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fDraft = 
            AllPass.Rm2ndPass.adPassDraftRatio[i];

        if (AllPass.Rm2ndPass.adPassDraftRatio[i] > 0)
        {
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth = 
                m_pCurPceData->stRollSched.fC_W;
        }
    }

    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit = 
            AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[i];
    }

    for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Exit = 
            AllDeliveryGauge.Rm2ndDeliveryGauge.adDeliveryGauge[i];
    }


    m_pCurPceData->stRoughRollStra.emPassMode = 
        (HRS_PASS_MODE_EM)AllPass.Rm1stPass.nPassMode;

    return ERR_SUCCESS;
}


int CViewGhostRoll::GetRMGuiData()
{
    int nRet = -1;

    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");

        return ERR_FAILED;
    }

    memset(&m_RmAllCalcData, 0, sizeof(HRS_RM_ALL_DATA));

    nRet = PceData_GetPdiForCalc(m_pCurPceData, &m_RmAllCalcData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return nRet;
    }

    nRet = PceData_GetRmStraDataForCalc(m_pCurPceData, &m_RmAllCalcData.StrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return nRet;
    }

    m_RmAllCalcData.StrategyData.dExtTemp = m_RmAllCalcData.PlanData.dDischargeTemp;
    memcpy(&m_RmAllCalcData.PlateData.SlabeData, 
        &m_RmAllCalcData.PlanData.SlabData, 
        sizeof(HRS_SLAB_DATA));
    m_RmAllCalcData.PlateData.dSlabeEntryTemp = 1600;                //����

    // ��ȡ������
    CHRSEquipParaMgr *pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return nRet;
    }

    nRet = pModule->GetAllStandPara(&m_RmAllCalcData.AllStandPara);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸����ʧ��!");
        return nRet;
    }

    CHRSEquipParaMgr_Destroy(pModule);

    //���ο�������
    memcpy(m_RmAllCalcData.DeformFactor.szSteelGrade, 
        m_RmAllCalcData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);

    if (pFactor != NULL )
    {
        m_RmAllCalcData.DeformFactor = *pFactor;
    }
    else
    {
        m_RmAllCalcData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;               // ��������
        m_RmAllCalcData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_RmAllCalcData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_RmAllCalcData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_RmAllCalcData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        m_RmAllCalcData.DeformFactor.dReserve1 = 1;
        m_RmAllCalcData.DeformFactor.dReserve2 = 1;
    }

    return ERR_SUCCESS;
}


int CViewGhostRoll::HRS_RMCalc_Speed(HRS_RM_ALL_DATA *pAllData,
                                     HRS_RM_ALL_PASS *pAllPass,
                                     HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                                     HRS_RM_ALL_SPEED *pAllSpeed)
{
    HRS_SLAB_DATA               *pSlabData;

    HRS_RM_ALL_ENTRY_PARA        AllEntry;        // �����¶Ⱥ��ٶ�ʹ�õĲ���   

    int                          nRet;

    if ( pAllData == NULL 
        || pAllSpeed == NULL 
        || NULL == pAllDeliveryGauge 
        || NULL == pAllPass)
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    nRet = HRS_RML2Calc_GetSteelData(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    //ѹ���ʲ�������
    //HRS_TABLE_RM_DRAFTRATIO RmDraftTab[6];
    memset(m_RmDraftTab, 0, sizeof(HRS_TABLE_RM_DRAFTRATIO) * HRS_RM_DRAFT_NUM_MAX);
    HRS_RML2Calc_RmDraftPara(pAllData, pAllPass, m_RmDraftTab, HRS_RM_DRAFT_NUM_MAX);

    nRet = HRS_RML2Calc_CalcGauge(pAllPass, pAllDeliveryGauge,
                                  pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox(pAllData->szOutErr);
        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareEntryPara(pAllData, 
        pAllPass, 
        pAllDeliveryGauge, 
        &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, pAllSpeed);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewGhostRoll::GetFMGuiData()
{
    int nRet = -1;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return ERR_FAILED;
    } 

    // ��ȡGUI�������趨���ݸ�����
    nRet = PceData_GetPdiForCalc(m_pCurPceData, &m_FmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡPDI���ݴ���!");
        return nRet;
    }

    nRet = PceData_GetFmStraDataForCalc(m_pCurPceData, 
                                        &m_FmAllData.FMStrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�����������ݴ���!");
        return nRet;
    }

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return nRet;
    }

    pModule->GetAllStandPara(&m_FmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    m_FmAllData.FMStrategyData.FMStraData.dFMEntryTemp =
                                                m_pCurPceData->stRollSched.fFDT;

    //���ּ������

    //���ο�������
    memcpy(m_FmAllData.DeformFactor.szSteelGrade, 
           m_FmAllData.PlanData.SlabData.szSteelGradeName, 
           HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);

    if (pFactor != NULL )
    {
        m_FmAllData.DeformFactor = *pFactor;
    }
    else
    {
        m_FmAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;    // ��������
        m_FmAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_FmAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_FmAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_FmAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        m_FmAllData.DeformFactor.dReserve1 = 1;
        m_FmAllData.DeformFactor.dReserve2 = 1;
    }

    return ERR_SUCCESS;
}


int CViewGhostRoll::HRS_FM_QuerySpeedTable(HRS_FM_ALL_DATA *pAllData,
                                           HRS_TABLE_FM_SPEED *pSpeedTable)
{
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    if (pAllData == NULL || pSpeedTable == NULL)
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;
    pPlanData     = &(pAllData->PlanData);

    pSpeedTable->nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pSpeedTable->nQualityCode = pAllData->PlanData.nQualityCode;
    pSpeedTable->nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pSpeedTable->nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pSpeedTable->nFinalTempLevel = SteelLevel->nFinalTempLevel;

    return ERR_SUCCESS;
}


int  CViewGhostRoll::HRS_GetStrategyData(HRS_FM_ALL_DATA *pAllData,
                                         HRS_FM_DRAFT_RATIO *pDraftRatio,
                                         HRS_TABLE_FM_SPEED *pSpeedTable)
{
    HRS_FM_DRAFTRATIO_QUERY_INFO    DraftRatioQueryInfo;
    int                             nRet;

    if (NULL == pAllData || NULL == pDraftRatio || NULL == pSpeedTable)
    {
        return ERR_FAILED;
    }

    // ������ѯ�����ȼ���Ϣ
    nRet = HRS_FM_QuerySlabLevel(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����׼������
    nRet = HRS_FM_QueryDraftRatioTable_PrepPara(pAllData, &DraftRatioQueryInfo);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����
    nRet = HRS_FM_QueryDraftRatioTable(&DraftRatioQueryInfo, 
                                       pDraftRatio,
                                       pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FM_QuerySpeedTable(pAllData, pSpeedTable);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmSpeedTab_Search(pSpeedTable, pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewGhostRoll::GetFMCfgData()
{
    if (NULL == m_pCurPceData)
    {
        return ERR_FAILED;
    }

    HRS_FM_DRAFT_RATIO DraftRatio;
    HRS_TABLE_FM_SPEED SpeedPara;

    //��ȡ����
    if (ERR_FAILED == GetFMGuiData())
    {
        MessageBox("CViewGhostRoll::GetFMCfgData(), GetFMGuiData(): �������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }

    if (ERR_FAILED == HRS_GetStrategyData(&m_FmAllData,&DraftRatio, &SpeedPara))
    {
        MessageBox("CViewGhostRoll::GetFMCfgData(), HRS_GetStrategyData(): �����������ݻ�ȡʧ��!");
        return ERR_FAILED;
    }

    //���ݸ�ֵ
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarThick = 
        m_pCurPceData->stRollSched.fR_H;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarWidth = 
        m_pCurPceData->stRollSched.fC_W;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarTemp  = 
        m_pCurPceData->stRollSched.fRDT;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fFET      = 0;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fThickCorr = 0;

    m_pCurPceData->stFinishRollStra.FinishRollStraData.fACC1 = 
        SpeedPara.dTempAccelator;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fMaxSpeed = 
        SpeedPara.dMaxSpeed;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fThreadSpeed = 
        SpeedPara.dThreadSpeed;
    m_pCurPceData->stFinishRollStra.FinishRollStraData.fACC2 = 
        SpeedPara.dPowerAccelator;


    for (int i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadValue[i] = 
            DraftRatio.adDraftRatio[i];
    }

    return ERR_SUCCESS;
}


void CViewGhostRoll::GetCalcData(HRS_RM_DATA_FROM_GUI &RMGUIData, 
                                 HRS_FM_DATA_FROM_GUI &FMGUIData)
{
    //��������
    memset(&RMGUIData, 0, sizeof(HRS_RM_DATA_FROM_GUI));

    RMGUIData.PlanData     = m_RmAllCalcData.PlanData;
    RMGUIData.StrategyData = m_RmAllCalcData.StrategyData;

    //��������
    memset(&FMGUIData, 0, sizeof(HRS_FM_DATA_FROM_GUI));

    if (m_FmAllData.FMStrategyData.FMStraData.dTransferBarThick <= 0)
    {
        m_FmAllData.FMStrategyData.FMStraData.dTransferBarThick = 
            m_FmAllData.PlanData.dTransferBarGauge;
    }

    if (m_FmAllData.FMStrategyData.FMStraData.dTransferBarWidth <= 0)
    {
        m_FmAllData.FMStrategyData.FMStraData.dTransferBarWidth = 
            m_FmAllData.PlanData.SlabData.dSlabWidth;
    }

    FMGUIData.PlanData     = m_FmAllData.PlanData;
    FMGUIData.StrategyData = m_FmAllData.FMStrategyData;

    return ;
}


void CViewGhostRoll::OnBnClickedButCalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    int nRet = -1;

    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return;
    }

    if (NULL == theApp.m_pGUIComm)
    {
        return;
    }

    HRS_L1_RM_SCHED RMGUISched;

    if (ERR_FAILED == m_pCurPceData->nRoughRollSchedStatus)
    {
        AfxMessageBox("����û�м��㣬���ȼ���������!");
        return;
    }

    if (ERR_FAILED == m_pCurPceData->nFinishRollSchedStatus)
    {
        AfxMessageBox("����û�м��㣬���ȼ��㾫�����!");
        return;
    }

    if (ERR_FAILED == m_pCurPceData->nSimulatorStatus)
    {
        AfxMessageBox("L1����û�м��㣬���ȼ���L1����!");
        return;
    }

    RMGUISched.stRoughRollSched = m_pCurPceData->stRealRoughRollSched;
    //FMGUISched.stFinishRollSched = m_pCurPceData->stRealFinishRollSched;

    PceData_GetSlabForCalc(m_pCurPceData, RMGUISched);

    theApp.m_pGUIComm->SetL1SimuRMData(&RMGUISched);

    //theApp.m_pGUIComm->SetL1SimuFMData(&FMGUISched);

    m_pCurPceData->nSimulatorStatus = ERR_FAILED;

    m_pCurPceData->nRollingStatus = ERR_SUCCESS;

    m_nSimulatorStatus = ERR_SUCCESS;

    RefreshSchedCalcGrid();

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 1, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    GetDlgItem(IDC_FM_SIMULATION_CLAC)->EnableWindow(FALSE);
    GetDlgItem(IDC_VR_ROLL)->EnableWindow(FALSE);

    return;
}


void CViewGhostRoll::OnBnClickedSimulationButCalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    int nRet = -1;

    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return;
    }

    if (NULL == theApp.m_pGUIComm)
    {
        return;
    }

    HRS_L1_FM_SCHED stFMGUISched;

    if (ERR_FAILED == m_pCurPceData->nRoughRollSchedStatus)
    {
        AfxMessageBox("����û�м��㣬���ȼ���������!");
        return;
    }

    if (ERR_FAILED == m_pCurPceData->nFinishRollSchedStatus)
    {
        AfxMessageBox("����û�м��㣬���ȼ��㾫�����!");
        return;
    }

    stFMGUISched.stFinishRollSched = m_pCurPceData->stRealFinishRollSched;

    nRet = theApp.m_pGUIComm->SetL1SimuFMData(&stFMGUISched);

    m_nSimulatorStatus = ERR_SUCCESS;

    m_pCurPceData->nRolledStatus = ERR_FAILED;

    m_GridGrPDI.SetSelectedRange(theApp.m_nPDIRow, 1, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    if (NULL == m_pAveClacDialog)
    {
        m_pAveClacDialog = new CAveClacDialog;
        m_pAveClacDialog->Create(IDD_AVE_CLAC , this);
    }

    m_pAveClacDialog->ShowWindow(SW_SHOW);

    GetDlgItem(IDC_VR_ROLL)->EnableWindow(FALSE);
    GetDlgItem(IDC_FM_SIMULATION_CLAC)->EnableWindow(FALSE);

    theApp.m_nAverageing = ERR_SUCCESS;
    //theApp.m_nRolling = ERR_SUCCESS;

    theApp.m_nAveTotalTimes = 0;

    return;
}
