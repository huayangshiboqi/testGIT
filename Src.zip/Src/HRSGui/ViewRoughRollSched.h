#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"


// CViewRoughRollSched ������ͼ

class CViewRoughRollSched : public CFormView
{
    DECLARE_DYNCREATE(CViewRoughRollSched)

protected:
    CViewRoughRollSched();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewRoughRollSched();

    CGridCtrl m_GridRoughRollPDI;
    CGridCtrl m_GridRoughRollBasicData;
    CGridCtrl m_GridRoughRollSchedCalc;
    void GridCtrlInit();

    CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls

public:
    enum { IDD = IDD_VIEW_ROUGHROLL_SCHED };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()

public:
    virtual void OnInitialUpdate();

    void SetRollSchedMgr(CPceDataMgr * pRollSchedMgr) 
    {
        m_pRollSchedMgr = pRollSchedMgr;
        InitRollSchedGrid();
    }

    afx_msg void OnGridRoughRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult);

private:
    CPceDataMgr *     m_pRollSchedMgr;
    PCE_DATA *          m_pCurPceData;

    void RefreshRoughRollSchedGrid();
    void InitRollSchedGrid();
public:
    afx_msg void OnBnClickedButRmCalc();
};


