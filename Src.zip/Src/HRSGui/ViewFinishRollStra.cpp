// ViewFinishRollStra.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewFinishRollStra.h"

#include "WinCommon.h "
#include "NG_errno.h" 
#include "NG_malloc.h"
#include "HRS_Global.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "HRS_EquipParaMgr.h"
#include "HRS_FMCalc.h"

#include "HRS_L1Comm.h"
#include "HRS_CalcData.h"
#include "GridCtrlFunc.h"


// CViewFinishRollStra

IMPLEMENT_DYNCREATE(CViewFinishRollStra, CFormView)

CViewFinishRollStra::CViewFinishRollStra()
    : CFormView(CViewFinishRollStra::IDD)
    , m_strStripNo(_T(""))
    , m_BRadioFDTCMode(FALSE)
    , m_bCheckFDTCFFUse(FALSE)
    , m_CheckISCF34(FALSE)
    , m_CheckISCF45(FALSE)
    , m_CheckISCF56(FALSE)
    , m_CheckISCF67(FALSE)
    , m_CheckRadio1(FALSE)
    , m_CheckRadio2(TRUE)
    , m_bCheckDescAuto(FALSE)
    , m_strCombDescSprayCod(_T(""))
    , m_pCurPceData(NULL)
    , m_bCheckRemoteCalc(FALSE)
{
}


CViewFinishRollStra::~CViewFinishRollStra()
{
    if (m_pCurPceData != NULL)
    {
//        PceData_Destroy(m_pCurPceData);
        m_pCurPceData = NULL;
    }
}

void CViewFinishRollStra::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_GridControl(pDX, IDC_GRID_FM_STRA_PDI, m_GridFinishRollPDI);
    DDX_GridControl(pDX, IDC_GRID_FM_STRA_PRECALC_SCHED, m_GridFinishRollPreCalc);

    DDX_GridControl(pDX, IDC_GRID_FINISHROLL_STRA_DATA, m_GridFMStraData);
    DDX_GridControl(pDX, IDC_GRID_FM_LOADDATA, m_GridFMLoadData);
    DDX_Control(pDX, IDC_COMB_FM_STRIPNO, m_ComboxStripNo);
    DDX_CBString(pDX, IDC_COMB_FM_STRIPNO, m_strStripNo);
    DDX_Radio(pDX, IDC_RAD_FDTC_SPEED, m_BRadioFDTCMode);
    DDX_Check(pDX, IDC_CHECK_FDTC_FF_USE, m_bCheckFDTCFFUse);
    DDX_Control(pDX, IDC_RAD_FDTC_SPEED, m_RadCtlFDTCSpeed);
    DDX_Control(pDX, IDC_RAD_FDTC_WATER, m_RadCtlFDTCWater);
    DDX_Check(pDX, IDC_CHECK_ISC_F34, m_CheckISCF34);

    DDX_Check(pDX, IDC_CHECK_ISC_F45, m_CheckISCF45);
    DDX_Check(pDX, IDC_CHECK_ISC_F56, m_CheckISCF56);
    DDX_Check(pDX, IDC_CHECK_ISC_F67, m_CheckISCF67);

    DDX_Check(pDX, IDC_RADIO1, m_CheckRadio1);
    //DDX_Check(pDX, IDC_RADIO2, m_CheckRadio2);

    DDX_Check(pDX, IDC_CHECK_DESC_AUTO, m_bCheckDescAuto);
    DDX_Control(pDX, IDC_COMB_DESC_SPRAY_COD, m_CombCtlDESCSprayCod);
    DDX_CBString(pDX, IDC_COMB_DESC_SPRAY_COD, m_strCombDescSprayCod);
    DDX_Check(pDX, IDC_FM_CHECK_REMOTE, m_bCheckRemoteCalc);
}

BEGIN_MESSAGE_MAP(CViewFinishRollStra, CFormView)
    ON_CBN_SELCHANGE(IDC_COMB_FM_STRIPNO, &CViewFinishRollStra::OnCbnSelchangeCombFmStripno)
    ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_FINISHROLL_STRA_DATA, OnGridEndLableEdit)
    ON_NOTIFY(NM_CLICK, IDC_GRID_FINISHROLL_STRA_DATA, OnGridFinishRollStraDataClick)
    ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_FM_LOADDATA, OnGridLoadDataEndLableEdit)
    ON_NOTIFY(NM_CLICK, IDC_GRID_FM_LOADDATA, OnGridFinishRollLoadDataClick)
    ON_BN_CLICKED(IDC_RAD_FDTC_SPEED, &CViewFinishRollStra::OnBnClickedRadFdtcSpeed)
    ON_BN_CLICKED(IDC_RAD_FDTC_WATER, &CViewFinishRollStra::OnBnClickedRadFdtcWater)
    ON_BN_CLICKED(IDC_CHECK_FDTC_FF_USE, &CViewFinishRollStra::OnBnClickedCheckFdtcFfUse)
    ON_BN_CLICKED(IDC_CHECK_ISC_F34, &CViewFinishRollStra::OnBnClickedCheckIscF34)
    ON_BN_CLICKED(IDC_CHECK_ISC_F45, &CViewFinishRollStra::OnBnClickedCheckIscF45)
    ON_BN_CLICKED(IDC_CHECK_ISC_F56, &CViewFinishRollStra::OnBnClickedCheckIscF56)
    ON_BN_CLICKED(IDC_CHECK_ISC_F67, &CViewFinishRollStra::OnBnClickedCheckIscF67)
    ON_BN_CLICKED(IDC_CHECK_DESC_AUTO, &CViewFinishRollStra::OnBnClickedCheckDescAuto)
    ON_CBN_SELCHANGE(IDC_COMB_DESC_SPRAY_COD, &CViewFinishRollStra::OnCbnSelchangeCombDescSprayCod)
    ON_BN_CLICKED(IDC_BUT_FM_STRA_SAVE, &CViewFinishRollStra::OnBnClickedButFmStraSave)
    ON_BN_CLICKED(IDC_BUT_FM_STRA_CLEAN, &CViewFinishRollStra::OnBnClickedButFmStraClean)

    ON_NOTIFY(NM_CLICK, IDC_GRID_FM_STRA_PDI, OnGridFinishRollPDIClick)
    ON_BN_CLICKED(IDC_BUT_FM_STRA_CALC, &CViewFinishRollStra::OnBnClickedButFmStraCalc)
    ON_BN_CLICKED(IDC_FM_CHECK_REMOTE, &CViewFinishRollStra::OnBnClickedFmCheckRemote)
    ON_BN_CLICKED(IDC_RADIO1, &CViewFinishRollStra::OnBnClickedRadio1)
    ON_BN_CLICKED(IDC_RADIO2, &CViewFinishRollStra::OnBnClickedRadio2)
END_MESSAGE_MAP()


// CViewFinishRollStra ���

#ifdef _DEBUG
void CViewFinishRollStra::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewFinishRollStra::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewFinishRollStra ��Ϣ��������

void CViewFinishRollStra::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���


    GridCtrlInit();
    //RefreshGridFMStraData();


}


void CViewFinishRollStra::GridCtrlInit()
{
    
    int                 iCol; 
    int                 iColNumber;  
    int                 iRowNumber;
    

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_FINISHROLL_STRA_DATA_LIST , "\0" };
    const char* pszUnit[]   = { HRS_FINISHROLL_STRA_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������Ա��������������
     */
    try
    {
        iColNumber = HRS_FINISHROLL_STRA_DATA_COL_NUM;
        iRowNumber = HRS_FINISHROLL_STRA_DATA_ROW_NUM;

        //m_GridFMStraData.SetGridStyle(GRID_BLUE);
        //m_GridFMStraData.SetListMode(TRUE);
        m_GridFMStraData.SetTextBkColor(GRID_BG_COR);
        //m_GridFMStraData.SetBkColor(GRID_BG_COR);
        m_GridFMStraData.SetModified(FALSE);

        m_GridFMStraData.SetColumnCount(iColNumber);
        m_GridFMStraData.SetRowCount(iRowNumber);
        //m_GridFMStraData.SetRowCount(iColNumber);

        //m_GridFMStraData.SetFixedRowCount(1);
        //m_GridFMStraData.SetFixedColumnCount(1); 
        m_GridFMStraData.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    for (int i = 0; i < iColNumber; i++)
    {
        m_GridFMStraData.SetColumnWidth(i, 150);
    }
    for (int i = 0; i < iRowNumber; i++)
    {
        m_GridFMStraData.SetRowHeight(i, 30);
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < HRS_FINISHROLL_STRA_DATA_ITEM_NUM; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  iCol % 3;
        Item.col        =  (iCol / 3) * 2;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridFMStraData.SetItem(&Item);
    }

    //m_GridFMStraData.AutoSize();



// MOVE
#define M_T(x) #x
    const char* pszTitle2[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit2[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridFinishRollPDI.SetListMode(TRUE);
        m_GridFinishRollPDI.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridFinishRollPDI.SetModified(FALSE);

        m_GridFinishRollPDI.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridFinishRollPDI.SetFixedRowCount(1);
        m_GridFinishRollPDI.SetFixedColumnCount(1); 
        m_GridFinishRollPDI.SetEditable(TRUE); 

    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    int anPDIWidth[HRS_ROLL_SCHED_ITEM_NUM] = {
        50, 95, 70, 70, 60, 
        70, 70, 45, 70, 45, 
        70, 70, 70, 70, 75, 
        60, 60, 60, 60, 55, 
        55, 40, 40, 40, 70
    };

    /*
     * ��ʼ��PDI����ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle2[iCol],pszUnit2[iCol]);

        m_GridFinishRollPDI.SetItem(&Item);

        m_GridFinishRollPDI.SetColumnWidth(iCol, anPDIWidth[iCol]);

    }

//    m_GridFinishRollPDI.AutoSize();



#define M_T(x) #x
    const char* pszTitle3[]  = { HRS_FM_PRECALC_DATA_LIST , "\0" };
    const char* pszUnit3[]   = { HRS_FM_PRECALC_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FM_PRECALC_DATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridFinishRollPreCalc.SetListMode(TRUE);
        m_GridFinishRollPreCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridFinishRollPreCalc.SetModified(FALSE);

        m_GridFinishRollPreCalc.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridFinishRollPreCalc.SetFixedRowCount(1);
        //m_GridFinishRollPreCalc.SetFixedColumnCount(1); 
        m_GridFinishRollPreCalc.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    int anPreCalcWidth[HRS_FM_PRECALC_DATA_ITEM_NUM] = {
        60, 100, 95, 65, 60, 
        70, 95, 95, 70, 70, 
        90, 65, 65, 75, 80, 
        65, 65, 95, 120, 78 
    };
    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle3[iCol],pszUnit3[iCol]);

        m_GridFinishRollPreCalc.SetItem(&Item);

        m_GridFinishRollPreCalc.SetColumnWidth(iCol, anPreCalcWidth[iCol]);
    }

//    m_GridFinishRollPreCalc.AutoSize();
// END

    return;
}

void CViewFinishRollStra::RefreshGridFMStraData()
{
    m_GridFMStraData.DeleteAllItems();


    int                 iCol; 
    int                 iColNumber;  
    int                 iRowNumber;
    

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_FINISHROLL_STRA_DATA_LIST , "\0" };
    const char* pszUnit[]   = { HRS_FINISHROLL_STRA_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FINISHROLL_STRA_DATA_COL_NUM;
        iRowNumber = HRS_FINISHROLL_STRA_DATA_ROW_NUM;

        //m_GridFMStraData.SetGridStyle(GRID_BLUE);
        //m_GridFMStraData.SetListMode(TRUE);
        m_GridFMStraData.SetTextBkColor(GRID_BG_COR);
        //m_GridFMStraData.SetBkColor(GRID_BG_COR);
        m_GridFMStraData.SetModified(FALSE);

        m_GridFMStraData.SetColumnCount(iColNumber);
        m_GridFMStraData.SetRowCount(iRowNumber);
        //m_GridFMStraData.SetRowCount(iColNumber);

        //m_GridFMStraData.SetFixedRowCount(1);
        //m_GridFMStraData.SetFixedColumnCount(1); 
        m_GridFMStraData.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    for (int i = 0; i < iColNumber; i++)
    {
        m_GridFMStraData.SetColumnWidth(i, 150);
    }
    for (int i = 0; i < iRowNumber; i++)
    {
        m_GridFMStraData.SetRowHeight(i, 30);
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < HRS_FINISHROLL_STRA_DATA_ITEM_NUM; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  iCol % 3;
        Item.col        =  (iCol / 3) * 2;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        //Item.crBkClr = STAC_BG_COR;  //test

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridFMStraData.SetItem(&Item);

        //m_GridFMStraData.SetItemBkColour(iCol % 3, (iCol / 3) * 2, GRID_BG_COR);
    }

    //m_GridFMStraData.AutoSize();



    if (m_pCurPceData == NULL)
    {
        return;
    }

    /********/
    /* 
     * CHEKE�ؼ���ʼ��
     */
    typedef struct
    {
        CGridBtnCellBase::STRUCT_DRAWCTL DrawCtl;  // most btn props here
        int iBtnNbr;                        // which btn within cell does this define?
        const char* pszBtnText;             // text associated with pushbutton or NULL
    }   STRUCT_CTL;

    //DFCS_BUTTONCHECK
    STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
    }; 

    if (!m_pCurPceData->stFinishRollStra.FinishRollStraData.bE3Dummy)
    {
        DrawCtlAry[0].DrawCtl.sState = DFCS_BUTTONCHECK;
    }
    else
    {
        DrawCtlAry[0].DrawCtl.sState = DFCS_BUTTONCHECK| DFCS_CHECKED;
    }

    if (!m_pCurPceData->stFinishRollStra.FinishRollStraData.bE3Offset)
    {
        DrawCtlAry[1].DrawCtl.sState = DFCS_BUTTONCHECK;
    }
    else
    {
        DrawCtlAry[1].DrawCtl.sState = DFCS_BUTTONCHECK| DFCS_CHECKED;
    }

    for (int i = 0; i < 2; i++)
    {
        // retain old cell properties
        CGridBtnCell GridCellCopy;
        GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
        CGridCellBase* pCurrCell = m_GridFMStraData.GetCell( i, 6);
        if (pCurrCell)
            GridCellCopy = *pCurrCell;

        // replace standard cell with special control cell
        m_GridFMStraData.SetCellType( i, 6, RUNTIME_CLASS(CGridBtnCell) );

        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridFMStraData.GetCell( i, 6);
        pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);

        int iWidth = DrawCtlAry[ 0].DrawCtl.iWidth;

        pGridBtnCell->SetupBtns(
            DrawCtlAry[ i].iBtnNbr,        // zero-based index of image to draw
            DrawCtlAry[ i].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
            DrawCtlAry[ i].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
            (CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ i].DrawCtl.ucAlign,
            // horizontal alignment of control image
            iWidth,                         // fixed width of control or 0 for size-to-fit
            DrawCtlAry[ i].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
            DrawCtlAry[ i].pszBtnText );   // Text to insert centered in button; if NULL no text
    }
    
    
/*********/

    GV_ITEM     Item;

    Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
    Item.nFormat    = DT_CENTER
                    | DT_VCENTER
                    | DT_SINGLELINE
                    | DT_END_ELLIPSIS;

    Item.row        =  0;
    Item.col        =  1;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarThick);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  1;
    Item.col        =  1;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarWidth);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  2;
    Item.col        =  1;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarTemp);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  0;
    Item.col        =  3;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fFET);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  1;
    Item.col        =  3;
    Item.strText.Format(_T("%5.3f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fThickCorr);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  2;
    Item.col        =  3;
    Item.strText.Format(_T("%5.3f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fACC1);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  0;
    Item.col        =  5;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fMaxSpeed);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  1;
    Item.col        =  5;
    Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fThreadSpeed);
    m_GridFMStraData.SetItem(&Item);

    Item.row        =  2;
    Item.col        =  5;
    Item.strText.Format(_T("%5.3f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fACC2);
    m_GridFMStraData.SetItem(&Item);

    if (m_pCurPceData->stFinishRollStra.FinishRollStraData.bE3Offset)
    {
        Item.row        =  1;
        Item.col        =  7;
        Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollStra.FinishRollStraData.fE3Offset);
        m_GridFMStraData.SetItem(&Item);
    }

    m_GridFMStraData.Refresh();

    return;
}

void CViewFinishRollStra::RefreshGridFMLoadData()
{
    m_GridFMLoadData.DeleteAllItems();


    int                 iCol; 
    int                 iColNumber;  
    int                 iRowNumber;
    

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FINISHROLL_LOAD_DATA_COL_NUM;
        iRowNumber = HRS_FINISHROLL_LOAD_DATA_ROW_NUM;

        //m_GridFMLoadData.SetGridStyle(GRID_BLUE);
        //m_GridFMLoadData.SetListMode(TRUE);
        m_GridFMLoadData.SetTextBkColor(GRID_BG_COR);
        //m_GridFMLoadData.SetBkColor(GRID_BG_COR);
        m_GridFMLoadData.SetModified(FALSE);

        m_GridFMLoadData.SetColumnCount(iColNumber);
        m_GridFMLoadData.SetRowCount(iRowNumber);
        //m_GridFMLoadData.SetRowCount(iColNumber);

        //m_GridFMLoadData.SetFixedRowCount(1);
        //m_GridFMLoadData.SetFixedColumnCount(1); 
        m_GridFMLoadData.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    for (int i = 0; i < iColNumber; i++)
    {
        m_GridFMLoadData.SetColumnWidth(i, 150);
    }
    for (int i = 0; i < iRowNumber; i++)
    {
        m_GridFMLoadData.SetRowHeight(i, 30);
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 1; iCol < HRS_FINISHROLL_LOAD_DATA_COL_NUM; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol ;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        //Item.crBkClr = STAC_BG_COR;  //test

        Item.strText.Format(_T("F%d DUMMY"),iCol);

        m_GridFMLoadData.SetItem(&Item);

        //m_GridFMLoadData.SetItemBkColour(iCol % 3, (iCol / 3) * 2, GRID_BG_COR);
    }

    for(iCol = 1; iCol < HRS_FINISHROLL_LOAD_DATA_ROW_NUM; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  iCol;
        Item.col        =  0 ;
        Item.nFormat    =  DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        //Item.crBkClr = STAC_BG_COR;  //test

        if (iCol == 1)
        {
            Item.strText.Format(_T("(%%)LOAD"));
        }
        else if (iCol == 2)
        {
            Item.strText.Format(_T("[B](%%)LOAD CORR"));//
        }
        

        m_GridFMLoadData.SetItem(&Item);

        //m_GridFMLoadData.SetItemBkColour(iCol % 3, (iCol / 3) * 2, GRID_BG_COR);
    }

    //m_GridFMLoadData.AutoSize();






    if (m_pCurPceData == NULL)
    {
        return; 
    }

    /********/
    /* 
     * CHEKE�ؼ���ʼ��
     */
    typedef struct
    {
        CGridBtnCellBase::STRUCT_DRAWCTL DrawCtl;  // most btn props here
        int iBtnNbr;                        // which btn within cell does this define?
        const char* pszBtnText;             // text associated with pushbutton or NULL
    }   STRUCT_CTL;

    //DFCS_BUTTONCHECK
    STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
        {  0, DFCS_BUTTONCHECK, FALSE, CGridBtnCellBase::CTL_ALIGN_LEFT,  DFC_BUTTON, 0, NULL },  // checkbox
       
    }; 

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        if (!m_pCurPceData->stFinishRollStra.FinishRollLoadData.bStandDummy[i])
        {
            DrawCtlAry[i].DrawCtl.sState = DFCS_BUTTONCHECK;
        }
        else
        {
            DrawCtlAry[i].DrawCtl.sState = DFCS_BUTTONCHECK| DFCS_INACTIVE;//DFCS_CHECKED;

            MessageBox("���ܿչ���ʱ���ã�������Ҫ����Ĵ��룡");
        }
    }

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        // retain old cell properties
        CGridBtnCell GridCellCopy;
        GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
        CGridCellBase* pCurrCell = m_GridFMLoadData.GetCell( 0, i+1);
        if (pCurrCell)
            GridCellCopy = *pCurrCell;

        // replace standard cell with special control cell
        m_GridFMLoadData.SetCellType( 0, i+1, RUNTIME_CLASS(CGridBtnCell) );

        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridFMLoadData.GetCell( 0, i+1);
        pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);

        int iWidth = DrawCtlAry[ i].DrawCtl.iWidth;

        pGridBtnCell->SetupBtns(
            DrawCtlAry[ i].iBtnNbr,        // zero-based index of image to draw
            DrawCtlAry[ i].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
            DrawCtlAry[ i].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
            (CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ i].DrawCtl.ucAlign,
            // horizontal alignment of control image
            iWidth,                         // fixed width of control or 0 for size-to-fit
            DrawCtlAry[ i].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
            DrawCtlAry[ i].pszBtnText );   // Text to insert centered in button; if NULL no text
    }
    
    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        Item.row        =  1;
        Item.col        =  i+1;
        Item.strText.Format(_T("%4.4f"),m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadValue[i]);
        m_GridFMLoadData.SetItem(&Item);
    }

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        Item.row        =  2;
        Item.col        =  i+1;
        Item.strText.Format(_T("%4.4f"),m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadCorr[i]);
        m_GridFMLoadData.SetItem(&Item);
    }

    /*for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridFMLoadData.GetCell( 0, i+1);
        pGridBtnCell->EnableWindow(FALSE);

    }*/

    m_GridFMLoadData.Refresh();

    return;
}




void CViewFinishRollStra::RefreshFMOtherData()
{
    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    switch (m_pCurPceData->stFinishRollStra.emFDTCMode)
    {
    case HRS_FDTC_SPEED:
        m_BRadioFDTCMode = 0;
        break;
    case HRS_FDTC_WATER:
        m_BRadioFDTCMode = 1;
        break;

    default:
        break;
    }

    ((CButton *)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
    ((CButton *)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);

    if ( m_pCurPceData->stFinishRollStra.bFF_USE)
    {
        m_bCheckFDTCFFUse = TRUE;
        m_RadCtlFDTCSpeed.EnableWindow(TRUE);
        m_RadCtlFDTCWater.EnableWindow(TRUE);
    }
    else
    {
        m_bCheckFDTCFFUse = FALSE;
        m_RadCtlFDTCSpeed.EnableWindow(FALSE);
        m_RadCtlFDTCWater.EnableWindow(FALSE);
    }

    m_CheckISCF34 = !(m_pCurPceData->stFinishRollStra.bISCCloseF34);
    m_CheckISCF45 = !(m_pCurPceData->stFinishRollStra.bISCCloseF45);
    m_CheckISCF56 = !(m_pCurPceData->stFinishRollStra.bISCCloseF56);
    m_CheckISCF67 = !(m_pCurPceData->stFinishRollStra.bISCCloseF67);

    m_bCheckDescAuto = m_pCurPceData->stFinishRollStra.bDESCAuto;

    //ˢ��Spray Cod
    CString strSprayCode;

    int nSprayCod = m_pCurPceData->stFinishRollStra.nSprayCod;

    int nFindPos = HRS_GetIndexByFMSprayCode(nSprayCod);

    m_CombCtlDESCSprayCod.SetCurSel(nFindPos);

    m_CombCtlDESCSprayCod.GetLBText(nFindPos, strSprayCode);

    m_strCombDescSprayCod = strSprayCode;

    UpdateData(FALSE);
}

void CViewFinishRollStra::InitComboxStripNo()
{
    char (* ppszStripNo)[HRS_STRIP_NO_LEN];
    int i = 0;

    ppszStripNo = (char (*)[HRS_STRIP_NO_LEN])m_pRollSchedMgr->GetStripNoList();

    while (ppszStripNo[i][0] != NULL)
    {
        m_ComboxStripNo.InsertString(i,ppszStripNo[i]);

        i++;
    }

    int nRow = theApp.m_nPDIRow - 1;
    m_ComboxStripNo.SetCurSel(nRow);
    m_strStripNo = ppszStripNo[nRow];

    m_strCurStripNo = ppszStripNo[nRow];


#if 0
    if (m_pCurPceData != NULL)
    {
        PceData_Destroy(m_pCurPceData);
    }
    m_pCurPceData = m_pRollSchedMgr->CopyPceDataByStripNo(m_strStripNo);
#endif

    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(m_strStripNo);

    NG_free(ppszStripNo);

    UpdateData(FALSE);
}



void CViewFinishRollStra::InitComboxSprayCod()
{
    char    szSprayCod[10]={0};
    HRS_FM_SPRAY_NODE  *pSprayNode;
    int                 nSprayCode;

    pSprayNode = HRS_GetFMSprayTable();


    int nIndex = 0;
    for (;;)
    {
        if ( pSprayNode[nIndex].nCode < 0 )
        {
            break;
        }
        
        nSprayCode = pSprayNode[nIndex].nCode;

        sprintf(szSprayCod, "%d", nSprayCode);

        m_CombCtlDESCSprayCod.InsertString(nIndex, szSprayCod);

        nIndex += 1;
    }


    if (m_pCurPceData == NULL)
    {
        return;
    }

    int nSprayCod = m_pCurPceData->stFinishRollStra.nSprayCod;

    int nFindPos = HRS_GetIndexByFMSprayCode(nSprayCod);

    m_CombCtlDESCSprayCod.SetCurSel(nFindPos);
    
    CString strSprayCod;

    m_CombCtlDESCSprayCod.GetLBText(nFindPos, strSprayCod);

    m_strCombDescSprayCod = strSprayCod;

    UpdateData(FALSE);
}


HRS_FINISHROLL_STRA_DATA * CViewFinishRollStra::GetFinishRollStraDataFromGrid()
{
    HRS_FINISHROLL_STRA_DATA * pFinishRollStraData;
    CString StrItem;
    char szMsg[256];

    if (m_pCurPceData == NULL)
    {
        return NULL;
    }

    pFinishRollStraData = (HRS_FINISHROLL_STRA_DATA *)NG_malloc(sizeof(HRS_FINISHROLL_STRA_DATA));
    if (pFinishRollStraData == NULL)
    {
        return NULL;
    }

    memset(pFinishRollStraData, 0, sizeof(HRS_FINISHROLL_STRA_DATA));

    StrItem = m_GridFMStraData.GetItemText(0, 1);
    pFinishRollStraData->fBarThick = atof(StrItem);

    if ( pFinishRollStraData->fBarThick > 65 
        || pFinishRollStraData->fBarThick < 30 )
    {
        sprintf(szMsg, "�м������ = %f ������Χ\r\n�Ϸ���Χ: 30~65", 
            pFinishRollStraData->fBarThick);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }

    StrItem = m_GridFMStraData.GetItemText(1, 1);
    pFinishRollStraData->fBarWidth = atof(StrItem);

    if ( pFinishRollStraData->fBarWidth > 1650 
        || pFinishRollStraData->fBarWidth < 850 )
    {
        sprintf(szMsg, "�м������� = %f ������Χ\r\n�Ϸ���Χ: 850~1650", 
            pFinishRollStraData->fBarWidth);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }


    StrItem = m_GridFMStraData.GetItemText(2, 1);
    pFinishRollStraData->fBarTemp = atof(StrItem);

    if ( pFinishRollStraData->fBarTemp > 1250 
        || pFinishRollStraData->fBarTemp < 900 )
    {
        sprintf(szMsg, "�м����¶� = %f ������Χ\r\n�Ϸ���Χ: 900~1250", 
            pFinishRollStraData->fBarTemp);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }

    StrItem = m_GridFMStraData.GetItemText(0, 3);
    pFinishRollStraData->fFET = atof(StrItem);
    if ( pFinishRollStraData->fFET > 1250 
        || pFinishRollStraData->fFET < 900 )
    {
        sprintf(szMsg, "��¯�¶� = %f ������Χ\r\n�Ϸ���Χ: 900~1250", 
            pFinishRollStraData->fFET);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }


    StrItem = m_GridFMStraData.GetItemText(1, 3);
    pFinishRollStraData->fThickCorr = atof(StrItem);
    double dTargetGauge = pFinishRollStraData->fThickCorr;

    dTargetGauge += m_pCurPceData->stRollSched.fC_H;
    if ( dTargetGauge > 19.05 
        || dTargetGauge < 1.1 )
    {
        sprintf(szMsg, "Ŀ����ں�� = %f ������Χ\r\n�Ϸ���Χ: 1.1~19.05", 
            dTargetGauge);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }


    // �¶ȼ��ٶ�
    StrItem = m_GridFMStraData.GetItemText(2, 3);
    pFinishRollStraData->fACC1 = atof(StrItem);
    if ( pFinishRollStraData->fACC1 > 0.2 
        || pFinishRollStraData->fACC1 < 0.001 )
    {
        sprintf(szMsg, "�¶ȼ��ٶ� = %f ������Χ\r\n�Ϸ���Χ: 0.001~0.2", 
            pFinishRollStraData->fACC1);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }

    StrItem = m_GridFMStraData.GetItemText(0, 5);
    pFinishRollStraData->fMaxSpeed = atof(StrItem);
    if ( pFinishRollStraData->fMaxSpeed > 20.0 
        || pFinishRollStraData->fMaxSpeed < 3.0 )
    {
        sprintf(szMsg, "����ٶ� = %f ������Χ\r\n�Ϸ���Χ: 3.0~20.0", 
                pFinishRollStraData->fMaxSpeed);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }

    StrItem = m_GridFMStraData.GetItemText(1, 5);
    pFinishRollStraData->fThreadSpeed = atof(StrItem);
    if ( pFinishRollStraData->fThreadSpeed > 11.3 
        || pFinishRollStraData->fThreadSpeed < 2.3 )
    {
        sprintf(szMsg, "�����ٶ� = %f ������Χ\r\n�Ϸ���Χ: 2.3~11.3", 
            pFinishRollStraData->fThreadSpeed);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }


    // ���ʼ��ٶ�
    StrItem = m_GridFMStraData.GetItemText(2, 5);
    pFinishRollStraData->fACC2 = atof(StrItem);
    if ( pFinishRollStraData->fACC2 > 0.5 
        || pFinishRollStraData->fACC2 < 0.001 )
    {
        sprintf(szMsg, "���ʼ��ٶ� = %f ������Χ\r\n�Ϸ���Χ: 0.001~0.5", 
            pFinishRollStraData->fACC2);
        AfxMessageBox(szMsg);

        NG_free(pFinishRollStraData);
        return NULL;
    }


    CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridFMStraData.GetCell( 0, 6);
    int GridBtnCellStatus = pGridBtnCell->GetDrawCtlState(0);
    if ( GridBtnCellStatus & DFCS_CHECKED )
    {
        pFinishRollStraData->bE3Dummy = true;
    }
    else
    {
        pFinishRollStraData->bE3Dummy = false;
    }

    pGridBtnCell = (CGridBtnCell*)m_GridFMStraData.GetCell( 1, 6);
    GridBtnCellStatus = pGridBtnCell->GetDrawCtlState(0);
    if ( GridBtnCellStatus & DFCS_CHECKED )
    {
        pFinishRollStraData->bE3Offset = true;

        StrItem = m_GridFMStraData.GetItemText(1, 7);
        pFinishRollStraData->fE3Offset = atof(StrItem);
    }
    else
    {
        pFinishRollStraData->bE3Offset = false;
    }


    return pFinishRollStraData;
}

HRS_FINISHROLL_LOAD_DATA * CViewFinishRollStra::GetFinishRollLoadDataFromGrid()
{
    HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData;
    CString StrItem;

    pFinishRollLoadData = 
        (HRS_FINISHROLL_LOAD_DATA *) NG_malloc(sizeof(HRS_FINISHROLL_LOAD_DATA));
    if (pFinishRollLoadData == NULL)
    {
        return NULL;
    }

    memset(pFinishRollLoadData, 0, sizeof(HRS_FINISHROLL_LOAD_DATA));

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        StrItem = m_GridFMLoadData.GetItemText(1, i+1);
        pFinishRollLoadData->fLoadValue[i] = atof(StrItem);

        StrItem = m_GridFMLoadData.GetItemText(2, i+1);
        pFinishRollLoadData->fLoadCorr[i] = atof(StrItem);

        CGridBtnCell* pGridBtnCell = 
                            (CGridBtnCell*)m_GridFMLoadData.GetCell( 0, i+1);
        int GridBtnCellStatus = pGridBtnCell->GetDrawCtlState(0);
        if ( GridBtnCellStatus & DFCS_CHECKED )
        {
            pFinishRollLoadData->bStandDummy[i] = true;
        }
        else
        {
            pFinishRollLoadData->bStandDummy[i] = false;
        }
    }

    return pFinishRollLoadData;
}


void CViewFinishRollStra::OnCbnSelchangeCombFmStripno()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if ( m_pCurPceData == NULL )
    {
        return;
    }

    CString strStripNo;
    PCE_DATA * pPceDataOrig;
    int nShift;

    nShift = m_ComboxStripNo.GetCurSel();

    m_ComboxStripNo.GetLBText(nShift,strStripNo);

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                            "�л��ְ�", 
                            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo), 
                m_pCurPceData, 
                sizeof(PCE_DATA) );

        }
        else if (nRet == IDCANCEL)
        {
            m_strStripNo = m_strCurStripNo;

            UpdateData(FALSE);
            return ;
        }

    }

//    PceData_Destroy(m_pCurPceData);

//    m_pCurPceData = m_pRollSchedMgr->CopyPceDataByStripNo(strStripNo);
    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(strStripNo);

    RefreshGridFMStraData();
    RefreshGridFMLoadData();
    RefreshFMOtherData();

    m_strStripNo = strStripNo;
    m_strCurStripNo = strStripNo;

    // move
    int nSeq;

    nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strCurStripNo);
    if (nSeq < 0)
    {
        return;
    }

    m_GridFinishRollPDI.SetFocusCell(nSeq, 2);
    m_GridFinishRollPDI.SetSelectedRange(nSeq,1,nSeq,HRS_ROLL_SCHED_ITEM_NUM-1);

#if 0
    int nRowHeight = m_GridFinishRollPDI.GetRowHeight(nSeq);

    int nRowCount = m_GridFinishRollPDI.GetRowCount();

    int nMinPos, nMaxPos;
    m_GridFinishRollPDI.GetScrollRange(SB_VERT, &nMinPos, &nMaxPos);
    SCROLLINFO  sinfo;
    m_GridFinishRollPDI.GetScrollInfo(SB_VERT, &sinfo, SIF_ALL);
    

    float fPos = (float)nSeq / (float)nRowCount;

    fPos *= nMaxPos;

    m_GridFinishRollPDI.SetScrollPos(SB_VERT, (int)fPos, TRUE);


 //   m_GridFinishRollPDI.OnVScroll(SB_LINEDOWN, (int)fPos, NULL);

    CRect rect;
    m_GridFinishRollPDI.GetClientRect(rect);

    rect.top = m_GridFinishRollPDI.GetFixedRowHeight();
    //rect.top = GetFixedRowHeight() + yScroll;
    //ScrollWindow(0, -yScroll, rect);
    //rect.top = rect.bottom - yScroll;
    m_GridFinishRollPDI.InvalidateRect(rect);
#endif

    m_GridFinishRollPDI.ScrollToRow(nSeq);

    RefreshFinishRollSchedGrid();
    // end

    UpdateData(FALSE);
}


void CViewFinishRollStra::OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    if (nCol == 1)
    {
        int nRet = MessageBox("������Ϊ������̼��������޸Ļᵼ�¾��������������ƥ�䣬�Ƿ������", 
                              "����", 
                              MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet != IDYES )
        {
            RefreshGridFMStraData();

            return;
        }
    }

    HRS_FINISHROLL_STRA_DATA * pFinishRollStraData;

    pFinishRollStraData = GetFinishRollStraDataFromGrid();

    if ( pFinishRollStraData == NULL )
    {
        return;
    }

    //m_pRollSchedMgr->ChangeFinishRollStraData(pFinishRollStraData, m_strStripNo );
    PceData_ChangeFmStraData(m_pCurPceData, pFinishRollStraData);

    RefreshGridFMStraData();

//    NG_free(pFinishRollStraData);
}


void CViewFinishRollStra::OnGridFinishRollStraDataClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nCol != 6 || nRow > 1 )
    {
        return;
    }

    HRS_FINISHROLL_STRA_DATA * pFinishRollStraData;

    pFinishRollStraData = GetFinishRollStraDataFromGrid();
    if (pFinishRollStraData == NULL)
    {
        return;
    }

    //m_pRollSchedMgr->ChangeFinishRollStraData(pFinishRollStraData, m_strStripNo );
    PceData_ChangeFmStraData(m_pCurPceData, pFinishRollStraData);

    RefreshGridFMStraData();
 
    return;
}


void CViewFinishRollStra::OnGridLoadDataEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData;

    pFinishRollLoadData = GetFinishRollLoadDataFromGrid();

    //m_pRollSchedMgr->ChangeFinishRollLoadData(pFinishRollLoadData, m_strStripNo );
    PceData_ChangeFmLoadData(m_pCurPceData, pFinishRollLoadData);

    RefreshGridFMLoadData();

}


void CViewFinishRollStra::OnGridFinishRollLoadDataClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow != 0 || nCol < 1 )
    {
        return;
    }

    HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData;

    pFinishRollLoadData = GetFinishRollLoadDataFromGrid();

    //m_pRollSchedMgr->ChangeFinishRollLoadData(pFinishRollLoadData, m_strStripNo );
    PceData_ChangeFmLoadData(m_pCurPceData, pFinishRollLoadData);

    RefreshGridFMLoadData();

}


void CViewFinishRollStra::OnBnClickedRadFdtcSpeed()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    switch (m_BRadioFDTCMode)
    {
    case 0:
        m_pCurPceData->stFinishRollStra.emFDTCMode = HRS_FDTC_SPEED;
        break;
    case 1:
        m_pCurPceData->stFinishRollStra.emFDTCMode = HRS_FDTC_WATER;
        break;

    default:
        break;
    }

    RefreshFMOtherData();
    return;
}


void CViewFinishRollStra::OnBnClickedRadFdtcWater()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    switch (m_BRadioFDTCMode)
    {
    case 0:
        m_pCurPceData->stFinishRollStra.emFDTCMode = HRS_FDTC_SPEED;
        break;
    case 1:
        m_pCurPceData->stFinishRollStra.emFDTCMode = HRS_FDTC_WATER;
        break;

    default:
        break;
    }

    RefreshFMOtherData();
    return;
}


void CViewFinishRollStra::OnBnClickedCheckFdtcFfUse()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);
    if (m_pCurPceData == NULL)
    {
        return;
    }

    if (m_bCheckFDTCFFUse)
    {
        m_pCurPceData->stFinishRollStra.bFF_USE = true;
        m_RadCtlFDTCSpeed.EnableWindow(TRUE);
        m_RadCtlFDTCWater.EnableWindow(TRUE);
    } 
    else
    {
        m_pCurPceData->stFinishRollStra.bFF_USE = false;
        m_RadCtlFDTCSpeed.EnableWindow(FALSE);
        m_RadCtlFDTCWater.EnableWindow(FALSE);
    }
}


void CViewFinishRollStra::OnBnClickedCheckIscF34()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    m_pCurPceData->stFinishRollStra.bISCCloseF34 = !m_CheckISCF34;

    RefreshFinishRollSchedGrid();
}


void CViewFinishRollStra::OnBnClickedCheckIscF45()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    m_pCurPceData->stFinishRollStra.bISCCloseF45 = !m_CheckISCF45;

    RefreshFinishRollSchedGrid();

}


void CViewFinishRollStra::OnBnClickedCheckIscF56()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    m_pCurPceData->stFinishRollStra.bISCCloseF56 = !m_CheckISCF56;

    RefreshFinishRollSchedGrid();

}

void CViewFinishRollStra::OnBnClickedCheckIscF67()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    m_pCurPceData->stFinishRollStra.bISCCloseF67 = !m_CheckISCF67;

    RefreshFinishRollSchedGrid();

}

void CViewFinishRollStra::OnBnClickedCheckDescAuto()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    m_pCurPceData->stFinishRollStra.bDESCAuto = (bool)m_bCheckDescAuto;

    if (m_bCheckDescAuto)
    {
        m_CombCtlDESCSprayCod.EnableWindow(FALSE);
    } 
    else
    {
        m_CombCtlDESCSprayCod.EnableWindow(TRUE);
    }

    return;
}

void CViewFinishRollStra::OnCbnSelchangeCombDescSprayCod()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    CString strSprayCode;
    int nShift;

    nShift = m_CombCtlDESCSprayCod.GetCurSel();
    if ( nShift == CB_ERR )
    {
        nShift = 0;
    }

    m_CombCtlDESCSprayCod.GetLBText(nShift, strSprayCode);

    m_pCurPceData->stFinishRollStra.nSprayCod = atoi((char *)(LPCTSTR)strSprayCode);

    m_strCombDescSprayCod = strSprayCode;

    RefreshFinishRollSchedGrid();

    UpdateData(FALSE);
}

void CViewFinishRollStra::OnBnClickedButFmStraSave()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    PCE_DATA * pPceDataOrig;

    if (m_pCurPceData == NULL)
    {
        return;
    }

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        memcpy( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) );

        MessageBox("���ݱ���ɹ���");
    }
    else 
    {
        MessageBox("û�����ݸ���");
    }

    return ;
}


bool CViewFinishRollStra::ExitConfirm()
{
    PCE_DATA * pPceDataOrig;

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);
    if (pPceDataOrig == NULL || m_pCurPceData == NULL)
    {
        return true;
    }

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                              "�뿪", 
                              MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) );
        }
        else if (nRet == IDCANCEL)
        {
            return false;
        }
    }
    else 
    {
        return true;
    }

    return true;

}
void CViewFinishRollStra::OnBnClickedButFmStraClean()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    HRS_FM_DRAFT_RATIO DraftRatio;
    HRS_TABLE_FM_SPEED SpeedPara;

    if (m_pCurPceData == NULL)
    {
        return;
    }

//    nRet = PceData_DefaultFmStra(m_pCurPceData);
    if (ERR_FAILED == HRS_GetStrategyData(&m_FmAllData,&DraftRatio, &SpeedPara))
    {
        MessageBox(m_FmAllData.szOutErr);
        return ;
    }

    HRS_FINISHROLL_STRA_DATA  *pStraData;

    HRS_ROUGHROLL_STRA *pRoughStra;

    pRoughStra = &(m_pCurPceData->stRoughRollStra);

    pStraData = &(m_pCurPceData->stFinishRollStra.FinishRollStraData);

    //�м�������ж�
    if ( pRoughStra->bRm_Exit_Thick_Auto)
    {
        pStraData->fBarThick    = m_pCurPceData->stRollSched.fR_H;
    }
    else
    {
        pStraData->fBarThick    = pRoughStra->fRm_Exit_Thick;
    }

    pStraData->fBarWidth    = pRoughStra->fRMExitWidth;
    pStraData->fBarTemp     = pRoughStra->fRMExitTemp;
    pStraData->fFET         = pRoughStra->fRMExitTemp - 15.0;


    pStraData->fThickCorr   = 0;

    pStraData->fACC1        = SpeedPara.dTempAccelator;
    pStraData->fMaxSpeed    = SpeedPara.dMaxSpeed;
    pStraData->fThreadSpeed = SpeedPara.dThreadSpeed;
    pStraData->fACC2        = SpeedPara.dPowerAccelator;

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadValue[i] = 
            DraftRatio.adDraftRatio[i];
        m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadCorr[i] = 0.0;
    }

    m_pCurPceData->stFinishRollStra.bISCCloseF34 = false;
    m_pCurPceData->stFinishRollStra.bISCCloseF45 = false;
    m_pCurPceData->stFinishRollStra.bISCCloseF56 = false;
    m_pCurPceData->stFinishRollStra.bISCCloseF67 = false;

    m_CheckISCF34 = true;
    m_CheckISCF45 = true;
    m_CheckISCF56 = true;
    m_CheckISCF67 = true;

    m_CheckRadio1 = FALSE;
    m_CheckRadio2 = TRUE;

    UpdateData(FALSE);

    RefreshGridFMStraData();
    RefreshGridFMLoadData();
    RefreshFMOtherData();

    RefreshFinishRollSchedGrid();


    MessageBox("�ظ�Ĭ�Ͼ���������ɣ�");
}


// move 
void CViewFinishRollStra::InitGridPDI()
{

    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    m_GridFinishRollPDI.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridFinishRollPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridFinishRollPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            SetTextBGCor(m_GridFinishRollPDI, pPceData, i + 1, j);

            switch (j)
            { 
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.2f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridFinishRollPDI.SetItem(&Item);
        }
    }

    m_GridFinishRollPDI.Refresh();

    m_GridFinishRollPDI.SetEditable(FALSE);

    return;
}


void CViewFinishRollStra::OnGridFinishRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;
    PCE_DATA * pPceDataOrig;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    if (m_pCurPceData == NULL)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridFinishRollPDI.GetFixedRowCount() )
    {
        return;
    }

    theApp.m_nPDIRow = nRow;

    itemStr = m_GridFinishRollPDI.GetItemText(nRow, 1);

    // move
    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                            "�л��ְ�", 
                            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo), 
                    m_pCurPceData, 
                    sizeof(PCE_DATA) );

        }
        else if (nRet == IDCANCEL)
        {
            int nSeq;

            nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strCurStripNo);
            if (nSeq < 0)
            {
                return;
            }

            m_GridFinishRollPDI.SetFocusCell(nSeq, 2);
            m_GridFinishRollPDI.SetSelectedRange(nSeq,1,nSeq,HRS_ROLL_SCHED_ITEM_NUM-1);

            UpdateData(FALSE);
            return ;
        }

    }

//    PceData_Destroy(m_pCurPceData);

//    m_pCurPceData = m_pRollSchedMgr->CopyPceDataByStripNo(itemStr);
    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(itemStr);

    if (ERR_FAILED == GetFinishRollCfgData())
    {
        MessageBox("�������ݶ�ȡʧ�ܣ�");
    }

    RefreshGridFMStraData();
    RefreshGridFMLoadData();
    RefreshFMOtherData();

    m_strStripNo = itemStr;
    m_strCurStripNo = itemStr;

    RefreshFinishRollSchedGrid();

    UpdateData(FALSE);

    return ;
    // end
}


void CViewFinishRollStra::RefreshFinishRollSchedGrid()
{
    char strHeading[5]={0};
    int  RowCount;

#if 0
    m_GridFinishRollPreCalcBasic.DeleteNonFixedRows();
    RowCount = m_GridFinishRollPreCalcBasic.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridFinishRollPreCalcBasic.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_PRECALC_BASICDATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
            | DT_VCENTER
            | DT_SINGLELINE
            | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_PRECALC_BASICDATA_STRIP_NO :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_FM_PRECALC_BASICDATA_RH2 :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRH2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RW2 :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRW2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RL2 :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRL2);
            break;
        case HRS_FM_PRECALC_BASICDATA_EXT_T :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fExtT);
            break;
        case HRS_FM_PRECALC_BASICDATA_FT0 :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fFT0);
            break;
        case HRS_FM_PRECALC_BASICDATA_LOADT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nLoadT);
            break;

        case HRS_FM_PRECALC_BASICDATA_SPRAY_C :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nSprayC);
            break;
        case HRS_FM_PRECALC_BASICDATA_V :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fV);
            break;
        case HRS_FM_PRECALC_BASICDATA_VOUT :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVOut);
            break;
        case HRS_FM_PRECALC_BASICDATA_VMAX :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVMax);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC1 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC1);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC2 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC2);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridFinishRollPreCalcBasic.SetItem(&Item);

    }


    m_GridFinishRollPreCalcBasic.AutoSizeColumns();
    m_GridFinishRollPreCalcBasic.Refresh();

#endif

    //precalc

    int i;
    int anSprayIsc[HRS_FINISHMILL_NUM];
    HRS_FM_SPRAY_NODE *pFMSprayNode;

    pFMSprayNode = HRS_GetFMSprayNode(
        m_pCurPceData->stFinishRollStra.nSprayCod);

    if (pFMSprayNode != NULL )
    {
        anSprayIsc[0] = pFMSprayNode->anSprayCode[0];
        anSprayIsc[1] = pFMSprayNode->anSprayCode[1];
    }
    else
    {
        anSprayIsc[0] = 0;
        anSprayIsc[1] = 0;
    }

    anSprayIsc[2] = m_pCurPceData->stFinishRollStra.bISCCloseF34;
    anSprayIsc[3] = m_pCurPceData->stFinishRollStra.bISCCloseF45;
    anSprayIsc[4] = m_pCurPceData->stFinishRollStra.bISCCloseF56;
    anSprayIsc[5] = m_pCurPceData->stFinishRollStra.bISCCloseF67;
    anSprayIsc[6] = 0;


    m_GridFinishRollPreCalc.DeleteNonFixedRows();

    RowCount = m_GridFinishRollPreCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridFinishRollPreCalc.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_PRECALC_DATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_PRECALC_DATA_STAND :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.strStand);
            break; 
        case HRS_FM_PRECALC_DATA_H_ENTRY :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHEntry);
            break;
        case HRS_FM_PRECALC_DATA_H_EXIT :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHExit);
            break;
        case HRS_FM_PRECALC_DATA_RED :
            Item.strText.Format(_T("%6.4f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRED);
            break;
        case HRS_FM_PRECALC_DATA_RF :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRF);
            break;
        case HRS_FM_PRECALC_DATA_GAP :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fGAP);
            break;
        case HRS_FM_PRECALC_DATA_TQRQUE :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nTqrque);
            break;
        case HRS_FM_PRECALC_DATA_POWER :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fPower);
            break;

        case HRS_FM_PRECALC_DATA_KM :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nKM);
            break;
        case HRS_FM_PRECALC_DATA_VR :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fV);
            break;
        case HRS_FM_PRECALC_DATA_FLOW :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nFlow);
            break;
        case HRS_FM_PRECALC_DATA_ENT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nENT);
            break;
        case HRS_FM_PRECALC_DATA_EXT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nEXT);
            break;
        case HRS_FM_PRECALC_DATA_BEND :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nBend);
            break;
        case HRS_FM_PRECALC_DATA_VS :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nShift);
            break;
        case HRS_FM_PRECALC_DATA_FS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fFS);
            break;
        case HRS_FM_PRECALC_DATA_BS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fBS);
            break;
        case HRS_FM_PRECALC_DATA_TENSION :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fTension);
            break;
        case HRS_FM_PRECALC_DATA_LOOPER_DIS :
            Item.strText.Format(_T("%4.2f"),
                m_pCurPceData->stFinishRollSched.PreCalcDataE3.fLooperDis * 1000);
            break;
        case HRS_FM_PRECALC_DATA_SPRAY_ISC :
            Item.strText.Format(_T("%d"), 0);
            break;
        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridFinishRollPreCalc.SetItem(&Item);

    }


    for (i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        RowCount = m_GridFinishRollPreCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridFinishRollPreCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_FM_PRECALC_DATA_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_FM_PRECALC_DATA_STAND :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].strStand);
                break; 
            case HRS_FM_PRECALC_DATA_H_ENTRY :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHEntry);
                break;
            case HRS_FM_PRECALC_DATA_H_EXIT :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHExit);
                break;
            case HRS_FM_PRECALC_DATA_RED :
                Item.strText.Format(_T("%6.4f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRED);
                break;
            case HRS_FM_PRECALC_DATA_RF :
                Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRF);
                break;
            case HRS_FM_PRECALC_DATA_GAP :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fGAP);
                break;
            case HRS_FM_PRECALC_DATA_TQRQUE :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nTqrque);
                break;
            case HRS_FM_PRECALC_DATA_POWER :
                Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fPower);
                break;

            case HRS_FM_PRECALC_DATA_KM :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nKM);
                break;
            case HRS_FM_PRECALC_DATA_VR :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fV);
                break;
            case HRS_FM_PRECALC_DATA_FLOW :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nFlow);
                break;
            case HRS_FM_PRECALC_DATA_ENT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nENT);
                break;
            case HRS_FM_PRECALC_DATA_EXT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nEXT);
                break;
            case HRS_FM_PRECALC_DATA_BEND :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nBend);
                break;
            case HRS_FM_PRECALC_DATA_VS :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nShift);
                break;
            case HRS_FM_PRECALC_DATA_FS :
                Item.strText.Format(_T("%4.5f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fFS);
                break;
            case HRS_FM_PRECALC_DATA_BS :
                Item.strText.Format(_T("%4.5f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fBS);
                break;
            case HRS_FM_PRECALC_DATA_TENSION :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fTension);
                break;
            case HRS_FM_PRECALC_DATA_LOOPER_DIS :
                Item.strText.Format(_T("%4.2f"),
                    m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fLooperDis * 1000);
                break;
            case HRS_FM_PRECALC_DATA_SPRAY_ISC:
                Item.strText.Format(_T("%d"), anSprayIsc[i]);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridFinishRollPreCalc.SetItem(&Item);

        }
    }

//    m_GridFinishRollPreCalc.AutoSizeColumns();
#if 0
    int nRowHeight = m_GridFinishRollPreCalc.GetRowHeight(1);

    m_GridFinishRollPreCalc.GetSel

    int nRow = CellRange.GetMinRow();
    int nCol = CellRange.GetMinCol();
    m_GridFinishRollPreCalc.EnsureVisible(nRow, nCol);
#endif
    m_GridFinishRollPreCalc.Refresh();

    UpdateData(FALSE);
}

#if 0
void CViewFinishRollStra::OnBnClickedButFmStraCalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    int nRet;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return;
    }
    strStipNo = m_pCurPceData->stRollSched.strSTRIP_NO;

    //
    // ��ȡGUI�������趨���ݸ�����
    //
    HRS_FM_ALL_DATA    HrsFmAllData;

    nRet = PceData_GetPdiForCalc(m_pCurPceData, &HrsFmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return;
    }
    //m_pRollSchedMgr->GetRmStraDataForCalc(strStipNo, &HrsFmAllData.StrategyData);
    nRet = PceData_GetFmStraDataForCalc(m_pCurPceData, &HrsFmAllData.FMStrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return;
    }


    //memcpy( &HrsFmAllData.PlateData.SlabeData, 
    //        &HrsFmAllData.PlanData.SlabData, 
    //        sizeof(HRS_SLAB_DATA));
    //HrsFmAllData.PlateData.dSlabeEntryTemp = 1600;                                  //����

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return;
    }

    pModule->GetAllStandPara(&HrsFmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(HrsFmAllData.DeformFactor.szSteelGrade, 
        HrsFmAllData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);
    HrsFmAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;                                        // ��������
    HrsFmAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
    HrsFmAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
    HrsFmAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
    HrsFmAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
    HrsFmAllData.DeformFactor.dReserve1 = 1;
    HrsFmAllData.DeformFactor.dReserve2 = 1;

    //��������
    HRS_FM_ALL_OUT_DATA pAllOutData;
    HRS_FM_SCHED pRMSched;
    nRet = HRS_FML2Calc_CalcAllData(&HrsFmAllData, &pAllOutData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("������̼������!");
        return;
    }
    nRet = HRS_FML2Calc_BuildSched(&HrsFmAllData, &pAllOutData, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("���ɾ�����̴���!");
        return;
    }

    //m_pRollSchedMgr->SetFmSchedCalcFromCalc(strStipNo, &pAllOutData);
    nRet = PceData_SetFmSchedCalcFromCalc(m_pCurPceData, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������þ�����̴���!");
        return;
    }

    RefreshFinishRollSchedGrid();

    AfxMessageBox("������̼���ɹ�!");
    return;
}
#else

void CViewFinishRollStra::OnBnClickedButFmStraCalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    int nRet;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("������Ϣ�����û��ѡ�����!");
        return;
    }
    strStipNo = m_pCurPceData->stRollSched.strSTRIP_NO;


    if (m_bCheckRemoteCalc)
    {
        // �ж�ͨ�������Ƿ���
        int nCommState = theApp.m_pGUIComm->GetCommState();

        if (nCommState == ERR_FAILED )
        {
            nRet = theApp.m_pGUIComm->GUICommCreate();

            if (nRet == ERR_FAILED)
            {
                AfxMessageBox("ͨ������δ���������ܽ���Զ�̼���");

                return;
            }
        }
    }

    //
    // ��ȡGUI�������趨���ݸ�����
    //
    HRS_FM_ALL_DATA    HrsFmAllData;

    nRet = PceData_GetPdiForCalc(m_pCurPceData, &HrsFmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return;
    }

    nRet = PceData_GetFmStraDataForCalc(m_pCurPceData, &HrsFmAllData.FMStrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return;
    }

    HRS_FINISHROLL_STRA_DATA * pFinishRollStraData;

    pFinishRollStraData = GetFinishRollStraDataFromGrid();
    if (pFinishRollStraData == NULL)
    {
        return;
    }

    //m_pRollSchedMgr->ChangeFinishRollStraData(pFinishRollStraData, m_strStripNo );
    PceData_ChangeFmStraData(m_pCurPceData, pFinishRollStraData);

 //   NG_free(pFinishRollStraData);


    //memcpy( &HrsFmAllData.PlateData.SlabeData, 
    //        &HrsFmAllData.PlanData.SlabData, 
    //        sizeof(HRS_SLAB_DATA));
    //HrsFmAllData.PlateData.dSlabeEntryTemp = 1600;                                  //����

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return;
    }

    pModule->GetAllStandPara(&HrsFmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(HrsFmAllData.DeformFactor.szSteelGrade, 
           HrsFmAllData.PlanData.SlabData.szSteelGradeName, 
           HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);

    if (pFactor != NULL )
    {
        HrsFmAllData.DeformFactor = *pFactor;
    }
    else
    {
        HrsFmAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;    // ��������
        HrsFmAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        HrsFmAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        HrsFmAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        HrsFmAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        HrsFmAllData.DeformFactor.dReserve1 = 1;
        HrsFmAllData.DeformFactor.dReserve2 = 1;
    }



    // ��ѯ�����������뾶
    HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerDataMgr;
    char   szOutErr[1024];
    double adRadius[HRS_FINISHMILL_NUM];

    pTotalRollerDataMgr = m_pRollSchedMgr->GetTotalRollerDataMgr();

    szOutErr[0] = '\0';
    nRet = HRS_TotalRollerDataMgr_GetFMWorkingRadius(pTotalRollerDataMgr,
        adRadius, 
        NG_ARRAY_SIZE(adRadius),
        szOutErr);

    if ( nRet == ERR_FAILED )
    {
        AfxMessageBox(szOutErr);
        return;
    }

    // ���ù������뾶
    HRS_ALL_STAND_PARA *pAllStandPara = &(HrsFmAllData.AllStandPara);

    int i;
    for (i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        pAllStandPara->aEquipPara[HRS_STAND_NO_FM1 +i].dMaxWorkingRollerRadius
             = adRadius[i];
    }


    if ( m_pCurPceData->stRoughRollStra.nIsHaveData != 0 )
    {
        HrsFmAllData.FMStrategyData.FMStraData.dFMEntryTemp 
            = m_pCurPceData->stRoughRollStra.fRMExitTemp;
        HrsFmAllData.FMStrategyData.FMStraData.dTransferBarThick
            = m_pCurPceData->stRoughRollStra.fRm_Exit_Thick;
        HrsFmAllData.FMStrategyData.FMStraData.dTransferBarTemp
            = m_pCurPceData->stRoughRollStra.fRMExitTemp;
    }

    //
    // ������������ݴ��뵽�����������ݽṹ��
    //

    HRS_FM_STRA_DATA *pFMStraData;

    pFMStraData = &(HrsFmAllData.FMStrategyData.FMStraData);

    CString strData;
    strData = m_GridFMStraData.GetItemText(0, 1);
    pFMStraData->dTransferBarThick = atof((char *)(LPCTSTR)strData);

    strData = m_GridFMStraData.GetItemText(1, 3);
    pFMStraData->dFMThickAdjust = atof((char *)(LPCTSTR)strData);

    strData = m_GridFMStraData.GetItemText(0, 3);
    pFMStraData->dFMEntryTemp = atof((char *)(LPCTSTR)strData);


    CCellRange cell_range = m_GridFinishRollPDI.GetSelectedCellRange();

    //��������
    if ( !m_bCheckRemoteCalc )
    {
        HRS_FM_ALL_OUT_DATA pAllOutData;
        HRS_FM_SCHED FMSched;
#if HRS_WUST_CLAC
        //��������
        nRet = HRS_FMCalc_WUSTCalc(&HrsFmAllData, &pAllOutData);
#else
        nRet = HRS_FML2Calc_CalcAllData(&HrsFmAllData, &pAllOutData);
#endif
        if (nRet == ERR_FAILED)
        {
            char szMsg[2048];

            sprintf(szMsg, "������̼������! \r\n %s", HrsFmAllData.szOutErr);
            AfxMessageBox(szMsg);
            return;
        }
        nRet = HRS_FML2Calc_BuildSched(&HrsFmAllData, &pAllOutData, &FMSched);
        if (nRet == ERR_FAILED)
        {
            AfxMessageBox("���ɾ�����̴���!");
            return;
        }

        //m_pRollSchedMgr->SetFmSchedCalcFromCalc(strStipNo, &pAllOutData);
        nRet = PceData_SetFmSchedCalcFromCalc(m_pCurPceData, &FMSched);
        if (nRet == ERR_FAILED)
        {
            AfxMessageBox("�������þ�����̴���!");
            return;
        }

        m_pCurPceData->stRealFinishRollSched = FMSched;
        m_pCurPceData->nFinishRollSchedStatus = ERR_SUCCESS;

        RefreshFinishRollSchedGrid();

        AfxMessageBox("��������ɹ�!");
    }
    else
    {
        if (ERR_SUCCESS == m_pCurPceData->nFinishRollSchedStatus)
        {
            nRet = MessageBox("��������Ѿ�������ˣ��Ƿ����¼��㣿", 
                              "����", 
                              MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);

            if ( nRet != IDYES )
            {
                RefreshGridFMStraData();

                return;
            }
        }

        if (NULL != theApp.m_pGUIComm)
        {
            HRS_FM_DATA_FROM_GUI FMGUIData;
            memset(&FMGUIData, 0, sizeof(HRS_FM_DATA_FROM_GUI));

            if (HrsFmAllData.FMStrategyData.FMStraData.dTransferBarThick <= 0)
            {
                HrsFmAllData.FMStrategyData.FMStraData.dTransferBarThick = 
                    HrsFmAllData.PlanData.dTransferBarGauge;
            }

            if (HrsFmAllData.FMStrategyData.FMStraData.dTransferBarWidth <= 0)
            {
                HrsFmAllData.FMStrategyData.FMStraData.dTransferBarWidth = 
                    HrsFmAllData.PlanData.SlabData.dSlabWidth;
            }

            FMGUIData.PlanData     = HrsFmAllData.PlanData;
            FMGUIData.StrategyData = HrsFmAllData.FMStrategyData;


            for ( i = 0; i < HRS_FINISHMILL_NUM; i++ )
            {
                FMGUIData.adWorkingRollerRadius[i] = adRadius[i];
            }

            memcpy(FMGUIData.szSign, 
                m_pCurPceData->stRollSched.strSIGN,
                HRS_SIGN_LEN);


            theApp.m_pGUIComm->SetFMData(&FMGUIData);
            m_pCurPceData->nFinishRollSchedStatus = ERR_SUCCESS;
        }
    }

    PCE_DATA *pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    memcpy(pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA));


    int nPos = m_GridFinishRollPDI.GetScrollPos(SB_VERT);

    // ˢ�����Ƽƻ�����
    InitGridPDI();
  
    m_GridFinishRollPDI.SetScrollPos(SB_VERT, nPos);

    theApp.m_nPDIRow = cell_range.GetMinRow();

    m_GridFinishRollPDI.SetSelectedRange(cell_range.GetMinRow(), 
        cell_range.GetMinCol(),
        cell_range.GetMaxRow(), cell_range.GetMaxCol(), TRUE);

    return;
}

#endif


int CViewFinishRollStra::HRS_FM_QuerySpeedTable(HRS_FM_ALL_DATA *pAllData,
                           HRS_TABLE_FM_SPEED *pSpeedTable)
{
    HRS_PLAN_DATA        *pPlanData;
    HRS_STEEL_LEVEL *SteelLevel;

    if (pAllData == NULL || pSpeedTable == NULL)
    {
        return ERR_FAILED;
    }

    SteelLevel = &pAllData->SteelLevel;
    pPlanData     = &(pAllData->PlanData);

    pSpeedTable->nSteelGradeCode = SteelLevel->nSteelGradeCode;
    pSpeedTable->nQualityCode = pAllData->PlanData.nQualityCode;
    pSpeedTable->nTargetGaugeLevel = SteelLevel->nTargetGaugeLevel;
    pSpeedTable->nFMWidthLevel = SteelLevel->nFMWidthLevel;
    pSpeedTable->nFinalTempLevel = SteelLevel->nFinalTempLevel;

    return ERR_SUCCESS;
}


int CViewFinishRollStra::HRS_GetStrategyData(HRS_FM_ALL_DATA *pAllData,
                                             HRS_FM_DRAFT_RATIO *pDraftRatio,
                                             HRS_TABLE_FM_SPEED *pSpeedTable)
{
    HRS_FM_DRAFTRATIO_QUERY_INFO    DraftRatioQueryInfo;
    int                             nRet;

    if (NULL == pAllData || NULL == pDraftRatio || NULL == pSpeedTable)
    {
        return ERR_FAILED;
    }

    // ������ѯ�����ȼ���Ϣ
    nRet = HRS_FM_QuerySlabLevel(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����׼������
    nRet = HRS_FM_QueryDraftRatioTable_PrepPara(pAllData, &DraftRatioQueryInfo);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ��ѯ����ѹ���ʷ����
    nRet = HRS_FM_QueryDraftRatioTable(&DraftRatioQueryInfo, 
                                       pDraftRatio,
                                       pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FM_QuerySpeedTable(pAllData, pSpeedTable);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    nRet = HRS_FmSpeedTab_Search(pSpeedTable, pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewFinishRollStra::GetFinishRollGuiData()
{
    int nRet = -1;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return ERR_FAILED;
    }

    // ��ȡGUI�������趨���ݸ�����
    nRet = PceData_GetPdiForCalc(m_pCurPceData, &m_FmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return nRet;
    }

    nRet = PceData_GetFmStraDataForCalc(m_pCurPceData, 
                                        &m_FmAllData.FMStrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return nRet;
    }

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return nRet;
    }

    pModule->GetAllStandPara(&m_FmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(m_FmAllData.DeformFactor.szSteelGrade, 
        m_FmAllData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);

    if (pFactor != NULL )
    {
        m_FmAllData.DeformFactor = *pFactor;
    }
    else
    {
        m_FmAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;    // ��������
        m_FmAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_FmAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_FmAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_FmAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        m_FmAllData.DeformFactor.dReserve1 = 1;
        m_FmAllData.DeformFactor.dReserve2 = 1;
    }


    return ERR_SUCCESS;
}


int CViewFinishRollStra::GetFinishRollCfgData()
{
#if 1
    if (NULL == m_pCurPceData)
    {
        return ERR_FAILED;
    }

    HRS_FM_DRAFT_RATIO DraftRatio;
    HRS_TABLE_FM_SPEED SpeedPara;

    //��ȡ����
    if (ERR_FAILED == GetFinishRollGuiData())
    {
        MessageBox("�������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }
    
    if (ERR_FAILED == HRS_GetStrategyData(&m_FmAllData,&DraftRatio, &SpeedPara))
    {
        MessageBox(m_FmAllData.szOutErr);
        return ERR_FAILED;
    }


    //���ݸ�ֵ
    HRS_FINISHROLL_STRA_DATA  *pStraData;

    HRS_ROUGHROLL_STRA *pRoughStra;

    pRoughStra = &(m_pCurPceData->stRoughRollStra);

    pStraData = &(m_pCurPceData->stFinishRollStra.FinishRollStraData);
 
    //�м�������ж�
    if ( pRoughStra->bRm_Exit_Thick_Auto)
    {
        pStraData->fBarThick = m_pCurPceData->stRollSched.fR_H;
    }
    else
    {
        if ( m_pCurPceData->nRoughRollSchedStatus == ERR_SUCCESS )
        {
            pStraData->fBarThick = m_pCurPceData->stRoughRollSched.dTransferBarGauge;
        }
        else
        {
            pStraData->fBarThick = m_pCurPceData->stRollSched.fR_H;
        }
    }

    pStraData->fBarWidth    = pRoughStra->fRMExitWidth;
    pStraData->fBarTemp     = pRoughStra->fRMExitTemp;
    pStraData->fFET         = pRoughStra->fRMExitTemp - 15.0;

#if 0
    pStraData->fBarWidth    = m_pCurPceData->stRollSched.fC_W;
    pStraData->fBarTemp     = m_pCurPceData->stRollSched.fRDT;
    pStraData->fFET         = m_pCurPceData->stRollSched.fRDT - 15.0;
#endif

    pStraData->fThickCorr   = 0;

    pStraData->fACC1        = SpeedPara.dTempAccelator;
    pStraData->fMaxSpeed    = SpeedPara.dMaxSpeed;
    pStraData->fThreadSpeed = SpeedPara.dThreadSpeed;
    pStraData->fACC2        = SpeedPara.dPowerAccelator;

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++ )
    {
        m_pCurPceData->stFinishRollStra.FinishRollLoadData.fLoadValue[i] = 
                                                    DraftRatio.adDraftRatio[i];
    }

#endif

    return ERR_SUCCESS;
}


void CViewFinishRollStra::SetRollSchedMgr(CPceDataMgr * pRollSchedMgr) 
{
    m_pRollSchedMgr = pRollSchedMgr;
    InitComboxStripNo();
    InitComboxSprayCod();

    if (ERR_FAILED == GetFinishRollCfgData())
    {
        MessageBox("�������ݶ�ȡʧ�ܣ�");
    }

    RefreshGridFMStraData();
    RefreshGridFMLoadData();
    RefreshFMOtherData();

    // move
    InitGridPDI();

    // ѡ�е�1��
    m_GridFinishRollPDI.SetSelectedRange(theApp.m_nPDIRow, 
                                1, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridFinishRollPDI.ScrollToRow(theApp.m_nPDIRow);

}


void CViewFinishRollStra::SetFMSched(HRS_FM_SCHED &FMSched)
{
    int nRet = -1;

    if (FMSched.nRet == ERR_FAILED)
    {
        AfxMessageBox(FMSched.szOutErr);
        AfxMessageBox("������̼���ʧ��!");

        return;
    }

    if ( FMSched.szOutErr[0] != '\0' )
    {
        if (stricmp(FMSched.szOutErr, HRS_SUCCESS_STR) != 0)
        {
            AfxMessageBox(FMSched.szOutErr);
            AfxMessageBox("������̼���ʧ��!");

            return;
        }
    }

    m_pCurPceData->stRealFinishRollSched = FMSched;

    nRet = PceData_SetFmSchedCalcFromCalc(m_pCurPceData, &FMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������þ�����̴���!");
        return;
    }
    m_pCurPceData->nFinishRollSchedStatus = nRet;

    nRet = m_pRollSchedMgr->SetSteelStatus(m_pCurPceData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�����������ô���!");
        return;
    }

    // ˢ�����Ƽƻ�����
    int nPos = m_GridFinishRollPDI.GetScrollPos(SB_VERT);

    InitGridPDI();

    m_GridFinishRollPDI.SetScrollPos(SB_VERT, nPos);

    m_GridFinishRollPDI.SetSelectedRange(theApp.m_nPDIRow, 
        1, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_CheckISCF34 = !(m_pCurPceData->stFinishRollStra.bISCCloseF34);
    m_CheckISCF45 = !(m_pCurPceData->stFinishRollStra.bISCCloseF45);
    m_CheckISCF56 = !(m_pCurPceData->stFinishRollStra.bISCCloseF56);
    m_CheckISCF67 = !(m_pCurPceData->stFinishRollStra.bISCCloseF67);

    m_bCheckDescAuto = m_pCurPceData->stFinishRollStra.bDESCAuto;

    UpdateData(FALSE);

    RefreshFinishRollSchedGrid();

    AfxMessageBox("������̼���ɹ�!");
}


void CViewFinishRollStra::OnBnClickedFmCheckRemote()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    UpdateData(TRUE);
}

void CViewFinishRollStra::OnBnClickedRadio1()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    m_CheckRadio1 = FALSE;

    ((CButton *)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);

    AfxMessageBox("��ʱû�д��־�����̼��㷽��!");

    UpdateData(FALSE);

    return;
}

void CViewFinishRollStra::OnBnClickedRadio2()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
}
