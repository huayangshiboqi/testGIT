// ViewRollerData.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"

#include "NG_errno.h" 
#include "NG_malloc.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "ViewRollerData.h"

#define  TABLE_INVAL_STR             ", \t;#!\\"


INT_STR  g_HRS_Roller_Key_IntStr[] = {

    {HRS_ROLLER_NO_E1WS,      HRS_ROLLER_E1WS_STR  },
    {HRS_ROLLER_NO_E1OS,      HRS_ROLLER_E1OS_STR  },
    {HRS_ROLLER_NO_R1T,       HRS_ROLLER_R1T_STR   },
    {HRS_ROLLER_NO_R1B,       HRS_ROLLER_R1B_STR   },
    {HRS_ROLLER_NO_E2WS,      HRS_ROLLER_E2WS_STR  },
    {HRS_ROLLER_NO_E2OS,      HRS_ROLLER_E2OS_STR  },
    {HRS_ROLLER_NO_R2BT,      HRS_ROLLER_R2BT_STR  },
    {HRS_ROLLER_NO_R2BB,      HRS_ROLLER_R2BB_STR  },
    {HRS_ROLLER_NO_R2WT,      HRS_ROLLER_R2WT_STR  },
    {HRS_ROLLER_NO_R2WB,      HRS_ROLLER_R2WB_STR  },
    {HRS_ROLLER_NO_E3WS,      HRS_ROLLER_E3WS_STR  },
    {HRS_ROLLER_NO_E3OS,      HRS_ROLLER_E3OS_STR  },
    {HRS_ROLLER_NO_F1BT,      HRS_ROLLER_F1BT_STR  },
    {HRS_ROLLER_NO_F1BB,      HRS_ROLLER_F1BB_STR  },
    {HRS_ROLLER_NO_F1WT,      HRS_ROLLER_F1WT_STR  }, 
    {HRS_ROLLER_NO_F1WB,      HRS_ROLLER_F1WB_STR  },
    {HRS_ROLLER_NO_F2BT,      HRS_ROLLER_F2BT_STR  },
    {HRS_ROLLER_NO_F2BB,      HRS_ROLLER_F2BB_STR  },
    {HRS_ROLLER_NO_F2WT,      HRS_ROLLER_F2WT_STR  },
    {HRS_ROLLER_NO_F2WB,      HRS_ROLLER_F2WB_STR  },
    {HRS_ROLLER_NO_F3BT,      HRS_ROLLER_F3BT_STR  },
    {HRS_ROLLER_NO_F3BB,      HRS_ROLLER_F3BB_STR  },
    {HRS_ROLLER_NO_F3WT,      HRS_ROLLER_F3WT_STR  },
    {HRS_ROLLER_NO_F3WB,      HRS_ROLLER_F3WB_STR  },
    {HRS_ROLLER_NO_F4BT,      HRS_ROLLER_F4BT_STR  },
    {HRS_ROLLER_NO_F4BB,      HRS_ROLLER_F4BB_STR  },
    {HRS_ROLLER_NO_F4WT,      HRS_ROLLER_F4WT_STR  },
    {HRS_ROLLER_NO_F4WB,      HRS_ROLLER_F4WB_STR  },
    {HRS_ROLLER_NO_F5BT,      HRS_ROLLER_F5BT_STR  },
    {HRS_ROLLER_NO_F5BB,      HRS_ROLLER_F5BB_STR  },
    {HRS_ROLLER_NO_F5WT,      HRS_ROLLER_F5WT_STR  },
    {HRS_ROLLER_NO_F5WB,      HRS_ROLLER_F5WB_STR  },
    {HRS_ROLLER_NO_F6BT,      HRS_ROLLER_F6BT_STR  },
    {HRS_ROLLER_NO_F6BB,      HRS_ROLLER_F6BB_STR  }, 
    {HRS_ROLLER_NO_F6WT,      HRS_ROLLER_F6WT_STR  },
    {HRS_ROLLER_NO_F6WB,      HRS_ROLLER_F6WB_STR  },
    {HRS_ROLLER_NO_F7BT,      HRS_ROLLER_F7BT_STR  },
    {HRS_ROLLER_NO_F7BB,      HRS_ROLLER_F7BB_STR  },
    {HRS_ROLLER_NO_F7WT,      HRS_ROLLER_F7WT_STR  },
    {HRS_ROLLER_NO_F7WB,      HRS_ROLLER_F7WB_STR  },

    { -1, NULL    }
};



/** ����ID�Ų���������Ϣ���ַ�

    @param  int nId -- Channel��Ϣ��ID��

    @return char * - ���ز��ҵ�����Ϣ������
*/
char *HRS_Roller_GetKeyName(int nId)
{
    int nPos;
    nPos = IntStr_FindByInt(g_HRS_Roller_Key_IntStr, nId);
    if ( nPos < 0 )
    {
        return NULL;
    }

    return g_HRS_Roller_Key_IntStr[nPos].psz;
}


// ViewRollerData

IMPLEMENT_DYNCREATE(CViewRollerData, CFormView)

CViewRollerData::CViewRollerData()
	: CFormView(CViewRollerData::IDD)
{

    m_pRollerDataMgr  = NULL;
    m_pTotalRollerMgr = NULL;

    //m_bAddState = FALSE;
}

CViewRollerData::~CViewRollerData()
{
    m_pRollerDataMgr  = NULL;
    m_pTotalRollerMgr = NULL;

}

void CViewRollerData::DoDataExchange(CDataExchange* pDX)
{
    DDX_GridControl(pDX, IDC_GRIDCTRL_ROLLER_DATA, m_GridRollerData);

	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CViewRollerData, CFormView)
    ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRIDCTRL_ROLLER_DATA, OnGridEndLableEdit)
    ON_BN_CLICKED(IDC_SAVEROLLER, &CViewRollerData::OnBnClickedButScSave)
    ON_BN_CLICKED(IDC_BUT_ADDROLLER, &CViewRollerData::OnBnClickedButScAdd)
    ON_BN_CLICKED(IDC_BUT_DELEROLLER, &CViewRollerData::OnBnClickedButScDel)

END_MESSAGE_MAP()


// ViewRollerData ���

#ifdef _DEBUG
void CViewRollerData::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewRollerData::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// ViewRollerData ��Ϣ��������

void CViewRollerData::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GridCtrlInit();

    return;
}


void CViewRollerData::OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    if (NULL == pNotifyStruct ||NULL == pResult)
    {
        return;
    }

    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    if (pItem->iRow < 1)
    {
        RefreshRollerGrid();

        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    CString StrTempItem;
    CString StrItem;

    HRS_ROLLER_DATA *pTempRollerData;

    HRS_ROLLER_DATA  **ppszTemp =NULL;
    HRS_ROLLER_DATA  *pszSearch =NULL;

    StrItem = m_GridRollerData.GetItemText(nRow, 1);

    //�����ż��
    if (nCol == 1)
    {
        CGridBtnCellCombo* pGridBtnCellCombo = 
                        (CGridBtnCellCombo*)m_GridRollerData.GetCell( nRow, 1);
        int nState = pGridBtnCellCombo->GetDownButtonPicture();

        //��ȡ
        ppszTemp = &(HRS_ROLLER_DATA *)m_pRollerDataMgr->ppstData[nRow - 1];

        pTempRollerData = (HRS_ROLLER_DATA *)*ppszTemp;
        StrTempItem = pTempRollerData->szRollerNo;

        int nRet = SearchRollerFromTotal((char *)(LPCTSTR)StrItem, 
                                          m_pTotalRollerMgr);

        //�༭״̬
        if (FALSE == nState && ERR_SUCCESS == nRet)
        {
            AfxMessageBox("���������ڣ�");

            RefreshRollerGrid();

            return;
        }
        else if (FALSE == nState && ERR_FAILED == nRet)
        {
            strcpy((*ppszTemp)->szRollerNo, StrItem);
        }

        //����״̬
        if (TRUE == nState)
        {
            *ppszTemp = m_pRollerMgr->SearchRolller((char *)(LPCTSTR)StrItem, 
                m_pTotalRollerMgr);
            if (NULL == *ppszTemp)
            {
                *ppszTemp = pTempRollerData;

                //strcpy((*ppszTemp)->szRollerNo, StrItem);
            }
            else
            {
                strcpy((*ppszTemp)->szRollerType, pTempRollerData->szRollerType);
                strcpy(pTempRollerData->szRollerType, "NULL");
            }

            pGridBtnCellCombo->SetDownButtonPicture(FALSE);
        }

#if 0
        if (m_bAddState)
        {
            int nRet = GetRollerPassFromGrid(nRow);
            if(ERR_FAILED == nRet)
            {
                RefreshRollerGrid();

                return;
            }

            nRet = SearchRollerFromTotal((char *)(LPCTSTR)StrItem, 
                                               m_pTotalRollerMgr);
            if (ERR_SUCCESS == nRet)
            {
                AfxMessageBox("���������ڣ�");

                RefreshRollerGrid();

                return;
            }

            pszSearch = m_pRollerMgr->SearchRolller((char *)(LPCTSTR)StrItem, 
                                                    m_pTotalRollerMgr);
            if (NULL == pszSearch)
            {
                //�ݲ�����
                //AfxMessageBox("������������, ���ӳɹ���");
            }
            else
            {
                AfxMessageBox("���������ڣ�");

                ppszTemp = &pszSearch;

                strcpy((*ppszTemp)->szRollerType, pTempRollerData->szRollerType);
                strcpy(pTempRollerData->szRollerType, "NULL");
            }

            m_bAddState = FALSE;
        }
        else
        {
            int nRet = SearchRollerFromTotal((char *)(LPCTSTR)StrItem, 
                                              m_pTotalRollerMgr);

            //�༭״̬
            if (FALSE == nState && ERR_SUCCESS == nRet)
            {
                AfxMessageBox("���������ڣ�");

                RefreshRollerGrid();

                return;
            }
            
            //����״̬
            if (TRUE == nState)
            {
                *ppszTemp = m_pRollerMgr->SearchRolller((char *)(LPCTSTR)StrItem, 
                                                        m_pTotalRollerMgr);
                if (NULL == *ppszTemp)
                {
                    *ppszTemp = pTempRollerData;

                    strcpy((*ppszTemp)->szRollerNo, StrItem);
                }
                else
                {
                    strcpy((*ppszTemp)->szRollerType, pTempRollerData->szRollerType);
                    strcpy(pTempRollerData->szRollerType, "NULL");
                }

                pGridBtnCellCombo->SetDownButtonPicture(FALSE);
            }
        }
#endif
    }
    else
    {
        //���Ľṹ������
        int nRet = GetRollerPassFromGrid(nRow);
        if(ERR_FAILED == nRet)
        {
            RefreshRollerGrid();

            return;
        }
    }
    

    //����״̬���
#if 0
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_STATE);
    if (ROLLER_USE == StrItem)
    {
        AfxMessageBox("���ݸ���ʧ�ܣ������������ã�");
    }
#endif


    RefreshRollerGrid();

    //m_pRollerMgr->SaveRollerData(ROLLER_DATA_FILE);
}


HRS_ROLLER_DATA *CViewRollerData::SearchRollerNum(int nRow)
{
    HRS_ROLLER_DATA *pRollerData;
    //CString StrItem;
    int RowCount;

    RowCount = m_GridRollerData.GetRowCount();
    if ( nRow < 1 || nRow >= RowCount)
    {
        return NULL;;
    }

    char **ppszTemp = (char **)m_pRollerDataMgr;

    ppszTemp += (nRow - 2);

    pRollerData = (HRS_ROLLER_DATA *)ppszTemp;

    //int nCurN0 = -1;

    ////������
    //StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_NO);

    ////����������Ϣ
    //for (int i = 0; i < pRollerData->nRollerDataNum; i++)
    //{
    //    if (StrItem == pRollerData->stRollerData[i].szRollerNo)
    //    {
    //        pRollerData->nRollerDataCurN0 = i;
    //        nCurN0 = pRollerData->nRollerDataCurN0;
    //    }
    //}
    //if (nCurN0 < 0)
    //{
    //    return NULL;
    //}

    //StrItem.ReleaseBuffer();

    return pRollerData;
}




/** Method:    CheckRollerDia
    �������

    @param int nRow - ����λ��
    @param int nRollerDia - ����ֵmm
    
    @return int - �����ڷ�Χ�ڷ���ERR_SUCCESS�����򷵻�ERR_FAILED
*/
int CViewRollerData::CheckRollerDia(int nRow, double dRollerDia)
{
    if (nRow < 0 || nRow > HRS_ROLLER_NO_MAX)
    {
        return ERR_FAILED;
    }
    
    int nRollerType = GetGroupNo( nRow - 1);

    if (g_RollerDiaMax[nRollerType] <= 0)
    {
        AfxMessageBox("���������");
    }

    if (dRollerDia > g_RollerDiaMax[nRollerType] * 1000 
    || dRollerDia < g_RollerDiaMin[nRollerType] * 1000 )
    {
        char szDia[256];
        sprintf_s(szDia, 256, 
            "����������������Χ��������ΧΪ%f~ %f", 
            g_RollerDiaMin[nRollerType] * 1000,
            g_RollerDiaMax[nRollerType] * 1000);
        AfxMessageBox(szDia);

        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewRollerData::GetRollerPassFromGrid(int nRow)
{
    #if 1
    HRS_ROLLER_DATA *pRollerData;

    CString StrItem;

    int nCurN0 = -1;

    //pRollerData = SearchRollerNum(nRow);
    char **ppszTemp = (char **)m_pRollerDataMgr;

    ppszTemp += (nRow - 1);

    pRollerData = (HRS_ROLLER_DATA *)*ppszTemp;

    if (NULL == pRollerData)
    {
        return ERR_FAILED;
    }

    //��������
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_NO);
    if (NULL != m_pRollerMgr->SearchRolller((char *)(LPCTSTR)StrItem, 
                                            m_pTotalRollerMgr))
    {
        AfxMessageBox("�˹����Ѿ����ڣ������¸���");

        return ERR_FAILED;
    }

    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("�˹������зǷ��ַ���");
        return ERR_FAILED;
    }

    sprintf_s(pRollerData->szRollerNo , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();

    //����ֱ��
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_DIA);

    double dData = atof((char *)(LPCTSTR)StrItem);

    int nRet = CheckRollerDia(nRow, dData);
    if (ERR_FAILED == nRet)
    {
        return ERR_FAILED;
    }

    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("�˹������зǷ��ַ���");
        return ERR_FAILED;
    }

    sprintf_s(pRollerData->szRollerDIA , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();


    //����͹��
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_CROW);
    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("��͹�����зǷ��ַ���");
        return ERR_FAILED;
    }
    sprintf_s(pRollerData->szRollerCrow , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();


    //��������
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_MATERIAL);
    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("�������������зǷ��ַ���");
        return ERR_FAILED;
    }
    sprintf_s(pRollerData->szRollerMaterial , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();

    //���ƶ�λ
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_TONS);
    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("�����ƶ�λ���зǷ��ַ���");
        return ERR_FAILED;
    }
    sprintf_s(pRollerData->szRollerTons , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();

    //��������
    /*StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_TYPE);
    sprintf_s(pRollerData->szRollerType , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();*/

    //���ܺ�
    /*StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_STAND_NO);
    sprintf_s(pRollerData->szStandNo , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();*/

    //����λ��
    /*StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_POS);
    sprintf_s(pRollerData->szRollPos , 
              HRS_RILLER_INFO_LEN,
              "%s", 
              StrItem.GetBuffer());
    StrItem.ReleaseBuffer();*/

    //����״̬
    StrItem = m_GridRollerData.GetItemText(nRow, HRS_ROLLER_DATA_ROLLER_STATE);
    if (ERR_SUCCESS == StrMatch((char *)(LPCTSTR)StrItem, TABLE_INVAL_STR))
    {
        AfxMessageBox("������״̬���зǷ��ַ���");
        return ERR_FAILED;
    }
    sprintf_s(pRollerData->szRollState , 
        HRS_RILLER_INFO_LEN,
        "%s", 
        StrItem.GetBuffer());
    StrItem.ReleaseBuffer();

#endif

    return ERR_SUCCESS;
}


void CViewRollerData::GridCtrlInit()
{
    int                 iCol; 
    int                 iColNumber;  

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROLLER_DATA_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROLLER_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLLER_ITEM_NUM;

        //m_GridRoughRollStra.SetGridStyle(GRID_BLUE);
        m_GridRollerData.SetListMode(TRUE);
        m_GridRollerData.SetTextBkColor(GRID_BG_COR);
        //m_GridRoughRollStra.SetBkColor(GRID_BG_COR);
        m_GridRollerData.SetModified(FALSE);

        m_GridRollerData.SetColumnCount(iColNumber);
        //m_GridRoughRollStra.SetRowCount(iColNumber);

        m_GridRollerData.SetFixedRowCount(1);
        m_GridRollerData.SetFixedColumnCount(1); 
        m_GridRollerData.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        //Item.lfFont.lfHeight = 20;      //test

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridRollerData.SetItem(&Item);

#if 1
        //��������
        CFont cNewFont;
        LOGFONT lgFont;
        cNewFont.CreateFontA(16,
                            0,
                            0,
                            0,
                            FW_NORMAL,
                            0,
                            0,
                            0,
                            DEFAULT_CHARSET,
                            OUT_DEFAULT_PRECIS,
                            CLIP_DEFAULT_PRECIS,
                            DEFAULT_QUALITY,
                            DEFAULT_PITCH | FF_SWISS,
                            "Arial");
        cNewFont.GetLogFont(&lgFont);
        m_GridRollerData.SetItemFont(0, iCol, &lgFont);
#endif

        m_GridRollerData.SetRowHeight(0, 28);
    }

    m_GridRollerData.AutoSizeColumns();

    return;
}


void CViewRollerData::OnBnClickedButScAdd()
{
    int nReturn =  AfxMessageBox("�Ƿ��������ݣ�",
        MB_OKCANCEL | MB_ICONQUESTION);

    if(MB_ICONQUESTION == nReturn)
    {
        return;
    }

    CCellID Crow = m_GridRollerData.GetFocusCell();

    int nRow = Crow.row;

    int nRet = m_pRollerMgr->AddRollerDataMgr(nRow, m_pTotalRollerMgr);
    if (ERR_FAILED == nRet)
    {
        AfxMessageBox("��������ʧ�ܣ�");
        return;
    }

    RefreshRollerGrid();

    m_bAddState = TRUE;

    return;
}


void CViewRollerData::OnBnClickedButScDel()
{
    int nReturn =  AfxMessageBox("�Ƿ�ɾ�����ݣ�",
        MB_OKCANCEL | MB_ICONQUESTION);

    if(MB_ICONQUESTION == nReturn)
    {
        return;
    }

    CCellID Crow = m_GridRollerData.GetFocusCell();

    int nRow = Crow.row;

    int nRet = m_pRollerMgr->DeletRollerDataMgr(nRow, 
                                                m_pRollerDataMgr,
                                                m_pTotalRollerMgr);

    if (ERROR_NG_DEL == nRet)
    {
        AfxMessageBox("��Ϊû�п���ʹ�õ�����������ɾ��ʧ�ܣ�");
    }

    RefreshRollerGrid();

    m_bAddState = TRUE;
}


void CViewRollerData::OnBnClickedButScSave()
{
    int nReturn =  AfxMessageBox("�Ƿ񱣴����ݣ�",
        MB_OKCANCEL | MB_ICONQUESTION);

    if(MB_ICONQUESTION == nReturn)
    {
        return;
    }

    if (ERR_FAILED == m_pRollerMgr->SaveRollerDataMgr(ROLLER_DATA_FILE))
    {
        AfxMessageBox("���ݱ���ʧ�ܣ�");

        return;
    }

    return;
}


void CViewRollerData::RefreshRollerGrid()
{
#if 1
    if (NULL == m_pRollerMgr)
    {
        return;
    }

    if (NULL == m_pRollerDataMgr)
    {
        m_pRollerDataMgr = m_pRollerMgr->GetRollerDataMgr();
    }

    if(NULL == m_pTotalRollerMgr)
    {
        m_pTotalRollerMgr = m_pRollerMgr->GetTotalRollerDataMgr();
    }

    if (NULL == m_pRollerDataMgr || NULL == m_pTotalRollerMgr)
    {
        return;
    }

    //������ֵ
    HRS_ROLLER_DATA *pRollerData = NULL;

    int nCurN0 = -1;

    char strHeading[5]={0};
    int  RowCount;

    if (m_pRollerMgr == NULL)
    {
        return;
    }

    CCellRange cell_range = m_GridRollerData.GetSelectedCellRange();

    int nScrollPos = m_GridRollerData.GetScrollPos(SB_VERT);



    m_GridRollerData.DeleteNonFixedRows();

    for (int i = 0; i < HRS_ROLLER_GUI_TYPE_NO; i++)
    {
        pRollerData = (HRS_ROLLER_DATA *)m_pRollerDataMgr->ppstData[i];
        if (NULL == pRollerData)
        {
            AfxMessageBox("������ʾʧ�ܣ�");
            return;
        }

        nCurN0 = pRollerData->nRollerEmptyState;
        if (nCurN0 != ERR_SUCCESS)
        {
            AfxMessageBox("������ʾʧ�ܣ�");
            continue;
        }

        pRollerData->nRollerUseState = ERR_FAILED;

        RowCount = m_GridRollerData.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRollerData.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLLER_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_ROLLER_DATA_STAND_NO :
                Item.strText.Format(_T("%s"), HRS_Roller_GetKeyName(i));
                break;
            case HRS_ROLLER_DATA_ROLLER_DIA :
                Item.strText.Format(_T("%s"), pRollerData->szRollerDIA);
                break;
            case HRS_ROLLER_DATA_ROLLER_CROW :
                Item.strText.Format(_T("%s"), pRollerData->szRollerCrow);
                break;
            case HRS_ROLLER_DATA_ROLLER_MATERIAL :
                Item.strText.Format(_T("%s"), pRollerData->szRollerMaterial);
                break;
            case HRS_ROLLER_DATA_ROLLER_TONS :
                Item.strText.Format(_T("%s"), pRollerData->szRollerTons);
                break;
            //case HRS_ROLLER_DATA_ROLLER_TYPE :
            //    Item.strText.Format(_T("%s"), 
            //                pRollerData->stRollerData[nCurN0].szRollerType);
            //    break;
            case HRS_ROLLER_DATA_ROLLER_NO :
                Item.strText.Format(_T("%s"), pRollerData->szRollerNo);
                break;
            //case HRS_ROLLER_DATA_ROLLER_POS :
            //    Item.strText.Format(_T("%s"), 
            //                pRollerData->stRollerData[nCurN0].szRollPos);
            //    break;
            case HRS_ROLLER_DATA_ROLLER_STATE :
                Item.strText.Format(_T("%s"), ROLLER_USE);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridRollerData.SetItem(&Item);

#if 1
            //��������
            CFont cNewFont;
            LOGFONT lgFont;
            cNewFont.CreateFontA(16,
                                0,
                                0,
                                0,
                                FW_NORMAL,
                                0,
                                0,
                                0,
                                DEFAULT_CHARSET,
                                OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,
                                DEFAULT_QUALITY,
                                DEFAULT_PITCH | FF_SWISS,
                                "Arial");
            cNewFont.GetLogFont(&lgFont);
            m_GridRollerData.SetItemFont(RowCount, j, &lgFont);
#endif

            m_GridRollerData.SetRowHeight(RowCount, 28);
        }
    }

    typedef struct
    {
        CGridBtnCellBase::STRUCT_DRAWCTL DrawCtl;  // most btn props here
        int iBtnNbr;                        // which btn within cell does this define?
        const char* pszBtnText;             // text associated with pushbutton or NULL
    }   STRUCT_CTL;

    STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        
        { -1,  DFCS_SCROLLDOWN, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 0, NULL},
    };  // (-1 iWidth's will be filled-in later)

    int iComboCtlWidth = GetSystemMetrics( SM_CXVSCROLL);

    HRS_ROLLER_GROUP *pRollerGroup = (HRS_ROLLER_GROUP *)m_pTotalRollerMgr;

    //pTemRollerData = pRollerData;

    int nNum = m_GridRollerData.GetRowCount();
    for ( int row = m_GridRollerData.GetFixedRowCount(); row < m_GridRollerData.GetRowCount(); row++)
    {
        CStringArray strAryCombo;

        pRollerGroup = HRS_GetRollerDataOneByRow(m_pTotalRollerMgr, row);
        if (NULL == pRollerGroup)
        {
            continue;
        }

        for(int i = 0; i < pRollerGroup->nRollerDataNum; i++)
        {
            if (0 != StrCompare(pRollerGroup->stRollerData[i].szRollerType, "NULL"))
            {
                continue;
            }
            strAryCombo.Add( pRollerGroup->stRollerData[i].szRollerNo);

        }
        // retain old cell properties
        CGridBtnCell GridCellCopy;
        GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
        CGridCellBase* pCurrCell = m_GridRollerData.GetCell( row,1);
        if (pCurrCell)
            GridCellCopy = *pCurrCell;

        // replace standard cell with special control cell
        m_GridRollerData.SetCellType( row, 1, RUNTIME_CLASS(CGridBtnCellCombo) );
        CGridBtnCellCombo* pGridBtnCellCombo = (CGridBtnCellCombo*)m_GridRollerData.GetCell( row, 1);
        pGridBtnCellCombo->SetComboStyle( CBS_DROPDOWN);
        pGridBtnCellCombo->SetComboString( strAryCombo);

        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridRollerData.GetCell( row, 1);
        pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);

        // draw controls within a cell
        int iWidth = DrawCtlAry[ 0].DrawCtl.iWidth;
        if( iWidth < 0) iWidth = 22;  //iComboCtlWidth;      //mod

        pGridBtnCell->SetupBtns(
            DrawCtlAry[ 0].iBtnNbr,        // zero-based index of image to draw
            DrawCtlAry[ 0].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
            DrawCtlAry[ 0].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
            (CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ 0].DrawCtl.ucAlign,
            // horizontal alignment of control image
            iWidth,                         // fixed width of control or 0 for size-to-fit
            DrawCtlAry[ 0].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
            DrawCtlAry[ 0].pszBtnText );   // Text to insert centered in button; if NULL no text
    }

#if 0

    CStringArray strAryCombo;
    strAryCombo.Add( "USE");
    strAryCombo.Add( "UNUSE");

    for ( int row = m_GridRollerData.GetFixedRowCount(); row < m_GridRollerData.GetRowCount(); row++)
    {
        // retain old cell properties
        CGridBtnCell GridCellCopy;
        GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
        CGridCellBase* pCurrCell = m_GridRollerData.GetCell( row, 6);
        if (pCurrCell)
            GridCellCopy = *pCurrCell;

        // replace standard cell with special control cell
        m_GridRollerData.SetCellType( row, 6, RUNTIME_CLASS(CGridBtnCellCombo) );
        CGridBtnCellCombo* pGridBtnCellCombo = (CGridBtnCellCombo*)m_GridRollerData.GetCell( row, 6);
        pGridBtnCellCombo->SetComboStyle( CBS_DROPDOWN);
        pGridBtnCellCombo->SetComboString( strAryCombo);

        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridRollerData.GetCell( row, 6);
        pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);

        // draw controls within a cell
        int iWidth = DrawCtlAry[ 0].DrawCtl.iWidth;
        if( iWidth < 0) iWidth = 22;  //iComboCtlWidth;      //mod

        pGridBtnCell->SetupBtns(
            DrawCtlAry[ 0].iBtnNbr,        // zero-based index of image to draw
            DrawCtlAry[ 0].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
            DrawCtlAry[ 0].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
            (CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ 0].DrawCtl.ucAlign,
            // horizontal alignment of control image
            iWidth,                         // fixed width of control or 0 for size-to-fit
            DrawCtlAry[ 0].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
            DrawCtlAry[ 0].pszBtnText );   // Text to insert centered in button; if NULL no text

    }

#endif

    m_GridRollerData.AutoSizeColumns();

    m_GridRollerData.Refresh();

    m_GridRollerData.SetScrollPos(SB_VERT, nScrollPos);

    m_GridRollerData.SetSelectedRange(cell_range.GetMinRow(), cell_range.GetMinCol(),
        cell_range.GetMaxRow(), cell_range.GetMaxCol(), TRUE);

    UpdateData(FALSE);

    return;
#endif
}
