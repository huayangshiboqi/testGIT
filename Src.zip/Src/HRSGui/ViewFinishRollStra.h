#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"
#include "HRS_FmSpeedTable.h"
#include "HRS_FMCalc.h"
#include "afxwin.h"


// CViewFinishRollStra ������ͼ

class CViewFinishRollStra : public CFormView
{
    DECLARE_DYNCREATE(CViewFinishRollStra)
private:
    CPceDataMgr *       m_pRollSchedMgr;
    PCE_DATA *          m_pCurPceData;

protected:
    CGridCtrl m_GridFMStraData;  // ���Ա���

    // move
    CGridCtrl m_GridFinishRollPreCalc;
    CGridCtrl m_GridFinishRollPDI;

    CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls

    CGridCtrl m_GridFMLoadData;

    CBtnDataBase m_BtnFMLoadData; // grid with some cells with buttons / controls
    
    HRS_FM_ALL_DATA    m_FmAllData;
    float              m_fThickCorr;

public:
    CComboBox m_ComboxStripNo;
    CString m_strStripNo;
    CString m_strCurStripNo;
    BOOL    m_BRadioFDTCMode;
    BOOL    m_bCheckFDTCFFUse;
    CButton m_RadCtlFDTCSpeed;
    CButton m_RadCtlFDTCWater;
    BOOL    m_CheckISCF34;
    BOOL    m_CheckISCF45;
    BOOL    m_CheckISCF56;
    BOOL    m_CheckISCF67;
    BOOL    m_bCheckDescAuto;
    CComboBox m_CombCtlDESCSprayCod;
    CString   m_strCombDescSprayCod;

    BOOL    m_CheckRadio1;
    BOOL    m_CheckRadio2;

protected:
    CViewFinishRollStra();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewFinishRollStra();

    int HRS_FM_QuerySpeedTable(HRS_FM_ALL_DATA *pAllData,
        HRS_TABLE_FM_SPEED *pSpeedTable);

    int HRS_GetStrategyData(HRS_FM_ALL_DATA *pAllData,
        HRS_FM_DRAFT_RATIO *pDraftRatio,
        HRS_TABLE_FM_SPEED *pSpeedTable);

    int GetFinishRollCfgData();
    int GetFinishRollGuiData();

public:
    enum { IDD = IDD_VIEW_FINISHROLL_STRA };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()

protected:
    void GridCtrlInit();
    //
    void InitGridPDI();

public:
    virtual void OnInitialUpdate();

    void InitComboxStripNo();
    void InitComboxSprayCod();
    bool ExitConfirm();

    void RefreshGridFMStraData();
    void RefreshGridFMLoadData();
    void RefreshFMOtherData();

private:
    void RefreshFinishRollSchedGrid();

private:
    HRS_FINISHROLL_STRA_DATA * GetFinishRollStraDataFromGrid();
    HRS_FINISHROLL_LOAD_DATA * GetFinishRollLoadDataFromGrid();

public:
    //
    // ������Ĵ�������
    //
    afx_msg void OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnGridFinishRollStraDataClick(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnGridLoadDataEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnGridFinishRollLoadDataClick(NMHDR *pNotifyStruct, LRESULT* pResult);

    // PDI������������������
    afx_msg void OnGridFinishRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult);

public:
    afx_msg void OnCbnSelchangeCombFmStripno();
    afx_msg void OnBnClickedRadFdtcSpeed();
    afx_msg void OnBnClickedRadFdtcWater();
    afx_msg void OnBnClickedCheckFdtcFfUse();
    afx_msg void OnBnClickedCheckIscF34();
    afx_msg void OnBnClickedCheckIscF45();
    afx_msg void OnBnClickedCheckIscF56();
    afx_msg void OnBnClickedCheckIscF67();
    afx_msg void OnBnClickedCheckDescAuto();
    afx_msg void OnCbnSelchangeCombDescSprayCod();
    
    // ���水ť��Ӧ����
    afx_msg void OnBnClickedButFmStraSave();

    // �����ť��Ӧ����
    afx_msg void OnBnClickedButFmStraClean();

    // ���㰴ť��Ӧ����
    afx_msg void OnBnClickedButFmStraCalc();

protected:

    // ����ӿڣ���ChildFrm��ܵ���
public:

    void SetRollSchedMgr(CPceDataMgr * pRollSchedMgr); 
    void SetFMSched(HRS_FM_SCHED &FMSched);

public:
    BOOL m_bCheckRemoteCalc;
public:
    afx_msg void OnBnClickedFmCheckRemote();
    void OnTimer();
public:
    afx_msg void OnBnClickedRadio1();
public:
    afx_msg void OnBnClickedRadio2();
};
