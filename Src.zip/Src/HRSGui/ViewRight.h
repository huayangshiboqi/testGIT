#pragma once



// CViewRight ������ͼ

class CViewRight : public CFormView
{
	DECLARE_DYNCREATE(CViewRight)

public:
	CViewRight();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CViewRight();

public:
	enum { IDD = IDD_VIEWRIGHT };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

    //virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);

    //CSplitterWnd m_wndRightSplitter;

protected:

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:

};


