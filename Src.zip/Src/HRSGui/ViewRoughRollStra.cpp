// ViewRoughRollSchem.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include <math.h>
#include <assert.h>
#include "HRSGui.h"
#include "HRS_Global.h"


#include "NG_errno.h" 
#include "NG_malloc.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "ViewRoughRollStra.h"

#include "HRS_EquipParaMgr.h"
#include "HRS_RMCalc.h"
#include "GridCtrlFunc.h"

#include "NG_types.h"


#pragma warning(disable:4800)
// CViewRoughRollStra

IMPLEMENT_DYNCREATE(CViewRoughRollStra, CFormView)

CViewRoughRollStra::CViewRoughRollStra()
    : CFormView(CViewRoughRollStra::IDD)
    , m_strStripNo(_T(""))
    , m_BPassMode(FALSE)
    , m_pCurPceData(NULL)
    , m_bCheckStandDummyE1(FALSE)
    , m_bCheckRmExitThick(FALSE)
    , m_bCheckStandDummyR1(FALSE)
    , m_bCheckStandDummyE2(FALSE)
    , m_dExtTemp(0)
    , m_dBarThick(0)
    , m_bCheckRemoteCalc(FALSE)
{

    memset(m_RmDraftTab, 0, sizeof(HRS_TABLE_RM_DRAFTRATIO) * HRS_RM_DRAFT_NUM_MAX);
    memset(&m_stRoughRollStra, 0, sizeof(HRS_ROUGHROLL_STRA));

}

CViewRoughRollStra::~CViewRoughRollStra()
{
    //if (m_pCurPceData != NULL)
    //{
    //    PceData_Destroy(m_pCurPceData);
    //}

    m_pCurPceData = NULL;
}

void CViewRoughRollStra::DoDataExchange(CDataExchange* pDX)
{
    DDX_GridControl(pDX, IDC_GRID_ROUGHROLL_STRATEGY, m_GridRoughRollStra);
    DDX_GridControl(pDX, IDC_GRIDCTRL_RM_SCHEDCALC, m_GridRoughRollSchedCalc);
    DDX_GridControl(pDX, IDC_GRIDCTRL_RM_PDI, m_GridRoughRollPDI);

    CFormView::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_COMB_RRSTRA_STRIPNO, m_ComboxStripNo);
    DDX_CBString(pDX, IDC_COMB_RRSTRA_STRIPNO, m_strStripNo);
    DDX_Control(pDX, IDC_RAD_PASSMODE_AUTO, m_RadioGroup_PassMode);
    DDX_Radio(pDX, IDC_RAD_PASSMODE_AUTO, m_BPassMode);
    DDX_Check(pDX, IDC_CHECK_RRS_E1, m_bCheckStandDummyE1);
    DDX_Check(pDX, IDC_CHECK_RRS_RMEXITTHICK, m_bCheckRmExitThick);
    DDX_Control(pDX, IDC_EDIT_RRS_EMEXITTHICK, m_ButCtlRmExitThick);
    DDX_Check(pDX, IDC_CHECK_RRS_R1, m_bCheckStandDummyR1);
    DDX_Check(pDX, IDC_CHECK_RRS_E2, m_bCheckStandDummyE2);
    DDX_Text(pDX, IDC_EDIT_EXT_TEMP, m_dExtTemp);
    DDV_MinMaxDouble(pDX, m_dExtTemp, 1000, 1350);
    DDX_Text(pDX, IDC_EDIT_RRS_EMEXITTHICK, m_dBarThick);
    DDX_Check(pDX, IDC_CHECK_REMOTE, m_bCheckRemoteCalc);
}

BEGIN_MESSAGE_MAP(CViewRoughRollStra, CFormView)
    ON_CBN_SELCHANGE(IDC_COMB_RRSTRA_STRIPNO, &CViewRoughRollStra::OnCbnSelchangeCombRrstraStripno)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_AUTO, &CViewRoughRollStra::OnBnClickedRadPassmodeAuto)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_05, &CViewRoughRollStra::OnBnClickedRadPassmode05)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_17, &CViewRoughRollStra::OnBnClickedRadPassmode17)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_07, &CViewRoughRollStra::OnBnClickedRadPassmode07)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_13, &CViewRoughRollStra::OnBnClickedRadPassmode13)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_15, &CViewRoughRollStra::OnBnClickedRadPassmode15)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_33, &CViewRoughRollStra::OnBnClickedRadPassmode33)
    ON_BN_CLICKED(IDC_RAD_PASSMODE_35, &CViewRoughRollStra::OnBnClickedRadPassmode35)
    ON_NOTIFY(GVN_ENDLABELEDIT, IDC_GRID_ROUGHROLL_STRATEGY, OnGridEndLableEdit)

    ON_BN_CLICKED(IDC_CHECK_RRS_E1, &CViewRoughRollStra::OnBnClickedCheckRrsE1)
    ON_BN_CLICKED(IDC_CHECK_RRS_RMEXITTHICK, &CViewRoughRollStra::OnBnClickedCheckRrsRmexitthick)
    ON_BN_CLICKED(IDC_CHECK_RRS_R1, &CViewRoughRollStra::OnBnClickedCheckRrsR1)
    ON_BN_CLICKED(IDC_CHECK_RRS_E2, &CViewRoughRollStra::OnBnClickedCheckRrsE2)
    ON_EN_CHANGE(IDC_EDIT_RRS_EMEXITTHICK, &CViewRoughRollStra::OnEnChangeEditRrsEmexitthick)
    ON_BN_CLICKED(IDC_BUT_RM_STRA_SAVE, &CViewRoughRollStra::OnBnClickedRmStraSave)

    ON_NOTIFY(NM_CLICK, IDC_GRIDCTRL_RM_PDI, OnGridRoughRollPDIClick)
    ON_NOTIFY(NM_CLICK, IDC_GRID_ROUGHROLL_STRATEGY, OnGridRoughRollStraClick)

    ON_BN_CLICKED(IDC_BUT_RM_STRA_CALC, &CViewRoughRollStra::OnBnClickedRmStraCalc)
    ON_BN_CLICKED(IDC_RM_CLEAR_SET, &CViewRoughRollStra::OnBnClickedRmClearSet)
    ON_BN_CLICKED(IDC_CHECK_REMOTE, &CViewRoughRollStra::OnBnClickedCheckRemote)
END_MESSAGE_MAP()


// CViewRoughRollStra ���

#ifdef _DEBUG
void CViewRoughRollStra::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewRoughRollStra::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewRoughRollStra ��Ϣ��������

void CViewRoughRollStra::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GridCtrlInit();
    //InitComboxStripNo();

    //UpdateData(FALSE);
}



void CViewRoughRollStra::InitComboxStripNo()
{
    char (* ppszStripNo)[HRS_STRIP_NO_LEN];
    int i = 0;

    ppszStripNo = (char (*)[HRS_STRIP_NO_LEN])m_pRollSchedMgr->GetStripNoList();

    while (ppszStripNo[i][0] != NULL)
    {
        m_ComboxStripNo.InsertString(i,ppszStripNo[i]);

        i++;
    }

    int nRow = theApp.m_nPDIRow - 1;
    m_ComboxStripNo.SetCurSel(nRow);
    m_strStripNo = ppszStripNo[nRow];

    m_strCurStripNo = ppszStripNo[nRow];

    m_pCurPceData = m_pRollSchedMgr->GetPceDataByStripNo(m_strStripNo);
    NG_free(ppszStripNo);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    if (ERR_FAILED == m_pCurPceData->nRoughRollStraCfgStatus)
    {
//        CalcRMStraData();

        if (ERR_FAILED == GetCfgData())
        {
            return;
        }

        //SetThick_Exit();

        m_pCurPceData->nRoughRollStraCfgStatus = ERR_SUCCESS;
    }


    if ( m_pCurPceData->nRoughRollSchedStatus == ERR_SUCCESS )
    {
        m_dBarThick = m_pCurPceData->stRoughRollSched.dTransferBarGauge;

        int nIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;
        m_dExtTemp 
          = m_pCurPceData->stRMStraData.aAllPassModeStra[nIndex].fDischargeTemp;
    }
    else
    {
        m_dBarThick = m_pCurPceData->stRollSched.fR_H;
        m_dExtTemp  = m_pCurPceData->stRollSched.fEXT;
    }


    memcpy(&m_stRoughRollStra, 
           &m_pCurPceData->stRoughRollStra, 
           sizeof(HRS_ROUGHROLL_STRA));
    UpdateData(FALSE);
}


void CViewRoughRollStra::GridCtrlInit()
{
    
    int                 iCol; 
    int                 iColNumber;  

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROUGHROLL_STRATEGY_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROUGHROLL_STRA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROUGHROLL_STRA_ITEM_NUM;

        //m_GridRoughRollStra.SetGridStyle(GRID_BLUE);
        m_GridRoughRollStra.SetListMode(TRUE);
        m_GridRoughRollStra.SetTextBkColor(GRID_BG_COR);
        //m_GridRoughRollStra.SetBkColor(GRID_BG_COR);
        m_GridRoughRollStra.SetModified(FALSE);

        m_GridRoughRollStra.SetColumnCount(iColNumber);
        //m_GridRoughRollStra.SetRowCount(iColNumber);

        m_GridRoughRollStra.SetFixedRowCount(1);
        m_GridRoughRollStra.SetFixedColumnCount(1); 
        m_GridRoughRollStra.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        //Item.lfFont.lfHeight = 20;      //test

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridRoughRollStra.SetItem(&Item);

#if 1
        //��������
        CFont cNewFont;
        LOGFONT lgFont;
        cNewFont.CreateFontA(16,
                            0,
                            0,
                            0,
                            FW_NORMAL,
                            0,
                            0,
                            0,
                            DEFAULT_CHARSET,
                            OUT_DEFAULT_PRECIS,
                            CLIP_DEFAULT_PRECIS,
                            DEFAULT_QUALITY,
                            DEFAULT_PITCH | FF_SWISS,
                            "Arial");
        cNewFont.GetLogFont(&lgFont);
        m_GridRoughRollStra.SetItemFont(0, iCol, &lgFont);
#endif

        m_GridRoughRollStra.SetRowHeight(0, 28);
    }

    m_GridRoughRollStra.AutoSizeColumns();


/****/
#define M_T(x) #x
    const char* pszTitle2[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit2[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRoughRollPDI.SetListMode(TRUE);
        m_GridRoughRollPDI.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRoughRollPDI.SetModified(FALSE);

        m_GridRoughRollPDI.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRoughRollPDI.SetFixedRowCount(1);
        m_GridRoughRollPDI.SetFixedColumnCount(1); 
        m_GridRoughRollPDI.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    int anPDIWidth[HRS_ROLL_SCHED_ITEM_NUM] = {
        50, 105, 70, 75, 60, 
        70, 70, 45, 70, 45, 
        70, 70, 70, 70, 75, 
        60, 60, 60, 60, 55, 
        55, 40, 40, 40, 70
    };


    /*
     * ��ʼ�����Ƽƻ�����ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle2[iCol],pszUnit2[iCol]);

        m_GridRoughRollPDI.SetItem(&Item);

        m_GridRoughRollPDI.SetColumnWidth(iCol, anPDIWidth[iCol]);

    }

//    m_GridRoughRollPDI.AutoSize();
/****/

#define M_T(x) #x
    const char* pszTitle3[]  = { HRS_ROUGHROLL_SCHEDCALC_LIST , "\0" };
    const char* pszUnit3[]   = { HRS_ROUGHROLL_SCHEDCALC_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ��������̱��������������
     */
    try
    {
        iColNumber = HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRoughRollSchedCalc.SetListMode(TRUE);
        m_GridRoughRollSchedCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRoughRollSchedCalc.SetModified(FALSE);

        m_GridRoughRollSchedCalc.SetColumnCount(iColNumber);

        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRoughRollSchedCalc.SetFixedRowCount(1);
        m_GridRoughRollSchedCalc.SetFixedColumnCount(1); 
        m_GridRoughRollSchedCalc.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    int anShedWidth[HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM] = {
        80, 85, 85, 90, 90, 
        90, 90, 90, 90, 85, 
        85, 85, 95, 85, 85, 
        85, 80
    };

    /*
     * ��ʼ�������̱���ؼ��ı�ͷ,
     */
    for (iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle3[iCol],pszUnit3[iCol]);

        m_GridRoughRollSchedCalc.SetItem(&Item);

        m_GridRoughRollSchedCalc.SetColumnWidth(iCol, anShedWidth[iCol]);
    }

//    m_GridRoughRollSchedCalc.AutoSize();
/****/

    return;
}



int CViewRoughRollStra::CalcRMStraData()
{
    int nRet;

    //��ȡ����
    if (ERR_FAILED == GetGuiData())
    {
        MessageBox("CViewRoughRollStra::GetCfgData(), GetGuiData(): �������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }

    int nCurIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;

    m_RmAllCalcData.StrategyData.nPassMode 
        = m_pCurPceData->stRoughRollStra.emPassMode;

    if (FALSE == m_bCheckRmExitThick 
        && (m_dBarThick > 1)
        && (ERR_SUCCESS == m_pCurPceData->nRoughRollStraCfgStatus))
    {

    }
    else
    {
        m_RmAllCalcData.StrategyData.dTransferBarThick = 
            m_RmAllCalcData.PlanData.dTransferBarGauge;
    }

    if ( ERR_FAILED == HRS_RMStraData_GetOrgStraData(&m_RmAllCalcData,
        &(m_pCurPceData->stRMStraData)) )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_GetOrgStraData() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    nRet = HRS_RMStraData_CalcAllGauge(&m_RmAllCalcData, 
        &(m_pCurPceData->stRMStraData));
    if ( nRet == ERR_FAILED )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_CalcAllGauge() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    nRet = HRS_RMStraData_CalcAllSpeed(&m_RmAllCalcData, 
        &(m_pCurPceData->stRMStraData));
    if ( nRet == ERR_FAILED )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_CalcAllSpeed() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewRoughRollStra::InitCalcRMStraData()
{
    int nRet;

    //��ȡ����
    if (ERR_FAILED == GetGuiData())
    {
        MessageBox("CViewRoughRollStra::GetCfgData(), GetGuiData(): �������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }

    int nCurIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;

    m_RmAllCalcData.StrategyData.nPassMode 
        = m_pCurPceData->stRoughRollStra.emPassMode;

    if (FALSE == m_bCheckRmExitThick 
        && (m_dBarThick > 1)
        && (ERR_SUCCESS == m_pCurPceData->nRoughRollStraCfgStatus))
    {

    }
    else
    {
        m_RmAllCalcData.StrategyData.dTransferBarThick = 
            m_RmAllCalcData.PlanData.dTransferBarGauge;
    }

    if ( ERR_FAILED == HRS_RMStraData_GetOrgStraData(&m_RmAllCalcData,
        &(m_pCurPceData->stRMStraData)) )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_GetOrgStraData() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    nRet = HRS_RMStraData_CalcAllGauge(&m_RmAllCalcData, 
        &(m_pCurPceData->stRMStraData));
    if ( nRet == ERR_FAILED )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_CalcAllGauge() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    nRet = HRS_RMStraData_InitAllSpeed(&m_RmAllCalcData, 
        &(m_pCurPceData->stRMStraData));
    if ( nRet == ERR_FAILED )
    {
        char szMsg[2048];
        sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMStraData_CalcAllSpeed() Failed\r\n"
            "%s ", 
            m_RmAllCalcData.szOutErr);
        MessageBox(szMsg);
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewRoughRollStra::GetCfgData()
{
    HRS_RM_ALL_PASS AllPass;
    HRS_RM_ALL_SPEED AllSpeed;
    HRS_RM_ALL_DELIVERY_GAUGE AllDeliveryGauge;

    //��ȡ����
    if (ERR_FAILED == GetGuiData())
    {
        MessageBox("CViewRoughRollStra::GetCfgData(), GetGuiData(): �������ݻ�ȡʧ�ܣ�", 
            "�л��ְ�", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);
        return ERR_FAILED;
    }

    int nCurIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;

    m_RmAllCalcData.StrategyData.nPassMode 
        = m_pCurPceData->stRoughRollStra.emPassMode;

    if (FALSE == m_bCheckRmExitThick 
        && (m_dBarThick > 1)
        && (ERR_SUCCESS == m_pCurPceData->nRoughRollStraCfgStatus))
    {
        if (ERR_FAILED == HRS_RMCalc_SpeedGUI(&m_RmAllCalcData, 
            &AllPass,
            &AllDeliveryGauge,
            &AllSpeed))
        {
            char szMsg[2048];
            sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMCalc_Speed() Failed: %s ", 
                m_RmAllCalcData.szOutErr);
            MessageBox(szMsg);
            return ERR_FAILED;
        }

    }
    else
    {
        m_RmAllCalcData.StrategyData.dTransferBarThick = 
                        m_RmAllCalcData.PlanData.dTransferBarGauge;

        if (ERR_FAILED == HRS_RMCalc_Speed(&m_RmAllCalcData, 
            &AllPass,
            &AllDeliveryGauge,
            &AllSpeed))
        {
            char szMsg[2048];
            sprintf(szMsg, "CViewRoughRollStra::GetCfgData(), HRS_RMCalc_Speed() Failed: %s ", 
                m_RmAllCalcData.szOutErr);
            MessageBox(szMsg);
            return ERR_FAILED;
        }
    }

    //���ݸ�ֵ
    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        /*m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit = 
        AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[i];*/

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed = 
            AllSpeed.Rm1stPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraft = 
            AllPass.Rm1stPass.adPassDraftRatio[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth = 
            m_pCurPceData->stRollSched.fC_W;

    }

    for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        /*m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Exit = 
        AllDeliveryGauge.Rm2ndDeliveryGauge.adDeliveryGauge[i];*/

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fSpeed = 
            AllSpeed.Rm2ndPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fDraft = 
            AllPass.Rm2ndPass.adPassDraftRatio[i];

        if (AllPass.Rm2ndPass.adPassDraftRatio[i] > 0)
        {
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth = 
                m_pCurPceData->stRollSched.fC_W;
        }
    }
    
    //���ݸ�ֵ
    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit = 
            AllDeliveryGauge.Rm1stDeliveryGauge.adDeliveryGauge[i];

        if (0 == i)
        {
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraftValue = 
                m_pCurPceData->stRollSched.fS_H - 
                m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit;
        }
        else
        {
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraftValue = 
                m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i - 1].fThick_Exit - 
                m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit;
        }
       
       /* m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed = 
            AllSpeed.Rm1stPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraft = 
            AllPass.Rm1stPass.adPassDraftRatio[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth = 
            m_pCurPceData->stRollSched.fC_W;*/

    }

    for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Exit = 
            AllDeliveryGauge.Rm2ndDeliveryGauge.adDeliveryGauge[i];

        /*m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fSpeed = 
            AllSpeed.Rm2ndPassSpeed.adSpeed[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fDraft = 
            AllPass.Rm2ndPass.adPassDraftRatio[i];

        if (AllPass.Rm2ndPass.adPassDraftRatio[i] > 0)
        {
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth = 
                                    m_pCurPceData->stRollSched.fC_W;
        }*/
    }

    m_pCurPceData->stRoughRollStra.emPassMode = 
                                (HRS_PASS_MODE_EM)AllPass.Rm1stPass.nPassMode;

    //if (m_dBarThick < 1)
    //{
    //    memcpy(&m_stRoughRollStra, 
    //        &m_pCurPceData->stRoughRollStra, 
    //        sizeof(HRS_ROUGHROLL_STRA));

    //}


    if ( InitCalcRMStraData() == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


void CViewRoughRollStra::OnCbnSelchangeCombRrstraStripno()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    CString strStripNo;
    PCE_DATA * pPceDataOrig;

    int nShift;

    if ( m_pCurPceData == NULL )
    {
        return;
    }

    nShift = m_ComboxStripNo.GetCurSel();

    m_ComboxStripNo.GetLBText(nShift,strStripNo);

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                              "�л��ְ�", 
                              MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo), 
                    m_pCurPceData, 
                    sizeof(PCE_DATA) );
            
        }
        else if (nRet == IDCANCEL)
        {
            m_strStripNo = m_strCurStripNo;

            UpdateData(FALSE);
            return ;
        }
        
    }

    //PceData_Destroy(m_pCurPceData);

    //m_pCurPceData = m_pRollSchedMgr->CopyPceDataByStripNo(strStripNo);
    m_pCurPceData = m_pRollSchedMgr->GetPceDataByStripNo(strStripNo);

    if (ERR_FAILED == m_pCurPceData->nRoughRollStraCfgStatus)
    {
        GetCfgData();

        m_pCurPceData->nRoughRollStraCfgStatus = ERR_SUCCESS;
    }

    memcpy(&m_stRoughRollStra, 
        &m_pCurPceData->stRoughRollStra, 
        sizeof(HRS_ROUGHROLL_STRA));

    RefreshRoughRollStraGrid();

    m_strStripNo = strStripNo;
    m_strCurStripNo = strStripNo;


    // move
    int nSeq;

    nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strCurStripNo);
    if (nSeq < 0)
    {
        return;
    }

    m_GridRoughRollPDI.SetFocusCell(nSeq, 2);
    m_GridRoughRollPDI.SetSelectedRange(nSeq,1,nSeq,HRS_ROLL_SCHED_ITEM_NUM-1);


    m_GridRoughRollPDI.ScrollToRow(nSeq);

    RefreshRoughRollSchedGrid();
    // end

    UpdateData(FALSE);

    return ;

}


void CViewRoughRollStra::RefreshPassModeRadioButton()
{
    //���ò������ڸøְ�Ĳ���

    CButton *pButton  = NULL;
    int nMode[HRS_RM_DRAFT_NUM_MAX];

    nMode[0] = HRS_PASS_MODE_0_5;
    nMode[1] = HRS_PASS_MODE_0_7;
    nMode[2] = HRS_PASS_MODE_1_3;
    nMode[3] = HRS_PASS_MODE_1_5;
    nMode[4] = HRS_PASS_MODE_1_7;
    nMode[5] = HRS_PASS_MODE_3_3;
    nMode[6] = HRS_PASS_MODE_3_5;
    nMode[7] = HRS_PASS_MODE_AUTO;

    if ( m_pCurPceData == NULL )
    {
        return;
    }


    HRS_ROUGHROLL_STRA  *pRMStra;

    assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);



    HRS_RM_DRAFT_RATIO_STRA *pDraftStra;

    pDraftStra = &(m_pCurPceData->stRoughRollStra.stDraftRatioStra);

    int i;
    for(i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        switch (nMode[i])
        {
        case HRS_PASS_MODE_AUTO:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_AUTO);
            break;
        case HRS_PASS_MODE_0_5:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_05);
            break;
        case HRS_PASS_MODE_0_7:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_07);
            break;
        case HRS_PASS_MODE_1_3:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_13);
            break;
        case HRS_PASS_MODE_1_5:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_15);
            break;
        case HRS_PASS_MODE_1_7:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_17);
            break;
        case HRS_PASS_MODE_3_3:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_33);
            break;
        case HRS_PASS_MODE_3_5:
            pButton = (CButton *)this->GetDlgItem(IDC_RAD_PASSMODE_35);
            break;
        } 


        if (pButton != NULL)
        {
            pButton->EnableWindow(FALSE);


            for ( int j = 0; j < HRS_RM_DRAFT_NUM_MAX; j++ )
            {
                pRMStra = &(m_pCurPceData->stRMStraData.aOrgStra[j]);
                if (pRMStra->stDraftRatio.nPassMode == nMode[i])
                {
                    pButton->EnableWindow(TRUE);
                    break;
                }
            }


#if 0
            for ( int j = 0; j < HRS_RM_DRAFT_NUM_MAX; j++ )
            {
                if (pDraftStra->aRmDraftTab[j].nPassMode == nMode[i])
                {
                    pButton->EnableWindow(TRUE);
                    break;
                }
            }
#endif
        }
    }

    return;
}


void CViewRoughRollStra::ShowRMStraTable(int nRowCount, 
                                         HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                         int nPassModeIndex,
                                         int nRMPassNo,
                                         int nStandNo)
{
    HRS_ROUGHROLL_STRA      *pRMStra;

    HRS_ROUGHROLL_STRA_PASS *pRMStraPass;

    char *pszPassNo; 

    pRMStra = &(pRMStraData->aAllPassModeStra[nPassModeIndex]);

    if ( nStandNo == HRS_STAND_NO_RM1 )
    {
        pRMStraPass = &(pRMStra->stRoughRollStraR1[nRMPassNo]);
        pszPassNo = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[nRMPassNo].strPass_No;
    }
    else
    {
        pRMStraPass = &(pRMStra->stRoughRollStraR2[nRMPassNo]);
        pszPassNo = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nRMPassNo].strPass_No;
    }

    for(int j = 0; j < HRS_ROUGHROLL_STRA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  nRowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
            | DT_VCENTER
            | DT_SINGLELINE
            | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_ROUGHROLL_STRA_PASS_NO :
            Item.strText.Format(_T("%s"), pszPassNo);
            break;
        case HRS_ROUGHROLL_STRA_THICK_EXIT :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fThick_Exit);
            break;
        case HRS_ROUGHROLL_STRA_DELTA_DRAFT :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fDeltaDraftValue);
            break;
        case HRS_ROUGHROLL_STRA_DRAFT :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fDraft);
            break;
        case HRS_ROUGHROLL_STRA_DRAFT_COR :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fDraftCor);
            break;
        case HRS_ROUGHROLL_STRA_WIDTH :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fWidth);
            break;
        case HRS_ROUGHROLL_STRA_WIDTH_COR :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fWidth_Cor);
            break;
        case HRS_ROUGHROLL_STRA_SPEED :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fSpeed);
            break;
        case HRS_ROUGHROLL_STRA_SPEED_COR :
            Item.strText.Format(_T("%4.4f"),pRMStraPass->fSpeed_Cor);
            break;
        case HRS_ROUGHROLL_STRA_SPRAY :
            if (pRMStraPass->emSprayMode == HRS_SPRAY_ON)
            {
                Item.strText.Format(_T("%s"),"ON");
            }
            else if (pRMStraPass->emSprayMode == HRS_SPRAY_OFF)
            {
                Item.strText.Format(_T("%s"),"OFF");
            }
            else
            {
                Item.strText.Format(_T("%s"),"OFF");
            }
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridRoughRollStra.SetItem(&Item);

        //��������
        CFont cNewFont;
        LOGFONT lgFont;
        cNewFont.CreateFontA(16,
            0,
            0,
            0,
            FW_NORMAL,
            0,
            0,
            0,
            DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS,
            DEFAULT_QUALITY,
            DEFAULT_PITCH | FF_SWISS,
            "Arial");
        cNewFont.GetLogFont(&lgFont);
        m_GridRoughRollStra.SetItemFont(nRowCount, j, &lgFont);

        m_GridRoughRollStra.SetRowHeight(nRowCount, 28);
    }

    return;
}


void CViewRoughRollStra::RefreshRoughRollStraGrid()
{
    HRS_ROUGHROLL_STRA  *pRMStra;
    HRS_ROUGHROLL_STRA_DATA  *pRMStraData;

    char strHeading[5]={0};
    int  RowCount;

    int  nCountR1;
    int  nCountR2;

    if (m_pCurPceData == NULL)
    {
        return;
    }

    //GetThick_Cor();

    /* 
     * ��ʾStand Dummy
     */
    m_bCheckStandDummyE1 = m_pCurPceData->stRoughRollStra.bStand_Dummy_E1;
    m_bCheckStandDummyR1 = m_pCurPceData->stRoughRollStra.bStand_Dummy_R1;
    m_bCheckStandDummyE2 = m_pCurPceData->stRoughRollStra.bStand_Dummy_E2;

    m_BPassMode = m_pCurPceData->stRMStraData.nCurPassModeIndex;
    //assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);


    pRMStraData = &(m_pCurPceData->stRMStraData);
    pRMStra = &(pRMStraData->aAllPassModeStra[m_BPassMode]);
    /* 
     * ��ʾ RM EXIT THICK
     */
//    if ( m_pCurPceData->stRoughRollStra.bRm_Exit_Thick_Auto)
    if ( pRMStra->bRm_Exit_Thick_Auto )
    {
        m_bCheckRmExitThick = TRUE;
        m_ButCtlRmExitThick.EnableWindow(FALSE);
    }
    else
    {
        m_bCheckRmExitThick = FALSE;
        m_ButCtlRmExitThick.EnableWindow(TRUE);
    }


    //m_dBarThick = m_pCurPceData->stRoughRollStra.stHSB.fThick_Exit;

    //m_pCurPceData->stRoughRollStra.stHSB.fThick_Exit = m_dBarThick;

    if (TRUE == m_bCheckRmExitThick)
    {
        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick =
                                    m_pCurPceData->stRollSched.fR_H;

        pRMStra->fRm_Exit_Thick = m_pCurPceData->stRollSched.fR_H;
    }
    else
    {
        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick = m_dBarThick;
        pRMStra->fRm_Exit_Thick = m_dBarThick;
    }

    /* 
     * ��ʾPassMode
     */
    RefreshPassModeRadioButton();

    m_BPassMode = m_pCurPceData->stRMStraData.nCurPassModeIndex;

#if 0
    //�ְ��̼��������ʾ
    switch (m_pCurPceData->stRoughRollStra.emPassMode)
    {
    case HRS_PASS_MODE_AUTO:
        m_BPassMode = 0;
        break;
    case HRS_PASS_MODE_0_5:
        m_BPassMode = 1;
        break;
    case HRS_PASS_MODE_0_7:
        m_BPassMode = 2;
        break;
    case HRS_PASS_MODE_1_3:
        m_BPassMode = 3;
        break;
    case HRS_PASS_MODE_1_5:
        m_BPassMode = 4;
        break;
    case HRS_PASS_MODE_1_7:
        m_BPassMode = 5;
        break;
    case HRS_PASS_MODE_3_3:
        m_BPassMode = 6;
        break;
    case HRS_PASS_MODE_3_5:
        m_BPassMode = 7;
        break;
    }

#endif

    m_pCurPceData->nRoughRollStraStatus = ERR_SUCCESS;

    HRS_PASS_MODE_EM emPassMode;
    emPassMode = m_pCurPceData->stRMStraData.aOrgStra[m_BPassMode].emPassMode;

//    nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
//    nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;

    nCountR1 = emPassMode / 10;
    nCountR2 = emPassMode % 10;

    m_GridRoughRollStra.DeleteNonFixedRows();

    RowCount = m_GridRoughRollStra.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRoughRollStra.InsertRow(strHeading);
#if 1


    for(int j = 0; j < HRS_ROUGHROLL_STRA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    =    DT_CENTER
                           | DT_VCENTER
                           | DT_SINGLELINE
                           | DT_END_ELLIPSIS;

        switch (j)
        {
            case HRS_ROUGHROLL_STRA_PASS_NO :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollStra.stHSB.strPass_No);
                break;
            case HRS_ROUGHROLL_STRA_THICK_EXIT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fThick_Exit);
                break;
            case HRS_ROUGHROLL_STRA_DELTA_DRAFT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fDeltaDraftValue);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fDraft);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fDraftCor);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fWidth);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fWidth_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPEED :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fSpeed);
                break;
            case HRS_ROUGHROLL_STRA_SPEED_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fSpeed_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPRAY :
                /*if (m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode == HRS_SPRAY_AUTO)
                {
                    Item.strText.Format(_T("%s"),"AUTO");
                }
                else */
                {
                    HRS_SPRAY_MODE_EM  emSprayMode;

                    int nPassModeIndex = HRS_GetPassModeIndex(emPassMode);


                    emSprayMode = m_pCurPceData->stRMStraData.aAllPassModeStra[nPassModeIndex].stHSB.emSprayMode;

                    if (emSprayMode == HRS_SPRAY_ON)
                    {
                        Item.strText.Format(_T("%s"),"ON");
                    }
                    else if (emSprayMode == HRS_SPRAY_OFF)
                    {
                        Item.strText.Format(_T("%s"),"OFF");
                    }
                    else
                    {
                        Item.strText.Format(_T("%s"),"OFF");
                    }

                }
                break;

#if 0
        case HRS_ROUGHROLL_STRA_PASS_NO :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollStra.stHSB.strPass_No);
            break;
        case HRS_ROUGHROLL_STRA_THICK_COR :
            Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fThick_Cor);
            break;
        case HRS_ROUGHROLL_STRA_WIDTH_COR :
            Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fWidth_Cor);
            break;
        case HRS_ROUGHROLL_STRA_SPEED_COR :
            Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stHSB.fSpeed_Cor);
            break;
        case HRS_ROUGHROLL_STRA_SPRAY :
            /*if (m_pCurPceData->stRoughRollStra.stHSB.emSprayMode == HRS_SPRAY_AUTO)
            {
                Item.strText.Format(_T("%s"),"AUTO");
            }
            else */
            if (m_pCurPceData->stRoughRollStra.stHSB.emSprayMode == HRS_SPRAY_ON)
            {
                Item.strText.Format(_T("%s"),"ON");
            }
            else if (m_pCurPceData->stRoughRollStra.stHSB.emSprayMode == HRS_SPRAY_OFF)
            {
                Item.strText.Format(_T("%s"),"OFF");
            }
            else
            {
                Item.strText.Format(_T("%s"),"OFF");
            }
            break;
#endif

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridRoughRollStra.SetItem(&Item);

#if 1
        //��������
        CFont cNewFont;
        LOGFONT lgFont;
        cNewFont.CreateFontA(16,
                            0,
                            0,
                            0,
                            FW_NORMAL,
                            0,
                            0,
                            0,
                            DEFAULT_CHARSET,
                            OUT_DEFAULT_PRECIS,
                            CLIP_DEFAULT_PRECIS,
                            DEFAULT_QUALITY,
                            DEFAULT_PITCH | FF_SWISS,
                            "Arial");
        cNewFont.GetLogFont(&lgFont);
        m_GridRoughRollStra.SetItemFont(RowCount, j, &lgFont);
#endif
        m_GridRoughRollStra.SetRowHeight(RowCount, 28);
    }
#endif


    HRS_ROUGHROLL_STRA_PASS  *pRMStraPass;
    //
    // ������1������������ʾ�ڱ�����
    //
    for (int i = 0; i < nCountR1; i++)
    {
        RowCount = m_GridRoughRollStra.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollStra.InsertRow(strHeading);

        pRMStraPass = &(pRMStra->stRoughRollStraR1[i]);

        ShowRMStraTable(RowCount, pRMStraData, m_BPassMode, i, HRS_STAND_NO_RM1);

#if 0
        for(int j = 0; j < HRS_ROUGHROLL_STRA_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
                case HRS_ROUGHROLL_STRA_PASS_NO :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].strPass_No);
                break;
            case HRS_ROUGHROLL_STRA_THICK_EXIT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit);
                break;
            case HRS_ROUGHROLL_STRA_THICK_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Cor);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraft);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraftCor);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPEED :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed);
                break;
            case HRS_ROUGHROLL_STRA_SPEED_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPRAY :
                /*if (m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode == HRS_SPRAY_AUTO)
                {
                    Item.strText.Format(_T("%s"),"AUTO");
                }
                else */
                if (m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode == HRS_SPRAY_ON)
                {
                    Item.strText.Format(_T("%s"),"ON");
                }
                else if (m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode == HRS_SPRAY_OFF)
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                else
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                break;

#if 0
            case HRS_ROUGHROLL_STRA_PASS_NO :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].strPass_No);
                break;
            case HRS_ROUGHROLL_STRA_THICK_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Cor);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPEED_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fSpeed_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPRAY :
                /*if (m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode == HRS_SPRAY_AUTO)
                {
                    Item.strText.Format(_T("%s"),"AUTO");
                }
                else */
                if (m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode == HRS_SPRAY_ON)
                {
                    Item.strText.Format(_T("%s"),"ON");
                }
                else if (m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode == HRS_SPRAY_OFF)
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                else
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                break;
#endif

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridRoughRollStra.SetItem(&Item);

#if 1
            //��������
            CFont cNewFont;
            LOGFONT lgFont;
            cNewFont.CreateFontA(16,
                                0,
                                0,
                                0,
                                FW_NORMAL,
                                0,
                                0,
                                0,
                                DEFAULT_CHARSET,
                                OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,
                                DEFAULT_QUALITY,
                                DEFAULT_PITCH | FF_SWISS,
                                "Arial");
            cNewFont.GetLogFont(&lgFont);
            m_GridRoughRollStra.SetItemFont(RowCount, j, &lgFont);
#endif

            m_GridRoughRollStra.SetRowHeight(RowCount, 28);

        }
#endif
    }


    //
    // ������2������������ʾ�ڱ�����
    //
    for (int i = 0; i < nCountR2; i++)
    {
        RowCount = m_GridRoughRollStra.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollStra.InsertRow(strHeading);

        pRMStraPass = &(pRMStra->stRoughRollStraR2[i]);

        ShowRMStraTable(RowCount, pRMStraData, m_BPassMode, i, HRS_STAND_NO_RM2);

#if 0
        for(int j = 0; j < HRS_ROUGHROLL_STRA_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_ROUGHROLL_STRA_PASS_NO :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].strPass_No);
                break;
            case HRS_ROUGHROLL_STRA_THICK_EXIT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Exit);
                break;
            case HRS_ROUGHROLL_STRA_THICK_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fThick_Cor);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fDraft);
                break;
            case HRS_ROUGHROLL_STRA_DRAFT_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fDraftCor);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth);
                break;
            case HRS_ROUGHROLL_STRA_WIDTH_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPEED :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fSpeed);
                break;
            case HRS_ROUGHROLL_STRA_SPEED_COR :
                Item.strText.Format(_T("%4.4f"),m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fSpeed_Cor);
                break;
            case HRS_ROUGHROLL_STRA_SPRAY :
                /*if (m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode == HRS_SPRAY_AUTO)
                {
                    Item.strText.Format(_T("%s"),"AUTO");
                }
                else */
                if (m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode == HRS_SPRAY_ON)
                {
                    Item.strText.Format(_T("%s"),"ON");
                }
                else if (m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode == HRS_SPRAY_OFF)
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                else
                {
                    Item.strText.Format(_T("%s"),"OFF");
                }
                break;
           
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridRoughRollStra.SetItem(&Item);

#if 1
            //��������
            CFont cNewFont;
            LOGFONT lgFont;
            cNewFont.CreateFontA(16,
                                0,
                                0,
                                0,
                                FW_NORMAL,
                                0,
                                0,
                                0,
                                DEFAULT_CHARSET,
                                OUT_DEFAULT_PRECIS,
                                CLIP_DEFAULT_PRECIS,
                                DEFAULT_QUALITY,
                                DEFAULT_PITCH | FF_SWISS,
                                "Arial");
            cNewFont.GetLogFont(&lgFont);
            m_GridRoughRollStra.SetItemFont(RowCount, j, &lgFont);
#endif

            m_GridRoughRollStra.SetRowHeight(RowCount, 28);
        }
#endif
    }

/**************/

    typedef struct
    {
        CGridBtnCellBase::STRUCT_DRAWCTL DrawCtl;  // most btn props here
        int iBtnNbr;                        // which btn within cell does this define?
        const char* pszBtnText;             // text associated with pushbutton or NULL
    }   STRUCT_CTL;


    STRUCT_CTL DrawCtlAry[] =
    { //iWidth,         sState, ucIsMbrRadioGrp,            ucAlign,     ucType, iBtnNbr, pszBtnText
        
        { -1,  DFCS_SCROLLDOWN, FALSE, CGridBtnCellBase::CTL_ALIGN_RIGHT, DFC_SCROLL, 0, NULL},
    };  // (-1 iWidth's will be filled-in later)

    int iComboCtlWidth = GetSystemMetrics( SM_CXVSCROLL);
    CStringArray strAryCombo;
    //strAryCombo.Add( "AUTO");
    strAryCombo.Add( "ON");
    strAryCombo.Add( "OFF");


    for ( int row = m_GridRoughRollStra.GetFixedRowCount(); row < m_GridRoughRollStra.GetRowCount(); row++)
    {
        // retain old cell properties
        CGridBtnCell GridCellCopy;
        GridCellCopy.SetBtnDataBase( &m_BtnDataBase);
        CGridCellBase* pCurrCell = m_GridRoughRollStra.GetCell( row, HRS_ROUGHROLL_STRA_ITEM_NUM - 1);
        if (pCurrCell)
            GridCellCopy = *pCurrCell;

        // replace standard cell with special control cell
        m_GridRoughRollStra.SetCellType( row, HRS_ROUGHROLL_STRA_ITEM_NUM - 1, RUNTIME_CLASS(CGridBtnCellCombo) );
        CGridBtnCellCombo* pGridBtnCellCombo = (CGridBtnCellCombo*)m_GridRoughRollStra.GetCell( row, HRS_ROUGHROLL_STRA_ITEM_NUM - 1);
        pGridBtnCellCombo->SetComboStyle( CBS_DROPDOWN);
        pGridBtnCellCombo->SetComboString( strAryCombo);

        CGridBtnCell* pGridBtnCell = (CGridBtnCell*)m_GridRoughRollStra.GetCell( row, HRS_ROUGHROLL_STRA_ITEM_NUM - 1);
        pGridBtnCell->SetBtnDataBase( &m_BtnDataBase);

        // draw controls within a cell
        int iWidth = DrawCtlAry[ 0].DrawCtl.iWidth;
        if( iWidth < 0) iWidth = 22;  //iComboCtlWidth;      //mod

        pGridBtnCell->SetupBtns(
            DrawCtlAry[ 0].iBtnNbr,        // zero-based index of image to draw
            DrawCtlAry[ 0].DrawCtl.ucType, // type of frame control to draw e.g. DFC_BUTTON
            DrawCtlAry[ 0].DrawCtl.sState, // like DrawFrameControl()'s nState  e.g. DFCS_BUTTONCHECK
            (CGridBtnCellBase::CTL_ALIGN)DrawCtlAry[ 0].DrawCtl.ucAlign,
            // horizontal alignment of control image
            iWidth,                         // fixed width of control or 0 for size-to-fit
            DrawCtlAry[ 0].DrawCtl.ucIsMbrRadioGrp,  // T=btn is member of a radio group
            DrawCtlAry[ 0].pszBtnText );   // Text to insert centered in button; if NULL no text


    }

/**************/

    m_GridRoughRollStra.AutoSizeColumns();
    m_GridRoughRollStra.Refresh();

    UpdateData(FALSE);
}



void CViewRoughRollStra::OnBnClickedRadPassmodeAuto()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    if (ERR_FAILED == SetPassModeByRadio())
    {
        MessageBox("����ˢ��ʧ�ܣ��øֺ�û�д˲��ԣ�");
        return;
    }

    RefreshRoughRollStraGrid();

}

void CViewRoughRollStra::OnBnClickedRadPassmode05()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    if (ERR_FAILED == SetPassModeByRadio())
    {
        MessageBox("����ˢ��ʧ�ܣ��øֺ�û�д˲��ԣ�");
        return;
    }

    RefreshRoughRollStraGrid();
}


void CViewRoughRollStra::OnBnClickedRadPassmode17()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    if (ERR_FAILED == SetPassModeByRadio())
    {
        MessageBox("����ˢ��ʧ�ܣ��øֺ�û�д˲��ԣ�");
        return;
    }

    RefreshRoughRollStraGrid();
}

#if 0
HRS_PASS_MODE_EM  g_RMPassMode[HRS_RM_DRAFT_NUM_MAX] = {
    HRS_PASS_MODE_AUTO,
    HRS_PASS_MODE_0_5,
    HRS_PASS_MODE_0_7,  
    HRS_PASS_MODE_1_3,  
    HRS_PASS_MODE_1_5,  
    HRS_PASS_MODE_1_7,  
    HRS_PASS_MODE_3_3,  
    HRS_PASS_MODE_3_5,  
};
#endif

int CViewRoughRollStra::SetPassModeByRadio()
{
    //  �鿴�ְ�����Ƿ����
    int nFindFlag = -1;
    HRS_PASS_MODE_EM   emPassMode;

    if ( m_BPassMode < 0 || m_BPassMode >= HRS_RM_DRAFT_NUM_MAX )
    {
        return ERR_FAILED;
    }

    HRS_PASS_MODE_EM  nPassMode;

    nPassMode = HRS_GetPassModeByIndex(m_BPassMode);

    m_pCurPceData->stRoughRollStra.emPassMode = nPassMode;

    m_pCurPceData->stRMStraData.nCurPassModeIndex = m_BPassMode;

    //CalcRMStraData();
    GetCfgData();

    emPassMode = HRS_GetPassModeByIndex(m_BPassMode);

    for (int i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        if (m_RmDraftTab[i].nPassMode <= 0)
        {
            continue;
        }

        if (emPassMode == m_RmDraftTab[i].nPassMode)
        {
            nFindFlag = 1;
            break;
        }
    }

    if ( nFindFlag < 0 )
    {
        return ERR_FAILED;
    }

    m_pCurPceData->stRoughRollStra.emPassMode = emPassMode;
#if 0
    switch (m_BPassMode)
    {
    case 0:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_AUTO;
        break;
    case 1:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_0_5;
        break;
    case 2:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_0_7;
        break;
    case 3:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_1_3;
        break;
    case 4:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_1_5;
        break;
    case 5:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_1_7;
        break;
    case 6:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_3_3;
        break;
    case 7:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_3_5;
        break;

    default:
        m_pCurPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_AUTO;
        break;
    }
#endif
    return ERR_SUCCESS;
}

void CViewRoughRollStra::OnBnClickedRadPassmode07()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    SetPassModeByRadio();

    RefreshRoughRollStraGrid();
}

void CViewRoughRollStra::OnBnClickedRadPassmode13()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    SetPassModeByRadio();

    RefreshRoughRollStraGrid();
}

void CViewRoughRollStra::OnBnClickedRadPassmode15()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    HRS_PASS_MODE_EM  nPassMode;

    nPassMode = HRS_GetPassModeByIndex(m_BPassMode);

    m_pCurPceData->stRoughRollStra.emPassMode = nPassMode;

    SetPassModeByRadio();

    RefreshRoughRollStraGrid();
}

void CViewRoughRollStra::OnBnClickedRadPassmode33()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    HRS_PASS_MODE_EM  nPassMode;

    nPassMode = HRS_GetPassModeByIndex(m_BPassMode);

    m_pCurPceData->stRoughRollStra.emPassMode = nPassMode;

    SetPassModeByRadio();

    RefreshRoughRollStraGrid();
}


void CViewRoughRollStra::OnBnClickedRadPassmode35()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    SetPassModeByRadio();

    RefreshRoughRollStraGrid();
}



#if 0
void CViewRoughRollStra::OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    if (pItem->iRow < 1)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    // �޸�����У��򲻱����������
    if (nCol < 1)
    {
        RefreshRoughRollStraGrid();
        return;
    }

    HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass;

    pRoughRollStraPass = GetRoughRollStraPassFromGrid(nRow);

    PceData_ChangeRmStraPass(m_pCurPceData, pRoughRollStraPass, nRow - 1);

    //m_pRollSchedMgr->ChangeRoughRollStraPass(pRoughRollStraPass, m_strStripNo, nRow - 1);

    RefreshRoughRollStraGrid();

}
#endif


int CViewRoughRollStra::FindPreAndNextPassData(int nRow)
{
    HRS_ROUGHROLL_STRA      *pstRoughRollStra    = NULL;    //�����������ݽṹ

    if (NULL == m_pCurPceData)
    {
        return ERR_FAILED;
    }

    int nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
    int nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;
    int nTotalCount = nCountR1 + nCountR2 + 1;

    pstRoughRollStra = &m_pCurPceData->stRoughRollStra;

    //��ȡǰ����ε�ѹ���ʺ� ���ں��
    if (nCountR1 >= 3 && nRow > 2 && nRow < nCountR1 + 1)
    {
        m_fDraftPre  = pstRoughRollStra->stRoughRollStraR1[nRow - 3].fDraft;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR1[nRow - 1].fDraft;

        m_fThick_ExitPre  = pstRoughRollStra->stRoughRollStraR1[nRow - 3].fThick_Exit;
        m_fThick_ExitNext = pstRoughRollStra->stRoughRollStraR1[nRow - 1].fThick_Exit;

        return ERR_SUCCESS;
    }
    else if (nCountR1 >= 2 && nRow == nCountR1 + 1)
    {
        m_fDraftPre  = pstRoughRollStra->stRoughRollStraR1[nRow - 3].fDraft;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR2[0].fDraft;

        m_fThick_ExitPre  = pstRoughRollStra->stRoughRollStraR1[nRow - 3].fThick_Exit;
        m_fThick_ExitNext = pstRoughRollStra->stRoughRollStraR2[0].fThick_Exit;

        return ERR_SUCCESS;
    }
    else if (nCountR1 >= 2 && nRow == 2)
    {
        m_fDraftPre  = 0;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR1[nRow - 1].fDraft;

        m_fThick_ExitPre  = m_pCurPceData->stRollSched.fS_H;;
        m_fThick_ExitNext = pstRoughRollStra->stRoughRollStraR1[nRow - 1].fThick_Exit;

        return ERR_SUCCESS;
    }
    else if (nCountR1 == 1 && nRow == 2)
    {
        m_fDraftPre  = 0;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR2[0].fDraft;

        m_fThick_ExitPre  = m_pCurPceData->stRollSched.fC_H;;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR2[0].fDraft;

        return ERR_SUCCESS;
    }

    if (nCountR2 >= 3 && nRow > nCountR1 + 2 && nRow < nCountR1 + nCountR2 + 1)
    {
        m_fDraftPre  = pstRoughRollStra->stRoughRollStraR2[nRow - 3 - nCountR1].fDraft;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR2[nRow - 1 -nCountR1].fDraft;

        m_fThick_ExitPre  = pstRoughRollStra->stRoughRollStraR2[nRow - 3 - nCountR1].fThick_Exit;
        m_fThick_ExitNext = pstRoughRollStra->stRoughRollStraR2[nRow - 1 -nCountR1].fThick_Exit;

        return ERR_SUCCESS;
    }
    else if (nCountR2 >= 2 && nRow == nCountR1 + 2)
    {
        m_fDraftPre  = pstRoughRollStra->stRoughRollStraR1[nCountR1].fDraft;
        m_fDraftNext = pstRoughRollStra->stRoughRollStraR2[nRow - 1 - nCountR1].fDraft;

        m_fThick_ExitPre  = pstRoughRollStra->stRoughRollStraR1[nCountR1].fThick_Exit;
        m_fThick_ExitNext = pstRoughRollStra->stRoughRollStraR1[nRow - 1 - nCountR1].fThick_Exit;

        return ERR_SUCCESS;
    }

    return ERR_FAILED;
}


void CViewRoughRollStra::OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    HRS_ROUGHROLL_STRA_PASS   RMStraPass;
    HRS_ROUGHROLL_STRA_PASS * pStraPass = NULL;

    if (NULL == pNotifyStruct ||NULL == pResult)
    {
        return;
    }

    if ( m_pCurPceData == NULL )
    {
        return;
    }

    memcpy(&m_stRoughRollStra, 
           &m_pCurPceData->stRoughRollStra, 
           sizeof(HRS_ROUGHROLL_STRA));

    // ��ǰ���ε�ǰ����ε�ѹ���ʺͳ��ں��
    // HRS_ROUGHROLL_STRA_PASS * pStraNextPass = NULL;

    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;

    // ��ǰR1��R2�ĵ���
    int nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
    int nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;
    int nTotalCount = nCountR1 + nCountR2 + 1;

    //����м����Ƿ����仯
    /*pStraPass = GetRoughRollStraPassFromGrid(nTotalCount);
    if (0 != FEqual(m_dBarThick, pStraPass->fThick_Exit))
    {
        m_RmAllCalcData.PlanData.dTransferBarGauge = m_dBarThick;
        GetCfgData();

        RefreshRoughRollStraGrid();
    }
    NG_free(pStraPass);
    pStraPass = NULL;*/


    //R2���һ�����εĺ�Ⱥ�ѹ���ʲ���ֱ�Ӹ���
    //if (nRow == nTotalCount && nCol < HRS_WIDTH_CRO_COL)
    /*if (nCol < HRS_WIDTH_CRO_COL)
    {
        MessageBox("�����ݲ���ֱ�Ӹ��ģ�����ͨ�����Ĵ������ں����������", 
            "����",
            MB_DEFBUTTON2);

        RefreshRoughRollStraGrid();

        return;
    }*/

    //������ܸ��ģ����ھ��У���
    if ((nCol % 2 == 1 && nCol < HRS_SPEED_CRO_COL) || HRS_THICK_CRO_COL == nCol )
    {
        MessageBox("�����ݲ���ֱ�Ӹ��ģ�����ͨ������ֵ��������", 
                   "����",
                   MB_DEFBUTTON2);

        RefreshRoughRollStraGrid();

        return;
    }

    //�ھ��к�ż���п��Ը��ģ���ȥR2���һ�����εĺ�Ⱥ�ѹ���ʣ�
    if (nCol == HRS_SPRAY_COL || (nCol % 2 == 0 && nCol <= HRS_SPEED_CRO_COL))
    {
        int nRet = MessageBox("�Ƿ��������ݣ�", 
                              "����", 
                              MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet != IDYES )
        {
            RefreshRoughRollStraGrid();

            return;
        }
    }

    //ȡ���޸��е�ֵ
    pStraPass = GetRoughRollStraPassFromGrid(nRow, &RMStraPass);
    /*if (nRow - 2 < nTotalCount)
    {
        pStraNextPass = GetRoughRollStraPassFromGrid(nRow + 1);
    }

    if (nRow < nTotalCount && ERR_FAILED == FindPreAndNextPassData(nRow))
    {
        MessageBox("û�в��ҵ�������ǰ����ε����ݣ���������ʧ�ܣ�", 
            "����",
            MB_DEFBUTTON2);

        return;
    }*/

    //��������ֵ
#if 0

    if (nCol == HRS_THICK_CRO_COL)
    {
        //�����������仯����ô��һ�����ε�ѹ���ʺͱ����ε�ѹ���ʾ������仯
        pStraPass->fThick_Exit += pStraPass->fThick_Cor;
        pStraPass->fDraftCor    = -pStraPass->fThick_Cor/m_fThick_ExitPre;
        pStraPass->fDraft      += pStraPass->fDraftCor;

        pStraNextPass->fThick_Cor -= pStraPass->fThick_Cor;
        pStraNextPass->fDraft      = (pStraPass->fThick_Exit - m_fThick_ExitNext)/pStraPass->fThick_Exit;
        pStraNextPass->fDraftCor   = pStraNextPass->fDraft - m_fDraftNext;
    }
    else if (nCol == HRS_DTAFT_CRO_COL)
    {
        //ѹ������������仯����ô��һ�����ε�ѹ���ʺͱ����εĳ��ں�Ⱦ������仯
		if ( pStraPass->fDraftCor >= 1)
		{
			MessageBox("ѹ����Ӧ��<1����������ʧ�ܣ�", 
				"����",
				MB_DEFBUTTON2);

			RefreshRoughRollStraGrid();

			return;
		}
        pStraPass->fDraft += pStraPass->fDraftCor;
        pStraPass->fThick_Cor = m_fThick_ExitPre / (1 + pStraPass->fDraft) - pStraPass->fThick_Exit;
        pStraPass->fThick_Exit += pStraPass->fThick_Cor;

        pStraNextPass->fThick_Cor -= pStraPass->fThick_Cor;
        pStraNextPass->fDraft      = (pStraPass->fThick_Exit - m_fThick_ExitNext)/pStraPass->fThick_Exit;
        pStraNextPass->fDraftCor   = pStraNextPass->fDraft - m_fDraftNext;
    }
    else if (nCol == HRS_WIDTH_CRO_COL)
    {
        pStraPass->fWidth += pStraPass->fWidth_Cor;
    }
    else
    {
        pStraPass->fSpeed += pStraPass->fSpeed_Cor;
    }

#endif

    HRS_ROUGHROLL_STRA_DATA  *pRMStraData;
    HRS_ROUGHROLL_STRA       *pOrgRMStra;
    HRS_ROUGHROLL_STRA       *pRMStra;


    int nPassModeIndex;

    pRMStraData = &(m_pCurPceData->stRMStraData);

    nPassModeIndex = pRMStraData->nCurPassModeIndex;

    pOrgRMStra = &(pRMStraData->aOrgStra[nPassModeIndex]);
    pRMStra = &(pRMStraData->aAllPassModeStra[nPassModeIndex]);

    if (nCol == HRS_DTAFT_CRO_COL)
    {
        //ѹ������������仯����ô��һ�����ε�ѹ���ʺͱ����εĳ��ں�Ⱦ������仯
        float fTemp = 0;
        
        if (nRow - 2 < nCountR1)
        {
            fTemp = 
                m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fDraft
                + pStraPass->fDraftCor
                - m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fDraftCor;

            m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fDraftCor 
                = pStraPass->fDraftCor;

            m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fDraft = fTemp;

            pOrgRMStra->stRoughRollStraR1[nRow-2].fDraftCor 
                = pStraPass->fDraftCor;

        }
        else if (nCountR1 < nRow - 1  && nRow - 1 < nTotalCount)
        {
            fTemp = 
                m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fDraft
                + pStraPass->fDraftCor
                -m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fDraftCor;

            m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fDraftCor 
                = pStraPass->fDraftCor;
            m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fDraft = fTemp;

            pOrgRMStra->stRoughRollStraR2[nRow-2-nCountR1].fDraftCor 
                = pStraPass->fDraftCor;

        }

        if (pStraPass->fDraftCor < -0.1 || pStraPass->fDraftCor > 0.1 || fTemp > 0.7 || fTemp < 0)
        {
            MessageBox("ѹ��������ֵӦ��-0.1~0.1����������ʧ�ܣ�", 
                "����",
                MB_DEFBUTTON2);

            RefreshRoughRollStraGrid();

 //           NG_free(pStraPass);

            return;
        }

        pStraPass->fDraft = fTemp;

        PceData_ChangeRmStraPass(m_pCurPceData, pStraPass, nRow - 1);

        GetCfgData();

        m_pCurPceData->nRoughRollStraCfgStatus = ERR_SUCCESS;
    }
    else if (nCol == HRS_WIDTH_CRO_COL)
    {
        if (nRow - 2 < nCountR1)
        {
            float fWith = m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fWidth
                         + pStraPass->fWidth_Cor
                         - m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fWidth_Cor;

            if (pStraPass->fWidth_Cor > 50 || pStraPass->fWidth_Cor < -50 || fWith > 1700 || 750 > fWith)
            {
                MessageBox("��������ֵӦ����-50~50����������İ�������Ϊ750~1700����������ʧ�ܣ�", 
                    "����",
                    MB_DEFBUTTON2);

                RefreshRoughRollStraGrid();

                return;
            }

            pStraPass->fWidth = fWith;

            for (int i = nRow - 2; i < nCountR1 + 2; i++)
            {
                m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth = 
                    pStraPass->fWidth;
                m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fWidth_Cor = 
                    pStraPass->fWidth_Cor;

            }

            for (int i = 0; i < nCountR2; i++)
            {
                m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth = 
                    pStraPass->fWidth;

                m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth_Cor = 
                    pStraPass->fWidth_Cor;

            }

            m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fWidth_Cor 
                                                    = pStraPass->fWidth_Cor;

            pOrgRMStra->stRoughRollStraR1[nRow - 2].fWidth_Cor = 
                pStraPass->fWidth_Cor;

            m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fWidth = pStraPass->fWidth;
        }
        else if (nCountR1 < nRow - 1  && nRow - 2 < nTotalCount)
        {
            float fWith = m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fWidth 
                          + pStraPass->fWidth_Cor
                           - m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fWidth_Cor;

            if (pStraPass->fWidth_Cor > 50 || pStraPass->fWidth_Cor < -50 || fWith > 1700 || 750 > fWith)
            {
                MessageBox("��������ֵӦ����-50~50����������İ�������Ϊ750~1700����������ʧ�ܣ�", 
                    "����",
                    MB_DEFBUTTON2);

                RefreshRoughRollStraGrid();

                return;
            }

            pStraPass->fWidth = fWith;

            for (int i = nRow - 2 - nCountR1; i < nTotalCount; i++)
            {
                m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth = 
                    pStraPass->fWidth;
                m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].fWidth_Cor = 
                    pStraPass->fWidth_Cor;
            }

            m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fWidth 
                = pStraPass->fWidth;

            pOrgRMStra->stRoughRollStraR2[nRow - 2 - nCountR1].fWidth_Cor 
                = pStraPass->fWidth_Cor;
        }

    }
    else
    {
        if (nRow - 2 < nCountR1)
        {
            float fSpeed = m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fSpeed
                           + pStraPass->fSpeed_Cor
                           - m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fSpeed_Cor;

            if (pStraPass->fSpeed_Cor > 2 || pStraPass->fSpeed_Cor < -2 || fSpeed > 10 || fSpeed < -10)
            {
                MessageBox("�ٶ�����ֵӦ����-2~2����������İ����ٶ�Ϊ-10~10����������ʧ�ܣ�", 
                    "����",
                    MB_DEFBUTTON2);

                RefreshRoughRollStraGrid();

                return;
            }

            pStraPass->fSpeed = m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fSpeed;//fSpeed;
                

            m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fSpeed_Cor = pStraPass->fSpeed_Cor;
            //m_stRoughRollStra.stRoughRollStraR1[nRow - 2].fSpeed = pStraPass->fSpeed;

            pOrgRMStra->stRoughRollStraR1[nRow - 2].fSpeed_Cor = 
                pStraPass->fSpeed_Cor;

            pRMStra->stRoughRollStraR1[nRow-2].emSprayMode
                = pStraPass->emSprayMode;
        }
        else if (nCountR1 < nRow - 1  && nRow - 2 < nTotalCount)
        {
            float fSpeed = m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed
                           + pStraPass->fSpeed_Cor
                           - m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed_Cor;
            if (pStraPass->fSpeed_Cor > 2 || pStraPass->fSpeed_Cor < -2 || fSpeed > 10 || fSpeed < -10)
            {
                MessageBox("�ٶ�����ֵӦ����-2~2����������İ����ٶ�Ϊ-10~10����������ʧ�ܣ�", 
                    "����",
                    MB_DEFBUTTON2);

                RefreshRoughRollStraGrid();

                return;
            }

            pStraPass->fSpeed = m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed;//fSpeed;
            m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed_Cor 
                = pStraPass->fSpeed_Cor;

            /*m_stRoughRollStra.stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed 
                = pStraPass->fSpeed;*/

            pOrgRMStra->stRoughRollStraR2[nRow - 2 - nCountR1].fSpeed_Cor = 
                pStraPass->fSpeed_Cor;

            pRMStra->stRoughRollStraR2[nRow-2-nCountR1].emSprayMode
                = pStraPass->emSprayMode;
        }

        PceData_ChangeRmStraPass(m_pCurPceData, pStraPass, nRow - 1);
    }

    //PceData_ChangeRmStraPass(m_pCurPceData, pStraNextPass, nRow);

    GetCfgData();

    RefreshRoughRollStraGrid();

    return;
}


HRS_ROUGHROLL_STRA_PASS * CViewRoughRollStra::GetRoughRollStraPassFromGrid(
                              int nRow, 
                              HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass)
{
    CString StrItem;
    int RowCount;

    RowCount = m_GridRoughRollStra.GetRowCount();
    if ( nRow < 1 || nRow >= RowCount)
    {
        return NULL;
    }

//    pRoughRollStraPass = (HRS_ROUGHROLL_STRA_PASS *) NG_malloc(sizeof(HRS_ROUGHROLL_STRA_PASS));

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_PASS_NO);
    sprintf_s( pRoughRollStraPass->strPass_No , HRS_PASS_NO_LEN, "%s", StrItem.GetBuffer());
    StrItem.ReleaseBuffer();
    pRoughRollStraPass->strPass_No[HRS_PASS_NO_LEN-1] = '\0';

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_THICK_EXIT);
    pRoughRollStraPass->fThick_Exit = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_DELTA_DRAFT);
    pRoughRollStraPass->fDeltaDraftValue = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_DRAFT);
    pRoughRollStraPass->fDraft = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_DRAFT_COR);
    pRoughRollStraPass->fDraftCor = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_WIDTH);
    pRoughRollStraPass->fWidth = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_WIDTH_COR);
    pRoughRollStraPass->fWidth_Cor = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_SPEED);
    pRoughRollStraPass->fSpeed = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_SPEED_COR);
    pRoughRollStraPass->fSpeed_Cor = atof(StrItem);

    StrItem = m_GridRoughRollStra.GetItemText(nRow, HRS_ROUGHROLL_STRA_SPRAY);
    /*if (StrItem == "AUTO")
    {
        pRoughRollStraPass->emSprayMode = HRS_SPRAY_AUTO;
    }
    else */
    if (StrItem == "ON")
    {
        pRoughRollStraPass->emSprayMode = HRS_SPRAY_ON;
    }
    else if (StrItem == "OFF")
    {
        pRoughRollStraPass->emSprayMode = HRS_SPRAY_OFF;
    }
    else
    {
        pRoughRollStraPass->emSprayMode = HRS_SPRAY_OFF;
    }

    return pRoughRollStraPass;
}


void CViewRoughRollStra::OnBnClickedCheckRrsE1()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);

    HRS_ROUGHROLL_STRA  *pRMStra;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[m_BPassMode]);


    if (m_bCheckStandDummyE1)
    {
        pRMStra->bStand_Dummy_E1 = true;
        m_pCurPceData->stRoughRollStra.bStand_Dummy_E1 = true;
    } 
    else
    {
        pRMStra->bStand_Dummy_E1 = false;
        m_pCurPceData->stRoughRollStra.bStand_Dummy_E1 = false;
    }
}


void CViewRoughRollStra::OnBnClickedCheckRrsRmexitthick()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);

    HRS_ROUGHROLL_STRA  *pRMStra;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[m_BPassMode]);


    if (m_bCheckRmExitThick)
    {
        pRMStra->bRm_Exit_Thick_Auto = true;
        m_pCurPceData->stRoughRollStra.bRm_Exit_Thick_Auto = true;
        m_ButCtlRmExitThick.EnableWindow(FALSE);
    } 
    else
    {
        pRMStra->bRm_Exit_Thick_Auto = false;
        m_pCurPceData->stRoughRollStra.bRm_Exit_Thick_Auto = false;
        m_ButCtlRmExitThick.EnableWindow(TRUE);
    }

    NMHDR nmHDR;
    LRESULT lresult;

    OnGridRoughRollStraClick(&nmHDR, &lresult);

}


void CViewRoughRollStra::OnBnClickedCheckRrsR1()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);

    HRS_ROUGHROLL_STRA  *pRMStra;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[m_BPassMode]);


    if (m_bCheckStandDummyR1)
    {
        pRMStra->bStand_Dummy_R1 = true;
        m_pCurPceData->stRoughRollStra.bStand_Dummy_R1 = true;
    } 
    else
    {
        pRMStra->bStand_Dummy_R1 = false;
        m_pCurPceData->stRoughRollStra.bStand_Dummy_R1 = false;
    }
}


void CViewRoughRollStra::OnBnClickedCheckRrsE2()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

    if (m_pCurPceData == NULL)
    {
        return;
    }

    assert(m_BPassMode == m_pCurPceData->stRMStraData.nCurPassModeIndex);

    HRS_ROUGHROLL_STRA  *pRMStra;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[m_BPassMode]);

    if (m_bCheckStandDummyE2)
    {
        pRMStra->bStand_Dummy_E2 = true;

        m_pCurPceData->stRoughRollStra.bStand_Dummy_E2 = true;
    } 
    else
    {
        pRMStra->bStand_Dummy_E2 = false;

        m_pCurPceData->stRoughRollStra.bStand_Dummy_E2 = false;
    }
}


void CViewRoughRollStra::OnEnChangeEditRrsEmexitthick()
{
    // TODO:  ����ÿؼ��� RICHEDIT �ؼ�������������
    // ���͸�֪ͨ��������д CFormView::OnInitDialog()
    // ���������� CRichEditCtrl().SetEventMask()��
    // ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

    // TODO:  �ڴ����ӿؼ�֪ͨ�����������

    UpdateData(TRUE);

#if 0
    if (m_pCurPceData == NULL)
    {
        return;
    }

    int nRet = MessageBox("�м�����ȸ��ģ��Ƿ񱣴棿", 
        "�뿪", 
        MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

    if ( nRet == IDYES )
    {
        int nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;

        HRS_ROUGHROLL_STRA_PASS  *pstStraR2 = 
            &m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCountR2 - 1];
        HRS_ROUGHROLL_STRA_PASS  *pstStraR2Pre = 
            &m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCountR2 - 2];

        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick = atof(m_strRmExitThick);

        pstStraR2->fThick_Cor  = atof(m_strRmExitThick) - pstStraR2->fThick_Exit;
        pstStraR2->fThick_Exit = atof(m_strRmExitThick);

        pstStraR2->fDraft = 
            (pstStraR2Pre->fThick_Exit - pstStraR2->fThick_Exit) / pstStraR2Pre->fThick_Exit;

        pstStraR2->fDraftCor = pstStraR2->fThick_Cor / pstStraR2Pre->fThick_Exit;
    }

    RefreshRoughRollStraGrid();
#endif
    return;
}


void CViewRoughRollStra::SavePceData()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    PCE_DATA * pPceDataOrig;

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        memcpy( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) );
    }
    else 
    {
    }

    return ;
}


void CViewRoughRollStra::OnBnClickedRmStraSave()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    PCE_DATA * pPceDataOrig;
    
    if ( m_pCurPceData == NULL )
    {
        return;
    }

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        memcpy( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) );

        MessageBox("���ݱ���ɹ���");
    }
    else 
    {
        MessageBox("û�����ݸ���");
    }

    return ;
}


bool CViewRoughRollStra::ExitConfirm()
{
    PCE_DATA * pPceDataOrig;

    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);
   if (pPceDataOrig == NULL || m_pCurPceData == NULL)
   {
       return true;
   }

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) )
    {
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                              "�뿪", 
                              MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) );
        }
        else if (nRet == IDCANCEL)
        {
            return false;
        }
    }
    else 
    {
        return true;
    }

    return true;
}


// move
void CViewRoughRollStra::RefreshRollPDIGrid()
{
    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    m_GridRoughRollPDI.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridRoughRollPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridRoughRollPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            //SetTextBGCor(pPceData, Item);

            SetTextBGCor(m_GridRoughRollPDI, pPceData, i + 1, j);

            switch (j)
            {
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.4f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.4f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridRoughRollPDI.SetItem(&Item);
        }
    }

    m_GridRoughRollPDI.Refresh();

    m_GridRoughRollPDI.SetEditable(FALSE);

    //m_GridRoughRollPDI.EnableSelection(TRUE);
}


void CViewRoughRollStra::FormatSchedText(GV_ITEM &Item, 
                                    HRS_ROUGHROLL_SCHEDCALC_PASS *pSchedCalcPass,
                                    int nCol,
                                    HRS_SPRAY_MODE_EM emSprayMode)
{
    switch (nCol)
    {
    case HRS_RM_SCHEDCALC_PASS :
        //Item.strText.Format(_T("%s"),strHeading);
        Item.strText.Format(_T("%s"),pSchedCalcPass->strPass);
        break;
    case HRS_RM_SCHEDCALC_EGAP :
        Item.strText.Format(_T("%d"),pSchedCalcPass->nEGAP);
        break;
    case HRS_RM_SCHEDCALC_ED :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fED);
        break;
    case HRS_RM_SCHEDCALC_RGAP :
        Item.strText.Format(_T("%6.4f"),pSchedCalcPass->fRGAP);
        break;
    case HRS_RM_SCHEDCALC_RD :
        Item.strText.Format(_T("%6.4f"),pSchedCalcPass->fRD);
        break;
    case HRS_RM_SCHEDCALC_BAR_H :
        Item.strText.Format(_T("%6.4f"),pSchedCalcPass->fBAR_H);
        break;
    case HRS_RM_SCHEDCALC_E_W :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fE_W);
        break;
    case HRS_RM_SCHEDCALC_BAR_W :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fBAR_W);
        break;

    case HRS_RM_SCHEDCALC_BAR_L :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fBAR_L);
        break;
    case HRS_RM_SCHEDCALC_E_RF :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fE_RF);
        break;
    case HRS_RM_SCHEDCALC_R_RF :
        Item.strText.Format(_T("%d"),pSchedCalcPass->nR_RF);
        break;
    case HRS_RM_SCHEDCALC_SPD :
        Item.strText.Format(_T("%6.4f"),pSchedCalcPass->fSPD);
        break;
    case HRS_RM_SCHEDCALC_R_ET :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fR_ET);
        break;
    case HRS_RM_SCHEDCALC_R_TOR :
        Item.strText.Format(_T("%d"),pSchedCalcPass->nR_TOR);
        break;
    case HRS_RM_SCHEDCALC_Effic :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fEffic);
        break;
    case HRS_RM_SCHEDCALC_R_POW :
        Item.strText.Format(_T("%6.2f"),pSchedCalcPass->fR_POW);
        break;
    case HRS_RM_SCHEDCALC_DESC :
        {
            int nMode;
            if ( emSprayMode == HRS_SPRAY_OFF)
            {
                nMode = 0;
            }
            else
            {
                nMode = 1;
            }
            Item.strText.Format(_T("%d"), nMode);
        }

        break;

    default:
        Item.strText.Format(_T("%d"),0);
        break;
    }
}


void CViewRoughRollStra::RefreshRoughRollSchedGrid()
{
    char strHeading[5]={0};
    int  RowCount;

    int  nCountR1;
    int  nCountR2;

    HRS_ROUGHROLL_SCHEDCALC_PASS ZeroPass;
    HRS_ROUGHROLL_SCHEDCALC_PASS *pSchedCalcPass;
    HRS_SPRAY_MODE_EM  emSprayMode;
    HRS_PASS_MODE_EM   emPassMode;


    //GetThick_Cor();
    emPassMode = m_pCurPceData->stRoughRollStra.emPassMode;

    int nPassModeIndex = HRS_GetPassModeIndex(emPassMode);

    nCountR1 = emPassMode / 10;
    nCountR2 = emPassMode % 10;

    m_GridRoughRollSchedCalc.DeleteNonFixedRows();

    memset(&ZeroPass, 0, sizeof(HRS_ROUGHROLL_SCHEDCALC_PASS));

    HRS_ROUGHROLL_STRA  *pRMStra;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[nPassModeIndex]);

    for (int i = 0; i < nCountR1; i++)
    {
        RowCount = m_GridRoughRollSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollSchedCalc.InsertRow(strHeading);

        if ( m_pCurPceData->stRoughRollSched.emCurPassMode != emPassMode )
        {
            pSchedCalcPass = &ZeroPass;
        }
        else
        {
            pSchedCalcPass =  &(m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i]);
        }
        //emSprayMode = m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].emSprayMode;

        emSprayMode = pRMStra->stRoughRollStraR1[i].emSprayMode;

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            FormatSchedText(Item, 
                pSchedCalcPass, 
                j,
                emSprayMode);
            m_GridRoughRollSchedCalc.SetItem(&Item);
        }
    }

    for (int i = 0; i < nCountR2; i++)
    {
        RowCount = m_GridRoughRollSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollSchedCalc.InsertRow(strHeading);

        if ( m_pCurPceData->stRoughRollSched.emCurPassMode != emPassMode )
        {
            pSchedCalcPass = &ZeroPass;
        }
        else
        {
            pSchedCalcPass =  &(m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i]);
        }

//        emSprayMode = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i].emSprayMode;
        emSprayMode = pRMStra->stRoughRollStraR2[i].emSprayMode;

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            FormatSchedText(Item, 
                pSchedCalcPass, 
                j,
                emSprayMode);

            m_GridRoughRollSchedCalc.SetItem(&Item);
        }
    }

    RowCount = m_GridRoughRollSchedCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRoughRollSchedCalc.InsertRow(strHeading);

    if ( m_pCurPceData->stRoughRollSched.emCurPassMode != emPassMode )
    {
        pSchedCalcPass = &ZeroPass;
    }
    else
    {
        pSchedCalcPass =  &(m_pCurPceData->stRoughRollSched.SchedCalcPassE3);
    }
    emSprayMode = HRS_SPRAY_OFF;

    for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        FormatSchedText(Item, 
            pSchedCalcPass, 
            j,
            emSprayMode);

        m_GridRoughRollSchedCalc.SetItem(&Item);
    }

//    m_GridRoughRollSchedCalc.AutoSizeColumns();
    m_GridRoughRollSchedCalc.Refresh();


#if 0
    /* 
     * ˢ��basicData���ݱ���
     */
    m_GridRoughRollBasicData.DeleteNonFixedRows();
    RowCount = m_GridRoughRollBasicData.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRoughRollBasicData.InsertRow(strHeading);

    for(int j = 0; j < HRS_ROUGHROLL_BASICDATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_RM_BASICDATA_STRIP_NO_ :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_RM_BASICDATA_HSB1 :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.BasicDataPass.nHSB1);
            break;
        case HRS_RM_BASICDATA_HSB2 :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.BasicDataPass.nHSB2);
            break;
        case HRS_RM_BASICDATA_S_TEMP :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fS_Temp);
            break;
        case HRS_RM_BASICDATA_RDT_ :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDT);
            break;
        case HRS_RM_BASICDATA_RDW :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDW);
            break;
        case HRS_RM_BASICDATA_RDH :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDH);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridRoughRollBasicData.SetItem(&Item);

    }
    m_GridRoughRollBasicData.AutoSizeColumns();
    m_GridRoughRollBasicData.Refresh();

#endif

    UpdateData(FALSE);
}


void CViewRoughRollStra::OnGridRoughRollStraClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    HRS_ROUGHROLL_STRA_PASS RMStraPass;
    HRS_ROUGHROLL_STRA_PASS * pStraPass = NULL;

    if (NULL == pNotifyStruct ||NULL == pResult)
    {
        return;
    }

    if ( m_pCurPceData == NULL )
    {
        return;
    }

    if (m_dBarThick > 65 || m_dBarThick < 30 || m_dBarThick > m_pCurPceData->stRollSched.fS_H)
    {
        /*if ( m_pCurPceData->nRoughRollSchedStatus == ERR_SUCCESS )
        {
            m_dBarThick = m_pCurPceData->stRoughRollSched.dTransferBarGauge;
        }
        else
        {
            m_dBarThick = m_pCurPceData->stRollSched.fR_H;
        }*/

        char szMsg[256];
        sprintf(szMsg, "�м������ = %f ������Χ\r\n�Ϸ���Χ: 30~65", 
                m_dBarThick);
        AfxMessageBox(szMsg);

        //UpdateData(FALSE);

        return;
    }

    //��ǰ���ε�ǰ����ε�ѹ���ʺͳ��ں��

    NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;

    HRS_PASS_MODE_EM nPassMode = HRS_GetPassModeByIndex(m_BPassMode);

    m_pCurPceData->stRoughRollStra.emPassMode = nPassMode;

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;


    //��ǰR1��R2�ĵ���
    int nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
    int nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;
    int nTotalCount = nCountR1 + nCountR2 + 1;

    HRS_ROUGHROLL_STRA *pRMStra;

    int nIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[nIndex]);

    //����м����Ƿ����仯
    pStraPass = GetRoughRollStraPassFromGrid(nTotalCount, &RMStraPass);
    if (TRUE == m_bCheckRmExitThick)
    {
        m_RmAllCalcData.StrategyData.dTransferBarThick = 
                                            m_pCurPceData->stRollSched.fR_H;

        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick = 
                                            m_pCurPceData->stRollSched.fR_H;

        pRMStra->fRm_Exit_Thick = m_pCurPceData->stRollSched.fR_H;

        m_RmAllCalcData.StrategyData.dTransferBarThick = m_pCurPceData->stRollSched.fR_H;

 //       m_pCurPceData->stRoughRollSched.dTransferBarGauge = m_dBarThick;

        GetCfgData();

        RefreshRoughRollStraGrid();
    }
    else if(m_dBarThick > 1 && abs(m_dBarThick - pStraPass->fThick_Exit) > 0.01 )
    {
//        m_RmAllCalcData.PlanData.dTransferBarGauge = m_dBarThick;
        m_RmAllCalcData.StrategyData.dTransferBarThick    = m_dBarThick;
        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick     = m_dBarThick;
//        m_pCurPceData->stRoughRollSched.dTransferBarGauge = m_dBarThick;
        pRMStra->fRm_Exit_Thick = m_dBarThick;

        GetCfgData();

        RefreshRoughRollStraGrid();
    }

//    NG_free(pStraPass);
    pStraPass = NULL;

    return;
}

#if 0

int CViewRoughRollStra::SetThick_Exit()
{

    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        m_pCurPceData->fThickExit[i] = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit;

        m_pCurPceData->fDraftValue[i] = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDraftValue;
        
    }

    for (int i = 0 + HRS_ROUGHROLL_R1_PASS_MAX; 
        i < HRS_ROUGHROLL_R2_PASS_MAX + HRS_ROUGHROLL_R1_PASS_MAX;
        i++ )
    {
        m_pCurPceData->fThickExit[i] = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i - HRS_ROUGHROLL_R1_PASS_MAX].fThick_Exit;

        m_pCurPceData->fDraftValue[i] = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[i - HRS_ROUGHROLL_R1_PASS_MAX].fDraftValue;

    }

    return ERR_SUCCESS;
}

int CViewRoughRollStra::GetThick_Cor()
{
    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Cor = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fThick_Exit
            - m_pCurPceData->fThickExit[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDeltaDraftValue = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR1[i].fDeltaDraftValue
            - m_pCurPceData->fDraftValue[i];

    }

    for (int i = 0 + HRS_ROUGHROLL_R1_PASS_MAX; 
        i < HRS_ROUGHROLL_R2_PASS_MAX + HRS_ROUGHROLL_R1_PASS_MAX;
        i++ )
    {
        int nCurPassNO = i - HRS_ROUGHROLL_R1_PASS_MAX;

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCurPassNO].fThick_Cor = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCurPassNO].fThick_Exit
            - m_pCurPceData->fThickExit[i];

        m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCurPassNO].fDeltaDraftValue = 
            m_pCurPceData->stRoughRollStra.stRoughRollStraR2[nCurPassNO].fDraftValue
            - m_pCurPceData->fDraftValue[i];
    }

    return ERR_SUCCESS;
}

#endif


void CViewRoughRollStra::OnGridRoughRollPDIClick(NMHDR *pNotifyStruct, 
                                                 LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;
    PCE_DATA * pPceDataOrig;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    if (m_pCurPceData == NULL)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridRoughRollPDI.GetFixedRowCount() )
    {
        return;
    }

    theApp.m_nPDIRow = nRow;

    itemStr = m_GridRoughRollPDI.GetItemText(nRow, 1);

// move
    pPceDataOrig = m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo);

    if ( memcmp( pPceDataOrig, m_pCurPceData, sizeof(PCE_DATA) ) != 0 )
    {
#if 0
        int nRet = MessageBox("�����ݸ��ģ��Ƿ񱣴棿", 
                            "�л��ְ�", 
                            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet == IDYES )
        {
            memcpy( m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo), 
                m_pCurPceData, 
                sizeof(PCE_DATA) );

        }
        else if (nRet == IDCANCEL)
        {
            int nSeq;

            nSeq = m_pRollSchedMgr->SearchSeqByStripNo(m_strCurStripNo);
            if (nSeq < 0)
            {
                return;
            }

            m_GridRoughRollPDI.SetFocusCell(nSeq, 2);
            m_GridRoughRollPDI.SetSelectedRange(nSeq,1,nSeq,HRS_ROLL_SCHED_ITEM_NUM-1);

            UpdateData(FALSE);
            return ;
        }
#endif
        memcpy( m_pRollSchedMgr->SearchPceDataByStripNo(m_strCurStripNo), 
            m_pCurPceData, 
            sizeof(PCE_DATA) );
    }

    //PceData_Destroy(m_pCurPceData);

    //m_pCurPceData = m_pRollSchedMgr->CopyPceDataByStripNo(itemStr);
    m_pCurPceData = m_pRollSchedMgr->GetPceDataByStripNo(itemStr);
    if ( m_pCurPceData == NULL )
    {
        return;
    }

    HRS_ROUGHROLL_STRA  *pRMStra;
    int nIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;

    pRMStra = &(m_pCurPceData->stRMStraData.aAllPassModeStra[nIndex]);

    if ( m_pCurPceData->nRoughRollSchedStatus == ERR_SUCCESS )
    {
        m_dBarThick = m_pCurPceData->stRoughRollSched.dTransferBarGauge;
    }
    else
    {
        m_dBarThick = m_pCurPceData->stRoughRollStra.fRm_Exit_Thick;

        m_dBarThick = pRMStra->fRm_Exit_Thick;
    }

    // ȡ����¯�¶ȸ��µ���¯�¶ȱ༭������
    m_dExtTemp = m_pCurPceData->stRollSched.fEXT;
    m_dExtTemp = pRMStra->fDischargeTemp;


    UpdateData(FALSE);

    memcpy(&m_stRoughRollStra, 
           &m_pCurPceData->stRoughRollStra, 
           sizeof(HRS_ROUGHROLL_STRA));

    if (ERR_FAILED == m_pCurPceData->nRoughRollStraCfgStatus)
    {
        GetCfgData();

        //SetThick_Exit();

        m_pCurPceData->nRoughRollStraCfgStatus = ERR_SUCCESS;
    }


    RefreshRoughRollStraGrid();

    m_strStripNo = itemStr;
    m_strCurStripNo = itemStr;

    RefreshRoughRollSchedGrid();

//    m_dBarThick = m_pCurPceData->stRoughRollStra.stHSB.fThick_Exit;


    UpdateData(FALSE);

    return ;
// end
}


int CViewRoughRollStra::HRS_RMCalc_Speed(HRS_RM_ALL_DATA *pAllData,
                                         HRS_RM_ALL_PASS *pAllPass,
                                         HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                                         HRS_RM_ALL_SPEED *pAllSpeed)
{
    HRS_SLAB_DATA               *pSlabData;

    //HRS_RM_ALL_PASS              AllPass;            // �������õĲ���
    //HRS_RM_ALL_DELIVERY_GAUGE    AllDeliveryGauge;   // ���л��ܸ����γ��ں��

    HRS_RM_ALL_ENTRY_PARA        AllEntry;           // �����¶Ⱥ��ٶ�ʹ�õĲ���   
    //HRS_RM_ALL_SPEED             AllSpeed;           // ���л��ܸ����ε��ٶ�

    int                          nRet;

    if ( pAllData == NULL 
        || pAllSpeed == NULL 
        || NULL == pAllDeliveryGauge 
        || NULL == pAllPass
        || m_pCurPceData == NULL )
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    pAllData->StrategyData.nPassMode = m_pCurPceData->stRoughRollStra.emPassMode;

    nRet = HRS_RML2Calc_GetSteelData(pAllData);
    if (nRet == ERR_FAILED)
    {
        char szMsg[2048];

        sprintf(szMsg, 
                " %s \r\nHRS_RMCalc_Speed(), GetSteelData() Failed.", 
                pAllData->szOutErr);

        AfxMessageBox(szMsg);
        return ERR_FAILED;
    }

    //ѹ���ʲ�������
    //HRS_TABLE_RM_DRAFTRATIO RmDraftTab[6];
    memset(m_RmDraftTab, 0, sizeof(HRS_TABLE_RM_DRAFTRATIO) * HRS_RM_DRAFT_NUM_MAX);

    HRS_RM_DRAFT_RATIO_STRA *pDraftStra;

    pDraftStra = &(m_pCurPceData->stRoughRollStra.stDraftRatioStra);


    HRS_RML2Calc_RmDraftPara(pAllData, pAllPass, 
        pDraftStra->aRmDraftTab, HRS_RM_DRAFT_NUM_MAX);

    LoadDraftRationFromCurPce();

    nRet = HRS_RML2Calc_CalcGauge_forGUI(pAllPass, pAllDeliveryGauge,
           pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox(pAllData->szOutErr);

        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareEntryPara(pAllData, 
                                  pAllPass, 
                                  pAllDeliveryGauge, 
                                  &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, pAllSpeed);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox(pAllData->szOutErr);
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CViewRoughRollStra::HRS_RMDate_ToPCE()
{
    m_RmDraftTab[0].nPassMode = m_pCurPceData->stRoughRollStra.emPassMode;

    m_RmDraftTab[0].dLoadValueR11 = m_pCurPceData->stRoughRollStra.stRoughRollStraR1[0].fDraft;
    m_RmDraftTab[0].dLoadValueR12 = m_pCurPceData->stRoughRollStra.stRoughRollStraR1[1].fDraft;
    m_RmDraftTab[0].dLoadValueR13 = m_pCurPceData->stRoughRollStra.stRoughRollStraR1[2].fDraft;

    m_RmDraftTab[0].dLoadValueR21 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[0].fDraft;
    m_RmDraftTab[0].dLoadValueR22 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[1].fDraft;
    m_RmDraftTab[0].dLoadValueR23 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[2].fDraft;
    m_RmDraftTab[0].dLoadValueR24 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[3].fDraft;
    m_RmDraftTab[0].dLoadValueR25 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[4].fDraft;
    m_RmDraftTab[0].dLoadValueR26 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[5].fDraft;
    m_RmDraftTab[0].dLoadValueR27 = m_pCurPceData->stRoughRollStra.stRoughRollStraR2[6].fDraft;

    return ERR_SUCCESS;
}


int CViewRoughRollStra::HRS_RMCalc_SpeedGUI(HRS_RM_ALL_DATA *pAllData,
                                         HRS_RM_ALL_PASS *pAllPass,
                                         HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                                         HRS_RM_ALL_SPEED *pAllSpeed)
{
    HRS_SLAB_DATA               *pSlabData;
    HRS_RM_ALL_ENTRY_PARA        AllEntry;           // �����¶Ⱥ��ٶ�ʹ�õĲ���   
    int                          nRet;

    if ( pAllData == NULL 
        || pAllSpeed == NULL 
        || NULL == pAllDeliveryGauge 
        || NULL == pAllPass)
    {
        return ERR_FAILED;
    }

    pSlabData = &(pAllData->PlanData.SlabData);

    nRet = HRS_RML2Calc_GetSteelData(pAllData);
    if (nRet == ERR_FAILED)
    {
        char szMsg[2048];

        sprintf(szMsg, " %s \r\nHRS_RMCalc_Speed(), GetSteelData() Failed.", 
            pAllData->szOutErr);
        AfxMessageBox(szMsg);
        return ERR_FAILED;
    }

    //ѹ���ʲ�������
    //HRS_TABLE_RM_DRAFTRATIO RmDraftTab[6];
    memset(m_RmDraftTab, 0, sizeof(HRS_TABLE_RM_DRAFTRATIO) * HRS_RM_DRAFT_NUM_MAX);
    //HRS_RML2Calc_RmDraftPara(pAllData, pAllPass, m_RmDraftTab, HRS_RM_DRAFT_NUM_MAX);

    HRS_RMDate_ToPCE();

    int nPassMode = m_pCurPceData->stRoughRollStra.emPassMode;

    HRS_RM_DRAFT_RATIO_STRA  *pRmDraftStra;
    pRmDraftStra = &(m_pCurPceData->stRoughRollStra.stDraftRatioStra);


    HRS_RML2Calc_RmDraftParaGUI(pAllData, pAllPass, 
        pRmDraftStra->aRmDraftTab, HRS_RM_DRAFT_NUM_MAX, nPassMode);
    
    nRet = HRS_RML2Calc_CalcGauge_forGUI(pAllPass, pAllDeliveryGauge,
                                         pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox(pAllData->szOutErr);

        return ERR_FAILED;
    }

    HRS_RML2Calc_PrepareEntryPara(pAllData, 
                                  pAllPass, 
                                  pAllDeliveryGauge, 
                                  &AllEntry);

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, pAllSpeed);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox(pAllData->szOutErr);
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int  CViewRoughRollStra::GetGuiData()
{
    int nRet = -1;

    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");

        return ERR_FAILED;
    }

    memset(&m_RmAllCalcData, 0, sizeof(HRS_RM_ALL_DATA));

    nRet = PceData_GetPdiForCalc(m_pCurPceData, &m_RmAllCalcData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return nRet;
    }

    nRet = PceData_GetRmStraDataForCalc(m_pCurPceData,
                                        &m_RmAllCalcData.StrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return nRet;
    }

    memcpy(&m_RmAllCalcData.PlateData.SlabeData, 
           &m_RmAllCalcData.PlanData.SlabData, 
           sizeof(HRS_SLAB_DATA));
    //m_RmAllCalcData.PlateData.dSlabeEntryTemp = 1600;                //����

    // ��ȡ������
    CHRSEquipParaMgr *pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return nRet;
    }

     nRet = pModule->GetAllStandPara(&m_RmAllCalcData.AllStandPara);
     if (nRet == ERR_FAILED)
     {
         AfxMessageBox("��ȡ�豸����ʧ��!");
         return nRet;
     }

    CHRSEquipParaMgr_Destroy(pModule);

    //���ο�������
    memcpy(m_RmAllCalcData.DeformFactor.szSteelGrade, 
           m_RmAllCalcData.PlanData.SlabData.szSteelGradeName, 
           HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;

    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);

    if (pFactor != NULL )
    {
        m_RmAllCalcData.DeformFactor = *pFactor;
    }
    else
    {
        m_RmAllCalcData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;               // ��������
        m_RmAllCalcData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        m_RmAllCalcData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        m_RmAllCalcData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        m_RmAllCalcData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        m_RmAllCalcData.DeformFactor.dReserve1 = 1;
        m_RmAllCalcData.DeformFactor.dReserve2 = 1;
    }


    // ��ѯ�����������뾶
    double dR1WorkRadius;
    double dR2WorkRadius;

    nRet = GetRMWorkRadius(&dR1WorkRadius, &dR2WorkRadius);

    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    // ���ù������뾶
    m_RmAllCalcData.AllStandPara.aEquipPara[HRS_STAND_NO_RM1].dMaxWorkingRollerRadius
        = dR1WorkRadius;
    m_RmAllCalcData.AllStandPara.aEquipPara[HRS_STAND_NO_RM2].dMaxWorkingRollerRadius 
        = dR2WorkRadius;

    return ERR_SUCCESS;
}


int CViewRoughRollStra::GetRMWorkRadius(double *pdR1WorkerRadius,
                                         double *pdR2WorkerRadius)
{

    HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerDataMgr;
    char szOutErr[1024];
    double adRadius[4];
    int    nRet;

    pTotalRollerDataMgr = m_pRollSchedMgr->GetTotalRollerDataMgr();

    szOutErr[0] = '\0';
    nRet = HRS_TotalRollerDataMgr_GetRMWorkingRadius(pTotalRollerDataMgr,
                                    adRadius, 
                                    NG_ARRAY_SIZE(adRadius),
                                    szOutErr);

    if ( nRet == ERR_FAILED )
    {
        AfxMessageBox(szOutErr);
        return ERR_FAILED;
    }

    *pdR1WorkerRadius = adRadius[0];
    *pdR2WorkerRadius = adRadius[1];

    return ERR_SUCCESS;
}


void CViewRoughRollStra::OnBnClickedRmStraCalc()
{
    CString strStripNo;

    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    int nRet = -1;

    UpdateData(TRUE);

    if ( m_dExtTemp <1000.0 || m_dExtTemp > 1350.0 )
    {
        AfxMessageBox("��¯�¶ȱ�����1000.0~1350.0��Χ��");
        return;
    }

    if ( m_dBarThick < 30.0 || m_dBarThick > 65.0 )
    {
        AfxMessageBox("�м�����ȱ�����30.0~65.0��Χ��");
        return;
    }

    NM_GRIDVIEW nmGridView;
    LRESULT  lresult;

    NM_GRIDVIEW* pItem = &nmGridView;

    pItem->iRow = theApp.m_nPDIRow;
    pItem->iColumn = 1;

    OnGridRoughRollStraClick((NMHDR *)pItem, &lresult);

#if 0
    if (FALSE == m_bCheckRmExitThick 
     && fabs(m_dBarThick - m_pCurPceData->stRollSched.fR_H) > NG_POSITIVE_ZERO )
    {
        int nRet = MessageBox("�м�����ȸ��ģ��Ƿ������", 
            "�뿪", 
            MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet != IDYES )
        {
            return;
        }
    }

    //��鵱ǰ�����Ƿ��Ѿ�������������
    if (ERR_SUCCESS == m_pCurPceData->nRoughRollSchedStatus)
    {
        nRet = MessageBox("������������Ѿ���������Ƿ����¼��㣿", 
                   "������̼���", 
                   MB_YESNOCANCEL | MB_ICONWARNING | MB_DEFBUTTON2);

        if ( nRet != IDYES )
        {
            return;
        }
    }
#endif


    //��ȡ��ǰ�����ְ��
    //CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return;
    }
    //strStipNo = m_pCurPceData->stRollSched.strSTRIP_NO;

    if (m_bCheckRemoteCalc)
    {
        // �ж�ͨ�������Ƿ���
        int nCommState = theApp.m_pGUIComm->GetCommState();

        if ( nCommState == ERR_FAILED )
        {
            nRet = theApp.m_pGUIComm->GUICommCreate();

            if (nRet == ERR_FAILED)
            {
                AfxMessageBox("ͨ������δ���������ܽ���Զ�̼���");

                return;
            }
        }
    }

#if 1

    //
    // ��ȡGUI�������趨���ݸ�����
    //
    HRS_RM_ALL_DATA    HrsRmAllData;

    nRet = PceData_GetPdiForCalc(m_pCurPceData, &HrsRmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return;
    }
    nRet = PceData_GetRmStraDataForCalc(m_pCurPceData, &HrsRmAllData.StrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return;
    }

    //m_pRollSchedMgr->GetFmStraDataForCalc(strStipNo, &HrsRmAllData.FMStrategyData);

    memcpy(&HrsRmAllData.PlateData.SlabeData, 
           &HrsRmAllData.PlanData.SlabData, 
           sizeof(HRS_SLAB_DATA));
    HrsRmAllData.PlateData.dSlabeEntryTemp = 1600;                                  //����

    // ��ȡ������
    CHRSEquipParaMgr *pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return;
    }

    pModule->GetAllStandPara(&HrsRmAllData.AllStandPara);


    m_AllStandPara = HrsRmAllData.AllStandPara;

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(HrsRmAllData.DeformFactor.szSteelGrade, 
           HrsRmAllData.PlanData.SlabData.szSteelGradeName, 
           HRS_MAX_GRADE_LEN);

    CHRSServerCfg  *pServerCfg = theApp.GetServerCfg();

    char *pszSteelGradeName = m_pCurPceData->stRollSched.strSIGN;
    
    HRS_DEFORM_RESIST_FACTOR  *pFactor;
    pFactor = pServerCfg->FindDeformFactor(pszSteelGradeName);
    
    if (pFactor != NULL )
    {
        HrsRmAllData.DeformFactor = *pFactor;
    }
    else
    {
        HrsRmAllData.DeformFactor.dFactorA = DEFORM_FACTOR_DEF_A;               // ��������
        HrsRmAllData.DeformFactor.dFactorB = DEFORM_FACTOR_DEF_B;
        HrsRmAllData.DeformFactor.dFactorC = DEFORM_FACTOR_DEF_C;
        HrsRmAllData.DeformFactor.dFactorD = DEFORM_FACTOR_DEF_D;
        HrsRmAllData.DeformFactor.dFactorN = DEFORM_FACTOR_DEF_N;
        HrsRmAllData.DeformFactor.dReserve1 = 1;
        HrsRmAllData.DeformFactor.dReserve2 = 1;
    }
#endif

    if (ERR_FAILED == GetGuiData())
    {
        return;
    }


    CCellRange cell_range = m_GridRoughRollPDI.GetSelectedCellRange();

    theApp.m_nPDIRow = cell_range.GetMinRow();


    //��������
    if ( m_bCheckRemoteCalc )
    {
#if 0
        if (ERR_SUCCESS == m_pCurPceData->nRoughRollSchedStatus)
        {
            nRet = MessageBox("��������Ѿ�������ˣ��Ƿ����¼��㣿", 
                "����", 
                MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);

            if ( nRet != IDYES )
            {
                RefreshRoughRollSchedGrid();

                return;
            }
        }
#endif

        HRS_RM_DATA_FROM_GUI RMGUIData;
        memset(&RMGUIData, 0, sizeof(HRS_RM_DATA_FROM_GUI));

        RMGUIData.PlanData     = m_RmAllCalcData.PlanData;

        memcpy(RMGUIData.szSign,
            m_pCurPceData->stRollSched.strSIGN,
            HRS_SIGN_LEN);

        m_RmAllCalcData.StrategyData.dExtTemp          = m_dExtTemp;
        RMGUIData.PlanData.dDischargeTemp = m_dExtTemp;

        HRS_STAND_PARA *pStandPara = m_RmAllCalcData.AllStandPara.aEquipPara;

        RMGUIData.adWorkingRollerRadius[0] = 
            pStandPara[HRS_STAND_NO_RM1].dMaxWorkingRollerRadius;
        RMGUIData.adWorkingRollerRadius[1] = 
            pStandPara[HRS_STAND_NO_RM2].dMaxWorkingRollerRadius;

        //    RMGUIData.PlanData.dTransferBarGauge = m_dBarThick;
        if (m_bCheckRmExitThick)
        {
            m_pCurPceData->stRoughRollStra.bRm_Exit_Thick_Auto = true;

            m_RmAllCalcData.StrategyData.dTransferBarThick = 
                m_pCurPceData->stRollSched.fR_H;

            RMGUIData.StrategyData.dTransferBarThick =
                m_pCurPceData->stRollSched.fR_H;
        }
        else
        {
            m_pCurPceData->stRoughRollStra.bRm_Exit_Thick_Auto = false;

            m_RmAllCalcData.StrategyData.dTransferBarThick = m_dBarThick;

            RMGUIData.StrategyData.dTransferBarThick = m_dBarThick;
        }

        RMGUIData.StrategyData = m_RmAllCalcData.StrategyData;

        theApp.m_pGUIComm->SetRMData(&RMGUIData);

        m_pCurPceData->nRoughRollSchedStatus = ERR_SUCCESS;
    }
    else
    {
        HRS_RM_ALL_OUT_DATA pAllOutData;
        HRS_RM_SCHED RMSched;

        //    m_RmAllCalcData.PlanData.dDischargeTemp = m_dExtTemp;
        m_RmAllCalcData.StrategyData.dExtTemp          = m_dExtTemp;

        //    m_RmAllCalcData.PlanData.dTransferBarGauge = m_dBarThick;
        m_RmAllCalcData.StrategyData.dTransferBarThick = m_dBarThick;

        nRet = HRS_RML2Calc_CalcAllData(&m_RmAllCalcData, &pAllOutData);
        if (nRet == ERR_FAILED)
        {
            char szMsg[2048];
            sprintf(szMsg, " %s\r\n������̼������!", m_RmAllCalcData.szOutErr);
            AfxMessageBox(szMsg);
            return;
        }


        // ����PCE DATA
        m_pCurPceData->stRoughRollStra.nIsHaveData       = 1;
        m_pCurPceData->stRoughRollStra.fRm_Exit_Thick    = m_dBarThick;

        HRS_ROUGHROLL_STRA_DATA   *pRMStraData;
        HRS_ROUGHROLL_STRA        *pRMStra;
        pRMStraData = &(m_pCurPceData->stRMStraData);

        int nCurModeIndex = pRMStraData->nCurPassModeIndex;
        pRMStra = &(pRMStraData->aAllPassModeStra[nCurModeIndex]);

        pRMStra->nIsHaveData    = 1;
        pRMStra->fRm_Exit_Thick = m_dBarThick;

        int nIndex = pAllOutData.Rm2ndOutData.nTotalPassNum - 1;

        double dExitTemp = pAllOutData.Rm2ndOutData.adTempPair[nIndex].dDeliveryTemp;
        m_pCurPceData->stRoughRollStra.fRMExitTemp 
            = dExitTemp;

        pRMStra->fRMExitTemp = dExitTemp;
        pRMStra->fDischargeTemp = m_dExtTemp;

        nRet = HRS_RML2Calc_BuildSched(&m_RmAllCalcData, &pAllOutData, &RMSched);
        if (nRet == ERR_FAILED)
        {
            AfxMessageBox("���ɴ�����̴���!");
            return;
        }

        nRet = PceData_SetRmSchedCalcFromCalc(m_pCurPceData, &RMSched, 
            &m_AllStandPara);
        if (nRet == ERR_FAILED)
        {
            AfxMessageBox("�������ô�����̴���!");
            return;
        }

        m_pCurPceData->stRealRoughRollSched = RMSched;

        m_pCurPceData->nRoughRollStraStatus = ERR_SUCCESS;

        RefreshRoughRollSchedGrid();

        SavePceData();

        m_pCurPceData->nRoughRollSchedStatus = ERR_SUCCESS;

        AfxMessageBox("������̼���ɹ�!");

        SaveRMStraDataToCurPce();
    }


    int nPos = m_GridRoughRollPDI.GetScrollPos(SB_VERT);

    // ˢ��PDI����
    RefreshRollPDIGrid();

    m_GridRoughRollPDI.SetScrollPos(SB_VERT, nPos);

    m_GridRoughRollPDI.SetSelectedRange(cell_range.GetMinRow(), 
                                        cell_range.GetMinCol(),
                                        cell_range.GetMaxRow(), 
                                        cell_range.GetMaxCol(), TRUE);

    return;
}


void CViewRoughRollStra::SetRollSchedMgr(CPceDataMgr * pRollSchedMgr) 
{
    m_pRollSchedMgr = pRollSchedMgr;


    InitComboxStripNo();

    // move
    RefreshRollPDIGrid();

    RefreshRoughRollStraGrid();

    // ��PDI����ѡ�е�1��
    m_GridRoughRollPDI.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

    m_GridRoughRollPDI.ScrollToRow(theApp.m_nPDIRow);

    if ( m_pCurPceData != NULL )
    {
        if ( m_pCurPceData->nRoughRollSchedStatus == ERR_SUCCESS )
        {
            m_dBarThick = m_pCurPceData->stRoughRollSched.dTransferBarGauge;
        }
        else
        {
            m_dBarThick = m_pCurPceData->stRoughRollStra.fRm_Exit_Thick;
        }
    }

    return;
}



void CViewRoughRollStra::SetRMSched(HRS_RM_SCHED &RMSched)
{
    int nRet = -1;

    if (RMSched.nRet == ERR_FAILED)
    {
        AfxMessageBox(RMSched.szOutErr);
        AfxMessageBox("������̼���ʧ��!");
        return;
    }

    if ( RMSched.szOutErr[0] != '\0' )
    {
        if (stricmp(RMSched.szOutErr, HRS_SUCCESS_STR) != 0)
        {
            AfxMessageBox(RMSched.szOutErr);
            AfxMessageBox("������̼���ʧ��!");
            return;
        }
    }

    nRet = PceData_SetRmSchedCalcFromCalc(m_pCurPceData, &RMSched, &m_AllStandPara);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������ô�����̴���!");
        return;
    }

    m_pCurPceData->nRoughRollSchedStatus = nRet;

    m_pCurPceData->stRealRoughRollSched = RMSched;

    nRet = m_pRollSchedMgr->SetSteelStatus(m_pCurPceData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�����������ô���!");
        return;
    }

    int nPos = m_GridRoughRollPDI.GetScrollPos(SB_VERT);

    // ˢ��PDI����
    RefreshRollPDIGrid();

    m_GridRoughRollPDI.SetScrollPos(SB_VERT, nPos);


    RefreshRoughRollSchedGrid();

    SavePceData();

    m_GridRoughRollPDI.SetSelectedRange(theApp.m_nPDIRow, 1, 
        theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);


    m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarThick 
                         = m_pCurPceData->stRoughRollSched.dTransferBarGauge;

    int nIndex = m_pCurPceData->stRMStraData.nCurPassModeIndex;
    m_pCurPceData->stRMStraData.aAllPassModeStra[nIndex].fDischargeTemp = m_dExtTemp;

    AfxMessageBox("������̼���ɹ�!");

    return;
}


void CViewRoughRollStra::SaveRMStraDataToCurPce()
{
    HRS_ROUGHROLL_STRA   *pRMStraData;

    UpdateData(TRUE);

    if (m_pCurPceData == NULL )
    {
        return;
    }

    pRMStraData = &(m_pCurPceData->stRoughRollStra);

    // 
    pRMStraData->bRm_Exit_Thick_Auto = (bool)m_bCheckRmExitThick;
    pRMStraData->bStand_Dummy_E1     = (bool)m_bCheckStandDummyE1;
    pRMStraData->bStand_Dummy_E2     = (bool)m_bCheckStandDummyE2;
    pRMStraData->bStand_Dummy_R1     = (bool)m_bCheckStandDummyR1;

    pRMStraData->emPassMode     = HRS_GetPassModeByIndex(m_BPassMode);

    if (m_bCheckRmExitThick)
    {
        pRMStraData->fRm_Exit_Thick = m_pCurPceData->stRollSched.fR_H;
    }
    else
    {
        pRMStraData->fRm_Exit_Thick = m_dBarThick;
    }

    m_pCurPceData->stFinishRollStra.FinishRollStraData.fBarThick 
            = m_pCurPceData->stRoughRollSched.dTransferBarGauge;

//    pRMStraData->fRMExitTemp    = m_dExtTemp;  // ֮ǰ�Ѿ���ֵ����

    int nR1PassNum = pRMStraData->emPassMode / 10;
    int nR2PassNum = pRMStraData->emPassMode % 10;

    int nRow = nR1PassNum + nR2PassNum + 1;

    CString strWidth = m_GridRoughRollStra.GetItemText(nRow, 5);
    CString strTest = m_GridRoughRollStra.GetItemText(2, 1);

    pRMStraData->fRMExitWidth   = atof(strWidth);
    pRMStraData->nIsHaveData    = 1;

    HRS_RM_DRAFT_RATIO_STRA  *pDraftStra;

    pDraftStra = &(pRMStraData->stDraftRatioStra);

    HRS_STEEL_LEVEL *pSteelLevel = &(m_RmAllCalcData.SteelLevel);

    HRS_TABLE_RM_DRAFTRATIO *pRmDraftTab = pDraftStra->aRmDraftTab;

    for (int i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        pRmDraftTab[i].nSteelGradeCode = pSteelLevel->nSteelGradeCode;;
        pRmDraftTab[i].nSlabGaugeLevel = pSteelLevel->nSlabGaugeLevel;
        pRmDraftTab[i].nSlabWidthLevel = pSteelLevel->nSlabWidthLevel;
        pRmDraftTab[i].nBarGaugeLevel  = pSteelLevel->nTargetGaugeLevel;
        pRmDraftTab[i].nRMWidthLevel   = pSteelLevel->nRMWidthLevel;
        //        pRmDraftTab[i].nFinalTempLevel = SteelLevel->nFinalTempLevel;

    }

    char szOutErr[1024];
    
    szOutErr[0] = '\0';

    int nRet = HRS_RmDraftRatioTab_SearchMulti(pRmDraftTab, 
                                               HRS_RM_DRAFT_NUM_MAX, szOutErr);

    if ( nRet == ERR_FAILED )
    {
        AfxMessageBox(szOutErr);
        return;
    }
 
    return;
}


int CViewRoughRollStra::LoadDraftRationFromCurPce()
{
    if ( m_pCurPceData == NULL )
    {
        return ERR_FAILED;
    }

    HRS_RM_DRAFT_RATIO_STRA *pDraftStraData;
    pDraftStraData = &(m_pCurPceData->stRoughRollStra.stDraftRatioStra);

    memcpy(m_RmDraftTab, pDraftStraData->aRmDraftTab, sizeof(m_RmDraftTab));

    return ERR_SUCCESS;
}

#if 0
int CViewRoughRollStra::ReadPassDataStra(int nPassMode)
{
    if (m_pCurPceData == NULL)
    {
        return ERR_FAILED;
    }

    HRS_RM_DRAFT_RATIO_STRA *pDraftStra;

    pDraftStra = &(m_pCurPceData->stRoughRollStra.stDraftRatioStra);

    int nFind = -1;

    int i;

    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )
    {
        if (pDraftStra->aRmDraftTab[i].nPassMode == nPassMode)
        {
            nFind = i;
            break;
        }
    }

    if ( nFind < 0 )
    {
        nFind = 0;
    }

    HRS_TABLE_RM_DRAFTRATIO *pDraftTable = &(pDraftStra->aRmDraftTab[nFind]);


    HRS_ROUGHROLL_STRA_PASS             *pRMPass;
    
    pRMPass       = &(m_pCurPceData->stRoughRollStra.stRoughRollStraR1);

    // ��ѹ�������鸳ֵ
    pRMPass->[0] = pDraftTable->dLoadValueR21;
    pRMPass->adPassDraftRatio[1] = pDraftTable->dLoadValueR22;
    pRMPass->adPassDraftRatio[2] = pDraftTable->dLoadValueR23;
    pRMPass->adPassDraftRatio[3] = pDraftTable->dLoadValueR24;
    pRMPass->adPassDraftRatio[4] = pDraftTable->dLoadValueR25;
    pRMPass->adPassDraftRatio[5] = pDraftTable->dLoadValueR26;
    pRMPass->adPassDraftRatio[6] = pDraftTable->dLoadValueR27;

}
#endif

void CViewRoughRollStra::OnBnClickedRmClearSet()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    // �����ǰ���η���ģʽ�е�����ֵ���ָ���ԭʼֵ
    if (m_pCurPceData == NULL)
    {
        return;
    }

    PceData_ClearStraDataCor(m_pCurPceData);

    HRS_ROUGHROLL_STRA_DATA   *pRMStraData;
    HRS_ROUGHROLL_STRA        *pRMStra;
    pRMStraData = &(m_pCurPceData->stRMStraData);

    int nCurModeIndex = pRMStraData->nCurPassModeIndex;
    pRMStra = &(pRMStraData->aAllPassModeStra[nCurModeIndex]);


    m_dBarThick = pRMStra->fRm_Exit_Thick;
    m_dExtTemp  = pRMStra->fDischargeTemp;

    UpdateData(FALSE);

    CalcRMStraData();

    RefreshRoughRollStraGrid();

    return;
}

void CViewRoughRollStra::OnBnClickedCheckRemote()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    UpdateData(TRUE);

}
