// ViewNavig.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "NG_Time.h"
#include "HRSGui.h"
#include "ViewNavig.h"

#include "InterfaceStruct.h"


/*
 *  ������ɫ�궨��
 */

//  ������ɫ����
#define RED_COR             RGB(255, 0  , 0  )   /* ��ɫ                     */
#define GREEN_COR           RGB(0  , 255, 0  )   /* ��ɫ                     */
#define BLUE_COR            RGB(0  , 0  , 255)   /* ��ɫ                     */

#define WHITE_COR           RGB(255, 255, 255)   /* ��ɫ                     */
#define BLACK_COR           RGB(0  , 0  , 0  )   /* ��ɫ                     */
#define BLUE_GREEN_COR      RGB(0  , 255, 255)   /* ����ɫ                   */

//  �ؼ���ɫ����
#define IF_BG_COR           RGB(150, 175, 207)   /* ���汳��ɫ               */
#define BUTN_TEXT_COR       RGB(0  , 0  , 0  )   /* ��ť�ı���ɫ             */
#define BUTN_BG_COR         RGB(238, 233, 233)   /* ��ť������ɫ             */

//#define EDIT_TEXT_COR     RGB(255, 255, 255)   /* �ɱ༭�ı���ɫ           */
//#define EDIT_BG_COR       RGB(0  , 0  , 255)   /* �ɱ༭������ɫ           */
#define EDIT_TEXT_COR       RGB(0  , 0  , 255)   /* �ɱ༭�ı���ɫ           */
#define EDIT_BG_COR         RGB(250, 250, 250)   /* �ɱ༭������ɫ           */

#define STAC_TEXT_COR       RGB(0  , 0  , 0  )   /* ��̬�ı�������ɫ         */
#define STAC_BG_COR         RGB(238, 233, 233)   /* ��̬�ı�������ɫ         */

//  ����ؼ���ɫ����
#define GRID_BG_COR         RGB(255, 255, 224)   /* ����ɫ                 */
#define CUR_PASS_BG_COR     RGB(0  , 255, 255)   /* ��ǰ���α���ɫ           */
#define TURN_PASS_BG_COR    RGB(255, 255, 0  )   /* ת�ֵ��α���ɫ           */
#define WAIT_PASS_BG_COR    RGB(128, 255, 0  )   /* �������µ��α���ɫ       */

//  ����״̬��ɫ���
#define FUR_CHARGE_COR      RGB(0  , 0  , 236)   /* ��¯����ɫ               */
#define FUR_DISCHARGE_COR   RGB(23 , 23 , 23 )   /* ��¯����ɫ               */
#define FUR_RECHARGE_COR    RGB(192, 162, 99 )   /* ��¯����ɫ               */
#define FUR_REVOKE_COR      RGB(206, 74 , 217)   /* ���ϣ�ź��ɫ             */
#define TOTAL_COR           RGB(102, 13 , 183)   /* �ܼƣ���ɫ               */
#define OTHER_COR           RGB(72 , 145, 145)   /* ������ī��               */

//  ������Ϣ��ɫ���
#define SERIOUS_FAULT_COR   RGB(238, 44 , 44 )   /* ���ع���                 */
#define COMMON_FAULT_COR    RGB(255, 173, 14 )   /* ��ͨ����                 */
#define WARNING_COR         RGB(191, 62 , 255)   /* ����                     */
#define SUGGESTION_COR      RGB(87 , 12 , 156)   /* ��ʾ                     */



// CViewNavig

IMPLEMENT_DYNCREATE(CViewNavig, CFormView)

CViewNavig::CViewNavig()
    : CFormView(CViewNavig::IDD)
    , m_strCurTime(_T(""))
    , m_strCurState(_T(""))
{

}

CViewNavig::~CViewNavig()
{
     /*
     *  �ͷŻ�ˢ
     */
    m_CBrushDlgBG.DeleteObject();
    m_CBrushEditBG.DeleteObject();
}

void CViewNavig::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_BUT_ROLL_SCHEM,  m_butRollSchem);
    DDX_Control(pDX, IDC_BUT_ROUGHROLL_CALC,  m_butRoughRollStra);
    //DDX_Control(pDX, IDC_BUT_ROUGHROLL_SCHED,  m_butRoughRollSched);
    DDX_Control(pDX, IDC_BUT_ROUGHROLL_SCHEM3,  m_butFinishRollStra);
    /*   DDX_Control(pDX, IDC_BUT_ROUGHROLL_SCHEM4,  m_butFinishRollSched);*/
    DDX_Control(pDX, IDC_BUT_ROUGHROLL_SCHEM5,  m_butGhostRoll);
    DDX_Control(pDX, IDC_BUT_ROLLER_DATA,  m_butRollerData);

    DDX_Control(pDX, IDC_BUT_NAVIG_EXIT,  m_butExit);
    DDX_Text(pDX, IDC_STAC_TIME, m_strCurTime);
    DDX_Text(pDX, IDC_CURRENT_STATE, m_strCurState);
}

BEGIN_MESSAGE_MAP(CViewNavig, CFormView)
    ON_WM_CTLCOLOR()

    ON_BN_CLICKED(IDC_BUT_ROLL_SCHEM,  &CViewNavig::OnBnClickedButRollSchem)
    ON_BN_CLICKED(IDC_BUT_ROUGHROLL_CALC,  &CViewNavig::OnBnClickedButRoughRollSchem)
    //ON_BN_CLICKED(IDC_BUT_ROUGHROLL_SCHED, &CViewNavig::OnBnClickedButRoughrollSched)
    ON_BN_CLICKED(IDC_BUT_ROUGHROLL_SCHEM3, &CViewNavig::OnBnClickedButFinishRoll)
    //ON_BN_CLICKED(IDC_BUT_ROUGHROLL_SCHEM4, &CViewNavig::OnBnClickedButRoughrollSchem4)
    ON_BN_CLICKED(IDC_BUT_ROUGHROLL_SCHEM5, &CViewNavig::OnBnClickedButGhostRoll)
    ON_BN_CLICKED(IDC_BUT_ROLLER_DATA, &CViewNavig::OnBnClickedButRollerData)
    ON_BN_CLICKED(IDC_BUT_NAVIG_EXIT, &CViewNavig::OnBnClickedButNavigExit)
    ON_WM_TIMER()
    ON_STN_CLICKED(IDC_CURRENT_USER, &CViewNavig::OnStnClickedCurrentUser)
END_MESSAGE_MAP()


// CViewNavig ���

#ifdef _DEBUG
void CViewNavig::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewNavig::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewNavig ��Ϣ��������


void CViewNavig::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���
    
    GetParentFrame()->RecalcLayout();
    ResizeParentToFit();

    /*
     *  ��ʼ�����滭ˢ
     */
    m_CBrushDlgBG.CreateSolidBrush(IF_BG_COR);
    m_CBrushEditBG.CreateSolidBrush(EDIT_BG_COR);

    m_butRollSchem._SetFont(22, true);
    m_butRoughRollStra._SetFont(22, true);
    //m_butRoughRollSched._SetFont(22, true);
    m_butFinishRollStra._SetFont(22, true);
    /*m_butFinishRollSched._SetFont(22, true);*/
    m_butGhostRoll._SetFont(22, true);
    m_butRollerData._SetFont(22, true);
    m_butExit._SetFont(22, true);

    m_butRollSchem.EnableWindow(FALSE);
    m_iCurViewId = IDC_BUT_ROLL_SCHEM;

    SetTimer(0, 1000, NULL);
}


/*****************************************************************************/
/*                     CFormViewNavig::OnCtlColor ʵ��                       */
/*****************************************************************************/
/*
@fn OnCtlColor
@brief
    ���ÿؼ�����ɫ
@return
    ��
@*/
HBRUSH CViewNavig::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
    /*
     *  ����ؼ�������ɫ��ˢ
     */
    HBRUSH hbr = CFormView::OnCtlColor(pDC, pWnd, nCtlColor);

    /* 
     *  ���ݿؼ��������ÿؼ���ɫ
     */
    switch (nCtlColor)
    {
        case (CTLCOLOR_STATIC):
        {
            pDC->SetTextColor(STAC_TEXT_COR);
            pDC->SetBkColor(STAC_BG_COR);
            pDC->SetBkMode(TRANSPARENT);
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        case (CTLCOLOR_EDIT):
        {
            pDC->SetTextColor(EDIT_TEXT_COR);
            pDC->SetBkColor(EDIT_BG_COR);
            return (HBRUSH)m_CBrushEditBG.m_hObject;
        }
        case (CTLCOLOR_BTN):
        {
            pDC->SetBkColor(BUTN_BG_COR);
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        case (CTLCOLOR_DLG):
        {
            return (HBRUSH)m_CBrushDlgBG.m_hObject;
        }
        default:
            break;
    }

    /*
     *  ���ر���ɫ
     */
    return hbr;
}


/*****************************************************************************/
/*                 CFormViewNavig::OnBnClickedButMonit ʵ��                  */
/*****************************************************************************/
/*
@fn OnBnClickedButMonit
@brief
    �����̼�ء���ť��Ӧ����
@return
    ��
@*/
void CViewNavig::OnBnClickedButRollSchem()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }

    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_ROLLSCHEM);
    //_SetButtonEnable(m_iCurViewId);
    //_SetButtonDisable(IDC_BUT_ROLL_SCHEM);
    //m_iCurViewId = IDC_BUT_ROLL_SCHEM;

    return;
}

/*****************************************************************************/
/*                 CFormViewNavig::OnBnClickedButMonit ʵ��                  */
/*****************************************************************************/
/*
@fn OnBnClickedButMonit
@brief
    �����̼�ء���ť��Ӧ����
@return
    ��
@*/
void CViewNavig::OnBnClickedButRoughRollSchem()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_ROUGHROLLSCHEM);
    //_SetButtonEnable(m_iCurViewId);
    //_SetButtonDisable(IDC_BUT_ROUGHROLL_SCHEM);
    //m_iCurViewId = IDC_BUT_ROUGHROLL_SCHEM;

    return;
}


/*****************************************************************************/
/*                 CFormViewNavig::_SendMessageToFrm ʵ��                    */
/*****************************************************************************/
/*
@fn _SendMessageToFrm
@brief
    ���ܷ�����Ϣ
@return
    ��
@*/
bool CViewNavig::_SendMessageToFrm(int iMesId,
                                       WPARAM wParam,
                                       LPARAM lParam)
{
    this->GetParentFrame()->SendMessage(iMesId, wParam, lParam);

    return true;
}

//void CViewNavig::OnBnClickedButRoughrollSched()
//{
//    // TODO: �ڴ����ӿؼ�֪ͨ�����������
//
//    // TODO: �ڴ����ӿؼ�֪ͨ�����������
//    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_ROUGHROLL_SCHED);
//     //_SetButtonEnable(m_iCurViewId);
//     //_SetButtonDisable(IDD_VIEW_ROUGHROLL_SCHED);
//     //m_iCurViewId = IDD_VIEW_ROUGHROLL_SCHED;
//}

void CViewNavig::OnBnClickedButFinishRoll()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }
    
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_FINISHROLL_STRA);
     //_SetButtonEnable(m_iCurViewId);
     //_SetButtonDisable(IDD_VIEW_FINISHROLL_STRA);
     //m_iCurViewId = IDD_VIEW_FINISHROLL_STRA;
}

//void CViewNavig::OnBnClickedButRoughrollSchem4()
//{
//    // TODO: �ڴ����ӿؼ�֪ͨ�����������
//
//    // TODO: �ڴ����ӿؼ�֪ͨ�����������
//    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_FM_SCHED);
//     //_SetButtonEnable(m_iCurViewId);
//     //_SetButtonDisable(IDD_VIEW_FM_SCHED);
//     //m_iCurViewId = IDD_VIEW_FM_SCHED;
//}

void CViewNavig::OnBnClickedButGhostRoll()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_GHOSTROLL);
     //_SetButtonEnable(m_iCurViewId);
     //_SetButtonDisable(IDD_VIEW_GHOSTROLL);
     //m_iCurViewId = IDD_VIEW_GHOSTROLL;
}

void CViewNavig::OnBnClickedButRollerData()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }
    _SendMessageToFrm(NM_VIEW_CHANGE, IDD_VIEW_ROLLER_DATA);
}


void CViewNavig::OnBnClickedButNavigExit()
{
    if (ERR_SUCCESS == theApp.m_nRolling)
    {
        AfxMessageBox("������������,�����л���Ч��");
        return;
    }

    if (ERR_SUCCESS == theApp.m_nAverageing)
    {
        AfxMessageBox("���ھ����������,�����л���Ч��");
        return;
    }

    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    _SendMessageToFrm(NM_VIEW_CHANGE, IDC_BUT_NAVIG_EXIT);
     //_SetButtonEnable(m_iCurViewId);
     //_SetButtonDisable(IDC_BUT_NAVIG_EXIT);
     //m_iCurViewId = IDC_BUT_NAVIG_EXIT;

    theApp.m_pGUIComm->MTaskSetExitFlag();

}

#if 0

bool CViewNavig::_SetButtonEnable(int iViewId)
{
    bool    bOK(true);                  //  ��ǲ����ɹ�

    /*
     *  ���ݵ�ǰ��ͼID�����ö�Ӧ��ť����
     */
    switch (iViewId)
    {
        case (IDC_BUT_ROLL_SCHEM):
        {
            m_butRollSchem.EnableWindow(TRUE);
            break;
        }
        case (IDC_BUT_ROUGHROLL_SCHEM):
        {
            m_butRoughRollStra.EnableWindow(TRUE);
            break;
        }
        /*case (IDD_VIEW_ROUGHROLL_SCHED):
        {
            m_butRoughRollSched.EnableWindow(TRUE);
            break;
        }*/
        case (IDD_VIEW_FINISHROLL_STRA):
        {
            m_butFinishRollStra.EnableWindow(TRUE);
            break;
        }
        /*case (IDD_VIEW_FM_SCHED):
        {
            m_butFinishRollSched.EnableWindow(TRUE);
            break;
        }*/
        case (IDD_VIEW_GHOSTROLL):
        {
            m_butGhostRoll.EnableWindow(TRUE);
            break;
        }
        default :
        {
            bOK = false;
            break;
        }
    }

    return bOK;
}


bool CViewNavig::_SetButtonDisable(int iViewId)
{
    bool    bOK(true);                  //  ��ǲ����ɹ�

    /*
     *  ���ݵ�ǰ��ͼID�����ö�Ӧ��ť����
     */
    switch (iViewId)
    {
        case (IDC_BUT_ROLL_SCHEM):
            {
                m_butRollSchem.EnableWindow(FALSE);
                break;
            }
        case (IDC_BUT_ROUGHROLL_SCHEM):
            {
                m_butRoughRollStra.EnableWindow(FALSE);
                break;
            }
        /*case (IDD_VIEW_ROUGHROLL_SCHED):
            {
                m_butRoughRollSched.EnableWindow(FALSE);
                break;
            }*/
        case (IDD_VIEW_FINISHROLL_STRA):
            {
                m_butFinishRollStra.EnableWindow(FALSE);
                break;
            }
        /*case (IDD_VIEW_FM_SCHED):
            {
                m_butFinishRollSched.EnableWindow(FALSE);
                break;
            }*/
        case (IDD_VIEW_GHOSTROLL):
            {
                m_butGhostRoll.EnableWindow(FALSE);
                break;
            }
        default :
            {
                bOK = false;
                break;
            }
    }

    return bOK;
}

#endif

bool CViewNavig::_SetButtonState(int iViewId)
{
    bool    bOK(true);                  //  ��ǲ����ɹ�

    /*
     *  ���ݵ�ǰ��ͼID�����ö�Ӧ��ť����
     */
    switch (iViewId)
    {
        case (IDD_VIEW_ROLLSCHEM):
            {
                m_butRollSchem.EnableWindow(FALSE);
                m_butRoughRollStra.EnableWindow(TRUE);
                /*m_butRoughRollSched.EnableWindow(TRUE);*/
                m_butFinishRollStra.EnableWindow(TRUE);
                /*m_butFinishRollSched.EnableWindow(TRUE);*/
                m_butGhostRoll.EnableWindow(TRUE);
                m_butRollerData.EnableWindow(TRUE);
                break;
            }
        case (IDD_VIEW_ROUGHROLLSCHEM):
            {
                m_butRollSchem.EnableWindow(TRUE);
                m_butRoughRollStra.EnableWindow(FALSE);
                /*m_butRoughRollSched.EnableWindow(TRUE);*/
                m_butFinishRollStra.EnableWindow(TRUE);
                /*m_butFinishRollSched.EnableWindow(TRUE);*/
                m_butGhostRoll.EnableWindow(TRUE);
                m_butRollerData.EnableWindow(TRUE);

                break;
            }
        //case (IDD_VIEW_ROUGHROLL_SCHED):
        //    {
        //        m_butRollSchem.EnableWindow(TRUE);
        //        m_butRoughRollStra.EnableWindow(TRUE);
        //        /*m_butRoughRollSched.EnableWindow(FALSE);*/
        //        m_butFinishRollStra.EnableWindow(TRUE);
        //       /* m_butFinishRollSched.EnableWindow(TRUE);*/
        //        m_butGhostRoll.EnableWindow(TRUE);
        //        break;
        //    }
        case (IDD_VIEW_FINISHROLL_STRA):
            {
                m_butRollSchem.EnableWindow(TRUE);
                m_butRoughRollStra.EnableWindow(TRUE);
                /*m_butRoughRollSched.EnableWindow(TRUE);*/
                m_butFinishRollStra.EnableWindow(FALSE);
                /*m_butFinishRollSched.EnableWindow(TRUE);*/
                m_butGhostRoll.EnableWindow(TRUE);
                m_butRollerData.EnableWindow(TRUE);

                break;
            }
        //case (IDD_VIEW_FM_SCHED):
        //    {
        //        m_butRollSchem.EnableWindow(TRUE);
        //        m_butRoughRollStra.EnableWindow(TRUE);
        //        /*m_butRoughRollSched.EnableWindow(TRUE);*/
        //        m_butFinishRollStra.EnableWindow(TRUE);
        //        /*m_butFinishRollSched.EnableWindow(FALSE);*/
        //        m_butGhostRoll.EnableWindow(TRUE);
        //        break;
        //    }
        case (IDD_VIEW_GHOSTROLL):
            {
                m_butRollSchem.EnableWindow(TRUE);
                m_butRoughRollStra.EnableWindow(TRUE);
                /*m_butRoughRollSched.EnableWindow(TRUE);*/
                m_butFinishRollStra.EnableWindow(TRUE);
                /*m_butFinishRollSched.EnableWindow(TRUE);*/
                m_butGhostRoll.EnableWindow(FALSE);
                m_butRollerData.EnableWindow(TRUE);

                break;
            }
        case (IDD_VIEW_ROLLER_DATA):
            {
                m_butRollSchem.EnableWindow(TRUE);
                m_butRoughRollStra.EnableWindow(TRUE);
                /*m_butRoughRollSched.EnableWindow(TRUE);*/
                m_butFinishRollStra.EnableWindow(TRUE);
                /*m_butFinishRollSched.EnableWindow(TRUE);*/
                m_butGhostRoll.EnableWindow(TRUE);
                m_butRollerData.EnableWindow(FALSE);

                break;
            }
        default :
            {
                bOK = false;
                break;
            }
    }

    return bOK;
}


void CViewNavig::OnTimer(UINT_PTR nIDEvent)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
    NG_TIME  ng_time;
    char     szTime[128];

    NGTime_GetLocalTimeMs(&ng_time);

    memset(szTime, 0, sizeof(szTime));

    NGTime_ToSecondStr(&ng_time, NULL, szTime, sizeof(szTime)-1);

    m_strCurTime = _T(szTime);


    // ��ʾͨ��״̬(GUI)
    char szComState[1024];
    int nCommState = theApp.m_pGUIComm->GetCommState();
    if ( nCommState == ERR_SUCCESS )
    {
        strcpy(szComState, "ͨ��״̬��\r\nService-GUI\r\n ON\r\n\r\n");
    }
    else
    {
        strcpy(szComState, "ͨ��״̬��\r\nService-GUI\r\n OFF\r\n\r\n");
    }

    m_strCurState = _T(szComState);

    // ��ʾͨ��״̬(L1)
    memset(szComState, 0, 1024);
    if ( ERR_SUCCESS == nCommState && theApp.m_nServiceL1State == ERR_SUCCESS )
    {
        strcpy(szComState, "Service-L1Sim\r\n ON\r\n\r\n");
    }
    else
    {
        strcpy(szComState, "Service-L1Sim\r\n OFF\r\n\r\n");
    }

    m_strCurState += _T(szComState);

    // ��ʾͨ��״̬(VR)
    memset(szComState, 0, 1024);
    if ( ERR_SUCCESS == nCommState && theApp.m_nServiceVRState == ERR_SUCCESS )
    {
        strcpy(szComState, "Service-VR\r\n ON\r\n\r\n");
    }
    else
    {
        strcpy(szComState, "Service-VR\r\n OFF\r\n\r\n");
    }

    m_strCurState += _T(szComState);

    UpdateData(FALSE);

    CFormView::OnTimer(nIDEvent);
}


void CViewNavig::OnStnClickedCurrentUser()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
}
