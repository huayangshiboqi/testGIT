// ViewTitle.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewTitle.h"
#include "InterfaceMacro.h"

// CViewTitle

IMPLEMENT_DYNCREATE(CViewTitle, CFormView)

CViewTitle::CViewTitle()
	: CFormView(CViewTitle::IDD)
{

}

CViewTitle::~CViewTitle()
{
}

void CViewTitle::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_STEEL, m_RwStatic);

    m_RwStatic._vSetPos(50, 101, 30, 5);
    //m_RwStatic._vSetBkColor(RED_COR);
}

BEGIN_MESSAGE_MAP(CViewTitle, CFormView)
    ON_STN_CLICKED(IDC_STEEL, &CViewTitle::OnStnClickedSteel)
END_MESSAGE_MAP()


// CViewTitle ���

#ifdef _DEBUG
void CViewTitle::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewTitle::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewTitle ��Ϣ��������

void CViewTitle::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GetDlgItem(IDC_TITLE_PART)->ShowWindow(SW_HIDE);

        m_RwStatic._vSetMaxData(1500);
    //m_RwStatic._vSetBkColor(RGB(0,0,180));
    
    return;
}


void  CViewTitle::SetSteelPos(int nXPos, int nWidth)
{

    //GetDlgItem(IDC_TITLE_PART)->ShowWindow(SW_NORMAL)

    m_RwStatic._vSetPos(nXPos, 101, nWidth, 5);

    return;
}


void  CViewTitle::ShowCoil()
{
    GetDlgItem(IDC_TITLE_PART)->ShowWindow(SW_NORMAL);

    return;
}


void  CViewTitle::HideCoil()
{
    GetDlgItem(IDC_TITLE_PART)->ShowWindow(SW_HIDE);

    return;
}
//
//
//int CViewTitle::GetPosScroll()
//{
//
//    return GetScrollPos();
//}


void CViewTitle::OnStnClickedSteel()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
}
