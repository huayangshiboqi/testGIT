
/* 
 *    FILE
 *      e:\svn_Company\RWPlatform\Include\DBProxy.h
 *
 *    DESCRIPTION
 *      �ͻ������ݷ��͸��������ģ��    
 *
 *    HISTORY
 *        2016-5-20 10:26 create by gaochunmei.
 *
 */

#ifndef __HRS_GUICOMM_H__
#define __HRS_GUICOMM_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "HRS_CalcData.h"
#include "HRS_Comm.h"
#include "HRS_Service_CommError.h"

#define HRS_CLIENT_COMM_CFG             "HRSClientComm.cfg"

class CHRSGUIComm
{
public:
    CHRSGUIComm();
    ~CHRSGUIComm();

    int GUICommCreate();

    //��������ҳ��ʹ��
    int SetVRRMData(HRS_RM_DATA_FROM_GUI *pRMData);
    int SetVRFMData(HRS_FM_DATA_FROM_GUI *pFMData);

    //int SetL1SimuRMData(HRS_RM_DATA_FROM_GUI *pRMData); //����L1��������
    int SetL1SimuFMData(HRS_L1_FM_SCHED *pFMData); //����L1��������
    int SetL1SimuRMData(HRS_L1_RM_SCHED *pRMData); //���� ����

    int SetRMData(HRS_RM_DATA_FROM_GUI *pRMData);
    int SetFMData(HRS_FM_DATA_FROM_GUI *pFMData);

    int GetRMSched(HRS_RM_SCHED &RMSched);
    int GetFMSched(HRS_FM_SCHED &FMSched);

    int GetL1AveData(HRS_L1_SIMULATE_ALL_AVEDATA &AveData);
    int GetSteelInfo(HRS_STEEL_INFO &SteelInfo);
    int GetServiceCommInfo(HRS_Service_CommError &ServiceCommState);

    int GetCommState();

    void GetStateMsg(char *pszMsg);

    void MTaskSetExitFlag();

private:

    int SendRMData(HRS_RM_DATA_FROM_GUI *pRMData);
    int SendFMData(HRS_FM_DATA_FROM_GUI *pFMData);

    int SendL1RMSchedData(HRS_L1_RM_SCHED *pRMData);
    int SendL1FMSchedData(HRS_L1_FM_SCHED *pFMData);


    HRS_COMM_INFO *m_pCommInfo;    // ͨ����Ϣ

    int            m_nCommState;   // ERR_FAILED, ERR_SUCCESS
};




#ifdef __cplusplus
}
#endif



#endif // __HRS_GUICOMM_H__
