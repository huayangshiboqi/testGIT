#pragma once


#include "ViewRight.h"
#include "RwStatic.h"


// CViewTitle ������ͼ

class CViewTitle : public CFormView
{
	DECLARE_DYNCREATE(CViewTitle)

protected:
	CViewTitle();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CViewTitle();

public:
	enum { IDD = IDD_VIEWTITLE };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    CRwStatic m_RwStatic;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnStnClickedTitle();
public:
    virtual void OnInitialUpdate();

    void  ShowCoil();
    void  HideCoil();

    //int   GetPosScroll();

    void SetSteelPos(int nXPos, int nWidth);
public:
    afx_msg void OnStnClickedSteel();
};


