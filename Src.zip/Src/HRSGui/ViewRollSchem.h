#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"


#define   ROLLSCHEM_TEST_PDIFILE          "TestSched.txt"

// CViewRollSchem ������ͼ

class CViewRollSchem : public CFormView
{
    DECLARE_DYNCREATE(CViewRollSchem)

protected:
    CViewRollSchem();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewRollSchem();

    CGridCtrl m_GridRollSchem;
    void GridCtrlInit();

    CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls

 
public:
    enum { IDD = IDD_VIEW_ROLLSCHEM };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif
 
protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    afx_msg void OnSize(UINT nType, int cx, int cy);    //  ���ÿؼ��ߴ�
    afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
    CBrush          m_CBrushDlgBG;              /* �Ի��򱳾��Ļ�ˢ          */
    CBrush          m_CBrushEditBG;             /* �ı��򱳾��Ļ�ˢ          */

    DECLARE_MESSAGE_MAP()

private:
    CString m_strSearchNo;
    CPceDataMgr *     m_pRollSchedMgr;
    CPceDataMgr **    m_pRollSchedMgrOrig;

    int               m_nInitPDIGrid;


    void SavePDIFile();

private:
    HRS_ROLL_SCHED * GetRollSchedFromGrid(int nRow);

public:
    afx_msg void OnBnClickedButSaveFile();
    afx_msg void OnBnClickedButScMoveup();
    afx_msg void OnBnClickedButScMovedown();
    afx_msg void OnBnClickedButScSearch();

    afx_msg void OnBnClickedButScImport();
    afx_msg void OnBnClickedButScExport();

    afx_msg void OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnGridClick(NMHDR *pNotifyStruct, LRESULT* pResult);

    virtual void OnInitialUpdate();
    afx_msg void OnBnClickedButScAdd();
    afx_msg void OnBnClickedButScDel();

    void RefeshRollSchemTab();
    int LoadPDIData();


    bool ExitConfirm(CPceDataMgr **m_pRollSchedMgrOrig);

    void SetRollSchedMgr(CPceDataMgr **pRollSchedMgr) 
    {
        if (NULL == *pRollSchedMgr)
        {
            return;
        }

        m_pRollSchedMgrOrig= pRollSchedMgr;

        m_pRollSchedMgr = *pRollSchedMgr;

        RefeshRollSchemTab();

        m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

        m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

        m_GridRollSchem.ScrollToRow(theApp.m_nPDIRow);

        UpdateData(FALSE);
    }

    void InitRollSchedMgr(CPceDataMgr *pRollSchedMgr)
    {
        if (NULL == pRollSchedMgr)
        {
            return;
        }

        m_pRollSchedMgrOrig= &pRollSchedMgr;

        m_pRollSchedMgr = pRollSchedMgr;

        LoadPDIData();

        RefeshRollSchemTab();

        m_GridRollSchem.SetFocusCell(theApp.m_nPDIRow, 0);

        m_GridRollSchem.SetSelectedRange(theApp.m_nPDIRow, 0, theApp.m_nPDIRow, HRS_ROLL_SCHED_ITEM_NUM-1);

        UpdateData(FALSE);
    }

    CPceDataMgr *  GetRollSchedMgr() 
    {
        return m_pRollSchedMgr;
    }

    int GetInitPDIGridState()
    {
        return m_nInitPDIGrid;
    }

    void SetetInitPDIGridState(int nInitPDIGrid)
    {
        m_nInitPDIGrid = nInitPDIGrid;
        return;
    }
};


