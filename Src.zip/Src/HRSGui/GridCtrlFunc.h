/** 
 *	FILE
 *      d:\SVN\HotContinuousRoll\Src\HRSGui
 *
 *	DESCRIPTION
 *      �����дģ������XXXXXX		
 *
 *	HISTORY
 *		2016-12-8 10:34 create by GAOCHUNMEI.
 *
 */
#ifndef __GridCtrlFunc_H__
#define __GridCtrlFunc_H__

#include "PceDataMgr.h"
#include "GridBtnCell.h"


#ifdef __cplusplus
extern "C" {
#endif


//int SetTextBGCor(CGridCtrl &GridRoughRollPDI, PCE_DATA *pPceData, int nRow, int nCol)
    int SetTextBGCor(CGridCtrl &GridRoughRollPDI, PCE_DATA *pPceData, int nRow, int nCol);


#ifdef __cplusplus
}
#endif



#endif // __GridCtrlFunc_H__
