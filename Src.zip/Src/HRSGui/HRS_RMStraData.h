
/** 
 *	FILE
 *      C:\svn_Company\HotContinuousRoll\Src\HRSGui
 *
 *	DESCRIPTION
 *      ������������		
 *
 *	HISTORY
 *		2017-1-11 11:36 create by zhouweiming.
 *
 */
#ifndef __HRS_RM_STRA_DATA_H__
#define __HRS_RM_STRA_DATA_H__

#include "NG.h"
#include "DArray.h"
#include "HRS_CalcData.h"
#include "HRS_CommonCalc.h"
#include "HRS_RmDraftRatioTable.h"

#ifdef __cplusplus
extern "C" {
#endif

#define         HRS_PASS_NO_LEN                     10
#define         HRS_ROUGHROLL_R1_PASS_MAX           3
#define         HRS_ROUGHROLL_R2_PASS_MAX           7

#define         HRS_ROUGHROLL_STRA_ITEM_NUM         10

/* 
 * �������Ե������������ݽṹ�嶨��
 */
typedef struct HRS_ROUGHROLL_STRA_PASS_st
{
    char            strPass_No[HRS_PASS_NO_LEN];    //���κ�
    float           fThick_Exit;                    //���ں��
    float           fThick_Cor;                     //���������
    float           fDraftValue;                    //ѹ����
    float           fDeltaDraftValue;               //ѹ������ƫ��
    float           fDraft;                         //ѹ����
    float           fDraftCor;                      //ѹ����������
    float           fWidth;                         //����
    float           fWidth_Cor;                     //����������
    float           fSpeed;                         //�ٶ�
    float           fSpeed_Cor;                     //�ٶ�������
    HRS_SPRAY_MODE_EM  emSprayMode;                 //���۷�ʽ     //��ĸ�֮

} HRS_ROUGHROLL_STRA_PASS;


typedef struct HRS_RM_DRAFT_RATIO_STRA_st {
    HRS_TABLE_RM_DRAFTRATIO aRmDraftTab[HRS_RM_DRAFT_NUM_MAX];
} HRS_RM_DRAFT_RATIO_STRA;


/* 
 * �����������ݽṹ�嶨��
 */
#define HRS_THICK_EXIT_NUM    HRS_ROUGHROLL_R1_PASS_MAX + HRS_ROUGHROLL_R2_PASS_MAX

typedef struct HRS_ROUGHROLL_STRRA_ST
{
    HRS_TABLE_RM_DRAFTRATIO     stDraftRatio;   // ѹ���ʲ�������
    HRS_RM_DRAFT_RATIO_STRA     stDraftRatioStra;
    HRS_ROUGHROLL_STRA_PASS     stHSB;
    HRS_ROUGHROLL_STRA_PASS     stRoughRollStraR1[HRS_ROUGHROLL_R1_PASS_MAX];
    HRS_ROUGHROLL_STRA_PASS     stRoughRollStraR2[HRS_ROUGHROLL_R2_PASS_MAX];

    float                   fRm_Exit_Thick;         //�м������      // sched
    bool                    bRm_Exit_Thick_Auto;

    float                   fDischargeTemp;         // ��¯�¶�
    float                   fRMExitTemp;            // ���������¶�
    int                     nIsHaveData;            // 0: ������ 1: ������

    float                   fRMExitWidth;           // �������ڿ���

    bool                    bStand_Dummy_E1;        //E1���ܿչ�
    bool                    bStand_Dummy_R1;        //R1���ܿչ�
    bool                    bStand_Dummy_E2;        //E2���ܿչ�

    HRS_PASS_MODE_EM           emPassMode;             //���η��䷽ʽ

    float                   fThickExit[HRS_THICK_EXIT_NUM]; //���ݸְ������ļ�����ĳ��ں��
    float                   fDraftValue[HRS_THICK_EXIT_NUM]; //���ݸְ������ļ������ѹ����

} HRS_ROUGHROLL_STRA;


typedef struct HRS_ROUGHROLL_STRA_DATA_st {
    int                   nCurPassModeIndex;

    int                   nOrgGetFlag;            // 0��ʾδ��ȡ��ԭʼ���ݣ�1��ʾ�ѻ�ȡ
    HRS_ROUGHROLL_STRA    aOrgStra[HRS_RM_DRAFT_NUM_MAX];     // ԭʼ��������
    HRS_ROUGHROLL_STRA    aAllPassModeStra[HRS_RM_DRAFT_NUM_MAX]; // �޸Ĺ��Ĳ�������
} HRS_ROUGHROLL_STRA_DATA;


void HRS_RMStraData_Init(HRS_ROUGHROLL_STRA_DATA *pRMStraData);

HRS_ROUGHROLL_STRA *HRS_RMStraData_GetCur(
                         HRS_ROUGHROLL_STRA_DATA *pRMStraData);

HRS_ROUGHROLL_STRA *HRS_RMStraData_GetOrg(
                         HRS_ROUGHROLL_STRA_DATA *pRMStraData);


int HRS_RMStraData_GetOrgStraData(HRS_RM_ALL_DATA *pAllData,
                                  HRS_ROUGHROLL_STRA_DATA *pRMStraData);

int HRS_RMStraData_CalcOnePassModeOrgGauge(HRS_RM_ALL_DATA *pAllData,
                                           HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                           int nPassModeIndex);

int HRS_RMStraData_CalcAllOrgGauge(HRS_RM_ALL_DATA *pAllData,
                                   HRS_ROUGHROLL_STRA_DATA *pRMStraData);


int HRS_RMStraData_CalcOnePassModeGauge(HRS_RM_ALL_DATA *pAllData,
                                        HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                        int nPassModeIndex);

int HRS_RMStraData_CalcAllGauge(HRS_RM_ALL_DATA *pAllData,
                              HRS_ROUGHROLL_STRA_DATA *pRMStraData);

int HRS_RMStraData_CalcOnePassModeSpeed(HRS_RM_ALL_DATA *pAllData,
                                        HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                        int nPassModeIndex);

int HRS_RMStraData_CalcAllSpeed(HRS_RM_ALL_DATA *pAllData,
                             HRS_ROUGHROLL_STRA_DATA *pRMStraData);

int HRS_RMStraData_InitOnePassModeSpeed(HRS_RM_ALL_DATA *pAllData,
                                        HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                        int nPassModeIndex);

int HRS_RMStraData_InitAllSpeed(HRS_RM_ALL_DATA *pAllData,
                                HRS_ROUGHROLL_STRA_DATA *pRMStraData);

#ifdef __cplusplus
}
#endif



#endif // __HRS_RM_STRA_DATA_H__
