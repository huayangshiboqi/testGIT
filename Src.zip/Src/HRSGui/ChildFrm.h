// ChildFrm.h : CChildFrame ��Ľӿ�
//


#pragma once

#include "PceDataMgr.h"

#include "ViewRight.h"

#include "ViewTitle.h"

#define HRS_TIMER_EVENT_ID          1

class CChildFrame : public CMDIChildWnd
{
    DECLARE_DYNCREATE(CChildFrame)
public:
    CChildFrame();

// ����
protected:
    CSplitterWnd m_wndSplitter;
    CSplitterWnd *m_pwndRightSplitter;


public:
    //CViewRight   *m_pRightView;
    CSplitterWnd m_wndRightSplitter;


// ����
public:

// ��д
    public:
    public:
    virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
    virtual ~CChildFrame();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

// ���ɵ���Ϣӳ�亯��
protected:
    DECLARE_MESSAGE_MAP()
    afx_msg void OnMDIActivate(BOOL bActivate, CWnd*, CWnd*);
    //  ��ͼ�л���Ϣ����
    afx_msg LRESULT _OnViewChange(WPARAM wParam,LPARAM lParam);
    virtual BOOL PreTranslateMessage(MSG* pMsg);

public:
    bool _SwitchRightView(int iViewId);     //  ������ͼID�л�����ͼ
    bool RefshView(int iViewId);            //  ������ͼIDˢ������ͼ
    virtual BOOL OnCreateRight(CCreateContext* pContext, UINT uID, int nWith, int nLenth);
                                                                   
private:
    int               m_nRightViewType;
    void              *m_pCViewData;
    CViewTitle        *m_pCViewTitle;

    bool              m_bState;
    HRS_STEEL_INFO    m_SteelInfo;
    CPceDataMgr       *m_pRollSchedMgr;

    int m_nTitleHeight;
    int m_nTitleWidth;

    int m_nRollEnd;
    int m_nRolling;

    int m_nXPos;

    int nTelTotalTime;//��ʱδ��Service���յ����ģ��ְ��˳�

    afx_msg void OnTimer(UINT_PTR nIDEvent);
};
