#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"


// CViewFinishRollSched ������ͼ

class CViewFinishRollSched : public CFormView
{
    DECLARE_DYNCREATE(CViewFinishRollSched)

protected:
    CViewFinishRollSched();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewFinishRollSched();

    CGridCtrl m_GridFinishRollPreCalcBasic;
    CGridCtrl m_GridFinishRollPreCalc;
    CGridCtrl m_GridFinishRollPDI;
    void GridCtrlInit();

    CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls

public:
    enum { IDD = IDD_VIEW_FM_SCHED };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()

public:
    virtual void OnInitialUpdate();
    afx_msg void OnGridFinishRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult);

    void SetRollSchedMgr(CPceDataMgr * pRollSchedMgr) 
    {
        m_pRollSchedMgr = pRollSchedMgr;
        InitGridPDI();
    }

private:
    CPceDataMgr *     m_pRollSchedMgr;
    PCE_DATA *          m_pCurPceData;

    void InitGridPDI();
    void RefreshFinishRollSchedGrid();
public:
    afx_msg void OnBnClickedButFmSchedcalc();
};


