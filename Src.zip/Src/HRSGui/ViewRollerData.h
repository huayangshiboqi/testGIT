#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"
#include "HRS_RollerData.h"
#include "afxwin.h"

#define ROLLER_DATA_FILE         "RollerData.cfg"

#define ROLLER_USE                      "USE"
#define ROLLER_UNUSE                    "UNUSE"

// ViewRollerData ������ͼ

class CViewRollerData : public CFormView
{
    DECLARE_DYNCREATE(CViewRollerData)

protected:
    CViewRollerData();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewRollerData();

    CGridCtrl m_GridRollerData;

    void GridCtrlInit();
    void RefreshRollerGrid();

    int CheckRollerDia(int nRow, double dRollerDia);

public:
    enum { IDD = IDD_VIEW_ROLLER_DATA };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()
private:
    CPceDataMgr *m_pRollerMgr;
    HRS_ROLLER_DATA_MGR *m_pRollerDataMgr;
    HRS_ROLLER_TOTAL_DATA_MGR *m_pTotalRollerMgr;
    CBtnDataBase m_BtnDataBase;

    BOOL m_bAddState;
    BOOL m_bDelState;

public:
    virtual void OnInitialUpdate();

    //void OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);

    HRS_ROLLER_DATA *SearchRollerNum(int nRow);
    int GetRollerPassFromGrid(int nRow);

    afx_msg void OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnBnClickedButScSave();
    afx_msg void OnBnClickedButScAdd();
    afx_msg void OnBnClickedButScDel();

    void SetRollSchedMgr(CPceDataMgr *pRollerMgr) 
    {
        m_pRollerMgr = pRollerMgr;

        RefreshRollerGrid();
    }
};


