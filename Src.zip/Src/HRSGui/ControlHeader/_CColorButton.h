/*****************************************************************************/
/*                                                                           */
/* ��Ŀ���� ��                                                           */
/* ��д��λ �� �Ϻ��ſؿƼ����޹�˾                                          */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ˵�� �� ����Ŀ�����ռ�����Դվ�㷢�͵����ݲ���ʾ�ʹ洢               */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/* ����˵�� �� ��ɫ��ť�ؼ�ͷ�ļ�                                            */
/*                                                                           */
/*****************************************************************************/
/* ��    �� �� ��Ҷ               ��������  ��2012-09-14                     */
/*****************************************************************************/
/*                                 �޸ļ�¼                                  */
/*                                                                           */
/* �޸����� ��2012-09-17        ** �� �� �� �� �� Ҷ                         */
/* �޸����� ��                                                               */
/*          1.��ʽ                                                           */
/*          2.���ӻ�ȡ��ɫ�Ƚӿ�                                             */
/*                                                                           */
/*****************************************************************************/
/* �� �� �� ��                  ** ������� ��                               */
/*****************************************************************************/
/* �ļ��汾�� ��1.0                                                          */
/*****************************************************************************/

#ifndef _COLORBUTTON_H
#define _COLORBUTTON_H

/*****************************************************************************/
/*                     _CColorButton ������                                   */
/*****************************************************************************/
/*
@category ��ť�� 
@*/
/*
@class _CColorButton
@brief
    ��ɫ��ť��
@*/
class _CColorButton : public CButton
{

DECLARE_DYNAMIC(_CColorButton)

public:

    _CColorButton();

    virtual ~_CColorButton();

    DECLARE_MESSAGE_MAP()

public:

    BOOL Attach(const UINT nID, CWnd* pParent, 
                const COLORREF BGColor = RGB(192, 192, 192),/* ��ť   */
                const COLORREF FGColor = RGB(1, 1, 1),      /* �ı�    */
                const COLORREF DisabledColor = RGB(128, 128, 128),/* ���ı�    */
                const UINT nBevel = 2
                );

                                                 /* ����ǰ����ɫ             */
    inline void SetFGColor(COLORREF cfFG)
    { 
        m_clfFrontGround =  cfFG;
        return;
    }

                                                 /* ���ñ�����ɫ             */
    inline void SetBGColor(COLORREF cfBG)
    { 
        m_clfBackGround=  cfBG;
        //Invalidate();
        return;
    }

                                                 /* ���ñ�����ɫ             */
    inline void SetDisabledColor(COLORREF cfDB)
    {
        m_clfDisableColor = cfDB;
        return;
    }

                                                 /* ��ȡ������ɫ             */
    COLORREF GetBGColor() { return m_clfBackGround; }

                                                 /* ��ȡǰ����ɫ             */
    COLORREF GetFGColor() { return m_clfFrontGround; }

                                                 /* ��ȡ������ɫ             */
    COLORREF GetDisabledColor() { return m_clfDisableColor; }

protected:

    virtual void DrawItem(LPDRAWITEMSTRUCT lpDIS);

    void DrawFrame(CDC *pDC, CRect R, int Inset);

    void DrawFilledRect(CDC *pDC, CRect R, COLORREF color);

    void DrawLine(CDC *pDC, CRect EndPoints, COLORREF color);

    void DrawLine(CDC       *DC,
                  long      left,
                  long      top,
                  long      right,
                  long      bottom,
                  COLORREF  color);

    void DrawButtonText(CDC         *DC,
                        CRect       R,
                        const char  *Buf, 
                        COLORREF    TextColor);

    UINT GetBevel() { return m_bevel; }

private:

    UINT        m_bevel;                         /* б��                     */

    COLORREF    m_clfFrontGround;                /* ǰ��ɫ                   */
    COLORREF    m_clfBackGround;                 /* ����ɫ                   */
    COLORREF    m_clfDisableColor;               /* �ұ���ɫ                 */
};

#endif
