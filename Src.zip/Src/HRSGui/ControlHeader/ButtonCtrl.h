/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ���� ��  ���ֹ����Զ���  **  ��д��λ ��  �Ϻ��ſؿƼ����޹�˾       */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ˵�� ��  ����Ŀ���������ֹ����Զ�������                              */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ����˵�� ��  ���ļ�ΪͼƬ��ť������                                      */
/*                                                                           */
/*****************************************************************************/
/*  ��    �� ��                 **  ��������  ��  2009-12-14                 */
/*****************************************************************************/
/*                              �޸ļ�¼                                     */
/*                                                                           */
/*  �޸�����     **   �޸���      **    �޸�����                             */
/*                                                                           */
/*****************************************************************************/
/*          �� �� �� ��                         **  �������  ��             */
/*****************************************************************************/
/*  �ļ��汾�ţ�0.0.1                                                        */
/*****************************************************************************/

#if !defined(AFX_BUTTONCTRL_H__16C6D980_BD45_11D3_BDA3_00104B133581\
__INCLUDED_)
#define AFX_BUTTONCTRL_H__16C6D980_BD45_11D3_BDA3_00104B133581__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ButtonCtrl.h : header file
//

#include "afxwin.h"

enum    {   BTNST_COLOR_BK_IN    = 0, // Background color when mouse is INside
            BTNST_COLOR_FG_IN,        // Text color when mouse is INside
            BTNST_COLOR_BK_OUT,       // Background color when mouse is OUTside
            BTNST_COLOR_FG_OUT,       // Text color when mouse is OUTside
            BTNST_COLOR_BK_FOCUS,     // Background color when the 
                                      // button is focused
            BTNST_COLOR_FG_FOCUS,     // Text color when the button is focused

            BTNST_MAX_COLORS
        };

/////////////////////////////////////////////////////////////////////////////
// CButtonCtrl by Niek Albers
// Thanks to some people for the tooltip.
// A cool CBitmapButton derived class with 3 states,
// Up/Down/Hover.
class CButtonCtrl : public CBitmapButton
{
    DECLARE_DYNAMIC(CButtonCtrl);

    // Construction
public:
    CButtonCtrl();
    void SetToolTipText(CString* spText, BOOL bActivate = TRUE);
    void SetToolTipText(int nId, BOOL bActivate = TRUE);

// Attributes
protected:
    void ActivateTooltip(BOOL bActivate = TRUE);

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CButtonCtrl)
    protected:
    virtual BOOL PreTranslateMessage(MSG* pMsg);
    virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
    //}}AFX_VIRTUAL

// Implementation
public:
    BOOL LoadBitmap(UINT bitmapid);
    virtual ~CButtonCtrl();

    // Generated message map functions
protected:
    void InitToolTip();
    //{{AFX_MSG(CButtonCtrl)
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg LRESULT OnMouseLeave(WPARAM wparam, LPARAM lparam);
    afx_msg LRESULT OnMouseHover(WPARAM wparam, LPARAM lparam) ;
    //}}AFX_MSG

    DECLARE_MESSAGE_MAP()

public:

   /*
    @fn _SetFont
    @brief
        �����ı���ʽ
    @arg [in] lHight
        const long,����ĸ߶�
    @arg [in] bBold
        const bool,����Ӵ�
    @return
        ����ֵ��ʾ�����Ƿ�ɹ�
    @remark
    @see CButtonCtrl
    @*/
    bool _SetFont(const long lHight, const bool bBold = false);

    /*
    @fn _SetFont
    @brief
        �����ı�������ɫ
    @arg [in] _clrStart
        COLORREF,��ʼ��λ��ɫ
    @arg [in] _clrEnd
        COLORREF,������λ��ɫ
    @return
        ����ֵ��ʾ�����Ƿ�ɹ�
    @remark
    @see CButtonCtrl
    @*/
    bool _SetTextBkColor(COLORREF _clrStart, COLORREF _clrEnd);

protected:

    CToolTipCtrl    m_ToolTip;

    COLORREF        m_clrBkStart;
    COLORREF        m_clrBkEnd;
    COLORREF        m_clrFaceStart;
    COLORREF        m_clrFaceEnd;

    COLORREF        m_clrTextStart;
    COLORREF        m_clrTextEnd;

    BOOL            m_bTracking;
    BOOL            m_bHover;           // indicates if mouse is over the button

    CSize           m_ButtonSize;       // width and height of the button
    CBitmap         mybitmap;
    COLORREF        m_crColors[BTNST_MAX_COLORS];    // Colors to be used

    CFont           m_fontText;     //�ı���ʽ

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately 
// before the previous line.

#endif 
// !defined(AFX_BUTTONCTRL_H__16C6D980_BD45_11D3_BDA3_00104B133581__INCLUDED_)
