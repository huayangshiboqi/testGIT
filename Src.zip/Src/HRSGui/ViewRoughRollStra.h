#pragma once

#include "GridCtrl.h" 
#include "BtnDataBase.h"
#include "PceDataMgr.h"
#include "HRS_RMCalc.h"
#include "HRS_RmDraftRatioTable.h"
#include "afxwin.h"

// CViewRoughRollStra ������ͼ

#define  HRS_STR_THICK_NUM      10

class CViewRoughRollStra : public CFormView
{
    DECLARE_DYNCREATE(CViewRoughRollStra)

protected:
    CViewRoughRollStra();
    virtual ~CViewRoughRollStra();

protected:

    void GridCtrlInit();        //��ʼ��PDI/STRA/SCHED����

    void InitComboxStripNo();   //��ʼ��Combox�͸ְ�����

    virtual void OnInitialUpdate();

protected:
    //move from rmsched
    CGridCtrl m_GridRoughRollPDI;
    CGridCtrl m_GridRoughRollSchedCalc;
    CGridCtrl m_GridRoughRollStra;
    CBtnDataBase m_BtnDataBase; // grid with some cells with buttons / controls

public:
    enum { IDD = IDD_VIEW_ROUGHROLLSCHEM };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    DECLARE_MESSAGE_MAP()

public:
    CEdit     m_ButCtlRmExitThick;
    CComboBox m_ComboxStripNo;
    CButton   m_RadioGroup_PassMode;

    CPceDataMgr *m_pRollSchedMgr;
    PCE_DATA    *m_pCurPceData;

    HRS_RM_ALL_DATA         m_RmAllCalcData;
    HRS_TABLE_RM_DRAFTRATIO m_RmDraftTab[HRS_RM_DRAFT_NUM_MAX];
    HRS_ROUGHROLL_STRA      m_stRoughRollStra;      //�����������ݽṹ����

    HRS_ALL_STAND_PARA     m_AllStandPara; 
protected:
    BOOL m_BPassMode;
    BOOL m_bCheckStandDummyR1;
    BOOL m_bCheckStandDummyE2;
    BOOL m_bCheckStandDummyE1;
    BOOL m_bCheckRmExitThick;

    int    n_StraPassNum;

    double m_dExtTemp;
    double m_dBarThick;

    float  m_fThick_ExitPre;
    float  m_fThick_ExitNext;
    float  m_fDraftPre;
    float  m_fDraftNext;

    CString m_strStripNo;
    CString m_strCurStripNo;

public:
    // ��ڳ�ʼ������
    void SetRollSchedMgr(CPceDataMgr * pRollSchedMgr); 
    void SetRMSched(HRS_RM_SCHED &RMSched);

public:
    void SaveRMStraDataToCurPce();
    int LoadDraftRationFromCurPce();

    int GetRMWorkRadius(double *pdR1WorkerRadius,
        double *pdR2WorkerRadius);


protected:
    void FormatSchedText(GV_ITEM &Item, 
        HRS_ROUGHROLL_SCHEDCALC_PASS *pSchedCalcPass,
        int nCol,
        HRS_SPRAY_MODE_EM emSprayMode);

private:
    int CalcRMStraData();
    int InitCalcRMStraData();

    int GetCfgData();
    int GetGuiData();

    int SetThick_Exit();
    int GetThick_Cor();
    int HRS_RMDate_ToPCE();
    int SetPassModeByRadio();

    void SavePceData();

    bool ExitConfirm();

    HRS_ROUGHROLL_STRA_PASS * GetRoughRollStraPassFromGrid(int nRow,
                                 HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass);

    int FindPreAndNextPassData(int nRow);

    int HRS_RMCalc_Speed(HRS_RM_ALL_DATA *pAllData,
                         HRS_RM_ALL_PASS *pAllPass,
                         HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                         HRS_RM_ALL_SPEED *pAllSpeed);

    int HRS_RMCalc_SpeedGUI(HRS_RM_ALL_DATA *pAllData,
                            HRS_RM_ALL_PASS *pAllPass,
                            HRS_RM_ALL_DELIVERY_GAUGE *pAllDeliveryGauge,
                            HRS_RM_ALL_SPEED *pAllSpeed);

public:
    //  ˢ�½��������
    void RefreshRollPDIGrid();         // ˢ��PDI����
    void RefreshRoughRollSchedGrid();  // ˢ�¼�������̱���
    void RefreshRoughRollStraGrid();   // ˢ�²��Ա���

    void RefreshPassModeRadioButton();

    void ShowRMStraTable(int nRowCount, 
                         HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                         int nPassModeIndex,
                         int nRMPassNo,
                         int nStandNo);

public:
    afx_msg void OnBnClickedRadPassmode05();
    afx_msg void OnBnClickedRadPassmode07();
    afx_msg void OnBnClickedRadPassmode13();
    afx_msg void OnBnClickedRadPassmode15();
    afx_msg void OnBnClickedRadPassmode17();
    afx_msg void OnBnClickedRadPassmode33();
    afx_msg void OnBnClickedRadPassmode35();
    afx_msg void OnBnClickedRadPassmodeAuto();

    afx_msg void OnBnClickedCheckRrsE1();
    afx_msg void OnBnClickedCheckRrsR1();
    afx_msg void OnBnClickedCheckRrsE2();
    afx_msg void OnBnClickedCheckRrsRmexitthick();
    afx_msg void OnBnClickedCheckRemote();


    afx_msg void OnEnChangeEditRrsEmexitthick();
    afx_msg void OnCbnSelchangeCombRrstraStripno();

    afx_msg void OnBnClickedRmStraSave();   // ���水ť
    afx_msg void OnBnClickedRmStraCalc();   // ���㰴ť

    afx_msg void OnGridRoughRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult);
    afx_msg void OnGridRoughRollStraClick(NMHDR *pNotifyStruct, LRESULT* pResult);

    afx_msg void OnGridEndLableEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
public:
    afx_msg void OnBnClickedRmClearSet();
public:
public:
    BOOL m_bCheckRemoteCalc;
};


