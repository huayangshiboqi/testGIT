
#include "stdafx.h"
#include <math.h>

#include "NG_errno.h" 
#include "NG_malloc.h"
#include "NG.h"
#include "RW_string.h" 
#include "StrParse.h"
#include "NG_SimpleTypes.h"

#include "HRS_CommonCalc.h"
#include "HRS_RollerData.h"

#include "PceDataMgr.h"


#define  PARSE_ROLLSCHED_MACRO();   pszKeyToken = strtok(NULL, " \t");\
                                    if ( pszKeyToken == NULL )\
                                    {\
                                        bParseStatus = ERR_FAILED;\
                                        PceData_Destroy(pPceData);\
                                        goto Lable_Error_Goto;\
                                    }

#define  PARSE_PDI_MACRO(); memset(szData, 0, sizeof(szData));\
                            nDataLen = 64;\
                            pszData = StrGetStr(pDataIntStr, ',', szData, nDataLen);\
                            if (NULL == pszData)\
                            {\
                                continue;\
                            }

/** Method:    PceData_Create
    �������ݽṹ�崴������ 

    @param void - ��
    
    @return PCE_DATA * - �������ݽṹ��ָ��
*/
PCE_DATA * PceData_Create(void)
{
    PCE_DATA                        * pPceData;
    HRS_ROUGHROLL_STRA_PASS         * pRoughRollStraPass;
    HRS_ROUGHROLL_SCHEDCALC_PASS    * pRoughRollSchedCalcPass;
    HRS_FinishRoll_PRECALC_DATA     * pFinishRollPreCalcData;

    pPceData = (PCE_DATA *)NG_malloc(sizeof( PCE_DATA ));
    if (pPceData == NULL)
    {
        return NULL;
    }

    memset(pPceData, 0, sizeof(PCE_DATA));

    //��ʼ���������κ�
    pRoughRollStraPass = pPceData->stRoughRollStra.stRoughRollStraR1;
    strncpy(pPceData->stRoughRollStra.stHSB.strPass_No, "HSB", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[0].strPass_No, "R1 --1", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[1].strPass_No, "   --2", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[2].strPass_No, "   --3", HRS_PASS_NO_LEN);

    pRoughRollStraPass = pPceData->stRoughRollStra.stRoughRollStraR2;
    strncpy(pRoughRollStraPass[0].strPass_No, "R2 --1", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[1].strPass_No, "   --2", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[2].strPass_No, "   --3", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[3].strPass_No, "   --4", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[4].strPass_No, "   --5", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[5].strPass_No, "   --6", HRS_PASS_NO_LEN);
    strncpy(pRoughRollStraPass[6].strPass_No, "   --7", HRS_PASS_NO_LEN);

    pPceData->stRoughRollStra.bRm_Exit_Thick_Auto = false;
    pPceData->stRoughRollStra.fRm_Exit_Thick = 0;
    pPceData->stRoughRollStra.emPassMode = HRS_PASS_MODE_AUTO;

    pPceData->stRoughRollStra.fRMExitTemp = 0;
    pPceData->stRoughRollStra.nIsHaveData = 0;  // ȱʡ������

    //��ʼ�������ƻ�������κ�
    pRoughRollSchedCalcPass = pPceData->stRoughRollSched.SchedCalcPassR1;
    strncpy(pRoughRollSchedCalcPass[0].strPass, "R11", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[1].strPass, "R12", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[2].strPass, "R13", HRS_STRPASS_NO_LEN);

    pRoughRollSchedCalcPass = pPceData->stRoughRollSched.SchedCalcPassR2;
    strncpy(pRoughRollSchedCalcPass[0].strPass, "R21", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[1].strPass, "R22", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[2].strPass, "R23", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[3].strPass, "R24", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[4].strPass, "R25", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[5].strPass, "R26", HRS_STRPASS_NO_LEN);
    strncpy(pRoughRollSchedCalcPass[6].strPass, "R27", HRS_STRPASS_NO_LEN);
    strncpy(pPceData->stRoughRollSched.SchedCalcPassE3.strPass, 
            "E3", HRS_STRPASS_NO_LEN);

    pPceData->stFinishRollStra.nSprayCod = 4; //test

    // ��ʼ���������κ�
    strncpy(pPceData->stFinishRollSched.PreCalcDataE3.strStand, 
            "E3", HRS_STRPASS_NO_LEN);
    pFinishRollPreCalcData = pPceData->stFinishRollSched.PreCalcDataF;
    strncpy(pFinishRollPreCalcData[0].strStand, "F1", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[1].strStand, "F2", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[2].strStand, "F3", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[3].strStand, "F4", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[4].strStand, "F5", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[5].strStand, "F6", HRS_STRPASS_NO_LEN);
    strncpy(pFinishRollPreCalcData[6].strStand, "F7", HRS_STRPASS_NO_LEN);

    pPceData->nRolledStatus = ERR_FAILED;
    pPceData->nRoughRollSchedStatus = ERR_FAILED;
    pPceData->nRollingStatus = ERR_FAILED;
    pPceData->nSimulatorStatus = ERR_FAILED;
    pPceData->nFinishRollSchedStatus = ERR_FAILED;
    
    HRS_RMStraData_Init(&(pPceData->stRMStraData));

    return pPceData;
}

/** Method:    PceData_Destroy
    �������ݽṹ�����ٺ��� 

    @param void * pData - �������ݽṹ��ָ��
    
    @return void - ��
*/
void PceData_Destroy(void *pData)
{
    PCE_DATA * pPceData = (PCE_DATA *) pData;

    if ( pPceData != NULL )
    {
        NG_free( pPceData );
    }

    return;
}

int SchedCompareFunc(void * pdata1, void * pdata2)
{
    PCE_DATA * pPceData;
    int nRet;

    pPceData = (PCE_DATA *) pdata1;

    nRet = pPceData->stRollSched.nSEQ - *((int *)pdata2);

    return nRet;
}

void * SchedCopyFunc(void * pData)
{
    PCE_DATA * pPceData;

    pPceData = PceData_Create();
    if (pPceData == NULL)
    {
        return NULL;
    }

    memcpy(pPceData, pData, sizeof(PCE_DATA));

    return pPceData;
}

int SchedFullCmpFunc(void * pdata1, void * pdata2)
{
    PCE_DATA * pPceData1;
    PCE_DATA * pPceData2;
    int nRet;

    pPceData1 = (PCE_DATA *) pdata1;
    pPceData2 = (PCE_DATA *) pdata2;

    nRet = memcmp(pPceData1, pPceData2, sizeof(PCE_DATA));

    return nRet;
}


int SchedCompareFuncByStripNo(void * pdata1, void * pdata2)
{
    PCE_DATA * pPceData;
    int nRet;
    CString strTempStripNo;

    pPceData = (PCE_DATA *) pdata1;

    strTempStripNo = pPceData->stRollSched.strSTRIP_NO;

    if (strTempStripNo == *((CString *)pdata2))
    {
        nRet =0;
    }
    else
    {
        nRet =1;   
    }

    return nRet;

}

/** Method:    PceData_ChangeRmStraPass
    �޸Ĵ�������һ��������Ϣ 

    @param PCE_DATA * pPceData - �������ݽṹ��ָ��
    @param HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass - 
                                 �������Ե������������ݽṹ��
    @param int nIndex - �ܵ������� 
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int PceData_ChangeRmStraPass(PCE_DATA *pPceData, 
                             HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass, 
                             int nIndex)
{
    HRS_ROUGHROLL_STRA * pRoughRollStra;
    int nIndexR1;
    int nIndexR2;

    if (pPceData ==  NULL)
    {
        return ERR_FAILED;
    }

    pRoughRollStra = &(pPceData->stRoughRollStra);
    nIndexR1 = pRoughRollStra->emPassMode / 10 + 1;
    nIndexR2 = (pRoughRollStra->emPassMode % 10) + nIndexR1;

    if (nIndex == 0)
    {
        if (!strncmp(pRoughRollStraPass->strPass_No, 
            pRoughRollStra->stHSB.strPass_No, 
            HRS_PASS_NO_LEN))
        {
            memcpy(&pRoughRollStra->stHSB, 
                pRoughRollStraPass, 
                sizeof(HRS_ROUGHROLL_STRA_PASS));
        }

        /*pRoughRollStra->stHSB.fThick_Exit = pPceData->stRollSched.fC_H;
        pRoughRollStra->stHSB.fWidth      = pPceData->stRollSched.fC_W;
        pRoughRollStra->stHSB.fDraft      = 0;*/
    }

    if (nIndex > 0 && nIndex < nIndexR1)
    {
        for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++)
        {
            if (!strncmp(pRoughRollStraPass->strPass_No, 
                pRoughRollStra->stRoughRollStraR1[i].strPass_No, 
                HRS_PASS_NO_LEN))
            {
                memcpy(&pRoughRollStra->stRoughRollStraR1[i], 
                    pRoughRollStraPass, 
                    sizeof(HRS_ROUGHROLL_STRA_PASS));
            }

            //pRoughRollStra->stRoughRollStraR1[i].fWidth =
            //               pPceData.stRoughRollSched.SchedCalcPassR1[i].fBAR_W;
            //pRoughRollStra->stRoughRollStraR1[i].fThick_Exit =
            //    pPceData.stRoughRollSched.SchedCalcPassR1[i].fBAR_H;
        }
    }

    if (nIndex >= nIndexR1 && nIndex < nIndexR2)
    {
        for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++)
        {
            if (!strncmp(pRoughRollStraPass->strPass_No, 
                pRoughRollStra->stRoughRollStraR2[i].strPass_No, 
                HRS_PASS_NO_LEN))
            {
                memcpy(&pRoughRollStra->stRoughRollStraR2[i], 
                    pRoughRollStraPass, 
                    sizeof(HRS_ROUGHROLL_STRA_PASS));
            }
        }
    }
//    NG_free(pRoughRollStraPass);

    return ERR_SUCCESS;
}


/** Method:    PceData_ChangeFmStraData
    �޸ľ����������ݺ��� 

    @param PCE_DATA * pPceData - �������ݽṹ��ָ��
    @param HRS_FINISHROLL_STRA_DATA * pFinishRollStraData - ������������
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int PceData_ChangeFmStraData(PCE_DATA *pPceData, 
                             HRS_FINISHROLL_STRA_DATA * pFinishRollStraData )
{
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stFinishRollStra.FinishRollStraData, 
            pFinishRollStraData, 
            sizeof(HRS_FINISHROLL_STRA_DATA) );

    NG_free(pFinishRollStraData);

    return ERR_SUCCESS;
}

/** Method:    PceData_ChangeFmLoadData
    �޸ľ������ɵ�����ʽ���ݺ��� 

    @param PCE_DATA * pPceData - �������ݽṹ��ָ��
    @param HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData - ���ɵ�����ʽ���ݽṹ
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int PceData_ChangeFmLoadData(PCE_DATA *pPceData, 
                             HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData )
{
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stFinishRollStra.FinishRollLoadData, 
            pFinishRollLoadData, 
            sizeof(HRS_FINISHROLL_LOAD_DATA) );

    NG_free(pFinishRollLoadData);

    return ERR_SUCCESS;
}

int PceData_DefaultFmStra(PCE_DATA *pPceData)
{
    HRS_FINISHROLL_STRA *pFinishRollStra;
    HRS_FINISHROLL_STRA_DATA *pStraData;
    HRS_ROUGHROLL_STRA *pRoughRollStra;

    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    pFinishRollStra = & pPceData->stFinishRollStra;
    pRoughRollStra = &pPceData->stRoughRollStra;

    pStraData = &(pFinishRollStra->FinishRollStraData);
    pStraData->fBarTemp   = pPceData->stRollSched.fRDT;
    pStraData->fBarThick  = pPceData->stRollSched.fR_H;
    pStraData->fBarWidth  = pPceData->stRollSched.fS_W;
    pStraData->fFET       = pPceData->stRollSched.fRDT - 15.0;

//    memset(pFinishRollStra, 0, sizeof(HRS_FINISHROLL_STRA));

    pFinishRollStra->nSprayCod = 4; //test

    //�м�������ж�
    if (pRoughRollStra->bRm_Exit_Thick_Auto)
    {
        pFinishRollStra->FinishRollStraData.fBarThick = 
            pPceData->stRoughRollSched.dTransferBarGauge;
        //pFinishRollStra->FinishRollStraData.fBarThick = pRoughRollStra->fRm_Exit_Thick;
    }
    else
    {
        pFinishRollStra->FinishRollStraData.fBarThick = pPceData->stRollSched.fR_H;
    }

    pFinishRollStra->FinishRollStraData.fBarWidth = pPceData->stRollSched.fS_W;

    return ERR_SUCCESS;
}


void PceData_ProcessSprayMode(PCE_DATA *pPceData)
{
    // ������������״̬
    int                 nSprayMode;
    HRS_RM_SPRAY_NODE  *pRMSprayNode;
    int                 k;
    int                 i;

    pRMSprayNode = HRS_GetRMSprayNode(pPceData->stRollSched.nRSB);
    if ( pRMSprayNode != NULL)
    {
        // ���������
        pPceData->stRoughRollStra.stHSB.emSprayMode 
            = (HRS_SPRAY_MODE_EM)pRMSprayNode->nHSBSprayType;

        for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
        {
            pPceData->stRMStraData.aOrgStra[i].stHSB.emSprayMode
                = (HRS_SPRAY_MODE_EM)pRMSprayNode->nHSBSprayType;
            pPceData->stRMStraData.aAllPassModeStra[i].stHSB.emSprayMode
                = (HRS_SPRAY_MODE_EM)pRMSprayNode->nHSBSprayType;
        }

        // ����1����
        for ( k = 0; k < 3; k++)
        {
            nSprayMode = pRMSprayNode->anRM1SprayType[k];

            if (nSprayMode == 0)
            {
                nSprayMode = HRS_SPRAY_OFF;
            }
            else
            {
                nSprayMode = HRS_SPRAY_ON;
            }

            pPceData->stRoughRollStra.stRoughRollStraR1[k].emSprayMode 
                = (HRS_SPRAY_MODE_EM)nSprayMode;

            for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
            {
                pPceData->stRMStraData.aOrgStra[i].stRoughRollStraR1[k].emSprayMode
                    = (HRS_SPRAY_MODE_EM)nSprayMode;
                pPceData->stRMStraData.aAllPassModeStra[i].stRoughRollStraR1[k].emSprayMode
                    = (HRS_SPRAY_MODE_EM)nSprayMode;
            }

        }

        // ����2����
        for ( k = 0; k < 7; k++)
        {
            nSprayMode = pRMSprayNode->anRM2SprayType[k];

            if (nSprayMode == 0)
            {
                nSprayMode = HRS_SPRAY_OFF;
            }
            else
            {
                nSprayMode = HRS_SPRAY_ON;
            }

            pPceData->stRoughRollStra.stRoughRollStraR2[k].emSprayMode 
                = (HRS_SPRAY_MODE_EM)nSprayMode;

            for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
            {
                pPceData->stRMStraData.aOrgStra[i].stRoughRollStraR2[k].emSprayMode
                    = (HRS_SPRAY_MODE_EM)nSprayMode;
                pPceData->stRMStraData.aAllPassModeStra[i].stRoughRollStraR2[k].emSprayMode
                    = (HRS_SPRAY_MODE_EM)nSprayMode;
            }
        }
    }
    else
    {
        // ���������
        pPceData->stRoughRollStra.stHSB.emSprayMode 
            = HRS_SPRAY_OFF;

        for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
        {
            pPceData->stRMStraData.aOrgStra[i].stHSB.emSprayMode
                = HRS_SPRAY_OFF;
            pPceData->stRMStraData.aAllPassModeStra[i].stHSB.emSprayMode
                = HRS_SPRAY_OFF;
        }


        // ����1����
        for ( k = 0; k < 3; k++)
        {
            nSprayMode = pRMSprayNode->anRM1SprayType[k];

            pPceData->stRoughRollStra.stRoughRollStraR1[k].emSprayMode 
                = HRS_SPRAY_OFF;

            for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
            {
                pPceData->stRMStraData.aOrgStra[i].stRoughRollStraR1[k].emSprayMode
                    = HRS_SPRAY_OFF;
                pPceData->stRMStraData.aAllPassModeStra[i].stRoughRollStraR1[k].emSprayMode
                    = HRS_SPRAY_OFF;
            }
        }

        // ����2����
        for ( k = 0; k < 7; k++)
        {
            nSprayMode = pRMSprayNode->anRM2SprayType[k];

            pPceData->stRoughRollStra.stRoughRollStraR2[k].emSprayMode 
                = HRS_SPRAY_OFF;
            for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
            {
                pPceData->stRMStraData.aOrgStra[i].stRoughRollStraR2[k].emSprayMode
                    = HRS_SPRAY_OFF;
                pPceData->stRMStraData.aAllPassModeStra[i].stRoughRollStraR2[k].emSprayMode
                    = HRS_SPRAY_OFF;
            }
        }
    }


    // ������������״̬
    HRS_FM_SPRAY_NODE  *pFMSprayNode;

    pFMSprayNode = HRS_GetFMSprayNode(pPceData->stRollSched.nFSB);
    if ( pFMSprayNode != NULL)
    {
        // ���������
        pPceData->stFinishRollStra.nSprayCod  
            = pFMSprayNode->nCode;
    }
    else
    {
        // ���������
        pPceData->stFinishRollStra.nSprayCod  
            = 0;
    }

    return;
}



CPceDataMgr::CPceDataMgr()
{
    m_pRollSchedList = NULL;
    m_pRollSchedList = MTList_Create();

    m_pShowRollerMgr     = NULL;
    m_pTotalRollerMgr = NULL;

    m_nLoadFiledNum = 0;     
    m_nLoadSuccessNum = 0;   
    m_nRepeatStripNoNum = 0; 


}


CPceDataMgr::~CPceDataMgr()   
{
    if (NULL != m_pRollSchedList)
    {
        MTList_Destroy( m_pRollSchedList, PceData_Destroy );
    }

    if (NULL != m_pShowRollerMgr)
    {
        HRS_ShowRollerDataMgr_Destory(m_pShowRollerMgr);
    }

    if (NULL != m_pTotalRollerMgr)
    {
        HRS_TotalRollerDataMgr_Destory(m_pTotalRollerMgr);
    }
}



/** Method:    ReadSchedFromFile
    ���ļ���ȡ���Ƽƻ����� 

    @param char * pszSchedFile - ���Ƽƻ��ļ���
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ReadSchedFromFile(char *pszSchedFile)
{
    FILE *      fp;
    int         nFileLen;
    char *      pszFileBuf;
    int         nCount;
    int         nRet;

    fp = fopen( pszSchedFile, "rb" );
    if ( !fp )
    {
        return ERR_FAILED;
    }

    fseek(fp, 0, SEEK_END);

    nFileLen = ftell(fp);

    if ( nFileLen <= 0 )
    {
        return ERR_FAILED;
    }

    pszFileBuf = (char *)NG_malloc(nFileLen + 10);

    if ( pszFileBuf == NULL )
    {
        fclose(fp);
        return ERR_FAILED;
    }

    memset(pszFileBuf, 0, nFileLen + 10);

    fseek(fp, 0, SEEK_SET);
    nCount = (int)fread(pszFileBuf, 1, nFileLen, fp);
    if ( nCount <= 0 )
    { 
        fclose(fp);
        NG_free(pszFileBuf);
        return ERR_FAILED;
    }

    fclose(fp);

    pszFileBuf[nFileLen+9] = '\0';

    //nRet = ParseSchedFile(pszFileBuf, nFileLen+10);
    nRet = GetPDIData(pszFileBuf, nFileLen+10);

    NG_free(pszFileBuf);

    return nRet;
}


int CPceDataMgr::GetPDIEntry(DARRAY *pRowArray, PCE_DATA *pPceData, int nIndex)
{
    int        i;
    char      *pszData;
    int        nDataLen;
    PCE_DATA  *pTempPceData;

    for (i = 0; i < PCE_COL_INDEX_MAX; i++)
    {
        pszData = (char *)DArray_GetAt(pRowArray, i);

        StrTrimLeft(pszData);
        StrTrimRight(pszData);
        nDataLen = (int)strlen(pszData);

        if ( pszData[0] == '\0' )
        {
            return i;
        }

        switch (i)
        {
        case PCE_COL_INDEX_SEQ:
            pPceData->stRollSched.nSEQ = nIndex + 1;
            break;
        case PCE_COL_INDEX_STRIP_NO:
            {
                if (nDataLen < HRS_STRIP_NO_LEN_MIN 
                    || nDataLen >= HRS_STRIP_NO_LEN_MAX)
                {
                    return PCE_COL_INDEX_STRIP_NO;
                }
                strcpy(pPceData->stRollSched.strSTRIP_NO, pszData);

                //����Ƿ����ظ��ְ��
                CString strStripNo = pszData;
                pTempPceData = SearchPceDataByStripNo(strStripNo);
                if (pTempPceData != NULL)
                {
                    m_nRepeatStripNoNum += 1;

                    return PCE_COL_INDEX_STRIP_NO;
                }
            }
            break;

        case PCE_COL_INDEX_COMSEQ:
            pPceData->stRollSched.nCOMSEQ = atoi(pszData);
            break;

        case PCE_COL_INDEX_GRADE:
            if (nDataLen < HRS_GRADE_LEN_MIN 
                || nDataLen >= HRS_GRADE_LEN_MAX)
            {
                return PCE_COL_INDEX_GRADE;
            }
            strcpy(pPceData->stRollSched.strGRADE, pszData);
            break;

        case PCE_COL_INDEX_SIGN:
            if ( nDataLen >= HRS_SIGN_LEN)
            {
                return PCE_COL_INDEX_SIGN;
            }
            strcpy(pPceData->stRollSched.strSIGN, pszData);
            break;

        case PCE_COL_INDEX_C_H:
            pPceData->stRollSched.fC_H = atof(pszData);
            if (pPceData->stRollSched.fC_H > 20 
                || pPceData->stRollSched.fC_H < 1.0)
            {
                return PCE_COL_INDEX_C_H;
            }
            break;

        case PCE_COL_INDEX_C_W:
            pPceData->stRollSched.fC_W = atof(pszData);
            if (pPceData->stRollSched.fC_W > 1650 
                || pPceData->stRollSched.fC_W < 800)
            {
                return PCE_COL_INDEX_C_W;
            }
            break;

        case PCE_COL_INDEX_FSB:
            pPceData->stRollSched.nFSB = atoi(pszData);
            if (pPceData->stRollSched.nFSB < 0)
            {
                return PCE_COL_INDEX_FSB;
            }
            break;

        case PCE_COL_INDEX_R_H:
            pPceData->stRollSched.fR_H = atof(pszData);
            if (pPceData->stRollSched.fR_H > 150 
                || pPceData->stRollSched.fR_H < 20)
            {
                return PCE_COL_INDEX_R_H;
            }
            break;

        case PCE_COL_INDEX_RSB:
            pPceData->stRollSched.nRSB = atoi(pszData);
            if (pPceData->stRollSched.nRSB < 0)
            {
                return PCE_COL_INDEX_RSB;
            }
            break;

        case PCE_COL_INDEX_S_H:
            pPceData->stRollSched.fS_H = atof(pszData);
            if (pPceData->stRollSched.fS_H > 250 
                || pPceData->stRollSched.fS_H < 150)
            {
                return PCE_COL_INDEX_S_H;
            }
            break;

        case PCE_COL_INDEX_S_W:
            pPceData->stRollSched.fS_W = atof(pszData);
            if (pPceData->stRollSched.fS_W > 1650 
                || pPceData->stRollSched.fS_W < 800)
            {
                return PCE_COL_INDEX_S_W;
            }
            break;

        case PCE_COL_INDEX_S_L:
            pPceData->stRollSched.fS_L = atof(pszData);
            if (pPceData->stRollSched.fS_L > 15000 
                || pPceData->stRollSched.fS_L < 3000)
            {
                return PCE_COL_INDEX_S_L;
            }
            break;

        case PCE_COL_INDEX_WT:
            pPceData->stRollSched.fWT = atof(pszData);
            if (pPceData->stRollSched.fWT > 1000 
                || pPceData->stRollSched.fWT < 5)
            {
                return PCE_COL_INDEX_WT;
            }
            break;

        case PCE_COL_INDEX_WE:
            pPceData->stRollSched.fWE = atof(pszData);
            if (pPceData->stRollSched.fWE > 35 * 1000
                || pPceData->stRollSched.fWE < 2 *1000)
            {
                return PCE_COL_INDEX_WE;
            }

            break;

        case PCE_COL_INDEX_FDT:
            pPceData->stRollSched.fFDT = atof(pszData);
            if (pPceData->stRollSched.fFDT > 1000 
                || pPceData->stRollSched.fFDT < 600)
            {
                return PCE_COL_INDEX_WT;
            }

            break;

        case PCE_COL_INDEX_EXT:
            pPceData->stRollSched.fEXT = atof(pszData);
            if (pPceData->stRollSched.fEXT > 1300 
                || pPceData->stRollSched.fEXT < 1000)
            {
                return PCE_COL_INDEX_EXT;
            }
            break;

        case PCE_COL_INDEX_RDT:
            pPceData->stRollSched.fRDT = atof(pszData);
            if (pPceData->stRollSched.fRDT > 1300 
                || pPceData->stRollSched.fRDT < 800)
            {
                return PCE_COL_INDEX_RDT;
            }

            // �����������еĳ�¯�¶����ݳ�ʼ���ɺ͹���е��¶�����һ��
            pPceData->stFinishRollStra.FinishRollStraData.fFET 
                = pPceData->stRollSched.fRDT - 15.0;
            break;

        case PCE_COL_INDEX_CTC:
            pPceData->stRollSched.fCTC = atof(pszData);
            if (pPceData->stRollSched.fCTC > 800 
                || pPceData->stRollSched.fCTC < 400)
            {
                return PCE_COL_INDEX_CTC;
            }

            break;
        case PCE_COL_INDEX_QUAL:
            pPceData->stRollSched.nQUAL = atoi(pszData);
            if (pPceData->stRollSched.nQUAL < 0)
            {
                return PCE_COL_INDEX_QUAL;
            }

            break;
        case PCE_COL_INDEX_SFC:
            pPceData->stRollSched.nSFC = atoi(pszData);
            if (pPceData->stRollSched.nSFC < 0)
            {
                return PCE_COL_INDEX_SFC;
            }

            break;
        case PCE_COL_INDEX_STA:
            pPceData->stRollSched.nSTA = atoi(pszData);
            if (pPceData->stRollSched.nSTA < 0)
            {
                return PCE_COL_INDEX_STA;
            }
            break;
        case PCE_COL_INDEX_HTT:
            pPceData->stRollSched.nHTT = atoi(pszData);
            if (pPceData->stRollSched.nHTT < 0)
            {
                return PCE_COL_INDEX_HTT;
            }

            break;
        case PCE_COL_INDEX_CP:
            pPceData->stRollSched.nCP = atoi(pszData);

            break;
        case PCE_COL_INDEX_CROWN:
            pPceData->stRollSched.fCROWN = atof(pszData);
            if (pPceData->stRollSched.fCROWN > 15 
                || pPceData->stRollSched.fCROWN < -10)
            {
                return PCE_COL_INDEX_CROWN;
            }
            break;
        default:
            break;
        }
    }

    pPceData->nRollSchedStatus       = ERR_SUCCESS;
    pPceData->nRoughRollSchedStatus  = ERR_FAILED;
    pPceData->nRoughRollStraStatus   = ERR_FAILED;
    pPceData->nFinishROllStraStatus  = ERR_FAILED;
    pPceData->nFinishRollSchedStatus = ERR_FAILED;
    pPceData->nRollingStatus         = ERR_FAILED;
    pPceData->nRolledStatus          = ERR_FAILED;
    pPceData->nSimulatorStatus       = ERR_FAILED;

    pPceData->nRoughRollStraCfgStatus = ERR_FAILED;

    pPceData->stRoughRollStra.bRm_Exit_Thick_Auto = true;
    pPceData->stRoughRollStra.fRm_Exit_Thick = pPceData->stRollSched.fR_H;
    pPceData->stRoughRollStra.fRMExitTemp    = pPceData->stRollSched.fRDT;
    pPceData->stRoughRollStra.fRMExitWidth   = pPceData->stRollSched.fC_W;

    int k;
    HRS_ROUGHROLL_STRA  *pRMStra;


    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        // ԭʼ����
        pRMStra = &(pPceData->stRMStraData.aOrgStra[i]);

        for ( k = 0; k < HRS_ROUGHROLL_R1_PASS_MAX; k++ )
        {
            pRMStra->stRoughRollStraR1[k].fWidth = pPceData->stRollSched.fS_W;
        }
        for ( k = 0; k < HRS_ROUGHROLL_R2_PASS_MAX; k++ )
        {
            pRMStra->stRoughRollStraR2[k].fWidth = pPceData->stRollSched.fS_W;
        }

        pRMStra->fRm_Exit_Thick = pPceData->stRollSched.fR_H;
        pRMStra->fRMExitTemp    = pPceData->stRollSched.fRDT;
        pRMStra->fDischargeTemp = pPceData->stRollSched.fEXT;
        pRMStra->fRMExitWidth   = pPceData->stRollSched.fC_W;

        // ��ǰ��������
        pRMStra = &(pPceData->stRMStraData.aAllPassModeStra[i]);

        for ( k = 0; k < HRS_ROUGHROLL_R1_PASS_MAX; k++ )
        {
            pRMStra->stRoughRollStraR1[k].fWidth = pPceData->stRollSched.fS_W;
        }
        for ( k = 0; k < HRS_ROUGHROLL_R2_PASS_MAX; k++ )
        {
            pRMStra->stRoughRollStraR2[k].fWidth = pPceData->stRollSched.fS_W;
        }

        pRMStra->fRm_Exit_Thick = pPceData->stRollSched.fR_H;
        pRMStra->fRMExitTemp    = pPceData->stRollSched.fRDT;
        pRMStra->fDischargeTemp = pPceData->stRollSched.fEXT;
        pRMStra->fRMExitWidth   = pPceData->stRollSched.fC_W;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::GetPDIData(char * pszFileBuf, int nFileLen)
{
    DARRAY  *pRowArray;
    int     nRet;

    if (NULL == m_pRollSchedList || NULL == pszFileBuf)
    {
        return ERR_FAILED;
    }

    int nBufSize = 4096;
    int nDataLen = 64;

    char szBuf[4096];

    char *pszSub  = NULL;
    char *pszData = NULL;

    PCE_DATA *pTempPceData = NULL;

    m_nLoadFiledNum     = 0;
    m_nLoadSuccessNum   = 0;
    m_nRepeatStripNoNum = 0;


    char *pszTemp = pszFileBuf;
    char *pszNext;
    for (;;)
    {
        int nDataCount = MTList_GetDataCount(m_pRollSchedList);
        if(nDataCount >= GRID_ROW_MAX)
        {
            break;
        }

        memset(szBuf, 0, nBufSize);

        pszNext = StrGetLineOnce(pszTemp, szBuf);
        if ( pszNext == NULL )
        {
            break;
        }

        pszSub = szBuf;
        StrTrimLeft(pszSub);
        StrTrimRight(pszSub);

        pszTemp = pszNext;

        pRowArray = ParseStrArray(pszSub, ",");
        if ( pRowArray == NULL )
        {
            // ���У�����
            continue;
        }


        pszData = (char *)DArray_GetAt(pRowArray, 0);
        StrTrimLeft(pszData);
        if (pszData[0] == '\0'
            || pszData[0] == '#'
            || pszData[0] == '!'
            || pRowArray->nDataCount == 1)
        {
            // ע���� �� ��ͷ�У�����������

            DArray_Destroy(pRowArray);

            continue;
        }

        m_nLoadFiledNum += 1;

        if ( pRowArray->nDataCount != HRS_ROLL_SCHED_ITEM_NUM )
        {
            DArray_Destroy(pRowArray);
            continue;
        }

        PCE_DATA *pPceData = PceData_Create();
        if (NULL == pPceData)
        {
            DArray_Destroy(pRowArray);
            break;
        }

        int nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

        nRet = GetPDIEntry(pRowArray, pPceData, nSchedCount);
        if (nRet != ERR_SUCCESS)
        {
            // ʧ�ܣ�����

            // д��־
            char szMsg[2048];

            sprintf(szMsg, "GetPDIEntry: �� %d �� �� %d �� Failed,"
                "���ݳ�����Χ���߸ֺ��ظ���(�д�0��ʼ��)\r\n"
                "ԭʼ����: %s\r\n", 
                nSchedCount+1, nRet,
                pszSub);

            FPrintf("HRS_PDI.log", "%s", szMsg);

            DArray_Destroy(pRowArray);

            continue;
        }

        MTList_InsertTail(m_pRollSchedList, pPceData);
        m_nLoadSuccessNum++;

        // �������۴���
        PceData_ProcessSprayMode(pPceData);

        pPceData->stRoughRollStra.fRm_Exit_Thick = pPceData->stRollSched.fR_H;
        pPceData->stRoughRollStra.fRMExitTemp    = pPceData->stRollSched.fRDT;
        pPceData->stRoughRollStra.fRMExitWidth   = pPceData->stRollSched.fC_W;

        DArray_Destroy(pRowArray);
    }
   
    return ERR_SUCCESS;
}


/** Method:    ParseSchedFile
    �������Ƽƻ��ļ� 

    @param char * pszFileBuf - �ļ������ڴ�ָ��
    @param int nFileLen - �ļ����ݳ���
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ParseSchedFile(char * pszFileBuf, int nFileLen)
{
    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }

    char *  pszLineToken;
    char *  pszKeyToken;
    char *  pszNextBuf;

    int     nDataLen        = 0;
    int     nLineCount      = 0;
    BOOL    bParseStatus    = ERR_SUCCESS;

    m_nLoadFiledNum   = 0;
    m_nLoadSuccessNum = 0;

    for ( pszLineToken = strtok(pszFileBuf, "\r\n"); 
          pszLineToken != NULL; 
          pszLineToken = strtok(pszNextBuf, "\r\n") )
    {
        int         LineTokenLen;
        PCE_DATA *  pPceData;
        int         nSchedCount;

        pszNextBuf = pszLineToken;
        LineTokenLen = (int)strlen(pszLineToken);

        if ( nLineCount == 0 )
        {
            pszKeyToken = strtok(pszLineToken, " \t");
            if (pszKeyToken == NULL)
            {
                //����
                int exitflag = 0;
                for (pszNextBuf = pszNextBuf + LineTokenLen; 
                    *pszNextBuf == '\0'; 
                    pszNextBuf++)
                {
                    if ( pszNextBuf >= (pszFileBuf + nFileLen -1) )
                    {
                        exitflag = 1;
                        break;
                    }
                }
                if (exitflag)
                {
                    break;
                }

                continue;
            }

            if ( stricmp(pszKeyToken, "SEQ"))
            {
                bParseStatus = ERR_FAILED;
                goto Lable_Error_Goto;
            }
        }
        else
        {
            pPceData = PceData_Create();

            pszKeyToken = strtok(pszLineToken, " \t");
            if ( pszKeyToken == NULL )
            {
                //����
                int exitflag = 0;
                for (pszNextBuf = pszNextBuf + LineTokenLen; 
                    *pszNextBuf == '\0'; 
                    pszNextBuf++)
                {
                    if ( pszNextBuf >= (pszFileBuf + nFileLen -1) )
                    {
                        exitflag = 1;
                        break;
                    }
                }
                if (exitflag)
                {
                    break;
                }

                continue;
            }
            pPceData->stRollSched.nSEQ = atoi(pszKeyToken);
            if (pPceData->stRollSched.nSEQ <= 0)
            {
                m_nLoadFiledNum++;
                 PceData_Destroy(pPceData);
                 continue;
            }

            nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);
            pPceData->stRollSched.nSEQ = nSchedCount+1;

            PARSE_ROLLSCHED_MACRO();
            strncpy(pPceData->stRollSched.strSTRIP_NO, pszKeyToken, 
                    HRS_STRIP_NO_LEN);
            pPceData->stRollSched.strSTRIP_NO[HRS_STRIP_NO_LEN-1] = '\0';
            nDataLen = (int)strlen(pPceData->stRollSched.strSTRIP_NO);
            if (nDataLen < HRS_STRIP_NO_LEN_MIN 
                || nDataLen > HRS_STRIP_NO_LEN_MAX)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nCOMSEQ = atoi(pszKeyToken);

            PARSE_ROLLSCHED_MACRO();
            strncpy(pPceData->stRollSched.strGRADE, pszKeyToken, HRS_GRADE_LEN);
            pPceData->stRollSched.strGRADE[HRS_GRADE_LEN-1] = '\0';
            nDataLen = (int)strlen(pPceData->stRollSched.strGRADE);
            if (nDataLen < HRS_GRADE_LEN_MIN 
                || nDataLen > HRS_GRADE_LEN_MAX)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            strncpy(pPceData->stRollSched.strSIGN, pszKeyToken, HRS_SIGN_LEN);
            pPceData->stRollSched.strSIGN[HRS_SIGN_LEN-1] = '\0';

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fC_H = atof(pszKeyToken);
            if (pPceData->stRollSched.fC_H > 20 
                || pPceData->stRollSched.fC_H < 1.0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fC_W = atof(pszKeyToken);
            if (pPceData->stRollSched.fC_W > 1650 
                || pPceData->stRollSched.fC_W < 800)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nFSB = atoi(pszKeyToken);
            if (pPceData->stRollSched.nFSB < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fR_H = atof(pszKeyToken);
            if (pPceData->stRollSched.fR_H > 150 
                || pPceData->stRollSched.fR_H < 20)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nRSB = atoi(pszKeyToken);
            if (pPceData->stRollSched.nRSB < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fS_H = atof(pszKeyToken);
            if (pPceData->stRollSched.fS_H > 250 
                || pPceData->stRollSched.fS_H < 150)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fS_W = atof(pszKeyToken);
            if (pPceData->stRollSched.fS_W > 1650 
                || pPceData->stRollSched.fS_W < 800)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fS_L = atof(pszKeyToken);
            if (pPceData->stRollSched.fS_L > 15000 
                || pPceData->stRollSched.fS_L < 3000)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fWT = atof(pszKeyToken);
            if (pPceData->stRollSched.fWT > 1000 
                || pPceData->stRollSched.fWT < 5)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fWE = atof(pszKeyToken);
            if (pPceData->stRollSched.fWE > 35 * 1000
                || pPceData->stRollSched.fWE < 2 *1000)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fFDT = atof(pszKeyToken);
            if (pPceData->stRollSched.fFDT > 1000 
                || pPceData->stRollSched.fFDT < 600)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }
            
            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fEXT = atof(pszKeyToken);
            if (pPceData->stRollSched.fEXT > 1300 
                || pPceData->stRollSched.fEXT < 1000)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fRDT = atof(pszKeyToken);
            if (pPceData->stRollSched.fRDT > 1300 
                || pPceData->stRollSched.fRDT < 800)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fCTC = atof(pszKeyToken);
            if (pPceData->stRollSched.fCTC > 700 
                || pPceData->stRollSched.fCTC < 400)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nQUAL = atoi(pszKeyToken);
            if (pPceData->stRollSched.nQUAL < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nSFC = atoi(pszKeyToken);
            if (pPceData->stRollSched.nSFC < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nSTA = atoi(pszKeyToken);
            if (pPceData->stRollSched.nSTA < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nHTT = atoi(pszKeyToken);
            if (pPceData->stRollSched.nHTT < 0)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.nCP = atoi(pszKeyToken);

            PARSE_ROLLSCHED_MACRO();
            pPceData->stRollSched.fCROWN = atof(pszKeyToken);
            if (pPceData->stRollSched.fCROWN > 10 
                || pPceData->stRollSched.fCROWN < -10)
            {
                m_nLoadFiledNum++;
                PceData_Destroy(pPceData);
                continue;
            }

            pszKeyToken = strtok(NULL, " \t");
            if ( pszKeyToken != NULL )
            {
                bParseStatus = ERR_FAILED;
                PceData_Destroy(pPceData);
                goto Lable_Error_Goto;
            }

            pPceData->nRollSchedStatus       = ERR_SUCCESS;
            pPceData->nRoughRollSchedStatus  = ERR_FAILED;
            pPceData->nRoughRollStraStatus   = ERR_FAILED;
            pPceData->nFinishROllStraStatus  = ERR_FAILED;
            pPceData->nFinishRollSchedStatus = ERR_FAILED;
            pPceData->nRollingStatus         = ERR_FAILED;
            pPceData->nRolledStatus          = ERR_FAILED;

            pPceData->nRoughRollStraCfgStatus = ERR_FAILED;

            MTList_InsertTail(m_pRollSchedList, pPceData);

            m_nLoadSuccessNum++;
        }

        nLineCount++;

        int exitflag = 0;
        for (pszNextBuf = pszNextBuf + LineTokenLen; 
             *pszNextBuf == '\0'; 
             pszNextBuf++)
        {
            if ( pszNextBuf >= (pszFileBuf + nFileLen -1) )
            {
                exitflag = 1;
                break;
            }
        }
        if (exitflag)
        {
            break;
        }

    }

Lable_Error_Goto:

    return bParseStatus;
}

/** Method:    WriteSchedToFile
    д���Ƽƻ����ļ� 

    @param char * pszSchedFile - ���Ƽƻ��ļ���
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::WriteSchedToFile(char *pszSchedFile)
{
    FILE *      fp;
    int         nFileLen;
    void *      pszFileDataBuf;
    int         nCount;
    int         nRet;

    nRet = WriteSchedFileBuf(&pszFileDataBuf, &nFileLen);

    if (nRet)
    {
        return ERR_FAILED;
    }

    fp = fopen( pszSchedFile, "w+" );
    if ( !fp )
    {
        return ERR_FAILED;
    }

    fseek(fp, 0, SEEK_SET);

    nCount = (int)fwrite(pszFileDataBuf, 1, nFileLen, fp);

    fclose(fp);
    NG_free(pszFileDataBuf);

    if (nCount <= 0)
    {
        return ERR_FAILED;
    }
    
    return nRet;

}

/** Method:    WriteSchedFileBuf
    д���Ƽƻ������滺���� 

    @param void * * pszFileDataBuf - ���ݻ�����ָ��
    @param int * nFileLen - ���ݳ���
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::WriteSchedFileBuf(void ** pszFileDataBuf, int * nFileLen)
{
    int         nSchedCount;
    PCE_DATA *  pPceData;
    int         nBufLen;
    int         nBufRestLen;
    int         nBufUsedLen;

    char *      pszDataBuf;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }
    
    nSchedCount     = DoubleList_GetCount(m_pRollSchedList->pList);
    nBufLen         = nSchedCount * 300 + 300;
    nBufRestLen     = nBufLen;

    pszDataBuf =  (char *)NG_malloc(nBufLen);
    memset(pszDataBuf, 0 ,nBufLen);

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    pszDataBuf[0] = '#';
    pszDataBuf[1] = ' ';

    for (int i = 0; i < HRS_ROLL_SCHED_ITEM_NUM; i++)
    {
        int RestTitleLen;

        nBufRestLen = nBufLen - (int)strlen(pszDataBuf);
        nBufUsedLen = (int)strlen(pszDataBuf);

        sprintf_s(pszDataBuf+nBufUsedLen, nBufRestLen, "%s%s",
                                                       pszTitle[i], 
                                                       pszUnit[i] );

        if ( i == HRS_ROLLSCHED_STRIP_NO)
        {
            RestTitleLen = 15 - (int)strlen(pszTitle[i]) - (int)strlen(pszUnit[i]);
        }
        else
        {
            RestTitleLen = 10 - (int)strlen(pszTitle[i]) - (int)strlen(pszUnit[i]);
        }
        

        for ( int j = 0; j < RestTitleLen; j++)
        {
            nBufRestLen = nBufLen - (int)strlen(pszDataBuf);
            nBufUsedLen = (int)strlen(pszDataBuf);

            sprintf_s(pszDataBuf+nBufUsedLen, nBufRestLen, " " );
        }

    }

    nBufRestLen = nBufLen - (int)strlen(pszDataBuf);
    nBufUsedLen = (int)strlen(pszDataBuf);

    sprintf_s(pszDataBuf+nBufUsedLen, nBufRestLen, "\r\n");


    for ( int i = 0; i < nSchedCount; i++)
    {
        nBufRestLen = nBufLen - (int)strlen(pszDataBuf);
        nBufUsedLen = (int)strlen(pszDataBuf);

        pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,i);
        sprintf(pszDataBuf+nBufUsedLen, "%4d,%15s,%10d,%10s,%10s\
,%10.2f,%10.2f,%10d,%10.2f,%10d,%10.2f,%10.2f,%10.2f,%10.2f,%10.2f,%10.2f,%10.2f\
,%10.2f,%10.2f,%10d,%10d,%10d,%10d,%10d,%10.2f \r\n",
                  pPceData->stRollSched.nSEQ, 
                  pPceData->stRollSched.strSTRIP_NO, 
                  pPceData->stRollSched.nCOMSEQ,
                  pPceData->stRollSched.strGRADE,
                  pPceData->stRollSched.strSIGN,
                  pPceData->stRollSched.fC_H,
                  pPceData->stRollSched.fC_W,
                  pPceData->stRollSched.nFSB,
                  pPceData->stRollSched.fR_H,
                  pPceData->stRollSched.nRSB,
                  pPceData->stRollSched.fS_H,
                  pPceData->stRollSched.fS_W,
                  pPceData->stRollSched.fS_L,
                  pPceData->stRollSched.fWT,
                  pPceData->stRollSched.fWE,
                  pPceData->stRollSched.fFDT,
                  pPceData->stRollSched.fEXT,
                  pPceData->stRollSched.fRDT,
                  pPceData->stRollSched.fCTC,
                  pPceData->stRollSched.nQUAL,
                  pPceData->stRollSched.nSFC,
                  pPceData->stRollSched.nSTA,
                  pPceData->stRollSched.nHTT,
                  pPceData->stRollSched.nCP,
                  pPceData->stRollSched.fCROWN);

        nBufRestLen = nBufLen - (int)strlen(pszDataBuf);
        nBufUsedLen = (int)strlen(pszDataBuf);

    }

    *pszFileDataBuf = pszDataBuf;
    *nFileLen = (int)strlen( (char *)*pszFileDataBuf ) +1;

    return ERR_SUCCESS;
}

/** Method:    ChangeRollSchedItem
    �޸����Ƽƻ����ݺ��� 

    @param HRS_ROLL_SCHED * pRollSched - ���Ƽƻ����ݽṹָ��
    @param int nIndex - ���Ƽƻ����
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ChangeRollSchedItem(HRS_ROLL_SCHED * pRollSched, int nIndex)
{
    PCE_DATA * pPceData;
    int nSchedCount;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }

    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

    if ( pRollSched == NULL || nIndex < 0 || nIndex >= nSchedCount)
    {
        return ERR_FAILED;
    }

    pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,nIndex);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stRollSched, pRollSched, sizeof(HRS_ROLL_SCHED));

    NG_free(pRollSched);

    return ERR_SUCCESS;
}

/** Method:    ChangeRoughRollStraPass
    �޸Ĵ�������һ��������Ϣ 

    @param HRS_ROUGHROLL_STRA_PASS * pRoughRollStraPass - 
                                        �������Ե������������ݽṹ��
    @param CString strStripNo - ������
    @param int nIndex - �ܵ�������
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ChangeRoughRollStraPass(HRS_ROUGHROLL_STRA_PASS * 
                                         pRoughRollStraPass, 
                                         CString strStripNo, 
                                         int nIndex)
{
    PCE_DATA * pPceData;
    HRS_ROUGHROLL_STRA * pRoughRollStra;
    int nIndexR1;
    int nIndexR2;

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData ==  NULL)
    {
        return ERR_FAILED;
    }
    pRoughRollStra = &(pPceData->stRoughRollStra);
    nIndexR1 = pRoughRollStra->emPassMode / 10 + 1;
    nIndexR2 = (pRoughRollStra->emPassMode % 10) + nIndexR1;

    if (nIndex == 0)
    {
        if (!strncmp(pRoughRollStraPass->strPass_No, 
             pRoughRollStra->stHSB.strPass_No, 
             HRS_PASS_NO_LEN))
        {
            memcpy(&pRoughRollStra->stHSB, 
                    pRoughRollStraPass, 
                    sizeof(HRS_ROUGHROLL_STRA_PASS));
        }
    }

    if (nIndex > 0 && nIndex < nIndexR1)
    {
        for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++)
        {
            if (!strncmp(pRoughRollStraPass->strPass_No, 
                         pRoughRollStra->stRoughRollStraR1[i].strPass_No, 
                         HRS_PASS_NO_LEN))
            {
                memcpy(&pRoughRollStra->stRoughRollStraR1[i], 
                       pRoughRollStraPass, 
                       sizeof(HRS_ROUGHROLL_STRA_PASS));
            }
        }
    }

    if (nIndex >= nIndexR1 && nIndex < nIndexR2)
    {
        for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++)
        {
            if (!strncmp(pRoughRollStraPass->strPass_No, 
                 pRoughRollStra->stRoughRollStraR2[i].strPass_No, 
                 HRS_PASS_NO_LEN))
            {
                memcpy(&pRoughRollStra->stRoughRollStraR2[i], 
                        pRoughRollStraPass, 
                        sizeof(HRS_ROUGHROLL_STRA_PASS));
            }
        }
    }

    NG_free(pRoughRollStraPass);

    return ERR_SUCCESS;
}

/** Method:    ChangeFinishRollStraData
    �޸ľ����������ݺ��� 

    @param HRS_FINISHROLL_STRA_DATA * pFinishRollStraData - ������������
    @param CString strStripNo - ������
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ChangeFinishRollStraData(HRS_FINISHROLL_STRA_DATA * 
                                          pFinishRollStraData, 
                                          CString strStripNo )
{
    PCE_DATA * pPceData;

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stFinishRollStra.FinishRollStraData, 
           pFinishRollStraData, 
           sizeof(HRS_FINISHROLL_STRA_DATA) );

    NG_free(pFinishRollStraData);

    return ERR_SUCCESS;

}

/** Method:    ChangeFinishRollLoadData
    �޸ľ������ɵ�����ʽ���ݺ��� 

    @param HRS_FINISHROLL_LOAD_DATA * pFinishRollLoadData - 
                                        ���ɵ�����ʽ���ݽṹ
    @param CString strStripNo - ������
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::ChangeFinishRollLoadData(HRS_FINISHROLL_LOAD_DATA * 
                                          pFinishRollLoadData, 
                                          CString strStripNo )
{
    PCE_DATA * pPceData;

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stFinishRollStra.FinishRollLoadData, 
        pFinishRollLoadData, 
        sizeof(HRS_FINISHROLL_LOAD_DATA) );

    NG_free(pFinishRollLoadData);

    return ERR_SUCCESS;

}

/** Method:    AddRollSchedItem
    ����һ�����Ƽƻ����� 
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::AddRollSchedItem()
{
    PCE_DATA * pPceData;
    int nSchedCount;

    
    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }

    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);
    if (nSchedCount > 0)
    {
        PCE_DATA *pTemp; 
        pTemp = 
         (PCE_DATA *)DoubleList_GetAt(m_pRollSchedList->pList, nSchedCount - 1);
        if (NULL == pTemp)
        {
            pPceData = PceData_Create();
            if (pPceData == NULL)
            {
                return ERR_FAILED;
            }
        }

        pPceData = CopyPceDataByStripNo(pTemp->stRollSched.strSTRIP_NO);
    }
    else
    {
        pPceData = PceData_Create();
        if (pPceData == NULL)
        {
            return ERR_FAILED;
        }
    }

    pPceData->stRollSched.nSEQ = nSchedCount+1;

    pPceData->stRoughRollStra.stHSB.fThick_Cor = (float)3.45; //test

    pPceData->nRollSchedStatus       = ERR_SUCCESS;
    pPceData->nRoughRollStraStatus   = ERR_FAILED;
    pPceData->nRoughRollSchedStatus  = ERR_FAILED;
    pPceData->nFinishROllStraStatus  = ERR_FAILED;
    pPceData->nFinishRollSchedStatus = ERR_FAILED;

    pPceData->nRoughRollStraCfgStatus = ERR_FAILED;

    pPceData->nRollingStatus  = ERR_FAILED;
    pPceData->nRolledStatus = ERR_FAILED;

    MTList_InsertTail(m_pRollSchedList, pPceData);

    return ERR_SUCCESS;
}

/** Method:    DeleteRollSchedItem
    ɾ��һ�����Ƽƻ����� 

    @param int nIndex - ���Ƽƻ����
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::DeleteRollSchedItem(int nIndex)
{
    int nCopyIndex;
    int nSchedCount;
    PCE_DATA * pPceData;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }

    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);
    if (nIndex < 1 || nIndex > nSchedCount)
    {
        return ERR_FAILED;
    }

    nCopyIndex = nIndex;
    if ( DoubleList_Delete(m_pRollSchedList->pList, 
                            (void *) (&nCopyIndex), 
                            SchedCompareFunc, 
                            PceData_Destroy))
    {
        return ERR_FAILED;
    }

    for (int i = nCopyIndex - 1; i < nSchedCount-1; i++)
    {
        pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,i);
        pPceData->stRollSched.nSEQ -= 1;
    }

    return ERR_SUCCESS;
}

/** Method:    MoveUpRollSchedItem
    ����һ�����Ƽƻ����� 

    @param int nIndex - ���Ƽƻ����
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::MoveUpRollSchedItem(int nIndex)
{
    int nSchedCount;
    PCE_DATA * pPceData;
    PCE_DATA * pTempPceData;
    PCE_DATA * pPrevPceData;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }

    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

    if (nSchedCount < 2 || nIndex < 2 || nIndex > nSchedCount)
    {
        return ERR_FAILED;
    }

    pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,nIndex-1);
    pPrevPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,nIndex-2);

    pTempPceData = PceData_Create();
    if (pTempPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(pTempPceData, pPceData, sizeof(PCE_DATA));
    memcpy(pPceData, pPrevPceData, sizeof(PCE_DATA));
    memcpy(pPrevPceData, pTempPceData, sizeof(PCE_DATA));

    pPceData->stRollSched.nSEQ +=1;
    pPrevPceData->stRollSched.nSEQ -=1;

    PceData_Destroy(pTempPceData);

    return ERR_SUCCESS;
}

/** Method:    MoveUpRollSchedItem
    ����һ�����Ƽƻ����� 

    @param int nIndex - ���Ƽƻ����
    
    @return int - �ɹ�����ERR_SUCCESS, ʧ�ܷ���ERR_FAILED
*/
int CPceDataMgr::MoveDownRollSchedItem(int nIndex)
{
    int nSchedCount;
    PCE_DATA * pPceData;
    PCE_DATA * pTempPceData;
    PCE_DATA * pPrevPceData;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }
    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

    if (nSchedCount < 2 || nIndex >= nSchedCount || nIndex < 1)
    {
        return ERR_FAILED;
    }

    pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,nIndex-1);
    pPrevPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,nIndex);

    pTempPceData = PceData_Create();
    if (pTempPceData == NULL)
    {
        return ERR_FAILED;
    }

    memcpy(pTempPceData, pPceData, sizeof(PCE_DATA));
    memcpy(pPceData, pPrevPceData, sizeof(PCE_DATA));
    memcpy(pPrevPceData, pTempPceData, sizeof(PCE_DATA));

    pPceData->stRollSched.nSEQ -=1;
    pPrevPceData->stRollSched.nSEQ +=1;

    PceData_Destroy(pTempPceData);

    return ERR_SUCCESS;
}

/** Method:    SearchSeqByStripNo
    �������Ų�ѯ���Ƽƻ���� 

    @param CString strStripNo - ������
    
    @return int - ���Ƽƻ����,û�ҵ�����-1
*/
int CPceDataMgr::SearchSeqByStripNo(CString strStripNo)
{
    CString strComStripNo;
    PCE_DATA * pPceData;

    strComStripNo = strStripNo;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }
    pPceData = (PCE_DATA *)DoubleList_Find(m_pRollSchedList->pList, 
                                           (void *)(&strComStripNo), 
                                           SchedCompareFuncByStripNo);

    if (pPceData == NULL)
    {
        return -1;
    }

    return pPceData->stRollSched.nSEQ;
}

/** Method:    SearchPceDataByStripNo
    �������Ų�ѯ�������ݽṹָ�� 

    @param CString strStripNo - ������
    
    @return PCE_DATA * - �������ݽṹָ��,ʧ�ܷ���NULL
*/
PCE_DATA * CPceDataMgr::SearchPceDataByStripNo(CString strStripNo)
{
    CString strComStripNo;
    PCE_DATA * pPceData;

    strComStripNo = strStripNo;

    if (NULL == m_pRollSchedList)
    {
        return NULL;
    }
    pPceData = (PCE_DATA *)DoubleList_Find(m_pRollSchedList->pList, 
                                           (void *)(&strComStripNo), 
                                           SchedCompareFuncByStripNo);

    if (pPceData == NULL)
    {
        return NULL;
    }

    return pPceData;
}


/** Method:    CopyPceDataByStripNo
    �������Ÿ��ƻ�ȡ�������ݽṹ 

    @param CString strStripNo - ������
    
    @return PCE_DATA * - �������ݽṹָ��,ʧ�ܷ���NULL
*/
PCE_DATA * CPceDataMgr::CopyPceDataByStripNo(CString strStripNo)
{
    CString strComStripNo;
    PCE_DATA *pNewPceData;
    PCE_DATA * pPceData;

    strComStripNo = strStripNo;

    if (NULL == m_pRollSchedList)
    {
        return NULL;
    }
    pPceData = (PCE_DATA *)DoubleList_Find(m_pRollSchedList->pList, 
                                           (void *)(&strComStripNo), 
                                           SchedCompareFuncByStripNo);

    if (pPceData == NULL)
    {
        return NULL;
    }

    pNewPceData = PceData_Create();
    if (pNewPceData == NULL)
    {
        return NULL;
    }

    memcpy(pNewPceData, pPceData, sizeof(PCE_DATA));

    return pNewPceData;
}


PCE_DATA *CPceDataMgr::GetPceDataByStripNo(CString strStripNo)
{
    CString strComStripNo;
    PCE_DATA * pPceData;

    strComStripNo = strStripNo;

    if (NULL == m_pRollSchedList)
    {
        return NULL;
    }
    pPceData = (PCE_DATA *)DoubleList_Find(m_pRollSchedList->pList, 
                                           (void *)(&strComStripNo), 
                                           SchedCompareFuncByStripNo);

    if (pPceData == NULL)
    {
        return NULL;
    }

    return pPceData;
}


/** Method:    GetStripNoList
    ��ȡ���а��������� 
    
    @return void * - �������ַ�����λ�����ָ��
*/
void* CPceDataMgr::GetStripNoList()
{
    int nSchedCount;
    char (* ppszStripNo)[HRS_STRIP_NO_LEN];
    PCE_DATA * pPceData;

    if (NULL == m_pRollSchedList)
    {
        return NULL;
    }
    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

    ppszStripNo = (char (*)[HRS_STRIP_NO_LEN]) 
                  NG_malloc((nSchedCount+1) * HRS_STRIP_NO_LEN);
    if (ppszStripNo == NULL)
    {
        return NULL;
    }

    memset(ppszStripNo, 0 ,(nSchedCount+1) * HRS_STRIP_NO_LEN);

    for (int i = 0; i < nSchedCount; i++)
    {
        pPceData = (PCE_DATA *)DoubleList_GetAt(m_pRollSchedList->pList, i);

        strncpy(ppszStripNo[i], 
                pPceData->stRollSched.strSTRIP_NO, 
                HRS_STRIP_NO_LEN);
        if (ppszStripNo[i][0] == '\0')
        {
            strncpy(ppszStripNo[i], "-", HRS_STRIP_NO_LEN);
        }
        ppszStripNo[i][HRS_STRIP_NO_LEN-1] = '\0'; 
    }

    return (void *)ppszStripNo;
}


/** Method:    PceDataMgrCopy
    ���ư������ݹ����ຯ�� 
    
    @return CPceDataMgr * - �������ݹ�����ָ��
*/
CPceDataMgr * CPceDataMgr::PceDataMgrCopy()
{
    if (NULL == m_pRollSchedList)
    {
        return NULL;
    }

    CPceDataMgr * pPceDataMgr;

    pPceDataMgr = new CPceDataMgr;

    PceDataPreProcess(); // Ԥ����

    MTList_Copy2(m_pRollSchedList, pPceDataMgr->m_pRollSchedList, SchedCopyFunc);

    //pPceDataMgr->PceDataPreProcess(); // test

    return pPceDataMgr;
}


/** Method:    PceDataMgrCmp
    �������ݹ�����ȽϺ��� 

    @param CPceDataMgr * pPceDataMgr - �������ݹ�����ָ��
    
    @return int - �Ƚϳɹ�����0�����򷵻�1
*/
int CPceDataMgr::PceDataMgrCmp(CPceDataMgr * pPceDataMgr)
{
    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }
    return DoubleList_CmpContent(m_pRollSchedList->pList, 
                                 pPceDataMgr->m_pRollSchedList->pList, 
                                 SchedFullCmpFunc);
}

int CPceDataMgr::PceDataPreProcess()
{
    int nRet;
    int nSchedCount;
    PCE_DATA * pPceData;

    if (NULL == m_pRollSchedList)
    {
        return ERR_FAILED;
    }
    nSchedCount = DoubleList_GetCount(m_pRollSchedList->pList);

    for (int i = 0; i < nSchedCount; i++)
    {
        pPceData = (PCE_DATA *) DoubleList_GetAt(m_pRollSchedList->pList,i);

        if (pPceData->nFinishROllStraStatus == 0)
        {
            nRet = PceData_DefaultFmStra(pPceData);
            if (nRet == ERR_FAILED)
            {
                return ERR_FAILED;
            }

            pPceData->nFinishROllStraStatus = 1; //����pdi�ĳ�ʼ���������趨���
        }
        
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::GetPdiForCalc(CString strStripNo,
                               HRS_PLAN_DATA *pPlanData)
{
    PCE_DATA *pPceData;
    int nRet;

    if (pPlanData == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_GetPdiForCalc(pPceData, pPlanData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::GetRmStraDataForCalc(CString strStripNo,
                                      HRS_RM_STRATEGY_DATA *pRmStraData)
{
    PCE_DATA *pPceData;
    int nRet;

    if (pRmStraData == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_GetRmStraDataForCalc(pPceData, pRmStraData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::GetFmStraDataForCalc(CString strStripNo,
                         HRS_FM_STRATEGY_DATA *pFmStraData)
{
    PCE_DATA *pPceData;
    int nRet;
    
    if (pFmStraData == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_GetFmStraDataForCalc(pPceData, pFmStraData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::SetFmSchedCalcFromCalc(CString strStripNo,
                                        HRS_FM_ALL_OUT_DATA *pAllOutData)
{
    PCE_DATA *pPceData;
    int nRet;
    
    if (pAllOutData == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_SetFmSchedCalcFromCalc(pPceData, pAllOutData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::SetFmSchedCalcFromCalc(CString strStripNo,
                           HRS_FM_SCHED *pFMSched)
{
    PCE_DATA *pPceData;
    int nRet;

    if (pFMSched == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_SetFmSchedCalcFromCalc(pPceData, pFMSched);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}


int CPceDataMgr::SetRmSchedCalcFromCalc(CString strStripNo,
                           HRS_RM_SCHED *pRMSched, 
                           HRS_ALL_STAND_PARA *pAllStandPara)
{
    PCE_DATA *pPceData;
    int nRet;
    
    if (pRMSched == NULL)
    {
        return ERR_FAILED;
    }

    pPceData = SearchPceDataByStripNo(strStripNo);
    if (pPceData == NULL)
    {
        return ERR_FAILED;
    }

    // 
    nRet = PceData_SetRmSchedCalcFromCalc(pPceData, pRMSched, pAllStandPara);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    return ERR_SUCCESS;
}

int PceData_GetSlabForCalc(PCE_DATA *pCurPceData, HRS_L1_RM_SCHED &RMGUISched)
{
    if (NULL == pCurPceData)
    {
        return ERR_FAILED;
    }

    HRS_ROLL_SCHED *pRollSched;

    pRollSched = &pCurPceData->stRollSched;

    strncpy(RMGUISched.SlabData.szStripNo, pRollSched->strSTRIP_NO, HRS_MAX_STRIP_NO_LEN);
    RMGUISched.SlabData.szStripNo[HRS_MAX_STRIP_NO_LEN - 1] = '\0';

    strncpy(RMGUISched.SlabData.szGrade, pRollSched->strGRADE, HRS_MAX_GRADE_LEN);
    RMGUISched.SlabData.szGrade[HRS_MAX_GRADE_LEN - 1] = '\0';

    strncpy(RMGUISched.SlabData.szSteelGradeName, 
            pRollSched->strGRADE, 
            HRS_MAX_GRADE_LEN);
    RMGUISched.SlabData.szSteelGradeName[HRS_MAX_GRADE_LEN - 1] = '\0';

    RMGUISched.SlabData.nSteelGradeCode = pRollSched->nSFC;
    RMGUISched.SlabData.dSlabGauge      = pRollSched->fS_H;
    RMGUISched.SlabData.dSlabWidth      = pRollSched->fS_W;
    RMGUISched.SlabData.dSlabLen        = pRollSched->fS_L;

    RMGUISched.dTargetGauge = pRollSched->fC_H;
    RMGUISched.dTargetWidth = pRollSched->fC_W;

    return ERR_SUCCESS;
}


int PceData_GetPdiForCalc(PCE_DATA *pPceData, 
                          HRS_PLAN_DATA *pPlanData)
{
    HRS_ROLL_SCHED *pRollSched;

    pRollSched = &pPceData->stRollSched;

    strncpy(pPlanData->SlabData.szStripNo, pRollSched->strSTRIP_NO, HRS_MAX_STRIP_NO_LEN);
    pPlanData->SlabData.szStripNo[HRS_MAX_STRIP_NO_LEN - 1] = '\0';

    strncpy(pPlanData->SlabData.szGrade, pRollSched->strGRADE, HRS_MAX_GRADE_LEN);
    pPlanData->SlabData.szGrade[HRS_MAX_GRADE_LEN - 1] = '\0';

    strncpy(pPlanData->SlabData.szSteelGradeName, 
        pRollSched->strGRADE, 
        HRS_MAX_GRADE_LEN);
    pPlanData->SlabData.szSteelGradeName[HRS_MAX_GRADE_LEN - 1] = '\0';

    pPlanData->SlabData.nSteelGradeCode = pRollSched->nSFC;
    pPlanData->SlabData.dSlabGauge      = pRollSched->fS_H;
    pPlanData->SlabData.dSlabWidth      = pRollSched->fS_W;
    pPlanData->SlabData.dSlabLen        = pRollSched->fS_L;

    //��ѧ�ɷֲ���

    pPlanData->nSequentialNo    = pRollSched->nSEQ;
    pPlanData->dTargetGauge     = pRollSched->fC_H;
    pPlanData->dTargetWidth     = pRollSched->fC_W;
    pPlanData->nFMDescCode      = pRollSched->nFSB;
    pPlanData->dTransferBarGauge = pRollSched->fR_H;
    pPlanData->nRMDescCode      = pRollSched->nRSB;
    pPlanData->dAdditionalWidth = pRollSched->fWT;
    pPlanData->dSlabeWeight     = pRollSched->fWE;
    pPlanData->dFMDeliveryTemp  = pRollSched->fFDT;
    pPlanData->dDischargeTemp   = pRollSched->fEXT;
    pPlanData->nQualityCode     = pRollSched->nQUAL;
    pPlanData->nSteelPoistionNo = pRollSched->nSTA;
    pPlanData->dRMDeliveryTemp  = pRollSched->fRDT;
    pPlanData->dCoilTemp        = pRollSched->fCTC;
    pPlanData->nCoolingCode     = pRollSched->nHTT;
    pPlanData->nCoolingType     = pRollSched->nCP;
    pPlanData->dStripCrown      = pRollSched->fCROWN;

    return ERR_SUCCESS;
}


int PceData_GetRmStraDataForCalc(PCE_DATA *pPceData, 
                                 HRS_RM_STRATEGY_DATA *pRmStraData)
{
    HRS_ROUGHROLL_STRA *pRoughRollStra;
    int R1PassCount;
    int R2PassCount;

    //int nPassModeIndex;

    //nPassModeIndex = pPceData->stRMStraData.nCurPassModeIndex;

    /*HRS_ROUGHROLL_STRA_DATA *pRMStraData;
    HRS_ROUGHROLL_STRA      *pRMStra;*/

    /*pRMStraData = &(pPceData->stRMStraData);
    pRMStra     = &(pRMStraData->aAllPassModeStra[nPassModeIndex]);*/

    pRoughRollStra = &pPceData->stRoughRollStra;
    //pRoughRollStra = pRMStra;

    R1PassCount = pRoughRollStra->emPassMode / 10;
    R2PassCount = pRoughRollStra->emPassMode % 10;

    pRmStraData->rm_adjust_HSB.dThickDraftAdjust 
        = pRoughRollStra->stHSB.fDeltaDraftValue; 
    pRmStraData->rm_adjust_HSB.dWidthAdjust
        = pRoughRollStra->stHSB.fWidth_Cor;
    pRmStraData->rm_adjust_HSB.dSpeedAdjust
        = pRoughRollStra->stHSB.fSpeed_Cor;
    pRmStraData->rm_adjust_HSB.nSprayState
        = pRoughRollStra->stHSB.emSprayMode;

    for (int i = 0; i < R1PassCount; i++)
    {
        pRmStraData->rm_adjust_R1[i].dThickDraftAdjust 
            = pRoughRollStra->stRoughRollStraR1[i].fDeltaDraftValue; 
        pRmStraData->rm_adjust_R1[i].dWidthAdjust
            = pRoughRollStra->stRoughRollStraR1[i].fWidth_Cor;
        pRmStraData->rm_adjust_R1[i].dWidth
            = pRoughRollStra->stRoughRollStraR1[i].fWidth;

        pRmStraData->rm_adjust_R1[i].dSpeedAdjust
            = pRoughRollStra->stRoughRollStraR1[i].fSpeed_Cor;
        pRmStraData->rm_adjust_R1[i].nSprayState
            = pRoughRollStra->stRoughRollStraR1[i].emSprayMode;

        pRmStraData->rm_adjust_R1[i].dDraftRatio    
            = pRoughRollStra->stRoughRollStraR1[i].fDraft;
        pRmStraData->rm_adjust_R1[i].dDeliveryGauge 
            = pRoughRollStra->stRoughRollStraR1[i].fThick_Exit;
    }

    for (int i = 0; i < R2PassCount; i++)
    {
        pRmStraData->rm_adjust_R2[i].dThickDraftAdjust 
            = pRoughRollStra->stRoughRollStraR2[i].fDeltaDraftValue; 
        pRmStraData->rm_adjust_R2[i].dWidthAdjust
            = pRoughRollStra->stRoughRollStraR2[i].fWidth_Cor;
        pRmStraData->rm_adjust_R2[i].dWidth
            = pRoughRollStra->stRoughRollStraR2[i].fWidth;

        pRmStraData->rm_adjust_R2[i].dSpeedAdjust
            = pRoughRollStra->stRoughRollStraR2[i].fSpeed_Cor;
        pRmStraData->rm_adjust_R2[i].nSprayState
            = pRoughRollStra->stRoughRollStraR2[i].emSprayMode;

        pRmStraData->rm_adjust_R2[i].dDraftRatio    
            = pRoughRollStra->stRoughRollStraR2[i].fDraft;
        pRmStraData->rm_adjust_R2[i].dDeliveryGauge 
            = pRoughRollStra->stRoughRollStraR2[i].fThick_Exit;
    }

    pRmStraData->dTransferBarThick  = pRoughRollStra->fRm_Exit_Thick;
    pRmStraData->bTransferBarThick_Auto = pRoughRollStra->bRm_Exit_Thick_Auto;
    pRmStraData->nMillUseStateE1    = pRoughRollStra->bStand_Dummy_E1;
    pRmStraData->nMillUseStateR1    = pRoughRollStra->bStand_Dummy_R1;
    pRmStraData->nMillUseStateE2    = pRoughRollStra->bStand_Dummy_E2;
    pRmStraData->nPassMode          = pRoughRollStra->emPassMode;

    return ERR_SUCCESS;
}


int PceData_GetFmStraDataForCalc(PCE_DATA *pPceData, 
                                 HRS_FM_STRATEGY_DATA *pFmStraData)
{
    HRS_FINISHROLL_STRA *pFinishRollStra;

    pFinishRollStra = &pPceData->stFinishRollStra; 

    //memcpy(pFmStraData, pFinishRollStra, sizeof(HRS_FM_STRATEGY_DATA));

    pFmStraData->FMStraData.dTransferBarThick = pFinishRollStra->FinishRollStraData.fBarThick;
    pFmStraData->FMStraData.dTransferBarWidth = pFinishRollStra->FinishRollStraData.fBarWidth;
    pFmStraData->FMStraData.dTransferBarTemp = pFinishRollStra->FinishRollStraData.fBarTemp;
    pFmStraData->FMStraData.dFMEntryTemp = pFinishRollStra->FinishRollStraData.fFET;
    pFmStraData->FMStraData.dFMThickAdjust = pFinishRollStra->FinishRollStraData.fThickCorr;
    pFmStraData->FMStraData.dTempAccelator = pFinishRollStra->FinishRollStraData.fACC1;
    pFmStraData->FMStraData.dMaxRollSpeed = pFinishRollStra->FinishRollStraData.fMaxSpeed;
    pFmStraData->FMStraData.dThreadSpeed = pFinishRollStra->FinishRollStraData.fThreadSpeed;
    pFmStraData->FMStraData.dPowerAccelator = pFinishRollStra->FinishRollStraData.fACC2;
    pFmStraData->FMStraData.bE3Dummy = pFinishRollStra->FinishRollStraData.bE3Dummy;
    pFmStraData->FMStraData.bE3OffsetAuto = pFinishRollStra->FinishRollStraData.bE3Offset;
    pFmStraData->FMStraData.dE3Offset = pFinishRollStra->FinishRollStraData.fE3Offset;

    for (int i = 0; i < HRS_MAX_FM_STAND_NUM; i++)
    {
        pFmStraData->FMLoadData.bStandDummy[i] = pFinishRollStra->FinishRollLoadData.bStandDummy[i];
        pFmStraData->FMLoadData.adLoadValue[i] = pFinishRollStra->FinishRollLoadData.fLoadValue[i];
        pFmStraData->FMLoadData.adLoadCorr[i] = pFinishRollStra->FinishRollLoadData.fLoadCorr[i];
    }

    pFmStraData->bFFMode            = pFinishRollStra->bFF_USE;
    pFmStraData->emFDTCMode         = pFinishRollStra->emFDTCMode;

    pFmStraData->bISCCloseF34       = pFinishRollStra->bISCCloseF34;
    pFmStraData->bISCCloseF45       = pFinishRollStra->bISCCloseF45;
    pFmStraData->bISCCloseF56       = pFinishRollStra->bISCCloseF56;
    pFmStraData->bISCCloseF67       = pFinishRollStra->bISCCloseF67;

    pFmStraData->bDESCAuto          = pFinishRollStra->bDESCAuto;
    pFmStraData->nSprayCode         = pFinishRollStra->nSprayCod;


    return ERR_SUCCESS;
}


int PceData_SetFmSchedCalcFromCalc(PCE_DATA *pPceData, 
                                   HRS_FM_ALL_OUT_DATA *pAllOutData)
{
    HRS_FINISHROLL_SCHED *pFinishRollSched;

    pFinishRollSched = & pPceData->stFinishRollSched;

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {

        pFinishRollSched->PreCalcDataF[i].fHEntry 
            = pAllOutData->aFMOutData[i].dEntryGauge;

        pFinishRollSched->PreCalcDataF[i].fHExit 
            = pAllOutData->aFMOutData[i].dDeliveryGauge;

        pFinishRollSched->PreCalcDataF[i].fRF 
            = pAllOutData->aFMOutData[i].dRollingForce;

        pFinishRollSched->PreCalcDataF[i].fGAP
            = pAllOutData->aFMOutData[i].dGap;

        pFinishRollSched->PreCalcDataF[i].nTqrque
            = pAllOutData->aFMOutData[i].dTorque;

        pFinishRollSched->PreCalcDataF[i].fPower
            = pAllOutData->aFMOutData[i].dPower;

        pFinishRollSched->PreCalcDataF[i].fV
            = pAllOutData->aFMOutData[i].dSpeed;

        pFinishRollSched->PreCalcDataF[i].nENT
            = pAllOutData->aFMOutData[i].dTempPair.dEntryTemp;

        pFinishRollSched->PreCalcDataF[i].nEXT
            = pAllOutData->aFMOutData[i].dTempPair.dDeliveryTemp;

        pFinishRollSched->PreCalcDataF[i].fRED
            = pAllOutData->aFMOutData[i].dDraftRatio;

        pFinishRollSched->PreCalcDataF[i].nKM
            = pAllOutData->aFMOutData[i].dDeformResist;

        pFinishRollSched->PreCalcDataF[i].fFS
            = pAllOutData->aFMOutData[i].dForwardSlip;
    }

    return ERR_SUCCESS;
}


int PceData_SetFmSchedCalcFromCalc(PCE_DATA *pPceData, 
                                   HRS_FM_SCHED *pFMSched)
{
    double dBs;  // ��ϵ��
    double dFs;  // ǰ��ϵ��
    double dDeliveryGauge;
    double dEntryGauge;

    HRS_FINISHROLL_SCHED *pFinishRollSched;

    pFinishRollSched = & pPceData->stFinishRollSched;

    

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        pFinishRollSched->PreCalcDataF[i].fHEntry 
            = pFMSched->PreCalcDataF[i].fEntryGauge;

        pFinishRollSched->PreCalcDataF[i].fHExit 
            = pFMSched->PreCalcDataF[i].fDeliveryGauge;

        pFinishRollSched->PreCalcDataF[i].fRF 
            = pFMSched->PreCalcDataF[i].fRollingForce;

        pFinishRollSched->PreCalcDataF[i].fGAP
            = pFMSched->PreCalcDataF[i].fGap;

        pFinishRollSched->PreCalcDataF[i].nTqrque
            = pFMSched->PreCalcDataF[i].fTorque;

        pFinishRollSched->PreCalcDataF[i].fPower
            = pFMSched->PreCalcDataF[i].fPower;

        pFinishRollSched->PreCalcDataF[i].fV
            = pFMSched->PreCalcDataF[i].fSpeed;

        pFinishRollSched->PreCalcDataF[i].nENT
            = pFMSched->PreCalcDataF[i].fEnterTemp;

        pFinishRollSched->PreCalcDataF[i].nEXT
            = pFMSched->PreCalcDataF[i].fDeliveryTemp;

        pFinishRollSched->PreCalcDataF[i].fRED
            = pFMSched->PreCalcDataF[i].fDraftRatio;

        pFinishRollSched->PreCalcDataF[i].nKM
            = pFMSched->PreCalcDataF[i].fDeformResist;

        pFinishRollSched->PreCalcDataF[i].fFS
            = pFMSched->PreCalcDataF[i].fForwardSlip;

        // �����ϵ��
        dFs = pFMSched->PreCalcDataF[i].fForwardSlip;
        dDeliveryGauge = pFMSched->PreCalcDataF[i].fDeliveryGauge;
        dEntryGauge    = pFMSched->PreCalcDataF[i].fEntryGauge;
        dBs = dDeliveryGauge / dEntryGauge;
        dBs *= (1 + dFs);

        double dRatio = dEntryGauge - dDeliveryGauge;
        dRatio /= pFMSched->PreCalcDataF[i].fWorkingRollerRadius;
        dRatio /= 1000.0;  //  ���������뾶��λ����ת���ɺ���

        dRatio = sqrt(dRatio);
        dRatio = cos(dRatio);

        dBs = dBs / dRatio;

        //dBs = 1.0 - dBs;

        pFinishRollSched->PreCalcDataF[i].fBS = dBs;
     
        pFinishRollSched->PreCalcDataF[i].fTension   = pFMSched->PreCalcDataF[i].fTension;
        pFinishRollSched->PreCalcDataF[i].fLooperDis = pFMSched->PreCalcDataF[i].fLooperDis;

    }

    return ERR_SUCCESS;
}


int PceData_SetL1AveCalcFromCalc(PCE_DATA *pPceData, HRS_L1_SIMULATE_ALL_AVEDATA &AveData)
{
    if (NULL == pPceData)
    {
        return ERR_FAILED;
    }

    memcpy(&pPceData->stAveData, &AveData, sizeof(HRS_L1_SIMULATE_ALL_AVEDATA));

    return ERR_SUCCESS;
}


int PceData_SetRmSchedCalcFromCalc(PCE_DATA *pPceData, 
                                   HRS_RM_SCHED *pRMSched,
                                   HRS_ALL_STAND_PARA *pAllStandPara)
{
    HRS_ROUGHROLL_SCHED *pRoughRollSched;
    HRS_RM_SCHEDCALC_ONEPASS *pSourcePassSched;
    HRS_ROUGHROLL_SCHEDCALC_PASS *pPassSched;

    double dMaxPower;

    pPceData->stRoughRollSched.emCurPassMode = pRMSched->emPassMode;

    pRoughRollSched = &(pPceData->stRoughRollSched);

    pSourcePassSched = pRMSched->SchedCalcPassR1;
    pPassSched = pRoughRollSched->SchedCalcPassR1;
    
    if ( pAllStandPara != NULL )
    {
        dMaxPower = pAllStandPara->aEquipPara[HRS_STAND_NO_RM1].dMaxPower;
    }
    else
    {
        dMaxPower = 100.0;
    }

    dMaxPower /= 100.0;

    for (int i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++)
    {
        pPassSched[i].fRGAP  = pSourcePassSched[i].fMillerGap;
        pPassSched[i].fRD    = pSourcePassSched[i].fMillerDraft;
        pPassSched[i].fBAR_H = pSourcePassSched[i].fDeliveryGauge;
        pPassSched[i].nR_RF  = pSourcePassSched[i].fMillerForce;
        pPassSched[i].fSPD   = pSourcePassSched[i].fRollingSpeed;
        pPassSched[i].nR_TOR = pSourcePassSched[i].nMillerTorque;

        pPassSched[i].fBAR_W = pSourcePassSched[i].fDeliveryWidth;
        pPassSched[i].fBAR_L = pSourcePassSched[i].fDeliveryLength;

        pPassSched[i].fR_POW = pSourcePassSched[i].fRollingPower;
        pPassSched[i].fR_ET = pSourcePassSched[i].fDeliveryTemp;

        pPassSched[i].fEffic = pPassSched[i].fR_POW / dMaxPower;

        //pPassSched[i].nEGAP  = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fED    = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fE_W   = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fBAR_W = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fBAR_L = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fE_RF  = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fEffic = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fR_POW = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].nDESC  = pSourcePassSched[i].nMillerTorque;
        //pPassSched[i].fE_TOR = pSourcePassSched[i].nMillerTorque;
    }

    pSourcePassSched = pRMSched->SchedCalcPassR2;
    pPassSched = pRoughRollSched->SchedCalcPassR2;
    if ( pAllStandPara != NULL )
    {
        dMaxPower = pAllStandPara->aEquipPara[HRS_STAND_NO_RM2].dMaxPower;
    }
    else
    {
        dMaxPower = 100.0;
    }

    dMaxPower /= 100.0;

    for (int i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++)
    {
        pPassSched[i].fRGAP  = pSourcePassSched[i].fMillerGap;
        pPassSched[i].fRD    = pSourcePassSched[i].fMillerDraft;
        pPassSched[i].fBAR_H = pSourcePassSched[i].fDeliveryGauge;
        pPassSched[i].nR_RF  = pSourcePassSched[i].fMillerForce;
        pPassSched[i].fSPD   = pSourcePassSched[i].fRollingSpeed;
        pPassSched[i].nR_TOR = pSourcePassSched[i].nMillerTorque;

        pPassSched[i].fBAR_W = pSourcePassSched[i].fDeliveryWidth;
        pPassSched[i].fBAR_L = pSourcePassSched[i].fDeliveryLength;
        pPassSched[i].fR_POW = pSourcePassSched[i].fRollingPower;
        pPassSched[i].fR_ET = pSourcePassSched[i].fDeliveryTemp;

        pPassSched[i].fEffic = pPassSched[i].fR_POW / dMaxPower;
    }

    pPceData->stRoughRollStra.nIsHaveData    = 1;

    int nIndex = pRMSched->nR2ndPassNum - 1;

    float fRMExitTemp = pRMSched->SchedCalcPassR2[nIndex].fDeliveryTemp;
    float fRMExitThick = pRMSched->SchedCalcPassR2[nIndex].fDeliveryGauge;
    float fRMExitWidth = pRMSched->SchedCalcPassR2[nIndex].fDeliveryWidth;

    pPceData->stRoughRollSched.dTransferBarGauge = fRMExitThick;
    pPceData->stRoughRollSched.dTransferBarTemp  = fRMExitTemp;
    pPceData->stRoughRollSched.dTransferBarWidth = fRMExitWidth;

    pPceData->stRoughRollStra.fRm_Exit_Thick = fRMExitThick;
    pPceData->stRoughRollStra.fRMExitTemp    = fRMExitTemp;
    pPceData->stRoughRollStra.fRMExitWidth   = fRMExitWidth;

    return ERR_SUCCESS;
}


// �����ǰ���η���ģʽ�еĲ��������е�����ֵ
void PceData_ClearStraDataCor(PCE_DATA  *pPceData)
{
    HRS_ROUGHROLL_STRA_DATA  *pRMStraData;
    HRS_ROUGHROLL_STRA       *pRMStra;
    HRS_ROUGHROLL_STRA       *pOrgStra;

    int nPassModeIndex;
    int i;
    int k;

    if ( pPceData == NULL )
    {
        return;
    }

    pRMStraData = &(pPceData->stRMStraData);

    nPassModeIndex = pRMStraData->nCurPassModeIndex;

    if ( nPassModeIndex < 0 
        || nPassModeIndex >= HRS_RM_DRAFT_NUM_MAX )
    {
        return;
    }

    for ( i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++ )
    {
        pRMStra = &(pRMStraData->aAllPassModeStra[i]);
        pOrgStra = &(pRMStraData->aOrgStra[i]);

        pRMStra->stHSB.emSprayMode = pOrgStra->stHSB.emSprayMode;

        for ( k = 0; k < HRS_ROUGHROLL_R1_PASS_MAX; k++ )
        {
            pOrgStra->stRoughRollStraR1[k].fDraftCor        = 0;
            pOrgStra->stRoughRollStraR1[k].fDeltaDraftValue = 0;
            pOrgStra->stRoughRollStraR1[k].fSpeed_Cor       = 0;
            pOrgStra->stRoughRollStraR1[k].fThick_Cor       = 0;

            pOrgStra->stRoughRollStraR1[k].fWidth_Cor       = 0;
        }

        for ( k = 0; k < HRS_ROUGHROLL_R2_PASS_MAX; k++ )
        {
            pOrgStra->stRoughRollStraR2[k].fDraftCor        = 0;
            pOrgStra->stRoughRollStraR2[k].fDeltaDraftValue = 0;
            pOrgStra->stRoughRollStraR2[k].fSpeed_Cor       = 0;
            pOrgStra->stRoughRollStraR2[k].fThick_Cor       = 0;

            pOrgStra->stRoughRollStraR2[k].fWidth_Cor       = 0;
        }

        memcpy(pRMStra, pOrgStra, sizeof(HRS_ROUGHROLL_STRA));
    }

    return;
}



int CPceDataMgr::SetSteelStatus(PCE_DATA *pPceData)
{
    if (NULL == pPceData)
    {
        return ERR_FAILED;
    }

    PCE_DATA *pCurPceData = NULL;
    pCurPceData = SearchPceDataByStripNo(pPceData->stRollSched.strSTRIP_NO);
    if (NULL == pCurPceData)
    {
        return ERR_FAILED;
    }

    pCurPceData->nRollSchedStatus = pPceData->nRollSchedStatus;
    pCurPceData->nRoughRollStraStatus = pPceData->nRoughRollStraStatus;
    pCurPceData->nRoughRollSchedStatus = pPceData->nRoughRollSchedStatus;
    pCurPceData->nFinishROllStraStatus = pPceData->nFinishROllStraStatus;
    pCurPceData->nFinishRollSchedStatus = pPceData->nFinishRollSchedStatus;
    pCurPceData->nRollingStatus = pPceData->nRollingStatus;
    pCurPceData->nRolledStatus = pPceData->nRolledStatus;

    return ERR_SUCCESS;
}


HRS_ROLLER_DATA*CPceDataMgr::SearchRolller(char *pszRollerName, 
                                           HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pszRollerName || NULL == pTotalRollerMgr)
    {
        return NULL;
    }

    HRS_ROLLER_DATA*pOneRoller = NULL;

    pOneRoller = HRS_SearchRolller(pszRollerName, 
                                   pTotalRollerMgr);

    return pOneRoller;
}



HRS_ROLLER_TOTAL_DATA_MGR *CPceDataMgr::LoadRollerDataMgr(char *pszFileName)
{
    if (NULL == pszFileName)
    {
        return NULL;
    }

    if (NULL == m_pTotalRollerMgr)
    {
        m_pTotalRollerMgr = HRS_TotalRollerDataMgr_Create();
        HRS_TotalRollerMgr_Load(pszFileName, m_pTotalRollerMgr);
    }

    if (NULL == m_pShowRollerMgr && NULL != m_pTotalRollerMgr)
    {
        m_pShowRollerMgr = HRS_ShowRollerDataMgr_Create(m_pTotalRollerMgr);
    }

    return m_pTotalRollerMgr;
}


int CPceDataMgr::SaveRollerDataMgr(char *pszRollerName)
{
    if (NULL == pszRollerName 
        || NULL == m_pShowRollerMgr 
        || NULL == m_pTotalRollerMgr)
    {
        return ERR_FAILED;
    }

    int nRet = HRS_TotalRollerDataMgr_Save(pszRollerName,
                                           m_pShowRollerMgr,
                                           m_pTotalRollerMgr);

    return nRet;
}



int CPceDataMgr::AddRollerDataMgr(int nRow,
                                  HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pTotalRollerMgr || nRow <=0)
    {
        return ERR_FAILED;
    }

    int nRet = HRS_TotalRollerDataMgr_Add(nRow, m_pShowRollerMgr, pTotalRollerMgr);

    return nRet;
}


int CPceDataMgr::DeletRollerDataMgr(int nRow,
                                    HRS_ROLLER_DATA_MGR *pRollerDataMgr,
                                    HRS_ROLLER_TOTAL_DATA_MGR *pTotalRollerMgr)
{
    if (NULL == pTotalRollerMgr || nRow <=0)
    {
        return ERR_FAILED;
    }

    int nRet = HRS_TotalRollerDataMgr_Delet(nRow, 
                                            pRollerDataMgr, 
                                            pTotalRollerMgr);

    return nRet;
}