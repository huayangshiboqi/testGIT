/*****************************************************************************/
/*                                                                           */
/* ��Ŀ���� ��                                       */
/* ��д��λ �� �Ϻ��ſؿƼ����޹�˾                                          */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ˵�� �� ����Ŀ�����ռ�����Դվ�㷢�͵����ݲ���ʾ�ʹ洢               */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/* ����˵�� �� ��ɫ��ť�ؼ�ʵ���ļ�                                          */
/*                                                                           */
/*****************************************************************************/
/* ��    �� �� ��Ҷ               ��������  ��2012-09-14                     */
/*****************************************************************************/
/*                                 �޸ļ�¼                                  */
/*                                                                           */
/* �޸����� ��2012-09-17        ** �� �� �� �� �� Ҷ                         */
/* �޸����� ��                                                               */
/*          1.��ʽ                                                           */
/*          2.���ӻ�ȡ��ɫ�Ƚӿ�                                             */
/*                                                                           */
/*****************************************************************************/
/* �� �� �� ��                  ** ������� ��                               */
/*****************************************************************************/
/* �ļ��汾�� ��1.0                                                          */
/*****************************************************************************/

#include "stdafx.h"

#include "_CColorButton.h"

//#include "MacroDefine.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

// no automatic class substitution for this file!
#ifdef _CColorButton
#undef _CColorButton      _CColorButton
#endif

// _CColorButton
IMPLEMENT_DYNAMIC(_CColorButton, CButton)

_CColorButton::_CColorButton() 
{  
#if (_MFC_VER < 0x0250)
  // initialize hwndOwner for GetOwner() and SetOwner() support in MFC < 2.5
  hwndOwner = NULL;
#endif

    m_bevel             = 2;

    m_clfFrontGround    = RGB(192, 192, 192);
    m_clfBackGround     = RGB(1, 1, 1);
    m_clfDisableColor   = RGB(245, 244, 234);
} 


_CColorButton::~_CColorButton()
{
}

BOOL _CColorButton::Attach(const UINT       nID,
                           CWnd*            pParent,
                           const COLORREF   BGColor,
                           const COLORREF   FGColor,
                           const COLORREF   DisabledColor,
                           const UINT       nBevel)
{
    if(!SubclassDlgItem(nID, pParent))
    {
        return FALSE;
    }

    m_bevel             = nBevel;
    m_clfBackGround     = BGColor;
    m_clfFrontGround    = FGColor;
    m_clfDisableColor   = DisabledColor;

    return TRUE;
}

void _CColorButton::DrawItem(LPDRAWITEMSTRUCT lpDIS)
{
    CDC* pDC = CDC::FromHandle(lpDIS->hDC);

    UINT state = lpDIS->itemState;

    CRect focusRect, btnRect;

    focusRect.CopyRect(&lpDIS->rcItem); 

    btnRect.CopyRect(&lpDIS->rcItem); 

    /*
     * ���ý����
     */
    focusRect.left      += 4;
    focusRect.right     -= 4;
    focusRect.top       += 4;
    focusRect.bottom    -= 4;

    /*
     * ���ñ���
     */
    const int bufSize   = 512;

    TCHAR buffer[bufSize];

    GetWindowText(buffer, bufSize);

    /*
     * ���Ʊ�ǩ
     */
    DrawFilledRect(pDC, btnRect, GetBGColor());

    DrawFrame(pDC, btnRect, GetBevel());

    DrawButtonText(pDC, btnRect, buffer, GetFGColor());

    /*
     * ���ư��°�ťʱ��ʾ��
     */
    if(state & ODS_FOCUS)
    {
        DrawFocusRect(lpDIS->hDC, (LPRECT)&focusRect);

        if(state & ODS_SELECTED)
        {
            DrawFilledRect(pDC, btnRect, GetBGColor()); 

            DrawFrame(pDC, btnRect, -1);

            DrawButtonText(pDC, btnRect, buffer, GetFGColor());

            DrawFocusRect(lpDIS->hDC, (LPRECT)&focusRect);
        }
    }
    else if(state & ODS_DISABLED)
    {
        DrawFilledRect(pDC, btnRect, GetDisabledColor());

        DrawFrame(pDC, btnRect, GetBevel());

        DrawButtonText(pDC, btnRect, buffer, ::GetSysColor(COLOR_3DSHADOW));
    }
}

void _CColorButton::DrawFrame(CDC *pDC, CRect rc, int Inset)
{ 
    int         i;
    int         m;
    int         width;

    COLORREF    dark;
    COLORREF    light;
    COLORREF    tlColor;
    COLORREF    brColor;

    if(NULL == pDC)
    {
        return;
    }

    width = (Inset < 0)? - Inset : Inset;

    for(i =  0; i < width; ++i)
    {
        m       = 255 / (i + 2);

        dark    =  PALETTERGB(m, m, m);

        m       =  192 + (63 / (i + 1));

        light   =  PALETTERGB(m, m, m);
          
        if(1 == width)
        {
            light   = RGB(255, 255, 255);
            dark    = RGB(128, 128, 128);
        }
        
        if(Inset < 0)
        {
            tlColor = dark;
            brColor = light;
        }
        else 
        {
            tlColor = light;
            brColor = dark;
        }
        
        /*
         * �ϱ���
         */
        DrawLine(pDC, rc.left, rc.top, rc.right, rc.top, tlColor);

        /*
         * �����
         */
        DrawLine(pDC, rc.left, rc.top, rc.left, rc.bottom, tlColor);
      
        if((Inset < 0) && (i == width - 1) && (width > 1))
        {
            /*
             * �ұ���
             */
            DrawLine(pDC,
                     rc.left + 1,
                     rc.bottom - 1,
                     rc.right,
                     rc.bottom - 1,
                     RGB(1, 1, 1));

            /*
             * �ױ���
             */
            DrawLine(pDC,
                     rc.right - 1,
                     rc.top + 1,
                     rc.right - 1,
                     rc.bottom,
                     RGB(1, 1, 1));    // Down right
        }
        else
        {
            /*
             * �ױ���
             */
            DrawLine(pDC,
                     rc.left + 1,
                     rc.bottom - 1,
                     rc.right, rc.bottom - 1, brColor);

            /*
             * �ױ���
             */
            DrawLine(pDC,
                     rc.right - 1,
                     rc.top + 1,
                     rc.right - 1,
                     rc.bottom,
                     brColor);
        }

        InflateRect(rc, -1, -1);
    }
}

void _CColorButton::DrawFilledRect(CDC *pDC, CRect rc, COLORREF color)
{ 
    CBrush      brush;                           /* ��ˢ                     */

    if(NULL == pDC)
    {
        return;
    }

    brush.CreateSolidBrush(color);

    pDC->FillRect(rc, &brush);

    brush.DeleteObject();
}

void _CColorButton::DrawLine(CDC *pDC, CRect EndPoints, COLORREF color)
{ 
    CPen        pen;                             /* ����                     */
    CPen        *pOldPen;                        /* ����ָ��                 */

    if(NULL == pDC)
    {
        return;
    }

    pen.CreatePen(PS_SOLID, 1, color);

    pOldPen = pDC->SelectObject(&pen);

    pDC->MoveTo(EndPoints.left,  EndPoints.top);
    pDC->LineTo(EndPoints.right, EndPoints.bottom);

    pDC->SelectObject(pOldPen);

    pen.DeleteObject();
}

void _CColorButton::DrawLine(CDC *       pDC,
                             long        left,
                             long        top,
                             long        right,
                             long        bottom,
                             COLORREF    color)
{
    CPen        pen;                             /* ����                     */
    CPen        *pOldPen;                        /* ����ָ��                 */

    if(NULL == pDC)
    {
        return;
    }

    pen.CreatePen(PS_SOLID, 1, color);

    pOldPen = pDC->SelectObject(&pen);

    pDC->MoveTo(left,  top);
    pDC->LineTo(right, bottom);

    pDC->SelectObject(pOldPen);

    pen.DeleteObject();
}

void _CColorButton::DrawButtonText(CDC          *pDC,
                                   CRect        rc,
                                   const char   *pBuf,
                                   COLORREF     clrText)
{
    if((NULL == pDC) || (NULL == pBuf))
    {
        return;
    }

    COLORREF prevColor = pDC->SetTextColor(clrText);

    pDC->SetBkMode(TRANSPARENT);

    pDC->DrawText(pBuf,
                  (int)strlen(pBuf),
                  rc,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    pDC->SetTextColor(prevColor);
}

BEGIN_MESSAGE_MAP(_CColorButton, CButton)
END_MESSAGE_MAP()
