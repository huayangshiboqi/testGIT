/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ����  ��  ���ֹ����Զ���    **  ��д��λ ��  �Ϻ��ſؿƼ����޹�˾    */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ˵�� ��  ����Ŀ���������ֹ����Զ�������                              */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ����˵��  ��  ���ļ�ΪͼƬ��ť��ʵ��                                     */
/*                                                                           */
/*****************************************************************************/
/*  ��    ��  ��                    **  ��������  ��  2009-12-14             */
/*****************************************************************************/
/*                              �޸ļ�¼                                     */
/*                                                                           */
/*  �޸�����     **     �޸���      **      �޸�����                         */
/*                                                                           */
/*****************************************************************************/
/*  ��  ��  �ˣ�                         **    �������  ��                  */
/*****************************************************************************/
/*  �ļ��汾�ţ�0.0.1                                                        */
/*****************************************************************************/

// ButtonCtrl.cpp : implementation file


#include "stdafx.h"
#include "ButtonCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CButtonCtrl

CButtonCtrl::CButtonCtrl()
{
    m_bHover = FALSE;
    m_bTracking = FALSE;

    m_crColors[BTNST_COLOR_BK_IN]       = ::GetSysColor(COLOR_BTNFACE);
    m_crColors[BTNST_COLOR_FG_IN]       = ::GetSysColor(COLOR_BTNTEXT);
    m_crColors[BTNST_COLOR_BK_OUT]      = ::GetSysColor(COLOR_BTNFACE);
    m_crColors[BTNST_COLOR_FG_OUT]      = ::GetSysColor(COLOR_BTNTEXT);
    m_crColors[BTNST_COLOR_BK_FOCUS]    = ::GetSysColor(COLOR_BTNFACE);
    m_crColors[BTNST_COLOR_FG_FOCUS]    = ::GetSysColor(COLOR_BTNTEXT);

    m_clrBkStart    = RGB(220, 214, 194);
    m_clrBkEnd      = RGB(215, 214, 215);
    m_clrFaceStart  = RGB(215, 215, 215);
    m_clrFaceEnd    = RGB(126, 123, 114);

    m_clrTextStart  = RGB(0, 255, 0)/*RGB(72,72, 71)*/;
    m_clrTextEnd    = m_clrTextStart/*RGB(216, 215, 210)*/;
}

CButtonCtrl::~CButtonCtrl()
{
}
IMPLEMENT_DYNAMIC(CButtonCtrl, CBitmapButton)

BEGIN_MESSAGE_MAP(CButtonCtrl, CBitmapButton)
    //{{AFX_MSG_MAP(CButtonCtrl)
    //ON_WM_MOUSEMOVE()
    //ON_MESSAGE(WM_MOUSELEAVE, OnMouseLeave)
    //ON_MESSAGE(WM_MOUSEHOVER, OnMouseHover)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////
 //    CHoverButton message handlers
        
void CButtonCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
    //    TODO: Add your message handler code here and/or call default

    if (!m_bTracking)
    {
        TRACKMOUSEEVENT tme;
        tme.cbSize = sizeof(tme);
        tme.hwndTrack = m_hWnd;
        tme.dwFlags = TME_LEAVE|TME_HOVER;
        tme.dwHoverTime = 1;
        m_bTracking = _TrackMouseEvent(&tme);
    }
    
    CBitmapButton::OnMouseMove(nFlags, point);
}

BOOL CButtonCtrl::PreTranslateMessage(MSG* pMsg) 
{
    // TODO: Add your specialized code here and/or call the base class
    InitToolTip();
    m_ToolTip.RelayEvent(pMsg);
    return CButton::PreTranslateMessage(pMsg);
}

// Set the tooltip with a string resource
void CButtonCtrl::SetToolTipText(int nId, BOOL bActivate)
{
    CString sText;

    // load string resource
    sText.LoadString(nId);
    // If string resource is not empty
    if (sText.IsEmpty() == FALSE) SetToolTipText(&sText, bActivate);

}

// Set the tooltip with a CString
void CButtonCtrl::SetToolTipText(CString *spText, BOOL bActivate)
{
    // We cannot accept NULL pointer
    if (spText == NULL) return;

    // Initialize ToolTip
    InitToolTip();

    // If there is no tooltip defined then add it
    if (m_ToolTip.GetToolCount() == 0)
    {
        CRect rectBtn; 
        GetClientRect(rectBtn);
        m_ToolTip.AddTool(this, (LPCTSTR)*spText, rectBtn, 1);
    }

    // Set text for tooltip
    m_ToolTip.UpdateTipText((LPCTSTR)*spText, this, 1);
    m_ToolTip.Activate(bActivate);
}

void CButtonCtrl::InitToolTip()
{
    if (m_ToolTip.m_hWnd == NULL)
    {
        // Create ToolTip control
        m_ToolTip.Create(this);
        // Create inactive
        m_ToolTip.Activate(FALSE);
    }
} // End of InitToolTip

// Activate the tooltip
void CButtonCtrl::ActivateTooltip(BOOL bActivate)
{
    // If there is no tooltip then do nothing
    if (m_ToolTip.GetToolCount() == 0) return;

    // Activate tooltip
    m_ToolTip.Activate(bActivate);
} // End of EnableTooltip


void CButtonCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
    CDC     *dc = CDC::FromHandle(lpDrawItemStruct->hDC);

    CString cstrTitle;

    CRect   rc(lpDrawItemStruct->rcItem);
    CRect   rect = rc;

    CPen    pen1(PS_SOLID, 0, RGB(226, 222, 203));  // ����ߵ�һ������
    CPen    pen2(PS_SOLID, 0, RGB(248, 247, 242));  // ��ײ���һ������
    CPen    pen3;
    CPen    pen4;

    CPen    *pOldPen(NULL);

    COLORREF    bkColorStart    = m_clrBkStart;
    COLORREF    bkColorEnd      = m_clrBkEnd;
    COLORREF    FaceColorStart  = m_clrFaceStart;
    COLORREF    FaceColorEnd    = m_clrFaceEnd;
    COLORREF    TextColorStart  = m_clrTextStart;
    COLORREF    TextColorEnd    = m_clrTextEnd;

    COLORREF    bkColor = dc->GetPixel(rc.right-1, rc.top);    // mydc

    /*
     * �жϰ�ť�Ƿ����,����Բ�ǻ���
     */
    if(lpDrawItemStruct->itemState & ODS_DISABLED)
    {
        pen3.CreatePen(PS_SOLID, 0, RGB(216, 213, 199));    // Բ�Ǿ���(4,4)
        pen4.CreatePen(PS_SOLID, 0, RGB(201, 199, 186));    // Բ�Ǿ���(6,6)
    }
    else
    {
        pen3.CreatePen(PS_SOLID, 0, RGB(122, 149, 168));    // Բ�Ǿ���(4,4)
        pen4.CreatePen(PS_SOLID, 0, RGB(0, 60, 116) );      // Բ�Ǿ���(6,6)
    }

    int nSaveDC = dc->SaveDC();
    dc->SelectStockObject(NULL_BRUSH);

    /*
     * ������ߵ�һ�����ߺ���ײ���һ������
     */
    if(!(lpDrawItemStruct->itemState & ODS_DISABLED))
    {
        pOldPen = dc->SelectObject(&pen1);
        dc->MoveTo(rc.left, rc.top+1);
        dc->LineTo(rc.left, rc.bottom-1);
        dc->SelectObject(pOldPen);

        pOldPen = dc->SelectObject(&pen2);
        dc->MoveTo(rc.left+2, rc.bottom-1);
        dc->LineTo(rc.right-1, rc.bottom-1);
        dc->SelectObject(pOldPen);
    }

    /*
     * ����ײ㱳��
     */
    TRIVERTEX       vert[2];
    GRADIENT_RECT   gRect;

    vert[0].y      = rect.top;
    vert[0].x      = rect.left+1;
    vert[0].Red    = COLOR16(COLOR16(GetRValue(bkColorStart)) << 8);
    vert[0].Green  = COLOR16(COLOR16(GetGValue(bkColorStart)) << 8);
    vert[0].Blue   = COLOR16(COLOR16(GetBValue(bkColorStart)) << 8);
    vert[0].Alpha  = 0x0000;

    vert[1].y      = rect.bottom-1;
    vert[1].x      = rect.right;
    vert[1].Red    = COLOR16(COLOR16(GetRValue(bkColorEnd)) << 8);
    vert[1].Green  = COLOR16(COLOR16(GetGValue(bkColorEnd)) << 8);
    vert[1].Blue   = COLOR16(COLOR16(GetBValue(bkColorEnd)) << 8);
    vert[1].Alpha  = 0xFF00;

    gRect.UpperLeft  = 0;
    gRect.LowerRight = 1;
    if(!(lpDrawItemStruct->itemState & ODS_DISABLED))
    {
        GradientFill(dc->GetSafeHdc(),
                     vert,
                     2,
                     &gRect,
                     1,
                     GRADIENT_FILL_RECT_V);
    }

    if(lpDrawItemStruct->itemState & ODS_FOCUS)
    {
        FaceColorStart  = RGB(206, 231, 255);
        FaceColorEnd    = RGB(105, 130, 238);
        rect = rc;
        rect.DeflateRect(2, 0, 0, 0);
    }

    if(!(lpDrawItemStruct->itemState & ODS_DISABLED))
    {
        pOldPen = dc->SelectObject(&pen1);
        dc->MoveTo(rc.left, rc.top + 1);
        dc->LineTo(rc.left, rc.bottom - 1);
        dc->SelectObject(pOldPen);

        pOldPen = dc->SelectObject(&pen2);
        dc->MoveTo(rc.left + 2, rc.bottom - 1);
        dc->LineTo(rc.right - 1, rc.bottom - 1);
        dc->SelectObject(pOldPen);
    }

    if(lpDrawItemStruct->itemState & ODS_DISABLED)
    {
        FaceColorStart  = RGB(245, 244, 234);
        FaceColorEnd    = FaceColorStart;

        TextColorStart  = FaceColorStart;
        TextColorEnd    = FaceColorStart;

        rect = rc;
        rect.DeflateRect(2, 0, 0, 0);
    }
    else if(lpDrawItemStruct->itemState & ODS_SELECTED) // button down
    {
        FaceColorStart  = RGB(109, 204, 193);
        FaceColorEnd    = RGB(142, 241, 238);

        TextColorStart  = RGB(229, 228, 221);
        TextColorEnd    = RGB(226, 226, 218);

        rect = rc;
        rect.DeflateRect(2, 0, 0, 0);
    }
    else
    {
        if(m_bHover)  // button hover
        {
            FaceColorStart  = RGB(255, 240, 207);
            FaceColorEnd    = RGB(229, 151, 0);
            rect = rc;
            rect.DeflateRect( 2, 0, 0, 0 );
        }
        else  // button normal
        {
            ;
        }
    }

    /*
     * �� BUTTON �ڲ��������򱳾�
     */
    vert[0].y      = rc.top  + 2;
    vert[0].x      = rc.left + 2;
    vert[0].Red    = COLOR16(COLOR16(GetRValue(FaceColorStart)) << 8);
    vert[0].Green  = COLOR16(COLOR16(GetGValue(FaceColorStart)) << 8);
    vert[0].Blue   = COLOR16(COLOR16(GetBValue(FaceColorStart)) << 8);

    vert[1].y      = rc.bottom - 2 ;
    vert[1].x      = rc.right  - 2;
    vert[1].Red    = COLOR16(COLOR16(GetRValue(FaceColorEnd)) << 8);
    vert[1].Green  = COLOR16(COLOR16(GetGValue(FaceColorEnd)) << 8);
    vert[1].Blue   = COLOR16(COLOR16(GetBValue(FaceColorEnd)) << 8);

    GradientFill(dc->GetSafeHdc(), vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V);

    /*
     * �� BUTTON �ڲ���Ч���򱳾�
     */
    vert[0].y      = rect.top  + 3;
    vert[0].x      = rect.left + 2;
    vert[0].Red    = COLOR16(COLOR16(GetRValue(TextColorStart)) << 8);
    vert[0].Green  = COLOR16(COLOR16(GetGValue(TextColorStart)) << 8);
    vert[0].Blue   = COLOR16(COLOR16(GetBValue(TextColorStart)) << 8);

    vert[1].y      = rect.bottom - 3;
    vert[1].x      = rect.right  - 3;
    vert[1].Red    = COLOR16(COLOR16(GetRValue(TextColorEnd)) << 8);
    vert[1].Green  = COLOR16(COLOR16(GetGValue(TextColorEnd)) << 8);
    vert[1].Blue   = COLOR16(COLOR16(GetBValue(TextColorEnd)) << 8);

    GradientFill(dc->GetSafeHdc(), vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V);

    if(lpDrawItemStruct->itemState & ODS_FOCUS)
    {    
        rect = rc;
        rect.DeflateRect( 3, 3 );
        dc->DrawFocusRect( rect );
    }

    /*
     * ����Բ�����
     */
    rect = rc;
    rect.DeflateRect(1, 1);

    pOldPen = dc->SelectObject(&pen3);
    dc->RoundRect(rect, CPoint(4, 4));
    dc->SelectObject(pOldPen);

    pOldPen = dc->SelectObject(&pen4);
    dc->RoundRect(rect, CPoint(6, 6));
    dc->SelectObject(pOldPen);

    /*
     * ȥ�����ϽǵĶ����
     */
    dc->SetPixel(rc.right-1, rc.top, bkColor);

    dc->RestoreDC(nSaveDC);

    /*mydc->BitBlt(rc.left,
                 rc.top,
                 rc.Width(),
                 rc.Height(),
                 dc,
                 rc.left,
                 rc.top,
                 SRCCOPY);*/

    // �����ı�
    GetWindowText(cstrTitle);

    CRect centerRect = rc;
    dc->DrawText(cstrTitle, -1, rc, DT_WORDBREAK | DT_CENTER | DT_CALCRECT);
    rc.OffsetRect((centerRect.Width()  - rc.Width())  / 2,
                  (centerRect.Height() - rc.Height()) / 2);


    dc->SetBkMode(TRANSPARENT);

    if (lpDrawItemStruct->itemState & ODS_DISABLED)
    {
        rc.OffsetRect(1, 1);
        dc->SetTextColor(::GetSysColor(COLOR_3DHILIGHT));
        dc->DrawText(cstrTitle, -1, rc, DT_WORDBREAK | DT_CENTER);

        rc.OffsetRect(-1, -1);
        dc->SetTextColor(::GetSysColor(COLOR_3DSHADOW));
        dc->DrawText(cstrTitle, -1, rc, DT_WORDBREAK | DT_CENTER);
    } // if
    else
    {
        if (lpDrawItemStruct->itemState & ODS_SELECTED) 
        {
            dc->SetTextColor(m_crColors[BTNST_COLOR_FG_IN]);
            dc->SetBkColor(m_crColors[BTNST_COLOR_BK_IN]);
        } // if
        else 
        {
            dc->SetTextColor(m_crColors[BTNST_COLOR_FG_OUT]);
            dc->SetBkColor(m_crColors[BTNST_COLOR_BK_OUT]);
        } // else
        dc->DrawText(cstrTitle, -1, rc, DT_WORDBREAK | DT_CENTER);
    } // if

    pen3.DeleteObject();
    pen4.DeleteObject();

    // clean up
    //delete dc;
}

// Load a bitmap from the resources in the button, 
// the bitmap has to have 3 buttonsstates next to each other: Up/Down/Hover
BOOL CButtonCtrl::LoadBitmap(UINT bitmapid)
{
    mybitmap.Attach(::LoadImage(::AfxGetInstanceHandle(),
                    MAKEINTRESOURCE(bitmapid), IMAGE_BITMAP,0,0,
                    LR_LOADMAP3DCOLORS|LR_LOADTRANSPARENT));
    BITMAP    bitmapbits;
    mybitmap.GetBitmap(&bitmapbits);
    m_ButtonSize.cy=bitmapbits.bmHeight;
    m_ButtonSize.cx=bitmapbits.bmWidth/4;  // Modified by PRAS ���Ӱ�ť����ͼƬ
    SetWindowPos(NULL, 0, 0, m_ButtonSize.cx,m_ButtonSize.cy,
                 SWP_NOMOVE | SWP_NOOWNERZORDER);
    return TRUE;
}



LRESULT CButtonCtrl::OnMouseHover(WPARAM wparam, LPARAM lparam) 
{
    // TODO: Add your message handler code here and/or call default
    m_bHover = TRUE;
    Invalidate();
    return 0;
}


LRESULT CButtonCtrl::OnMouseLeave(WPARAM wparam, LPARAM lparam)
{
    m_bTracking = FALSE;
    m_bHover = FALSE;
    Invalidate();
    return 0;
}

/*****************************************************************************/
/*                  CButtonCtrl::_SetFont ʵ��                               */
/*****************************************************************************/
/*
@fn _SetFont
@brief
    �����ı�����
@arg [in] lHight
    const long,����ĸ߶�
@arg [in] bBold
    const bool,����Ӵ�
@return
    ����ֵ��ʾ�����Ƿ�ɹ�
@remark
@see CButtonCtrl
@*/
bool CButtonCtrl::_SetFont(const long lHight, const bool bBold)
{
    /*
     *  ��������
     */
    LOGFONT lfRef;

    /*
     *  �ж϶����Ƿ��Ѵ���
     */
    if (m_hWnd == NULL)
    {
        return false;
    }

    /*
     *  ����Ѿ��������������
     */
    if (m_fontText.GetSafeHandle())
    {
        if (!m_fontText.DeleteObject())
        {
            return false;
        }
    }

    /*
     *  ��������ĸ߶Ⱥ��Ƿ�Ӵ�
     */
    CFont* pFont = GetFont();
    pFont->GetLogFont(&lfRef);

    lfRef.lfHeight  = lHight;

    if (bBold)
    {
        lfRef.lfWeight = FW_BOLD;
    }
    else
    {
        lfRef.lfWeight = FW_NORMAL;
    }

    m_fontText.CreateFontIndirect(&lfRef);

    /*
     *  �����ɹ����������ı�����
     */
    if (m_fontText.GetSafeHandle())
    {
        SetFont(&m_fontText);
    }
    else
    {
        return false;
    }

    return true;
}

/*****************************************************************************/
/*                    CButtonCtrl::_SetTextBkColor ʵ��                      */
/*****************************************************************************/
/*
@fn _SetFont
@brief
    �����ı�������ɫ
@arg [in] _clrStart
    COLORREF,��ʼ��λ��ɫ
@arg [in] _clrEnd
    COLORREF,������λ��ɫ
@return
    ����ֵ��ʾ�����Ƿ�ɹ�
@remark
@see CButtonCtrl
@*/
bool CButtonCtrl::_SetTextBkColor(COLORREF _clrStart, COLORREF _clrEnd)
{
    if(   (m_clrTextStart == _clrStart)
       && (m_clrTextEnd   == _clrEnd))
    {
        return false;
    }

    m_clrTextStart = _clrStart;
    m_clrTextEnd   = _clrEnd;

    Invalidate();

    return true;
}

