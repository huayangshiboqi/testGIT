/*****************************************************************************/
/*                                                                           */
/*  ��Ŀ˵�� ��  ����Ŀ���������ֹ����Զ������ƵĽ��濪��                    */
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*  ����˵�� ��  ��װ��״ͼ��ʽ��static�ؼ�                                  */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/
/*  ��    �� ���ѫ                **  ��������  ��  2015-10-31            */
/*****************************************************************************/
/*                              �޸ļ�¼                                     */
/*                                                                           */
/*    �޸��� ��                      **  �޸����� ��                         */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/
/*          �� �� �� ��                         **  �������  ��             */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

/*****************************************************************************/
/*                              ͷ  ��  ��                                   */
/*****************************************************************************/


#include "stdafx.h"
#include "RwStatic.h"

/** Method: CRwStatic
    ���캯��
@*/
CRwStatic::CRwStatic()
{
    // Init our vars.
    m_dMaxData    =10000;
    m_dRealData   = 1500;
    m_clBackColor =RGB(255,0,0);
}

/** Method:  ~CRwStatic
    ��������
@*/
CRwStatic::~CRwStatic()
{
}


BEGIN_MESSAGE_MAP(CRwStatic, CStatic)
    //{{AFX_MSG_MAP(CRwStatic)
    ON_WM_ERASEBKGND()
    ON_WM_PAINT()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/**  Method:  OnEraseBkgnd
    ����OnEraseBkgnd����������static��ʽ
    @param  CDC* pDC
    @return BOOL �ɹ�����ture
*/
BOOL CRwStatic::OnEraseBkgnd(CDC* pDC) 
{
    CBrush Newbrush;
    CPen pen;
    CBrush brush;
    CPen Newpen;
    CRect rect;
    CBrush *pBrush;
    CPen *pPen;
    /*
     * ���֮ǰ��ɫ
     */
    GetClientRect(&rect);
    rect.bottom -= 1;
    rect.top += 1;
    rect.left += 1;
    rect.right -= 1;

   // brush.CreateSolidBrush(m_clBackColor);
   // pen.CreatePen(PS_SOLID,3,m_clBackColor);

   // pBrush = pDC->SelectObject(&brush);
   // pPen = pDC->SelectObject(&pen);
   // pDC->Rectangle(rect);
   ///*
   // * �滻���ͷ���Դ
   // */
   // pDC->SelectObject(pBrush);
   // pDC->SelectObject(pen);
    /*
     * ��������ɫ�����
     */
    Newbrush.CreateSolidBrush(m_clBackColor);
    Newpen.CreatePen(PS_SOLID,3,m_clBackColor);

    pBrush = pDC->SelectObject(&Newbrush);

    pPen = pDC->SelectObject(&Newpen);

    /*if (m_dMaxData >= m_dRealData)
    {
        rect.top=rect.bottom * (long)(1-m_dRealData/m_dMaxData);
    }*/

    rect.bottom -= 1;
    rect.top += 1;
    rect.left -= 2;
    rect.right += 2;

    pDC->Rectangle(rect);
    
    pDC->SelectObject(pBrush);
    pDC->SelectObject(pPen);

    return TRUE;
}

/**  Method:  OnPaint
    ����OnPaint����
    @return    void
*/
void CRwStatic::OnPaint() 
{
    CPaintDC dc(this);

    // TODO: Add your message handler code here
}

/**  Method:  SetBkColor
    �������ɫ
    @return    void
*/
void CRwStatic::_vSetBkColor(COLORREF clBkColor)
{
    m_clBackColor = clBkColor;
    Invalidate();
    return;
}


/**  Method:  SetRealData
    ������ʵֵ
    @return    void
*/
void CRwStatic::_vSetRealData(double dRealData)
{
    m_dRealData = dRealData;
    Invalidate();
    return;
}

/**  Method:  SetMaxData
    �������ֵ
    @return    void
*/
void CRwStatic::_vSetMaxData(double dMaxData)
{
    m_dMaxData = dMaxData;
    Invalidate();
    return;
}


void CRwStatic::_vSetPos(int x, int y, int nWidth, int nHeight)
{
    //m_hWnd = GetSafeHwnd();
    MoveWindow(x, y, nWidth, nHeight, TRUE);

    return;
}

