//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HRSGui.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_VIEW_ROUGHROLLSCHEM         101
#define IDD_VIEW_ROLLSCHEM              102
#define IDD_VIEW_NAVIG                  103
#define IDD_VIEW_FINISHROLL_STRA        105
#define IDD_VIEW_GHOSTROLL              107
#define IDD_VIEW_ROLLER_DATA            108
#define IDD_VIEWTITLE                   109
#define IDD_VIEWRIGHT                   110
#define IDD_AVE_CLAC                    111
#define IDR_MAINFRAME                   128
#define IDR_HRSGuiTYPE                  129
#define IDB_BITMAP_LOGO                 133
#define IDB_BITMAP1                     134
#define IDB_BITMAP2                     135
#define IDC_BUT_ROLL_SCHEM              1003
#define IDC_GRIDCTRL_ROLLSCHEM          1006
#define IDC_BUT_SC_ADD                  1007
#define IDC_BUT_SC_DEL                  1008
#define IDC_BUT_SC_IMPORT               1009
#define IDC_BUT_SC_SAVE                 1010
#define IDC_BUT_SC_MOVEUP               1011
#define IDC_BUT_SC_MOVEDOWN             1012
#define IDC_EDIT_SC_STRIPNO_SEARCH      1013
#define IDC_BUT_SC_SEARCH               1014
#define IDC_GRID_ROUGHROLL_STRATEGY     1015
#define IDC_VR_ROLL                     1016
#define IDC_COMB_RRSTRA_STRIPNO         1017
#define IDC_RAD_PASSMODE_AUTO           1018
#define IDC_BUT_ROUGHROLL_SCHEM3        1019
#define IDC_BUT_ROUGHROLL_SCHEM4        1020
#define IDC_BUT_ROUGHROLL_SCHEM5        1021
#define IDC_BUT_NAVIG_EXIT              1022
#define IDC_RAD_PASSMODE_15             1023
#define IDC_RAD_PASSMODE_33             1024
#define IDC_RAD_PASSMODE_35             1025
#define IDC_CHECK_RRS_E1                1026
#define IDC_CHECK_RRS_R1                1027
#define IDC_CHECK_RRS_E2                1028
#define IDC_CHECK_RRS_RMEXITTHICK       1029
#define IDC_EDIT_RRS_EMEXITTHICK        1030
#define IDC_RAD_PASSMODE_17             1031
#define IDC_RAD_PASSMODE_05             1032
#define IDC_BUT_ROUGHROLL_SCHED         1033
#define IDC_GRID_FINISHROLL_STRA_DATA   1034
#define IDC_COMB_FM_STRIPNO             1035
#define IDC_GRID_FM_LOADDATA            1036
#define IDC_CHECK_FDTC_FF_USE           1037
#define IDC_RAD_FDTC_SPEED              1038
#define IDC_RAD_FDTC_WATER              1039
#define IDC_CHECK_DESC_AUTO             1040
#define IDC_COMB_DESC_SPRAY_COD         1041
#define IDC_CHECK_ISC_F34               1042
#define IDC_CHECK_ISC_F45               1043
#define IDC_CHECK_ISC_F56               1044
#define IDC_CHECK_ISC_F67               1045
#define IDC_CHECK1                      1046
#define IDC_RADIO1                      1047
#define IDC_RADIO2                      1048
#define IDC_CUSTOM2                     1049
#define IDC_RAD_PASSMODE_13             1050
#define IDC_RAD_PASSMODE_07             1051
#define IDC_BUT_ROUGHROLL_SCHEM2        1052
#define IDC_GRID_GR_FM_PRECALC          1053
#define IDC_BUT_ROUGHROLL_CALC          1054
#define IDC_BUT_ROLLER_DATA             1055
#define IDC_GRID_GR_RM_SCHEDCALC        1056
#define IDC_GRID_GR_FM_PRECALC_BASIC    1057
#define IDC_GRID_GR_PDI                 1058
#define IDC_EDIT_STRIP_NO               1059
#define IDC_BUT_SAVE_TOMEM              1060
#define IDC_BUT_RM_STRA_SAVE            1061
#define IDC_BUT_FM_STRA_SAVE            1062
#define IDC_BUT_FM_STRA_CLEAN           1064
#define IDC_GRIDCTRL_RM_PDI             1066
#define IDC_GRIDCTRL_RM_SCHEDCALC       1067
#define IDC_BUT_RM_STRA_CALC            1068
#define IDC_GRID_FM_STRA_PDI            1069
#define IDC_GRID_FM_STRA_PRECALC_SCHED  1070
#define IDC_BUT_FM_STRA_CALC            1071
#define IDC_RM_CLEAR_SET                1072
#define IDC_FMS_SIMULATION_CLAC         1073
#define IDC_FM_SIMULATION_CLAC          1074
#define IDC_STAC_LOGO                   1075
#define IDC_GRIDCTRL_ROLLER_DATA        1077
#define IDC_SAVEROLLER                  1078
#define IDC_BUT_ADDROLLER               1079
#define IDC_BUT_DELEROLLER              1080
#define IDC_TITLE                       1081
#define IDC_GRIDCTRL_ROLLER_DATA2       1082
#define IDC_EDIT1                       1082
#define IDC_EDIT_EXT_TEMP               1082
#define IDC_CHECK_REMOTE                1083
#define IDC_FM_CHECK_REMOTE             1084
#define IDC_STEEL                       1085
#define IDC_TITLE_PART                  1086
#define IDC_STATIC_AVE                  1087
#define IDC_BUT_ROUGHROLL_SCHEM         1170
#define IDC_STAC_TIME                   1364
#define IDC_CURRENT_USER                1365
#define IDC_CURRENT_STATE               1365

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1088
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
