#pragma once

#include "ButtonCtrl.h"


// CViewNavig ������ͼ

class CViewNavig : public CFormView
{
    DECLARE_DYNCREATE(CViewNavig)

protected:
    CViewNavig();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
    virtual ~CViewNavig();

public:
    enum { IDD = IDD_VIEW_NAVIG };
#ifdef _DEBUG
    virtual void AssertValid() const;
#ifndef _WIN32_WCE
    virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

    afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

    DECLARE_MESSAGE_MAP()

private:
    CBrush          m_CBrushDlgBG;              /* �Ի��򱳾��Ļ�ˢ          */
    CBrush          m_CBrushEditBG;             /* �ı��򱳾��Ļ�ˢ          */

    CButtonCtrl     m_butRollSchem;             /* ���̼�ؽ���򿪰�ť      */
    CButtonCtrl     m_butRoughRollStra;             /* ���̼�ؽ���򿪰�ť      */
    //CButtonCtrl     m_butRoughRollSched;
    CButtonCtrl     m_butFinishRollStra;
    /*CButtonCtrl     m_butFinishRollSched;*/
    CButtonCtrl     m_butGhostRoll;
    CButtonCtrl     m_butRollerData;

    CButtonCtrl     m_butExit;


    afx_msg void OnBnClickedButRollSchem();     //  ��ؽ��水ť
    afx_msg void OnBnClickedButRoughRollSchem();     //  ��ؽ��水ť

    //  ���ܷ�����Ϣ
    bool _SendMessageToFrm(int iMesId, WPARAM wParam = 0L,LPARAM lParam = 0L);


public:
    virtual void OnInitialUpdate();
    //afx_msg void OnBnClickedButRoughrollSched();
    afx_msg void OnBnClickedButFinishRoll();
    //afx_msg void OnBnClickedButRoughrollSchem4();
    afx_msg void OnBnClickedButGhostRoll();
    afx_msg void OnBnClickedButRollerData();

    afx_msg void OnBnClickedButNavigExit();

    bool _SetButtonEnable(int iViewId);
    bool _SetButtonDisable(int iViewId);
    bool _SetButtonState(int iViewId);

private:
    int     m_iCurViewId;
    afx_msg void OnTimer(UINT_PTR nIDEvent);
    CString m_strCurTime;
    afx_msg void OnStnClickedCurrentUser();
    CString m_strCurState;
};


