#pragma once

#define HRS_TIMER_AVE_ID          2

// CAveClacDialog �Ի���

class CAveClacDialog : public CDialog
{
	DECLARE_DYNAMIC(CAveClacDialog)

public:
	CAveClacDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CAveClacDialog();

// �Ի�������
	enum { IDD = IDD_AVE_CLAC };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

    //afx_msg void OnTimer(UINT_PTR nIDEvent);

public:
    CString m_strMesg;

    int m_nTimes;

public:
    afx_msg void OnTimer(UINT_PTR nIDEvent);
};
