// ViewFinishRollSched.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewFinishRollSched.h"

#include "WinCommon.h "
#include "NG_errno.h" 
#include "NG_malloc.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "HRS_EquipParaMgr.h"
#include "HRS_FMCalc.h"


// CViewFinishRollSched

IMPLEMENT_DYNCREATE(CViewFinishRollSched, CFormView)

CViewFinishRollSched::CViewFinishRollSched()
    : CFormView(CViewFinishRollSched::IDD)
{
    m_pCurPceData = NULL;
}

CViewFinishRollSched::~CViewFinishRollSched()
{
}

void CViewFinishRollSched::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_GridControl(pDX, IDC_GRID_FM_PDI, m_GridFinishRollPDI);
    DDX_GridControl(pDX, IDC_GRID_FM_PRECALC, m_GridFinishRollPreCalcBasic);
    DDX_GridControl(pDX, IDC_GRID_FM_PRECALC_SCHED, m_GridFinishRollPreCalc);
}

BEGIN_MESSAGE_MAP(CViewFinishRollSched, CFormView)
    ON_NOTIFY(NM_CLICK, IDC_GRID_FM_PDI, OnGridFinishRollPDIClick)
    ON_BN_CLICKED(IDC_BUT_FM_SCHEDCALC, &CViewFinishRollSched::OnBnClickedButFmSchedcalc)
END_MESSAGE_MAP()


// CViewFinishRollSched ���

#ifdef _DEBUG
void CViewFinishRollSched::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewFinishRollSched::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewFinishRollSched ��Ϣ��������


void CViewFinishRollSched::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GridCtrlInit();

}

void CViewFinishRollSched::GridCtrlInit()
{
    int                 iCol; 
    int                 iColNumber;  
    

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridFinishRollPDI.SetListMode(TRUE);
        m_GridFinishRollPDI.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridFinishRollPDI.SetModified(FALSE);

        m_GridFinishRollPDI.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridFinishRollPDI.SetFixedRowCount(1);
        m_GridFinishRollPDI.SetFixedColumnCount(1); 
        m_GridFinishRollPDI.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridFinishRollPDI.SetItem(&Item);
    }

    m_GridFinishRollPDI.AutoSize();


    
#define M_T(x) #x
    const char* pszTitle2[]  = { HRS_FM_PRECALC_BASICDATA_LIST , "\0" };
    const char* pszUnit2[]   = { HRS_FM_PRECALC_BASICDATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FM_PRECALC_BASICDATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridFinishRollPreCalcBasic.SetListMode(TRUE);
        m_GridFinishRollPreCalcBasic.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridFinishRollPreCalcBasic.SetModified(FALSE);

        m_GridFinishRollPreCalcBasic.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridFinishRollPreCalcBasic.SetFixedRowCount(1);
        //m_GridFinishRollPreCalcBasic.SetFixedColumnCount(1); 
        m_GridFinishRollPreCalcBasic.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle2[iCol],pszUnit2[iCol]);

        m_GridFinishRollPreCalcBasic.SetItem(&Item);
    }

    m_GridFinishRollPreCalcBasic.AutoSize();


    
    
#define M_T(x) #x
    const char* pszTitle3[]  = { HRS_FM_PRECALC_DATA_LIST , "\0" };
    const char* pszUnit3[]   = { HRS_FM_PRECALC_DATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_FM_PRECALC_DATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridFinishRollPreCalc.SetListMode(TRUE);
        m_GridFinishRollPreCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridFinishRollPreCalc.SetModified(FALSE);

        m_GridFinishRollPreCalc.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridFinishRollPreCalc.SetFixedRowCount(1);
        //m_GridFinishRollPreCalc.SetFixedColumnCount(1); 
        m_GridFinishRollPreCalc.SetEditable(TRUE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle3[iCol],pszUnit3[iCol]);

        m_GridFinishRollPreCalc.SetItem(&Item);
    }

    m_GridFinishRollPreCalc.AutoSize();


    return;
}

void CViewFinishRollSched::InitGridPDI()
{

    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    m_GridFinishRollPDI.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridFinishRollPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridFinishRollPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                | DT_VCENTER
                | DT_SINGLELINE
                | DT_END_ELLIPSIS;

            switch (j)
            { 
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.2f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridFinishRollPDI.SetItem(&Item);
        }
    }

    m_GridFinishRollPDI.Refresh();

    return;
}


void CViewFinishRollSched::OnGridFinishRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridFinishRollPDI.GetFixedRowCount() )
    {
        return;
    }

    itemStr = m_GridFinishRollPDI.GetItemText(nRow, 1);

    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(itemStr);

    RefreshFinishRollSchedGrid();

    UpdateData(FALSE);
}

void CViewFinishRollSched::RefreshFinishRollSchedGrid()
{
    char strHeading[5]={0};
    int  RowCount;

    m_GridFinishRollPreCalcBasic.DeleteNonFixedRows();
    RowCount = m_GridFinishRollPreCalcBasic.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridFinishRollPreCalcBasic.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_PRECALC_BASICDATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_PRECALC_BASICDATA_STRIP_NO :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_FM_PRECALC_BASICDATA_RH2 :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRH2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RW2 :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRW2);
            break;
        case HRS_FM_PRECALC_BASICDATA_RL2 :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fRL2);
            break;
        case HRS_FM_PRECALC_BASICDATA_EXT_T :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fExtT);
            break;
        case HRS_FM_PRECALC_BASICDATA_FT0 :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fFT0);
            break;
        case HRS_FM_PRECALC_BASICDATA_LOADT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nLoadT);
            break;

        case HRS_FM_PRECALC_BASICDATA_SPRAY_C :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.nSprayC);
            break;
        case HRS_FM_PRECALC_BASICDATA_V :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fV);
            break;
        case HRS_FM_PRECALC_BASICDATA_VOUT :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVOut);
            break;
        case HRS_FM_PRECALC_BASICDATA_VMAX :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fVMax);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC1 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC1);
            break;
        case HRS_FM_PRECALC_BASICDATA_ACC2 :
            Item.strText.Format(_T("%6.3f"),m_pCurPceData->stFinishRollSched.PreCalcBasicData.fACC2);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridFinishRollPreCalcBasic.SetItem(&Item);

    }


    m_GridFinishRollPreCalcBasic.AutoSizeColumns();
    m_GridFinishRollPreCalcBasic.Refresh();


    //precalc

    m_GridFinishRollPreCalc.DeleteNonFixedRows();

    RowCount = m_GridFinishRollPreCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridFinishRollPreCalc.InsertRow(strHeading);

    for(int j = 0; j < HRS_FM_PRECALC_DATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_FM_PRECALC_DATA_STAND :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.strStand);
            break; 
        case HRS_FM_PRECALC_DATA_H_ENTRY :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHEntry);
            break;
        case HRS_FM_PRECALC_DATA_H_EXIT :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fHExit);
            break;
        case HRS_FM_PRECALC_DATA_RED :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRED);
            break;
        case HRS_FM_PRECALC_DATA_RF :
            Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fRF);
            break;
        case HRS_FM_PRECALC_DATA_GAP :
            Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fGAP);
            break;
        case HRS_FM_PRECALC_DATA_TQRQUE :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nTqrque);
            break;
        case HRS_FM_PRECALC_DATA_POWER :
            Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fPower);
            break;

        case HRS_FM_PRECALC_DATA_KM :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nKM);
            break;
        case HRS_FM_PRECALC_DATA_V :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fV);
            break;
        case HRS_FM_PRECALC_DATA_FLOW :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nFlow);
            break;
        case HRS_FM_PRECALC_DATA_ENT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nENT);
            break;
        case HRS_FM_PRECALC_DATA_EXT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nEXT);
            break;
        case HRS_FM_PRECALC_DATA_BEND :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nBend);
            break;
        case HRS_FM_PRECALC_DATA_SHIFT :
            Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.nShift);
            break;
        case HRS_FM_PRECALC_DATA_FS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fFS);
            break;
        case HRS_FM_PRECALC_DATA_BS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fBS);
            break;
        case HRS_FM_PRECALC_DATA_TENSION :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fTension);
            break;
        case HRS_FM_PRECALC_DATA_LOOPER_ANGLE :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fLooperAngle);
            break;
        case HRS_FM_PRECALC_DATA_LOOPER_DIS :
            Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataE3.fLooperDis);
            break;
        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridFinishRollPreCalc.SetItem(&Item);

    }

    for (int i = 0; i < HRS_FINISHMILL_NUM; i++)
    {
        RowCount = m_GridFinishRollPreCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridFinishRollPreCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_FM_PRECALC_DATA_STAND :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].strStand);
                break; 
            case HRS_FM_PRECALC_DATA_H_ENTRY :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHEntry);
                break;
            case HRS_FM_PRECALC_DATA_H_EXIT :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fHExit);
                break;
            case HRS_FM_PRECALC_DATA_RED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRED);
                break;
            case HRS_FM_PRECALC_DATA_RF :
                Item.strText.Format(_T("%8.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fRF);
                break;
            case HRS_FM_PRECALC_DATA_GAP :
                Item.strText.Format(_T("%7.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fGAP);
                break;
            case HRS_FM_PRECALC_DATA_TQRQUE :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nTqrque);
                break;
            case HRS_FM_PRECALC_DATA_POWER :
                Item.strText.Format(_T("%5.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fPower);
                break;

            case HRS_FM_PRECALC_DATA_KM :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nKM);
                break;
            case HRS_FM_PRECALC_DATA_V :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fV);
                break;
            case HRS_FM_PRECALC_DATA_FLOW :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nFlow);
                break;
            case HRS_FM_PRECALC_DATA_ENT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nENT);
                break;
            case HRS_FM_PRECALC_DATA_EXT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nEXT);
                break;
            case HRS_FM_PRECALC_DATA_BEND :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nBend);
                break;
            case HRS_FM_PRECALC_DATA_SHIFT :
                Item.strText.Format(_T("%d"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].nShift);
                break;
            case HRS_FM_PRECALC_DATA_FS :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fFS);
                break;
            case HRS_FM_PRECALC_DATA_BS :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fBS);
                break;
            case HRS_FM_PRECALC_DATA_TENSION :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fTension);
                break;
            case HRS_FM_PRECALC_DATA_LOOPER_ANGLE :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fLooperAngle);
                break;
            case HRS_FM_PRECALC_DATA_LOOPER_DIS :
                Item.strText.Format(_T("%4.2f"),m_pCurPceData->stFinishRollSched.PreCalcDataF[i].fLooperDis);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridFinishRollPreCalc.SetItem(&Item);

        }
    }

    m_GridFinishRollPreCalc.AutoSizeColumns();
    m_GridFinishRollPreCalc.Refresh();

    UpdateData(FALSE);
}
void CViewFinishRollSched::OnBnClickedButFmSchedcalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    int nRet;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
     AfxMessageBox("û��ѡ�����!");
     return;
    }
    strStipNo = m_pCurPceData->stRollSched.strSTRIP_NO;

    //
    // ��ȡGUI�������趨���ݸ�����
    //
    HRS_FM_ALL_DATA    HrsFmAllData;

    nRet = m_pRollSchedMgr->GetPdiForCalc(strStipNo, &HrsFmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return;
    }
    //m_pRollSchedMgr->GetRmStraDataForCalc(strStipNo, &HrsFmAllData.StrategyData);
    nRet = m_pRollSchedMgr->GetFmStraDataForCalc(strStipNo, &HrsFmAllData.FMStrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return;
    }


    //memcpy( &HrsFmAllData.PlateData.SlabeData, 
    //        &HrsFmAllData.PlanData.SlabData, 
    //        sizeof(HRS_SLAB_DATA));
    //HrsFmAllData.PlateData.dSlabeEntryTemp = 1600;                                  //����

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return;
    }

    pModule->GetAllStandPara(&HrsFmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(HrsFmAllData.DeformFactor.szSteelGrade, 
           HrsFmAllData.PlanData.SlabData.szSteelGradeName, 
           HRS_MAX_GRADE_LEN);
    HrsFmAllData.DeformFactor.dFactorA = 4.358254;                                         // ��������
    HrsFmAllData.DeformFactor.dFactorB = -1.526256;
    HrsFmAllData.DeformFactor.dFactorC = 0.580705;
    HrsFmAllData.DeformFactor.dFactorD = -0.351633;
    HrsFmAllData.DeformFactor.dFactorN = 0.025699;
    HrsFmAllData.DeformFactor.dReserve1 = 1;
    HrsFmAllData.DeformFactor.dReserve2 = 1;

    //��������
    HRS_FM_ALL_OUT_DATA pAllOutData;
    HRS_FM_SCHED pRMSched;
    nRet = HRS_FML2Calc_CalcAllData(&HrsFmAllData, &pAllOutData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("������̼������!");
        return;
    }
    nRet = HRS_FML2Calc_BuildSched(&HrsFmAllData, &pAllOutData, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("���ɾ�����̴���!");
        return;
    }

    //m_pRollSchedMgr->SetFmSchedCalcFromCalc(strStipNo, &pAllOutData);
    nRet = m_pRollSchedMgr->SetFmSchedCalcFromCalc(strStipNo, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������þ�����̴���!");
        return;
    }

    RefreshFinishRollSchedGrid();

    AfxMessageBox("������̼���ɹ�!");
    return;
}
