// RoughRollSched.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewRoughRollSched.h"

#include "WinCommon.h "
#include "NG_errno.h" 
#include "NG_malloc.h"

#include "GridBtnCell.h"
#include "GridBtnCellCombo.h"

#include "PceDataMgr.h"
#include "InterfaceMacro.h"

#include "HRS_EquipParaMgr.h"
#include "HRS_RMCalc.h"


// CViewRoughRollSched

IMPLEMENT_DYNCREATE(CViewRoughRollSched, CFormView)

CViewRoughRollSched::CViewRoughRollSched()
    : CFormView(CViewRoughRollSched::IDD)
{
    m_pCurPceData = NULL;
}

CViewRoughRollSched::~CViewRoughRollSched()
{
}

void CViewRoughRollSched::DoDataExchange(CDataExchange* pDX)
{
    CFormView::DoDataExchange(pDX);
    DDX_GridControl(pDX, IDC_GRIDCTRL_RRS_PDI, m_GridRoughRollPDI);
    DDX_GridControl(pDX, IDC_GRIDCTRL_RRS_BASICDATA, m_GridRoughRollBasicData);
    DDX_GridControl(pDX, IDC_GRIDCTRL_RRS_SCHEDCALC, m_GridRoughRollSchedCalc);
}

BEGIN_MESSAGE_MAP(CViewRoughRollSched, CFormView)
    ON_NOTIFY(NM_CLICK, IDC_GRIDCTRL_RRS_PDI, OnGridRoughRollPDIClick)
    ON_BN_CLICKED(IDC_BUT_RM_CALC, &CViewRoughRollSched::OnBnClickedButRmCalc)
END_MESSAGE_MAP()


// CViewRoughRollSched ���

#ifdef _DEBUG
void CViewRoughRollSched::AssertValid() const
{
    CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewRoughRollSched::Dump(CDumpContext& dc) const
{
    CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// CViewRoughRollSched ��Ϣ��������

void CViewRoughRollSched::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    GridCtrlInit();

}

void CViewRoughRollSched::GridCtrlInit()
{
        
    int                 iCol; 
    int                 iColNumber;  
    

#define M_T(x) #x
    const char* pszTitle[]  = { HRS_ROLLSCHED_LIST , "\0" };
    const char* pszUnit[]   = { HRS_ROLLSCHED_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROLL_SCHED_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRoughRollPDI.SetListMode(TRUE);
        m_GridRoughRollPDI.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRoughRollPDI.SetModified(FALSE);

        m_GridRoughRollPDI.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRoughRollPDI.SetFixedRowCount(1);
        m_GridRoughRollPDI.SetFixedColumnCount(1); 
        m_GridRoughRollPDI.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle[iCol],pszUnit[iCol]);

        m_GridRoughRollPDI.SetItem(&Item);
    }

    m_GridRoughRollPDI.AutoSize();
 


#define M_T(x) #x
    const char* pszTitle2[]  = { HRS_ROUGHROLL_SCHEDCALC_LIST , "\0" };
    const char* pszUnit2[]   = { HRS_ROUGHROLL_SCHEDCALC_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRoughRollSchedCalc.SetListMode(TRUE);
        m_GridRoughRollSchedCalc.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRoughRollSchedCalc.SetModified(FALSE);

        m_GridRoughRollSchedCalc.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRoughRollSchedCalc.SetFixedRowCount(1);
        m_GridRoughRollSchedCalc.SetFixedColumnCount(1); 
        m_GridRoughRollSchedCalc.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle2[iCol],pszUnit2[iCol]);

        m_GridRoughRollSchedCalc.SetItem(&Item);
    }

    m_GridRoughRollSchedCalc.AutoSize();




#define M_T(x) #x
    const char* pszTitle3[]  = { HRS_ROUGHROLL_BASICDATA_LIST , "\0" };
    const char* pszUnit3[]   = { HRS_ROUGHROLL_BASICDATA_UNIT_LIST , "\0" };
#undef  M_T

    /*
     * ������������������
     */
    try
    {
        iColNumber = HRS_ROUGHROLL_BASICDATA_ITEM_NUM;

        //m_GridRollSchem.SetGridStyle(GRID_BLUE);
        m_GridRoughRollBasicData.SetListMode(TRUE);
        m_GridRoughRollBasicData.SetTextBkColor(GRID_BG_COR);
        //m_GridRollSchem.SetBkColor(GRID_BG_COR);
        m_GridRoughRollBasicData.SetModified(FALSE);

        m_GridRoughRollBasicData.SetColumnCount(iColNumber);
        //m_GridRollSchem.SetRowCount(iColNumber);

        m_GridRoughRollBasicData.SetFixedRowCount(1);
        //m_GridRoughRollBasicData.SetFixedColumnCount(1); 
        m_GridRoughRollBasicData.SetEditable(FALSE); 
    }
    catch (CMemoryException *e)
    {
        e->ReportError();
        e->Delete();

        return;
    }

    /*
     * ��ʼ������ؼ��ı�ͷ,
     */
    for(iCol = 0; iCol < iColNumber/* - 1*/; iCol++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT ;
        Item.row        =  0;
        Item.col        =  iCol;
        Item.nFormat    =  DT_CENTER
                         | DT_VCENTER
                         | DT_SINGLELINE
                         | DT_END_ELLIPSIS;

        Item.strText.Format(_T("%s %s"),pszTitle3[iCol],pszUnit3[iCol]);

        m_GridRoughRollBasicData.SetItem(&Item);
    }

    m_GridRoughRollBasicData.AutoSize();







    return;
}




void CViewRoughRollSched::InitRollSchedGrid()
{
    MTLIST *    pRollSchedList;
    int         nRollSchedCount;

    pRollSchedList = m_pRollSchedMgr->GetRollSchedList();
    nRollSchedCount = DoubleList_GetCount(pRollSchedList->pList);

    m_GridRoughRollPDI.DeleteNonFixedRows();
    for (int i = 0; i < nRollSchedCount; i++)
    {
        char strHeading[5]={0};
        int  RowCount;
        PCE_DATA * pPceData;

        RowCount = m_GridRoughRollPDI.GetRowCount();
        itoa(RowCount,strHeading,10);

        pPceData = (PCE_DATA *) DoubleList_GetAt(pRollSchedList->pList,i);

        m_GridRoughRollPDI.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROLL_SCHED_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    =  DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case 0 :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSEQ);
                break;
            case HRS_ROLLSCHED_STRIP_NO :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSTRIP_NO);
                break;
            case HRS_ROLLSCHED_COMSEQ :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCOMSEQ);
                break;
            case HRS_ROLLSCHED_GRADE :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strGRADE);
                break;
            case HRS_ROLLSCHED_SIGN :
                Item.strText.Format(_T("%s"),pPceData->stRollSched.strSIGN);
                break;
            case HRS_ROLLSCHED_C_H :
                Item.strText.Format(_T("%4.2f"),pPceData->stRollSched.fC_H);
                break;
            case HRS_ROLLSCHED_C_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fC_W);
                break;
            case HRS_ROLLSCHED_FSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nFSB);
                break;
            case HRS_ROLLSCHED_R_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fR_H);
                break;
            case HRS_ROLLSCHED_RSB :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nRSB);
                break;
            case HRS_ROLLSCHED_S_H :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_H);
                break;
            case HRS_ROLLSCHED_S_W :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_W);
                break;
            case HRS_ROLLSCHED_S_L :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fS_L);
                break;
            case HRS_ROLLSCHED_WT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWT);
                break;
            case HRS_ROLLSCHED_WE :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fWE);
                break;
            case HRS_ROLLSCHED_FDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fFDT);
                break;
            case HRS_ROLLSCHED_EXT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fEXT);
                break;
            case HRS_ROLLSCHED_RDT :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fRDT);
                break;
            case HRS_ROLLSCHED_CTC :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCTC);
                break;
            case HRS_ROLLSCHED_QUAL :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nQUAL);
                break;
            case HRS_ROLLSCHED_SFC :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSFC);
                break;
            case HRS_ROLLSCHED_STA :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nSTA);
                break;
            case HRS_ROLLSCHED_HTT :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nHTT);
                break;
            case HRS_ROLLSCHED_CP :
                Item.strText.Format(_T("%d"),pPceData->stRollSched.nCP);
                break;
            case HRS_ROLLSCHED_CROWN :
                Item.strText.Format(_T("%8.2f"),pPceData->stRollSched.fCROWN);
                break;
            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }

            m_GridRoughRollPDI.SetItem(&Item);
        }
    }

    m_GridRoughRollPDI.Refresh();

}


void CViewRoughRollSched::OnGridRoughRollPDIClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
    CString itemStr;
    NM_GRIDVIEW* pItem;

    pItem = (NM_GRIDVIEW*) pNotifyStruct;
    if (pItem->iRow < 0)
    {
        return;
    }

    int nRow = pItem->iRow;
    int nCol = pItem->iColumn;
    if( nRow < m_GridRoughRollPDI.GetFixedRowCount() )
    {
        return;
    }

    itemStr = m_GridRoughRollPDI.GetItemText(nRow, 1);

    m_pCurPceData = m_pRollSchedMgr->SearchPceDataByStripNo(itemStr);

    RefreshRoughRollSchedGrid();

    UpdateData(FALSE);
}

void CViewRoughRollSched::RefreshRoughRollSchedGrid()
{
    char strHeading[5]={0};
    int  RowCount;

    int  nCountR1;
    int  nCountR2;

    nCountR1 = m_pCurPceData->stRoughRollStra.emPassMode / 10;
    nCountR2 = m_pCurPceData->stRoughRollStra.emPassMode % 10;

    m_GridRoughRollSchedCalc.DeleteNonFixedRows();

    for (int i = 0; i < nCountR1; i++)
    {
        RowCount = m_GridRoughRollSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollSchedCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_RM_SCHEDCALC_PASS :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].strPass);
                break;
            case HRS_RM_SCHEDCALC_EGAP :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nEGAP);
                break;
            case HRS_RM_SCHEDCALC_ED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fED);
                break;
            case HRS_RM_SCHEDCALC_RGAP :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fRGAP);
                break;
            case HRS_RM_SCHEDCALC_RD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fRD);
                break;
            case HRS_RM_SCHEDCALC_BAR_H :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_H);
                break;
            case HRS_RM_SCHEDCALC_E_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fE_W);
                break;
            case HRS_RM_SCHEDCALC_BAR_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_W);
                break;

            case HRS_RM_SCHEDCALC_BAR_L :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fBAR_L);
                break;
            case HRS_RM_SCHEDCALC_E_RF :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fE_RF);
                break;
            case HRS_RM_SCHEDCALC_R_RF :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nR_RF);
                break;
            case HRS_RM_SCHEDCALC_SPD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fSPD);
                break;
            case HRS_RM_SCHEDCALC_E_TOR :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fE_TOR);
                break;
            case HRS_RM_SCHEDCALC_R_TOR :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nR_TOR);
                break;
            case HRS_RM_SCHEDCALC_Effic :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fEffic);
                break;
            case HRS_RM_SCHEDCALC_R_POW :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].fR_POW);
                break;
            case HRS_RM_SCHEDCALC_DESC :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR1[i].nDESC);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridRoughRollSchedCalc.SetItem(&Item);

        }
    }

    for (int i = 0; i < nCountR2; i++)
    {
        RowCount = m_GridRoughRollSchedCalc.GetRowCount();
        itoa(RowCount,strHeading,10);

        m_GridRoughRollSchedCalc.InsertRow(strHeading);

        for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
        {
            GV_ITEM     Item;

            Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
            Item.row        =  RowCount;
            Item.col        =  j;
            Item.nFormat    = DT_CENTER
                            | DT_VCENTER
                            | DT_SINGLELINE
                            | DT_END_ELLIPSIS;

            switch (j)
            {
            case HRS_RM_SCHEDCALC_PASS :
                //Item.strText.Format(_T("%s"),strHeading);
                Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].strPass);
                break;
            case HRS_RM_SCHEDCALC_EGAP :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nEGAP);
                break;
            case HRS_RM_SCHEDCALC_ED :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fED);
                break;
            case HRS_RM_SCHEDCALC_RGAP :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fRGAP);
                break;
            case HRS_RM_SCHEDCALC_RD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fRD);
                break;
            case HRS_RM_SCHEDCALC_BAR_H :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_H);
                break;
            case HRS_RM_SCHEDCALC_E_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fE_W);
                break;
            case HRS_RM_SCHEDCALC_BAR_W :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_W);
                break;

            case HRS_RM_SCHEDCALC_BAR_L :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fBAR_L);
                break;
            case HRS_RM_SCHEDCALC_E_RF :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fE_RF);
                break;
            case HRS_RM_SCHEDCALC_R_RF :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nR_RF);
                break;
            case HRS_RM_SCHEDCALC_SPD :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fSPD);
                break;
            case HRS_RM_SCHEDCALC_E_TOR :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fE_TOR);
                break;
            case HRS_RM_SCHEDCALC_R_TOR :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nR_TOR);
                break;
            case HRS_RM_SCHEDCALC_Effic :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fEffic);
                break;
            case HRS_RM_SCHEDCALC_R_POW :
                Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].fR_POW);
                break;
            case HRS_RM_SCHEDCALC_DESC :
                Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassR2[i].nDESC);
                break;

            default:
                Item.strText.Format(_T("%d"),0);
                break;
            }
            m_GridRoughRollSchedCalc.SetItem(&Item);

        }
    }

    RowCount = m_GridRoughRollSchedCalc.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRoughRollSchedCalc.InsertRow(strHeading);

    for(int j = 0; j < HRS_ROUGHROLL_SCHEDCALC_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_RM_SCHEDCALC_PASS :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.strPass);
            break;
        case HRS_RM_SCHEDCALC_EGAP :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nEGAP);
            break;
        case HRS_RM_SCHEDCALC_ED :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fED);
            break;
        case HRS_RM_SCHEDCALC_RGAP :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fRGAP);
            break;
        case HRS_RM_SCHEDCALC_RD :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fRD);
            break;
        case HRS_RM_SCHEDCALC_BAR_H :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_H);
            break;
        case HRS_RM_SCHEDCALC_E_W :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fE_W);
            break;
        case HRS_RM_SCHEDCALC_BAR_W :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_W);
            break;

        case HRS_RM_SCHEDCALC_BAR_L :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fBAR_L);
            break;
        case HRS_RM_SCHEDCALC_E_RF :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fE_RF);
            break;
        case HRS_RM_SCHEDCALC_R_RF :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nR_RF);
            break;
        case HRS_RM_SCHEDCALC_SPD :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fSPD);
            break;
        case HRS_RM_SCHEDCALC_E_TOR :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fE_TOR);
            break;
        case HRS_RM_SCHEDCALC_R_TOR :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nR_TOR);
            break;
        case HRS_RM_SCHEDCALC_Effic :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fEffic);
            break;
        case HRS_RM_SCHEDCALC_R_POW :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.fR_POW);
            break;
        case HRS_RM_SCHEDCALC_DESC :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.SchedCalcPassE3.nDESC);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridRoughRollSchedCalc.SetItem(&Item);

    }


    m_GridRoughRollSchedCalc.AutoSizeColumns();
    m_GridRoughRollSchedCalc.Refresh();


    /* 
     * ˢ��basicData���ݱ���
     */
    m_GridRoughRollBasicData.DeleteNonFixedRows();
    RowCount = m_GridRoughRollBasicData.GetRowCount();
    itoa(RowCount,strHeading,10);

    m_GridRoughRollBasicData.InsertRow(strHeading);

    for(int j = 0; j < HRS_ROUGHROLL_BASICDATA_ITEM_NUM; j++)
    {
        GV_ITEM     Item;

        Item.mask       =  GVIF_TEXT | GVIF_FORMAT;
        Item.row        =  RowCount;
        Item.col        =  j;
        Item.nFormat    = DT_CENTER
                        | DT_VCENTER
                        | DT_SINGLELINE
                        | DT_END_ELLIPSIS;

        switch (j)
        {
        case HRS_RM_BASICDATA_STRIP_NO_ :
            //Item.strText.Format(_T("%s"),strHeading);
            Item.strText.Format(_T("%s"),m_pCurPceData->stRollSched.strSTRIP_NO);
            break;
        case HRS_RM_BASICDATA_HSB1 :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.BasicDataPass.nHSB1);
            break;
        case HRS_RM_BASICDATA_HSB2 :
            Item.strText.Format(_T("%d"),m_pCurPceData->stRoughRollSched.BasicDataPass.nHSB2);
            break;
        case HRS_RM_BASICDATA_S_TEMP :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fS_Temp);
            break;
        case HRS_RM_BASICDATA_RDT_ :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDT);
            break;
        case HRS_RM_BASICDATA_RDW :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDW);
            break;
        case HRS_RM_BASICDATA_RDH :
            Item.strText.Format(_T("%6.2f"),m_pCurPceData->stRoughRollSched.BasicDataPass.fRDH);
            break;

        default:
            Item.strText.Format(_T("%d"),0);
            break;
        }
        m_GridRoughRollBasicData.SetItem(&Item);

    }


    m_GridRoughRollBasicData.AutoSizeColumns();
    m_GridRoughRollBasicData.Refresh();

    UpdateData(FALSE);
}

void CViewRoughRollSched::OnBnClickedButRmCalc()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������

    int nRet;

    //��ȡ��ǰ�����ְ��
    CString    strStipNo;
    if ( m_pCurPceData == NULL )
    {
        AfxMessageBox("û��ѡ�����!");
        return;
    }
    strStipNo = m_pCurPceData->stRollSched.strSTRIP_NO;

    //
    // ��ȡGUI�������趨���ݸ�����
    //
    HRS_RM_ALL_DATA    HrsRmAllData;

    nRet = m_pRollSchedMgr->GetPdiForCalc(strStipNo, &HrsRmAllData.PlanData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡPDI���ݴ���!");
        return;
    }
    nRet = m_pRollSchedMgr->GetRmStraDataForCalc(strStipNo, &HrsRmAllData.StrategyData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�ӽ����ȡ�����������ݴ���!");
        return;
    }

    //m_pRollSchedMgr->GetFmStraDataForCalc(strStipNo, &HrsRmAllData.FMStrategyData);

    memcpy( &HrsRmAllData.PlateData.SlabeData, 
            &HrsRmAllData.PlanData.SlabData, 
            sizeof(HRS_SLAB_DATA));
    HrsRmAllData.PlateData.dSlabeEntryTemp = 1600;                                  //����

    // ��ȡ������
    CHRSEquipParaMgr * pModule;

    pModule = (CHRSEquipParaMgr *) 
        CHRSEquipParaMgr_Create(NULL, "MillPara.cfg", NULL, 0);

    nRet = CHRSEquipParaMgr_Init(NULL, pModule);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("��ȡ�豸�������ݴ���!");
        return;
    }

    pModule->GetAllStandPara(&HrsRmAllData.AllStandPara);

    CHRSEquipParaMgr_Destroy(pModule);

    //���ּ������

    //���ο�������
    memcpy(HrsRmAllData.DeformFactor.szSteelGrade, 
        HrsRmAllData.PlanData.SlabData.szSteelGradeName, 
        HRS_MAX_GRADE_LEN);
    HrsRmAllData.DeformFactor.dFactorA = 4.358254;                                         // ��������
    HrsRmAllData.DeformFactor.dFactorB = -1.526256;
    HrsRmAllData.DeformFactor.dFactorC = 0.580705;
    HrsRmAllData.DeformFactor.dFactorD = -0.351633;
    HrsRmAllData.DeformFactor.dFactorN = 0.025699;
    HrsRmAllData.DeformFactor.dReserve1 = 1;
    HrsRmAllData.DeformFactor.dReserve2 = 1;

    //��������
    HRS_RM_ALL_OUT_DATA pAllOutData;
    HRS_RM_SCHED pRMSched;
    nRet = HRS_RML2Calc_CalcAllData(&HrsRmAllData, &pAllOutData);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("������̼������!");
        return;
    }
    nRet = HRS_RML2Calc_BuildSched(&HrsRmAllData, &pAllOutData, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("���ɴ�����̴���!");
        return;
    }

    nRet = m_pRollSchedMgr->SetRmSchedCalcFromCalc(strStipNo, &pRMSched);
    if (nRet == ERR_FAILED)
    {
        AfxMessageBox("�������ô�����̴���!");
        return;
    }

    RefreshRoughRollSchedGrid();

    AfxMessageBox("������̼���ɹ�!");
    return;
}
