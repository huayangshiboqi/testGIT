// ViewRight.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "HRSGui.h"
#include "ViewRight.h"
#include "ViewTitle.h"
#include "ViewRollSchem.h"


// CViewRight

IMPLEMENT_DYNCREATE(CViewRight, CFormView)

CViewRight::CViewRight()
	: CFormView(CViewRight::IDD)
{

}

CViewRight::~CViewRight()
{
}

void CViewRight::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CViewRight, CFormView)
END_MESSAGE_MAP()


// CViewRight ���



#ifdef _DEBUG
void CViewRight::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CViewRight::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG

#if 0

virtual BOOL CViewRight::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
    if (CView::OnCreate(lpcs) == -1)
    {
        return;
    }

    CCreateContext *pContext = (CCreateContext*)lpcs->lpCreateParams;

    if (!m_wndRightSplitter.CreateStatic(this, 2, 1))
    {
        return FALSE;
    }

    CRect rcRightClient;

    ///*
    // *  ��ȡ��ܴ��ڿͻ�����CRect����
     */
    GetClientRect(&rcRightClient);
    ScreenToClient(rcRightClient);

    /*
     *  �������洰���е���ͼ
     */
    if (!m_wndRightSplitter.CreateView(0,
                                       0,
                                       RUNTIME_CLASS(CViewTitle),
                                       CSize(rcRightClient.Width(),
                                       20),
                                       pContext))
    {
        return FALSE;
    }

    if (!m_wndRightSplitter.CreateView(1,
                                       0,
                                       RUNTIME_CLASS(CViewRollSchem),
                                       CSize(rcRightClient.Width(),
                                       rcRightClient.Height() - 20),
                                       pContext))
    {
        return FALSE;
    }

    return TRUE;
}

#endif

// CViewRight ��Ϣ��������
