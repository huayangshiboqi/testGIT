#include "NG.h"
#include "HRS_RMCalc.h"
#include "HRS_RMStraData.h"



void HRS_RMStraData_Init(HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    memset(pRMStraData, 0, sizeof(HRS_ROUGHROLL_STRA_DATA));

    pRMStraData->nCurPassModeIndex = HRS_GetPassModeIndex(HRS_PASS_MODE_3_3);
}


HRS_ROUGHROLL_STRA *HRS_RMStraData_GetCur(
                            HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int nIndex;

    if ( pRMStraData == NULL )
    {
        return NULL;
    }

    if (pRMStraData->nCurPassModeIndex < 0 
        || pRMStraData->nCurPassModeIndex >= HRS_RM_DRAFT_NUM_MAX )
    {
        return NULL;
    }

    nIndex = pRMStraData->nCurPassModeIndex;

    return &(pRMStraData->aAllPassModeStra[nIndex]);
}


HRS_ROUGHROLL_STRA *HRS_RMStraData_GetOrg(
                                HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int nIndex;

    if ( pRMStraData == NULL )
    {
        return NULL;
    }

    if (pRMStraData->nCurPassModeIndex < 0 
        || pRMStraData->nCurPassModeIndex >= HRS_RM_DRAFT_NUM_MAX )
    {
        return NULL;
    }

    nIndex = pRMStraData->nCurPassModeIndex;

    return &(pRMStraData->aOrgStra[nIndex]);
}


int HRS_RMStraData_GetOrgStraData(HRS_RM_ALL_DATA *pAllData,
                                  HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    HRS_TABLE_RM_DRAFTRATIO   *pRmDraftTab;
    HRS_STEEL_LEVEL           *pSteelLevel;
    HRS_TABLE_RM_DRAFTRATIO   aRmDraftRatioTab[HRS_RM_DRAFT_NUM_MAX];

    int i;
    int nRet;

    // ��ȡ��������
    nRet = HRS_RML2Calc_GetSteelData(pAllData);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    if (pRMStraData->nOrgGetFlag != 0)
    {
        // �Ѿ���ȡ����ԭʼ���ݣ����ٻ�ȡ
        return ERR_SUCCESS;
    }
#if 0
    memset(pRMStraData->aOrgStra, 
           0, 
           sizeof(HRS_ROUGHROLL_STRA) * HRS_RM_DRAFT_NUM_MAX);
#endif
    memset(aRmDraftRatioTab, 
           0, 
           sizeof(HRS_TABLE_RM_DRAFTRATIO) * HRS_RM_DRAFT_NUM_MAX);

    //
    // ��ѯѹ���ʱ�����ȡ������ѹ��������
    //
    pSteelLevel = &(pAllData->SteelLevel);

    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        aRmDraftRatioTab[i].nSteelGradeCode = pSteelLevel->nSteelGradeCode;;
        aRmDraftRatioTab[i].nSlabGaugeLevel = pSteelLevel->nSlabGaugeLevel;
        aRmDraftRatioTab[i].nSlabWidthLevel = pSteelLevel->nSlabWidthLevel;
        aRmDraftRatioTab[i].nBarGaugeLevel  = pSteelLevel->nTargetGaugeLevel;
        aRmDraftRatioTab[i].nRMWidthLevel   = pSteelLevel->nRMWidthLevel;
    }

    nRet = HRS_RmDraftRatioTab_SearchMulti(aRmDraftRatioTab, 
                                           HRS_RM_DRAFT_NUM_MAX, 
                                           pAllData->szOutErr);

    if ( nRet == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    if (pRMStraData->nCurPassModeIndex == 0 )
    {
        pRMStraData->nCurPassModeIndex = HRS_GetPassModeIndex((HRS_PASS_MODE_EM)
            aRmDraftRatioTab[0].nPassMode);
    }

    int nIndex;

    // ��ѹ���ʱ���PassMode������к�
    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {

        if ( aRmDraftRatioTab[i].nPassMode == 0 )
        {
            continue;
        }

        nIndex = HRS_GetPassModeIndex((HRS_PASS_MODE_EM)aRmDraftRatioTab[i].nPassMode);

        pRmDraftTab = &(pRMStraData->aOrgStra[nIndex].stDraftRatio);

        memset(pRmDraftTab, 0, sizeof(HRS_TABLE_RM_DRAFTRATIO));

        memcpy(pRmDraftTab, &(aRmDraftRatioTab[i]), 
                 sizeof(HRS_TABLE_RM_DRAFTRATIO));

        pRMStraData->aOrgStra[nIndex].emPassMode = (HRS_PASS_MODE_EM)pRmDraftTab->nPassMode;

        pRMStraData->aOrgStra[nIndex].stRoughRollStraR1[0].fDraft 
             = pRmDraftTab->dLoadValueR11;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR1[1].fDraft 
            = pRmDraftTab->dLoadValueR12;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR1[2].fDraft 
            = pRmDraftTab->dLoadValueR13;

        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[0].fDraft 
            = pRmDraftTab->dLoadValueR21;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[1].fDraft 
            = pRmDraftTab->dLoadValueR22;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[2].fDraft 
            = pRmDraftTab->dLoadValueR23;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[3].fDraft 
            = pRmDraftTab->dLoadValueR24;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[4].fDraft 
            = pRmDraftTab->dLoadValueR25;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[5].fDraft 
            = pRmDraftTab->dLoadValueR26;
        pRMStraData->aOrgStra[nIndex].stRoughRollStraR2[6].fDraft 
            = pRmDraftTab->dLoadValueR27;

#if 0
        pRMStraData->aOrgStra[nIndex].fRm_Exit_Thick = 
            pAllData->PlanData.dTransferBarGauge;
        pRMStraData->aOrgStra[nIndex].fRMExitTemp    = 
            pAllData->PlanData.dDischargeTemp;

        pRMStraData->aAllPassModeStra[nIndex].fRm_Exit_Thick = 
            pAllData->PlanData.dTransferBarGauge;
        pRMStraData->aAllPassModeStra[nIndex].fRMExitTemp    = 
            pAllData->PlanData.dDischargeTemp;
#endif
    }

    HRS_RMStraData_CalcAllOrgGauge(pAllData, pRMStraData);

    pRMStraData->nOrgGetFlag = 1;   // �Ѿ���ȡ����ԭʼ���ݣ��´β��ٻ�ȡ

    return ERR_SUCCESS;
}


int HRS_RMStraData_CalcOnePassModeOrgGauge(HRS_RM_ALL_DATA *pAllData,
                                           HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                           int nPassModeIndex)
{
    HRS_RM_ALL_PASS AllPass;
    HRS_PASS        *pRMPass;
    HRS_TABLE_RM_DRAFTRATIO *pRmDraftTab;
    HRS_PASS_MODE_EM  nPassMode;
    int               i;
    int               nRet;

    // 
    // ׼��������ʹ�õĲ���
    //

    HRS_ROUGHROLL_STRA  *pRmStra;
    HRS_ROUGHROLL_STRA *pOrgRmStra;

    i = nPassModeIndex;

    pRmStra = &(pRMStraData->aAllPassModeStra[i]);
    pOrgRmStra = &(pRMStraData->aOrgStra[i]);


    //////////////////////////////////////////////////////////////////////////
    // ������1�ĳ�Ա��ֵ
    // 
    pRMPass       = &(AllPass.Rm1stPass);

    nPassMode = pRMStraData->aOrgStra[i].emPassMode;
    pRmDraftTab = &(pRMStraData->aOrgStra[i].stDraftRatio);

    HRS_ROUGHROLL_STRA_PASS  *pStraPass;

    pStraPass = pOrgRmStra->stRoughRollStraR1;

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStraPass[0].fDraft;
    pRMPass->adPassDraftRatio[1] = pStraPass[1].fDraft;
    pRMPass->adPassDraftRatio[2] = pStraPass[2].fDraft;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pAllData->PlanData.SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pAllData->StrategyData.dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM1;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode / 10;

    //////////////////////////////////////////////////////////////////////////
    // �ٸ�����2�ĳ�Ա��ֵ
    // 
    pRMPass       = &(AllPass.Rm2ndPass);

    // ��ѹ�������鸳ֵ
    nPassMode = pRMStraData->aOrgStra[i].emPassMode;

    pStraPass = pRMStraData->aOrgStra[i].stRoughRollStraR2;


    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStraPass[0].fDraft;
    pRMPass->adPassDraftRatio[1] = pStraPass[1].fDraft;
    pRMPass->adPassDraftRatio[2] = pStraPass[2].fDraft;
    pRMPass->adPassDraftRatio[3] = pStraPass[3].fDraft;
    pRMPass->adPassDraftRatio[4] = pStraPass[4].fDraft;
    pRMPass->adPassDraftRatio[5] = pStraPass[5].fDraft;
    pRMPass->adPassDraftRatio[6] = pStraPass[6].fDraft;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pAllData->PlanData.SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pAllData->StrategyData.dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM2;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode % 10;

    // ������ƫ��
    AllPass.dMaxDeviation = HRS_MAX_CALC_DEVIATION;

    HRS_RM_ALL_DELIVERY_GAUGE   AllDeliveryGauge;

    memset(&AllDeliveryGauge, 0, sizeof(HRS_RM_ALL_DELIVERY_GAUGE));

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, &AllDeliveryGauge,
        pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_DELIVERY_GAUGE  *pDeliveryGauge;



    int k;

    double dSlabGauge = pAllData->PlanData.SlabData.dSlabGauge;

    int nR1stNum = AllDeliveryGauge.Rm1stDeliveryGauge.nTotalPassNum;
    int nR2ndNum = AllDeliveryGauge.Rm2ndDeliveryGauge.nTotalPassNum;

    //���ݸ�ֵ
    // ����R1�ĳ��ں�Ⱥ�ѹ����
    pDeliveryGauge = &(AllDeliveryGauge.Rm1stDeliveryGauge);
    for ( i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        pOrgRmStra->stRoughRollStraR1[i].fThick_Exit = 
            pDeliveryGauge->adDeliveryGauge[i];
    }

    for ( k = 0; k < nR1stNum; k++ )
    {
        // ����ѹ����
        if ( k == 0 )
        {
            pOrgRmStra->stRoughRollStraR1[k].fDraftValue = dSlabGauge;
        }
        else
        {
            pOrgRmStra->stRoughRollStraR1[k].fDraftValue = 
                pOrgRmStra->stRoughRollStraR1[k-1].fThick_Exit;
        }

        pOrgRmStra->stRoughRollStraR1[k].fDraftValue -=
                pOrgRmStra->stRoughRollStraR1[k].fThick_Exit;
    }

    // ����R2�ĳ��ں�Ⱥ�ѹ����
    double dEntryGauge;

    if (nR1stNum <= 0)
    {
        dEntryGauge = dSlabGauge;
    }
    else
    {
        dEntryGauge = pDeliveryGauge->adDeliveryGauge[nR1stNum-1];
    }

    pDeliveryGauge = &(AllDeliveryGauge.Rm2ndDeliveryGauge);

    for ( i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        pOrgRmStra->stRoughRollStraR2[i].fThick_Exit = 
            pDeliveryGauge->adDeliveryGauge[i];
    }

    for ( k = 0; k < nR2ndNum; k++ )
    {
        if ( k == 0 )
        {
            pOrgRmStra->stRoughRollStraR2[k].fDraftValue = dEntryGauge;
        }
        else
        {
            pOrgRmStra->stRoughRollStraR2[k].fDraftValue = 
                pOrgRmStra->stRoughRollStraR2[k-1].fThick_Exit;
        }

        pOrgRmStra->stRoughRollStraR2[k].fDraftValue -=
            pOrgRmStra->stRoughRollStraR2[k].fThick_Exit;
    }

    pRmStra->emPassMode = nPassMode;

    return ERR_SUCCESS;
}


int HRS_RMStraData_CalcAllOrgGauge(HRS_RM_ALL_DATA *pAllData,
                                   HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int i;
    int nIndex;
    int nRet;
    HRS_PASS_MODE_EM  emPassMode;

    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        emPassMode = pRMStraData->aOrgStra[i].emPassMode;
        if ( emPassMode == 0 )
        {
            continue;
        }

        nIndex = HRS_GetPassModeIndex(emPassMode);

        nRet = HRS_RMStraData_CalcOnePassModeOrgGauge(pAllData, 
            pRMStraData, nIndex);
        if ( nRet == ERR_FAILED )
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}


int HRS_RMStraData_CalcOnePassModeGauge(HRS_RM_ALL_DATA *pAllData,
                             HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                             int nPassModeIndex)
{
    HRS_RM_ALL_PASS AllPass;
    HRS_PASS        *pRMPass;
    HRS_TABLE_RM_DRAFTRATIO *pRmDraftTab;
    HRS_PASS_MODE_EM  nPassMode;
    int               i;
    int               nRet;

    // 
    // ׼��������ʹ�õĲ���
    //

    HRS_ROUGHROLL_STRA  *pRmStra;
    HRS_ROUGHROLL_STRA *pOrgRmStra;

    i = nPassModeIndex;

    pRmStra = &(pRMStraData->aAllPassModeStra[i]);
    pOrgRmStra = &(pRMStraData->aOrgStra[i]);


    //////////////////////////////////////////////////////////////////////////
    // ������1�ĳ�Ա��ֵ
    // 
    pRMPass       = &(AllPass.Rm1stPass);

    nPassMode = pRMStraData->aOrgStra[i].emPassMode;
    pRmDraftTab = &(pRMStraData->aOrgStra[i].stDraftRatio);

    HRS_ROUGHROLL_STRA_PASS  *pStraPass;

    pStraPass = pOrgRmStra->stRoughRollStraR1;

    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStraPass[0].fDraft + pStraPass[0].fDraftCor;
    pRMPass->adPassDraftRatio[1] = pStraPass[1].fDraft + pStraPass[1].fDraftCor;
    pRMPass->adPassDraftRatio[2] = pStraPass[2].fDraft + pStraPass[2].fDraftCor;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pAllData->PlanData.SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pAllData->StrategyData.dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM1;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode / 10;

    //////////////////////////////////////////////////////////////////////////
    // �ٸ�����2�ĳ�Ա��ֵ
    // 
    pRMPass       = &(AllPass.Rm2ndPass);

    // ��ѹ�������鸳ֵ
    nPassMode = pRMStraData->aOrgStra[i].emPassMode;

    pStraPass = pRMStraData->aOrgStra[i].stRoughRollStraR2;


    // ��ѹ�������鸳ֵ
    pRMPass->adPassDraftRatio[0] = pStraPass[0].fDraft + pStraPass[0].fDraftCor;
    pRMPass->adPassDraftRatio[1] = pStraPass[1].fDraft + pStraPass[1].fDraftCor;
    pRMPass->adPassDraftRatio[2] = pStraPass[2].fDraft + pStraPass[2].fDraftCor;
    pRMPass->adPassDraftRatio[3] = pStraPass[3].fDraft + pStraPass[3].fDraftCor;
    pRMPass->adPassDraftRatio[4] = pStraPass[4].fDraft + pStraPass[4].fDraftCor;
    pRMPass->adPassDraftRatio[5] = pStraPass[5].fDraft + pStraPass[5].fDraftCor;
    pRMPass->adPassDraftRatio[6] = pStraPass[6].fDraft + pStraPass[6].fDraftCor;

    //
    // ��������Ա��ֵ
    //
    pRMPass->dSlabGauge        = pAllData->PlanData.SlabData.dSlabGauge;
    pRMPass->dTransferBarThick = pAllData->StrategyData.dTransferBarThick;
    pRMPass->nStandNo          = HRS_STAND_NO_RM2;
    pRMPass->nPassMode         = nPassMode;
    pRMPass->nTotalPassNum     = nPassMode % 10;

    // ������ƫ��
    AllPass.dMaxDeviation = HRS_MAX_CALC_DEVIATION;

    HRS_RM_ALL_DELIVERY_GAUGE   AllDeliveryGauge;

    memset(&AllDeliveryGauge, 0, sizeof(HRS_RM_ALL_DELIVERY_GAUGE));

    nRet = HRS_RML2Calc_CalcGauge(&AllPass, &AllDeliveryGauge,
                                  pAllData->szOutErr);
    if (nRet == ERR_FAILED)
    {
        return ERR_FAILED;
    }

    HRS_DELIVERY_GAUGE  *pDeliveryGauge;



    int k;
    double dSlabGauge = pAllData->PlanData.SlabData.dSlabGauge;

    int nR1stNum = AllDeliveryGauge.Rm1stDeliveryGauge.nTotalPassNum;
    int nR2ndNum = AllDeliveryGauge.Rm2ndDeliveryGauge.nTotalPassNum;

    //���ݸ�ֵ
    // ����R1�ĳ��ں�Ⱥ�ѹ����
#if 0
    memset(pRmStra->stRoughRollStraR1, 
           0, 
           sizeof(HRS_ROUGHROLL_STRA_PASS) * HRS_ROUGHROLL_R1_PASS_MAX);
#endif
    pDeliveryGauge = &(AllDeliveryGauge.Rm1stDeliveryGauge);

    for ( k = 0; k < HRS_ROUGHROLL_R1_PASS_MAX; k++ )
    {
        pRmStra->stRoughRollStraR1[k].fThick_Exit = 
            pDeliveryGauge->adDeliveryGauge[k];

        pRmStra->stRoughRollStraR1[k].fDraft = 
            AllPass.Rm1stPass.adPassDraftRatio[k];

        pRmStra->stRoughRollStraR1[k].fDraftCor = 
            pOrgRmStra->stRoughRollStraR1[k].fDraftCor;

        pRmStra->stRoughRollStraR1[k].fWidth_Cor = 
            pOrgRmStra->stRoughRollStraR1[k].fWidth_Cor;
    }

    for ( k = 0; k < nR1stNum; k++ )
    {
        // ����ѹ����
        if ( k == 0 )
        {
            pRmStra->stRoughRollStraR1[k].fDraftValue = dSlabGauge;
        }
        else
        {
            pRmStra->stRoughRollStraR1[k].fDraftValue = 
                pRmStra->stRoughRollStraR1[k-1].fThick_Exit;
        }

        pRmStra->stRoughRollStraR1[k].fDraftValue -=
            pRmStra->stRoughRollStraR1[k].fThick_Exit;

        // ����ѹ����ƫ��
        pRmStra->stRoughRollStraR1[k].fDeltaDraftValue =
                pRmStra->stRoughRollStraR1[k].fDraftValue;

        pRmStra->stRoughRollStraR1[k].fDeltaDraftValue -=
            pOrgRmStra->stRoughRollStraR1[k].fDraftValue;
    }

    // ����R2�ĳ��ں�Ⱥ�ѹ����
    double dEntryGauge;

    if (nR1stNum <= 0)
    {
        dEntryGauge = dSlabGauge;
    }
    else
    {
        dEntryGauge = pDeliveryGauge->adDeliveryGauge[nR1stNum-1];
    }

#if 0
    memset(pRmStra->stRoughRollStraR2, 
           0, 
           sizeof(HRS_ROUGHROLL_STRA_PASS) * HRS_ROUGHROLL_R2_PASS_MAX);
#endif

    pDeliveryGauge = &(AllDeliveryGauge.Rm2ndDeliveryGauge);
    for ( k = 0; k < HRS_ROUGHROLL_R2_PASS_MAX; k++ )
    {
        pRmStra->stRoughRollStraR2[k].fThick_Exit = 
            pDeliveryGauge->adDeliveryGauge[k];

        pRmStra->stRoughRollStraR2[k].fDraft = 
            AllPass.Rm2ndPass.adPassDraftRatio[k];

        pRmStra->stRoughRollStraR2[k].fDraftCor = 
            pOrgRmStra->stRoughRollStraR2[k].fDraftCor;

        pRmStra->stRoughRollStraR2[k].fWidth_Cor = 
            pOrgRmStra->stRoughRollStraR2[k].fWidth_Cor;
    }

    for ( k = 0; k < nR2ndNum; k++ )
    {
        // ����ѹ����
        if ( k == 0 )
        {
            pRmStra->stRoughRollStraR2[k].fDraftValue = dEntryGauge;
        }
        else
        {
            pRmStra->stRoughRollStraR2[k].fDraftValue = 
                pRmStra->stRoughRollStraR2[k-1].fThick_Exit;
        }

        pRmStra->stRoughRollStraR2[k].fDraftValue -=
            pRmStra->stRoughRollStraR2[k].fThick_Exit;

        // ����ѹ����ƫ��
        pRmStra->stRoughRollStraR2[k].fDeltaDraftValue =
            pRmStra->stRoughRollStraR2[k].fDraftValue;

        pRmStra->stRoughRollStraR2[k].fDeltaDraftValue -=
            pOrgRmStra->stRoughRollStraR2[k].fDraftValue;
    }

    pRmStra->emPassMode = nPassMode;


    double dDeliveryWidth;

    dDeliveryWidth = pAllData->PlanData.SlabData.dSlabWidth;
    if ( nR1stNum > 0 )
    {
        pRmStra->stRoughRollStraR1[0].fWidth =
            pOrgRmStra->stRoughRollStraR1[0].fWidth;
        pRmStra->stRoughRollStraR1[0].fWidth +=
            pOrgRmStra->stRoughRollStraR1[0].fWidth_Cor;
    }
    // �������
    for ( k = 1; k < nR1stNum; k++ )
    {
        pRmStra->stRoughRollStraR1[k].fWidth = 
            pRmStra->stRoughRollStraR1[k-1].fWidth;
        pRmStra->stRoughRollStraR1[k].fWidth +=
            pOrgRmStra->stRoughRollStraR1[k].fWidth_Cor;
    }


    if (nR1stNum > 0)
    {
        dDeliveryWidth = pRmStra->stRoughRollStraR1[nR1stNum-1].fWidth;
    }

    if ( nR2ndNum > 0)
    {
        pRmStra->stRoughRollStraR2[0].fWidth = dDeliveryWidth;
        pRmStra->stRoughRollStraR2[0].fWidth +=
            pOrgRmStra->stRoughRollStraR2[0].fWidth_Cor;
    }

    // �������
    for ( k = 1; k < nR2ndNum; k++ )
    {
        pRmStra->stRoughRollStraR2[k].fWidth = 
            pRmStra->stRoughRollStraR2[k-1].fWidth;
        pRmStra->stRoughRollStraR2[k].fWidth +=
            pOrgRmStra->stRoughRollStraR2[k].fWidth_Cor;
    }

    return ERR_SUCCESS;
}


int HRS_RMStraData_CalcAllGauge(HRS_RM_ALL_DATA *pAllData,
                          HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int i;
    int nIndex;
    int nRet;
    HRS_PASS_MODE_EM  emPassMode;

    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        emPassMode = pRMStraData->aOrgStra[i].emPassMode;
        if ( emPassMode == 0 )
        {
            continue;
        }

        nIndex = HRS_GetPassModeIndex(emPassMode);

        nRet = HRS_RMStraData_CalcOnePassModeGauge(pAllData, 
                                                   pRMStraData, nIndex);
        if ( nRet == ERR_FAILED )
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}


int HRS_RMStraData_CalcOnePassModeSpeed(HRS_RM_ALL_DATA *pAllData,
                             HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                             int nPassModeIndex)
{
    HRS_RM_ALL_ENTRY_PARA   AllEntry;
    HRS_RM_ALL_SPEED        AllSpeed;
    
    int nRet;
    int i;

    if (   pAllData    == NULL 
        || pRMStraData == NULL  )
    {
        return ERR_FAILED;
    }

    memset(&AllSpeed, 0, sizeof(HRS_RM_ALL_SPEED));

    //
    // ���ڼ����ٶȺ�����Ҫ�õ�pAllData->StrategyData.nPassMode ���η���ģʽ
    //
    HRS_PASS_MODE_EM emOldPassMode = pAllData->StrategyData.nPassMode;

    HRS_PASS_MODE_EM emPassMode = HRS_GetPassModeByIndex(nPassModeIndex);

    pAllData->StrategyData.nPassMode = emPassMode;

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, &AllSpeed);
    if ( nRet == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    // �ָ��ϵĵ���ģʽֵ
    pAllData->StrategyData.nPassMode = emOldPassMode;

    HRS_ROUGHROLL_STRA  *pRmStra;
    HRS_ROUGHROLL_STRA  *pOrgStra;

    pRmStra = &(pRMStraData->aAllPassModeStra[nPassModeIndex]);
    pOrgStra = &(pRMStraData->aOrgStra[nPassModeIndex]);


    //���ݸ�ֵ
    for (i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
       /* pRmStra->stRoughRollStraR1[i].fSpeed = 
            AllSpeed.Rm1stPassSpeed.adSpeed[i];*/

        pRmStra->stRoughRollStraR1[i].fSpeed 
            = pOrgStra->stRoughRollStraR1[i].fSpeed;
        pRmStra->stRoughRollStraR1[i].fSpeed_Cor
            = pOrgStra->stRoughRollStraR1[i].fSpeed_Cor;
    }

    for (i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        /*pRmStra->stRoughRollStraR2[i].fSpeed = 
            AllSpeed.Rm2ndPassSpeed.adSpeed[i];*/

        pRmStra->stRoughRollStraR2[i].fSpeed 
            = pOrgStra->stRoughRollStraR2[i].fSpeed;
        pRmStra->stRoughRollStraR2[i].fSpeed_Cor
            = pOrgStra->stRoughRollStraR2[i].fSpeed_Cor;
    }

    return ERR_SUCCESS; 
}


int HRS_RMStraData_CalcAllSpeed(HRS_RM_ALL_DATA *pAllData,
                                HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int i;
    int nIndex;
    int nRet;
    HRS_PASS_MODE_EM  emPassMode;

    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        emPassMode = pRMStraData->aOrgStra[i].emPassMode;
        if ( emPassMode == 0 )
        {
            continue;
        }

        nIndex = HRS_GetPassModeIndex(emPassMode);

        nRet = HRS_RMStraData_CalcOnePassModeSpeed(pAllData, 
            pRMStraData, nIndex);
        if ( nRet == ERR_FAILED )
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}


int HRS_RMStraData_InitOnePassModeSpeed(HRS_RM_ALL_DATA *pAllData,
                                        HRS_ROUGHROLL_STRA_DATA *pRMStraData,
                                        int nPassModeIndex)
{
    HRS_RM_ALL_ENTRY_PARA   AllEntry;
    HRS_RM_ALL_SPEED        AllSpeed;
    
    int nRet;
    int i;

    if (   pAllData    == NULL 
        || pRMStraData == NULL  )
    {
        return ERR_FAILED;
    }

    memset(&AllSpeed, 0, sizeof(HRS_RM_ALL_SPEED));

    //
    // ���ڼ����ٶȺ�����Ҫ�õ�pAllData->StrategyData.nPassMode ���η���ģʽ
    //
    HRS_PASS_MODE_EM emOldPassMode = pAllData->StrategyData.nPassMode;

    HRS_PASS_MODE_EM emPassMode = HRS_GetPassModeByIndex(nPassModeIndex);

    pAllData->StrategyData.nPassMode = emPassMode;

    nRet = HRS_RML2Calc_CalcSpeed(pAllData, &AllEntry, &AllSpeed);
    if ( nRet == ERR_FAILED )
    {
        return ERR_FAILED;
    }

    // �ָ��ϵĵ���ģʽֵ
    pAllData->StrategyData.nPassMode = emOldPassMode;

    HRS_ROUGHROLL_STRA  *pRmStra;
    HRS_ROUGHROLL_STRA  *pOrgStra;

    pRmStra = &(pRMStraData->aAllPassModeStra[nPassModeIndex]);
    pOrgStra = &(pRMStraData->aOrgStra[nPassModeIndex]);


    //���ݸ�ֵ
    for (i = 0; i < HRS_ROUGHROLL_R1_PASS_MAX; i++ )
    {
        pOrgStra->stRoughRollStraR1[i].fSpeed = 
            AllSpeed.Rm1stPassSpeed.adSpeed[i] 
           - pAllData->StrategyData.rm_adjust_R1[i].dSpeedAdjust;

       pRmStra->stRoughRollStraR1[i].fSpeed = 
           pOrgStra->stRoughRollStraR1[i].fSpeed;

        pRmStra->stRoughRollStraR1[i].fSpeed_Cor
            = pOrgStra->stRoughRollStraR1[i].fSpeed_Cor;
    }

    for (i = 0; i < HRS_ROUGHROLL_R2_PASS_MAX; i++ )
    {
        pOrgStra->stRoughRollStraR2[i].fSpeed 
            = AllSpeed.Rm2ndPassSpeed.adSpeed[i]
         - pAllData->StrategyData.rm_adjust_R2[i].dSpeedAdjust;;

         pRmStra->stRoughRollStraR2[i].fSpeed = 
             pOrgStra->stRoughRollStraR2[i].fSpeed ;

        pRmStra->stRoughRollStraR2[i].fSpeed_Cor
            = pOrgStra->stRoughRollStraR2[i].fSpeed_Cor;
    }

    return ERR_SUCCESS; 
}

int HRS_RMStraData_InitAllSpeed(HRS_RM_ALL_DATA *pAllData,
                                HRS_ROUGHROLL_STRA_DATA *pRMStraData)
{
    int i;
    int nIndex;
    int nRet;
    HRS_PASS_MODE_EM  emPassMode;

    for (i = 0; i < HRS_RM_DRAFT_NUM_MAX; i++)
    {
        emPassMode = pRMStraData->aOrgStra[i].emPassMode;
        if ( emPassMode == 0 )
        {
            continue;
        }

        nIndex = HRS_GetPassModeIndex(emPassMode);

        nRet = HRS_RMStraData_InitOnePassModeSpeed(pAllData, 
            pRMStraData, nIndex);
        if ( nRet == ERR_FAILED )
        {
            return ERR_FAILED;
        }
    }

    return ERR_SUCCESS;
}